# Snapshot: Context 8784:68696 · Selection 8815:1946

- documentType: snapshot
- contextId: ctx:8784:68696
- snapshotId: snap:8784:68696:8815:1946
- pageId: 8784:68696
- pageName: 🔒 Пустой экран в подключенных ДС
- selectionId: 8815:1946
- selectionName: [D](1024+) Content
- exportedAt: 2026-03-24T09:25:23.132Z
- platforms: desktop
- pageType: form
- itemsCount: 4
- figmaSelectionUrl: https://www.figma.com/design/r9RBGdR6KCwYlWwcxYaYlo/W--%D0%9F%D1%80%D0%BE%D1%86%D0%B5%D0%BD%D1%82-%D0%BD%D0%B0-%D0%BE%D1%81%D1%82%D0%B0%D1%82%D0%BE%D0%BA?node-id=8815-1946

## Fragment 1

- fragmentId: frag:8784:68696:8815:1946:1
- contextId: ctx:8784:68696
- snapshotId: snap:8784:68696:8815:1946
- orderIndex: 1
- location: form
- contentType: page_title
- typographyRole: header_xl
- layerName: Title
- componentName: View=xLarge, Skeleton=False
- componentKey: 3bfd179dc3b4c996f58db4cbcd26687a356fb3b7
- path: [D](1024+) Content > [D] TitleView > MainContent > Heading > Title
- shortPath: TitleView > Title


Проценты на остаток

## Fragment 2

- fragmentId: frag:8784:68696:8815:1946:2
- contextId: ctx:8784:68696
- snapshotId: snap:8784:68696:8815:1946
- orderIndex: 2
- location: form
- contentType: section_title
- typographyRole: header_m
- layerName: Title
- componentName: [D] SystemMessageLarge
- componentKey: 2d5fd9a8fd9cf6f63eaa20cb1db7cf1a41095595
- path: [D](1024+) Content > [D] CorporateSystemMessage > ErrorView > Content > Content > Title > Title
- shortPath: CorporateSystemMessage > ErrorView > Title > Title


Пока нет предложений

## Fragment 3

- fragmentId: frag:8784:68696:8815:1946:3
- contextId: ctx:8784:68696
- snapshotId: snap:8784:68696:8815:1946
- orderIndex: 3
- location: form
- contentType: subtitle
- typographyRole: unknown
- layerName: Subtitle
- componentName: [D] SystemMessageLarge
- componentKey: 2d5fd9a8fd9cf6f63eaa20cb1db7cf1a41095595
- path: [D](1024+) Content > [D] CorporateSystemMessage > ErrorView > Content > Content > Subtitle > Subtitle
- shortPath: CorporateSystemMessage > ErrorView > Subtitle > Subtitle


Чтобы получать доход, откройте накопительный счёт

## Fragment 4

- fragmentId: frag:8784:68696:8815:1946:4
- contextId: ctx:8784:68696
- snapshotId: snap:8784:68696:8815:1946
- orderIndex: 4
- location: form
- contentType: button_label
- typographyRole: unknown
- layerName: Label
- componentName: View=Secondary, Size=48, Shape=Rectangular, SingleIcon=False, DisabledState=False
- componentKey: a0cb87ed091553d85c6b02f129e8553db481a6b9
- path: [D](1024+) Content > [D] CorporateSystemMessage > ErrorView > Content > Buttons > ButtonsGroup > Button > Text > Label
- shortPath: ButtonsGroup > Button > Text > Label


К накопительному счёту