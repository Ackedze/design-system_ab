"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/vendor/sha256.ts
var sha256_exports = {};
__export(sha256_exports, {
  sha256Hex: () => sha256Hex
});
function utf8Bytes(input) {
  const bytes = new Uint8Array(input.length * 3);
  let length = 0;
  for (let index = 0; index < input.length; index += 1) {
    let codePoint = input.charCodeAt(index);
    if (codePoint >= 55296 && codePoint <= 56319) {
      const low = input.charCodeAt(index + 1);
      if (low >= 56320 && low <= 57343) {
        codePoint = 65536 + (codePoint - 55296 << 10) + (low - 56320);
        index += 1;
      } else codePoint = 65533;
    } else if (codePoint >= 56320 && codePoint <= 57343) codePoint = 65533;
    if (codePoint <= 127) {
      bytes[length++] = codePoint;
    } else if (codePoint <= 2047) {
      bytes[length++] = 192 | codePoint >>> 6;
      bytes[length++] = 128 | codePoint & 63;
    } else if (codePoint <= 65535) {
      bytes[length++] = 224 | codePoint >>> 12;
      bytes[length++] = 128 | codePoint >>> 6 & 63;
      bytes[length++] = 128 | codePoint & 63;
    } else {
      bytes[length++] = 240 | codePoint >>> 18;
      bytes[length++] = 128 | codePoint >>> 12 & 63;
      bytes[length++] = 128 | codePoint >>> 6 & 63;
      bytes[length++] = 128 | codePoint & 63;
    }
  }
  return bytes.subarray(0, length);
}
function sha256Hex(input) {
  const rightRotate = (value, amount) => value >>> amount | value << 32 - amount;
  const maxWord = Math.pow(2, 32);
  const words = [];
  const hash2 = [];
  const constants = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate += 1) {
    if (isComposite[candidate]) continue;
    for (let multiple = candidate * candidate; multiple < 313; multiple += candidate) {
      isComposite[multiple] = true;
    }
    hash2[primeCounter] = Math.pow(candidate, 0.5) * maxWord | 0;
    constants[primeCounter] = Math.pow(candidate, 1 / 3) * maxWord | 0;
    primeCounter += 1;
  }
  const bytes = utf8Bytes(input);
  const bitLength = bytes.length * 8;
  const paddedLength = bytes.length + 9 + 63 >> 6 << 6;
  const padded = new Uint8Array(paddedLength);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / maxWord), false);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const w15 = words[index - 15];
      const w2 = words[index - 2];
      const s0 = rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ w15 >>> 3;
      const s1 = rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ w2 >>> 10;
      words[index] = words[index - 16] + s0 + words[index - 7] + s1 | 0;
    }
    const working = hash2.slice(0, 8);
    for (let index = 0; index < 64; index += 1) {
      const s1 = rightRotate(working[4], 6) ^ rightRotate(working[4], 11) ^ rightRotate(working[4], 25);
      const choice = working[4] & working[5] ^ ~working[4] & working[6];
      const temp1 = working[7] + s1 + choice + constants[index] + words[index] | 0;
      const s0 = rightRotate(working[0], 2) ^ rightRotate(working[0], 13) ^ rightRotate(working[0], 22);
      const majority = working[0] & working[1] ^ working[0] & working[2] ^ working[1] & working[2];
      const temp2 = s0 + majority | 0;
      working.unshift(temp1 + temp2 | 0);
      working[4] = working[4] + temp1 | 0;
      working.pop();
    }
    for (let index = 0; index < 8; index += 1) {
      hash2[index] = hash2[index] + working[index] | 0;
    }
  }
  return hash2.slice(0, 8).map((value) => (value >>> 0).toString(16).padStart(8, "0")).join("");
}
var init_sha256 = __esm({
  "src/vendor/sha256.ts"() {
    "use strict";
  }
});

// ../../services/apollo-proxy/schemas/apollo-predicate-capabilities.v1.json
var require_apollo_predicate_capabilities_v1 = __commonJS({
  "../../services/apollo-proxy/schemas/apollo-predicate-capabilities.v1.json"(exports2, module2) {
    module2.exports = {
      schemaVersion: "apollo.predicate-capabilities.v1",
      documentType: "predicate-capability-registry",
      status: "mvp",
      semantics: {
        truthValues: ["true", "false", "unknown"],
        applicabilityValues: ["applicable", "not-applicable", "unknown"],
        unknownPolicy: "fail-closed",
        hiddenNodePolicy: "excluded-from-audit",
        orderingPolicy: "document-order-then-stable-id",
        verdictOwner: "predicate-engine",
        agentMayChangeVerdict: false
      },
      selectors: [
        "selection-root",
        "self",
        "direct-children",
        "descendants",
        "self-and-descendants",
        "parent",
        "ancestors",
        "siblings",
        "page-descendants",
        "where"
      ],
      factFamilies: [
        "node.identity",
        "node.type",
        "node.order",
        "node.bounds",
        "component.identity",
        "component.lifecycle",
        "component.properties",
        "baseline.effective",
        "override.actual",
        "layout.properties",
        "paint.state",
        "style.identity",
        "variable.binding",
        "text.content",
        "ownership.owner",
        "ownership.contour",
        "slot.identity",
        "page.context",
        "relation.measurement"
      ],
      predicates: [
        { id: "all", family: "logic", arity: "many" },
        { id: "any", family: "logic", arity: "many" },
        { id: "not", family: "logic", arity: "one" },
        { id: "exists", family: "value", arity: "one" },
        { id: "fact-present", family: "value", arity: "one" },
        { id: "equals", family: "value", arity: "two" },
        { id: "not-equals", family: "value", arity: "two" },
        { id: "one-of", family: "value", arity: "many" },
        { id: "none-of", family: "value", arity: "many" },
        { id: "compare", family: "value", arity: "two" },
        { id: "approximately-equals", family: "value", arity: "two" },
        { id: "between", family: "value", arity: "three" },
        { id: "string-length-between", family: "value", arity: "three" },
        { id: "matches", family: "value", arity: "two" },
        { id: "every", family: "collection", arity: "many" },
        { id: "some", family: "collection", arity: "many" },
        { id: "none", family: "collection", arity: "many" },
        { id: "count-between", family: "collection", arity: "three" },
        { id: "all-equal", family: "collection", arity: "many" },
        { id: "unique", family: "collection", arity: "many" },
        { id: "sequence-equals", family: "collection", arity: "many" },
        { id: "value-position", family: "collection", arity: "many" },
        { id: "direct-parent", family: "relation", arity: "two" },
        { id: "ancestor", family: "relation", arity: "two" },
        { id: "direct-child", family: "relation", arity: "two" },
        { id: "descendant", family: "relation", arity: "two" },
        { id: "before", family: "relation", arity: "two" },
        { id: "after", family: "relation", arity: "two" },
        { id: "adjacent", family: "relation", arity: "two" },
        { id: "contains", family: "geometry", arity: "two" },
        { id: "overlaps", family: "geometry", arity: "two" },
        { id: "aligned", family: "geometry", arity: "two" },
        { id: "distance", family: "geometry", arity: "three" },
        { id: "component-api-valid", family: "contract", arity: "one" },
        { id: "matches-effective-baseline", family: "contract", arity: "two" },
        { id: "binding-satisfies", family: "contract", arity: "two" },
        { id: "paint-state-satisfies", family: "contract", arity: "two" }
      ],
      gates: [
        "active-authority",
        "supported-capabilities",
        "complete-required-evidence",
        "unambiguous-component-identity",
        "no-authority-conflict"
      ],
      terminalClassifications: [
        "violation",
        "compliant",
        "allowed",
        "human-review",
        "not-applicable",
        "not-evaluable"
      ]
    };
  }
});

// ../../services/apollo-proxy/src/predicate-engine/index.js
var require_predicate_engine = __commonJS({
  "../../services/apollo-proxy/src/predicate-engine/index.js"(exports2, module2) {
    var { sha256Hex: sha256Hex2 } = (init_sha256(), __toCommonJS(sha256_exports));
    var crypto = { createHash: function() {
      let value = "";
      return { update: function(next) {
        value += String(next);
        return this;
      }, digest: function(format) {
        if (format !== "hex") throw new Error("Only hex digest is supported");
        return sha256Hex2(value);
      } };
    } };
    var registry = require_apollo_predicate_capabilities_v1();
    var TRUTH = Object.freeze({ TRUE: "true", FALSE: "false", UNKNOWN: "unknown" });
    var APPLICABILITY = Object.freeze({
      APPLICABLE: "applicable",
      NOT_APPLICABLE: "not-applicable",
      UNKNOWN: "unknown"
    });
    var IMPLEMENTED_PREDICATES = /* @__PURE__ */ new Set([
      "all",
      "any",
      "not",
      "exists",
      "fact-present",
      "equals",
      "not-equals",
      "one-of",
      "none-of",
      "compare",
      "approximately-equals",
      "between",
      "string-length-between",
      "matches",
      "every",
      "some",
      "none",
      "count-between",
      "all-equal",
      "unique",
      "sequence-equals",
      "value-position",
      "direct-parent",
      "ancestor",
      "direct-child",
      "descendant",
      "before",
      "after",
      "adjacent",
      "contains",
      "overlaps",
      "aligned",
      "distance",
      "component-api-valid",
      "matches-effective-baseline",
      "binding-satisfies",
      "paint-state-satisfies"
    ]);
    var REGISTERED_PREDICATES = new Set(registry.predicates.map((predicate) => predicate.id));
    var SELECTOR_ORIGINS = /* @__PURE__ */ new Set(["selection-root", "self", "page-descendants"]);
    var QUERY_ORIGINS = /* @__PURE__ */ new Set(["subject", "selection-root", "page-descendants"]);
    var SELECTOR_TRAVERSALS = /* @__PURE__ */ new Set([
      "self",
      "direct-children",
      "descendants",
      "self-and-descendants",
      "parent",
      "ancestors",
      "siblings"
    ]);
    var DERIVE_OPERATORS = /* @__PURE__ */ new Set([
      "add",
      "subtract",
      "multiply",
      "divide",
      "length",
      "absolute-difference"
    ]);
    var CAUSAL_RELATIONS = /* @__PURE__ */ new Set([
      "same-subject",
      "same-focus",
      "descendant-subject"
    ]);
    function stableStringify2(value) {
      if (Array.isArray(value)) return `[${value.map(stableStringify2).join(",")}]`;
      if (value && typeof value === "object") {
        return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify2(value[key])}`).join(",")}}`;
      }
      return JSON.stringify(value);
    }
    function stableHash2(value) {
      return crypto.createHash("sha256").update(stableStringify2(value)).digest("hex");
    }
    function snapshotHash2(snapshot) {
      if (typeof snapshot.snapshotHash === "string" && snapshot.snapshotHash) return snapshot.snapshotHash;
      const normalized = { ...snapshot };
      delete normalized.generatedAt;
      delete normalized.snapshotHash;
      return stableHash2(normalized);
    }
    function capabilityError(code, message) {
      const error = new Error(message);
      error.code = code;
      return error;
    }
    function validateValueRef(valueRef, location) {
      if (!valueRef || typeof valueRef !== "object" || Array.isArray(valueRef)) {
        throw capabilityError("RULE_IR_INVALID", `${location} must be a value reference object`);
      }
      const kinds = ["literal", "fact", "query", "derive"].filter((key) => Object.prototype.hasOwnProperty.call(valueRef, key));
      if (kinds.length !== 1) {
        throw capabilityError(
          "RULE_IR_INVALID",
          `${location} must contain exactly one of literal, fact, query or derive`
        );
      }
      if (kinds[0] === "literal") return;
      if (kinds[0] === "fact") {
        if (typeof valueRef.fact !== "string" || !valueRef.fact) {
          throw capabilityError("RULE_IR_INVALID", `${location}.fact must be a non-empty string`);
        }
        return;
      }
      if (kinds[0] === "query") {
        const query = valueRef.query;
        if (!query || typeof query !== "object" || Array.isArray(query)) {
          throw capabilityError("RULE_IR_INVALID", `${location}.query must be an object`);
        }
        if (!QUERY_ORIGINS.has(query.from)) {
          throw capabilityError("SELECTOR_UNKNOWN", `Unknown query origin: ${query.from}`);
        }
        if (!SELECTOR_TRAVERSALS.has(query.traverse)) {
          throw capabilityError("SELECTOR_UNKNOWN", `Unknown query traversal: ${query.traverse}`);
        }
        for (const [index, expression] of (query.where || []).entries()) {
          validateExpressionCapabilities(expression, `${location}.query.where[${index}]`);
        }
        if (query.project !== void 0) {
          validateValueRef(query.project, `${location}.query.project`);
        }
        return;
      }
      const derive = valueRef.derive;
      if (!derive || typeof derive !== "object" || Array.isArray(derive)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.derive must be an object`);
      }
      if (!DERIVE_OPERATORS.has(derive.operator)) {
        throw capabilityError(
          "RULE_IR_INVALID",
          `${location}.derive.operator is unsupported: ${derive.operator}`
        );
      }
      if (!Array.isArray(derive.args) || derive.args.length === 0) {
        throw capabilityError("RULE_IR_INVALID", `${location}.derive.args must not be empty`);
      }
      if (derive.operator === "length" && derive.args.length !== 1) {
        throw capabilityError("RULE_IR_INVALID", `${location}.derive.length requires one arg`);
      }
      if (["subtract", "divide", "absolute-difference"].includes(derive.operator) && derive.args.length !== 2) {
        throw capabilityError(
          "RULE_IR_INVALID",
          `${location}.derive.${derive.operator} requires two args`
        );
      }
      for (const [index, value] of derive.args.entries()) {
        validateValueRef(value, `${location}.derive.args[${index}]`);
      }
    }
    function validateExpressionCapabilities(expression, location) {
      if (!expression || typeof expression !== "object" || Array.isArray(expression)) {
        throw capabilityError("RULE_IR_INVALID", `${location} must be an expression object`);
      }
      const predicate = expression.predicate;
      if (typeof predicate !== "string" || !predicate) {
        throw capabilityError("RULE_IR_INVALID", `${location}.predicate is required`);
      }
      if (!REGISTERED_PREDICATES.has(predicate)) {
        throw capabilityError("PREDICATE_UNKNOWN", `Unknown predicate: ${predicate}`);
      }
      if (!IMPLEMENTED_PREDICATES.has(predicate)) {
        throw capabilityError("PREDICATE_NOT_IMPLEMENTED", `Predicate is not implemented yet: ${predicate}`);
      }
      const args = expression.args || [];
      if (["all", "any"].includes(predicate) && (!Array.isArray(args) || args.length === 0)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate} requires at least one arg`);
      }
      if (predicate === "not" && (!Array.isArray(args) || args.length !== 1)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.not requires exactly one arg`);
      }
      if (!["all", "any", "not"].includes(predicate) && !expression.actual) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate}.actual is required`);
      }
      for (const key of ["actual", "expected", "target", "lower", "upper"]) {
        if (expression[key] !== void 0) validateValueRef(expression[key], `${location}.${key}`);
      }
      if ([
        "equals",
        "not-equals",
        "one-of",
        "none-of",
        "compare",
        "approximately-equals",
        "matches",
        "every",
        "some",
        "none",
        "sequence-equals",
        "value-position",
        "direct-parent",
        "ancestor",
        "direct-child",
        "descendant",
        "before",
        "after",
        "adjacent",
        "matches-effective-baseline",
        "binding-satisfies",
        "paint-state-satisfies"
      ].includes(predicate) && !expression.expected) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate}.expected is required`);
      }
      if (predicate === "compare" && !["lt", "lte", "gt", "gte"].includes(expression.operator)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.compare.operator must be lt, lte, gt or gte`);
      }
      if (["between", "string-length-between", "count-between"].includes(predicate) && (!expression.lower || !expression.upper)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.between requires lower and upper values`);
      }
      if (expression.bounds && !["inclusive", "exclusive", "inclusive-lower", "inclusive-upper"].includes(expression.bounds)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.bounds is invalid`);
      }
      if (predicate === "value-position") {
        if (!Array.isArray(expression.positions) || expression.positions.length === 0) {
          throw capabilityError("RULE_IR_INVALID", `${location}.value-position.positions requires at least one position`);
        }
        if (expression.maxCount !== void 0 && (!Number.isInteger(expression.maxCount) || expression.maxCount < 0)) {
          throw capabilityError("RULE_IR_INVALID", `${location}.value-position.maxCount must be a non-negative integer`);
        }
      }
      if (["contains", "overlaps", "aligned", "distance"].includes(predicate) && !expression.target) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate}.target is required`);
      }
      if (predicate === "distance" && !expression.expected) {
        throw capabilityError("RULE_IR_INVALID", `${location}.distance.expected is required`);
      }
      if (predicate === "aligned" && !["left", "center-x", "right", "top", "center-y", "bottom"].includes(expression.axis)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.aligned.axis is invalid`);
      }
      if (predicate === "distance" && !["horizontal", "vertical", "euclidean"].includes(expression.axis)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.distance.axis is invalid`);
      }
      if (expression.tolerance !== void 0 && (typeof expression.tolerance !== "number" || !Number.isFinite(expression.tolerance) || expression.tolerance < 0)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.tolerance must be a non-negative finite number`);
      }
      for (const [index, child] of args.entries()) {
        validateExpressionCapabilities(child, `${location}.args[${index}]`);
      }
    }
    function validateRule(rule) {
      if (!rule || rule.schemaVersion !== "apollo.rule-ir.v1") {
        throw capabilityError("RULE_IR_INVALID", "RuleIR schemaVersion must be apollo.rule-ir.v1");
      }
      if (!["require", "forbid", "allow"].includes(rule.effect)) {
        throw capabilityError("RULE_IR_INVALID", `Unsupported rule effect: ${rule.effect}`);
      }
      for (const [dimension, values] of Object.entries(rule.scope || {})) {
        if (!["platform", "product", "channel", "pageType"].includes(dimension) || values !== void 0 && (!Array.isArray(values) || values.some((value) => typeof value !== "string" || !value.trim()))) {
          throw capabilityError("RULE_IR_INVALID", `Unsupported or invalid scope dimension: ${dimension}`);
        }
      }
      if (!rule.select || !SELECTOR_ORIGINS.has(rule.select.from)) {
        throw capabilityError("SELECTOR_UNKNOWN", `Unknown selector origin: ${rule.select?.from}`);
      }
      if (!SELECTOR_TRAVERSALS.has(rule.select.traverse)) {
        throw capabilityError("SELECTOR_UNKNOWN", `Unknown selector traversal: ${rule.select.traverse}`);
      }
      validateExpressionCapabilities(rule.assert, "assert");
      if (rule.when) validateExpressionCapabilities(rule.when, "when");
      for (const [index, expression] of (rule.select?.where || []).entries()) {
        validateExpressionCapabilities(expression, `select.where[${index}]`);
      }
      if (rule.causality !== void 0 && rule.causality !== null) {
        if (typeof rule.causality !== "object" || Array.isArray(rule.causality) || !Array.isArray(rule.causality.causes) || !rule.causality.causes.length) {
          throw capabilityError(
            "RULE_IR_INVALID",
            "causality.causes must be a non-empty array"
          );
        }
        for (const [index, cause] of rule.causality.causes.entries()) {
          if (!cause || typeof cause !== "object" || Array.isArray(cause)) {
            throw capabilityError("RULE_IR_INVALID", `causality.causes[${index}] must be an object`);
          }
          if (typeof cause.ruleId !== "string" || !cause.ruleId) {
            throw capabilityError(
              "RULE_IR_INVALID",
              `causality.causes[${index}].ruleId must be a non-empty string`
            );
          }
          if (!CAUSAL_RELATIONS.has(cause.relation)) {
            throw capabilityError(
              "RULE_IR_INVALID",
              `causality.causes[${index}].relation is unsupported: ${cause.relation}`
            );
          }
          if (typeof cause.reason !== "string" || !cause.reason) {
            throw capabilityError(
              "RULE_IR_INVALID",
              `causality.causes[${index}].reason must be a non-empty string`
            );
          }
        }
      }
      return rule;
    }
    function unknownFactMatches(unknownFacts, factPath) {
      return (unknownFacts || []).some((unknownPath) => unknownPath === factPath || factPath.startsWith(`${unknownPath}.`));
    }
    function readObjectPath(root, factPath) {
      let current = root;
      for (const part of factPath.split(".")) {
        if (current === null || current === void 0 || typeof current !== "object") {
          return { state: "absent", value: void 0 };
        }
        if (!Object.prototype.hasOwnProperty.call(current, part)) {
          return { state: "absent", value: void 0 };
        }
        current = current[part];
      }
      return { state: "known", value: current };
    }
    function resolveQueryValue(query, subject, snapshot) {
      const index = nodeIndex(snapshot);
      const roots = query.from === "subject" ? [subject] : selectionRoots(snapshot, query.from, index);
      const candidates = roots.flatMap((root) => traversalNodes(root, query.traverse, index));
      const unique = new Map(candidates.map((node) => [node.id, node]));
      const nodes = Array.from(unique.values()).sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
      const selected = [];
      const factPaths = /* @__PURE__ */ new Set();
      for (const node of nodes) {
        let matches = true;
        for (const expression of query.where || []) {
          const trace = evaluateExpression(expression, node, snapshot);
          for (const factPath of trace.factPaths) factPaths.add(factPath);
          if (trace.truth === TRUTH.UNKNOWN) {
            return { state: "unknown", value: void 0, factPaths: Array.from(factPaths).sort() };
          }
          if (trace.truth === TRUTH.FALSE) {
            matches = false;
            break;
          }
        }
        if (!matches) continue;
        if (query.project === void 0) {
          selected.push(node.id);
          continue;
        }
        const projected = resolveValue2(query.project, node, snapshot);
        for (const factPath of projected.factPaths) factPaths.add(factPath);
        if (projected.state !== "known") {
          return { state: "unknown", value: void 0, factPaths: Array.from(factPaths).sort() };
        }
        selected.push(projected.value);
      }
      return { state: "known", value: selected, factPaths: Array.from(factPaths).sort() };
    }
    function resolveDerivedValue(derive, subject, snapshot) {
      const resolved = derive.args.map((value) => resolveValue2(value, subject, snapshot));
      const factPaths = Array.from(new Set(resolved.flatMap((value) => value.factPaths))).sort();
      if (resolved.some((value) => value.state !== "known")) {
        return { state: "unknown", value: void 0, factPaths };
      }
      const values = resolved.map((value) => value.value);
      if (derive.operator === "length") {
        const value = values[0];
        if (!Array.isArray(value) && typeof value !== "string") {
          return { state: "unknown", value: void 0, factPaths };
        }
        return {
          state: "known",
          value: Array.isArray(value) ? value.length : Array.from(value).length,
          factPaths
        };
      }
      if (!values.every((value) => typeof value === "number" && Number.isFinite(value))) {
        return { state: "unknown", value: void 0, factPaths };
      }
      if (derive.operator === "add") {
        return { state: "known", value: values.reduce((sum, value) => sum + value, 0), factPaths };
      }
      if (derive.operator === "multiply") {
        return { state: "known", value: values.reduce((product, value) => product * value, 1), factPaths };
      }
      if (derive.operator === "subtract") {
        return { state: "known", value: values[0] - values[1], factPaths };
      }
      if (derive.operator === "absolute-difference") {
        return { state: "known", value: Math.abs(values[0] - values[1]), factPaths };
      }
      if (values[1] === 0) return { state: "unknown", value: void 0, factPaths };
      return { state: "known", value: values[0] / values[1], factPaths };
    }
    function resolveValue2(valueRef, subject, snapshot) {
      if (!valueRef || typeof valueRef !== "object" || Array.isArray(valueRef)) {
        return { state: "unknown", value: void 0, factPaths: [] };
      }
      if (Object.prototype.hasOwnProperty.call(valueRef, "literal")) {
        return { state: "known", value: valueRef.literal, factPaths: [] };
      }
      if (Object.prototype.hasOwnProperty.call(valueRef, "query")) {
        return resolveQueryValue(valueRef.query, subject, snapshot);
      }
      if (Object.prototype.hasOwnProperty.call(valueRef, "derive")) {
        return resolveDerivedValue(valueRef.derive, subject, snapshot);
      }
      if (typeof valueRef.fact !== "string" || !valueRef.fact) {
        return { state: "unknown", value: void 0, factPaths: [] };
      }
      const factPath = valueRef.fact;
      if (unknownFactMatches(subject.unknownFacts, factPath)) {
        return { state: "unknown", value: void 0, factPaths: [factPath] };
      }
      if (factPath.startsWith("page.context.")) {
        const contextFactPath = factPath.slice("page.context.".length);
        if (unknownFactMatches(snapshot.context?.unknownFacts, contextFactPath)) {
          return { state: "unknown", value: void 0, factPaths: [factPath] };
        }
        const resolved = readObjectPath(snapshot.context, contextFactPath);
        return { ...resolved, factPaths: [factPath] };
      }
      return { ...readObjectPath(subject, factPath), factPaths: [factPath] };
    }
    function deepEqual(left, right) {
      return stableStringify2(left) === stableStringify2(right);
    }
    function makeTrace(predicate, truth, reason, actual, expected, factPaths, children) {
      const trace = {
        predicate,
        truth,
        reason,
        actual: actual.state === "known" ? actual.value : { state: actual.state },
        expected: expected.state === "known" ? expected.value : { state: expected.state },
        factPaths
      };
      if (children) trace.children = children;
      return trace;
    }
    function combineLogic(predicate, children) {
      const truths = children.map((child) => child.truth);
      if (predicate === "all") {
        if (truths.includes(TRUTH.FALSE)) return TRUTH.FALSE;
        return truths.includes(TRUTH.UNKNOWN) ? TRUTH.UNKNOWN : TRUTH.TRUE;
      }
      if (predicate === "any") {
        if (truths.includes(TRUTH.TRUE)) return TRUTH.TRUE;
        return truths.includes(TRUTH.UNKNOWN) ? TRUTH.UNKNOWN : TRUTH.FALSE;
      }
      return truths[0] === TRUTH.UNKNOWN ? TRUTH.UNKNOWN : truths[0] === TRUTH.TRUE ? TRUTH.FALSE : TRUTH.TRUE;
    }
    function evaluateLogicExpression(expression, subject, snapshot) {
      const children = expression.args.map((child) => evaluateExpression(child, subject, snapshot));
      const truth = combineLogic(expression.predicate, children);
      const factPaths = Array.from(new Set(children.flatMap((child) => child.factPaths))).sort();
      const reason = expression.predicate === "not" ? "logical negation evaluated" : `logical ${expression.predicate} evaluated`;
      return makeTrace(
        expression.predicate,
        truth,
        reason,
        { state: "known", value: children.map((child) => child.truth) },
        { state: "known", value: expression.predicate === "all" ? "all true" : expression.predicate === "any" ? "at least one true" : "negated" },
        factPaths,
        children
      );
    }
    function numericValue(resolved) {
      return resolved.state === "known" && typeof resolved.value === "number" && Number.isFinite(resolved.value);
    }
    function knownArray(resolved) {
      return resolved.state === "known" && Array.isArray(resolved.value);
    }
    function resolveBounds(expression, subject, snapshot) {
      const lower = resolveValue2(expression.lower, subject, snapshot);
      const upper = resolveValue2(expression.upper, subject, snapshot);
      return {
        lower,
        upper,
        factPaths: Array.from(/* @__PURE__ */ new Set([...lower.factPaths, ...upper.factPaths])).sort()
      };
    }
    function evaluateNumericRange(predicate, actual, lower, upper, bounds, factPaths) {
      if ([actual, lower, upper].some((value) => value.state === "unknown")) {
        return makeTrace(predicate, TRUTH.UNKNOWN, "range evidence is unknown", actual, { state: "unknown" }, factPaths);
      }
      if ([actual, lower, upper].some((value) => value.state === "absent")) {
        return makeTrace(predicate, TRUTH.FALSE, "range value is absent", actual, { state: "absent" }, factPaths);
      }
      if (![actual, lower, upper].every(numericValue) || lower.value > upper.value) {
        return makeTrace(predicate, TRUTH.UNKNOWN, "range requires ordered finite numeric bounds", actual, { state: "known", value: { lower: lower.value, upper: upper.value } }, factPaths);
      }
      const lowerPass = ["inclusive", "inclusive-lower"].includes(bounds) ? actual.value >= lower.value : actual.value > lower.value;
      const upperPass = ["inclusive", "inclusive-upper"].includes(bounds) ? actual.value <= upper.value : actual.value < upper.value;
      const truth = lowerPass && upperPass ? TRUTH.TRUE : TRUTH.FALSE;
      return makeTrace(predicate, truth, `numeric range ${bounds} evaluated`, actual, { state: "known", value: { lower: lower.value, upper: upper.value, bounds } }, factPaths);
    }
    function resolveNodePair(actual, expected, snapshot) {
      if (typeof actual.value !== "string" || typeof expected.value !== "string") {
        return { state: "invalid", actualNode: null, expectedNode: null };
      }
      const index = nodeIndex(snapshot);
      const actualNode = index.get(actual.value) || null;
      const expectedNode = index.get(expected.value) || null;
      if (!actualNode || !expectedNode) {
        return { state: "missing", actualNode, expectedNode };
      }
      return { state: "known", actualNode, expectedNode };
    }
    function isAncestorNode(ancestorNode, descendantNode, index) {
      let current = descendantNode.parentId ? index.get(descendantNode.parentId) : null;
      while (current) {
        if (current.id === ancestorNode.id) return true;
        current = current.parentId ? index.get(current.parentId) : null;
      }
      return false;
    }
    function siblingPosition(node, parent, index) {
      if (!parent) return null;
      const visibleIds = (parent.childIds || []).filter((id) => index.get(id)?.visible === true);
      const position = visibleIds.indexOf(node.id);
      return position >= 0 ? position : null;
    }
    function evaluateRelation(predicate, actual, expected, snapshot, factPaths) {
      const pair = resolveNodePair(actual, expected, snapshot);
      if (pair.state !== "known") {
        return makeTrace(predicate, TRUTH.UNKNOWN, pair.state === "missing" ? "relation node is outside the snapshot" : "relation operands must be node ids", actual, expected, factPaths);
      }
      const { actualNode, expectedNode } = pair;
      const index = nodeIndex(snapshot);
      let passes = false;
      if (predicate === "direct-parent") passes = actualNode.parentId === expectedNode.id;
      else if (predicate === "ancestor") passes = isAncestorNode(expectedNode, actualNode, index);
      else if (predicate === "direct-child") passes = expectedNode.parentId === actualNode.id;
      else if (predicate === "descendant") passes = isAncestorNode(actualNode, expectedNode, index);
      else {
        const sameParent = actualNode.parentId !== null && actualNode.parentId === expectedNode.parentId;
        const parent = sameParent ? index.get(actualNode.parentId) : null;
        const actualPosition = siblingPosition(actualNode, parent, index);
        const expectedPosition = siblingPosition(expectedNode, parent, index);
        if (sameParent && actualPosition !== null && expectedPosition !== null) {
          if (predicate === "before") passes = actualPosition < expectedPosition;
          else if (predicate === "after") passes = actualPosition > expectedPosition;
          else passes = Math.abs(actualPosition - expectedPosition) === 1;
        }
      }
      const truth = passes ? TRUTH.TRUE : TRUTH.FALSE;
      return makeTrace(predicate, truth, truth === TRUTH.TRUE ? `node relation ${predicate} holds` : `node relation ${predicate} does not hold`, actual, expected, factPaths);
    }
    function isBounds(value) {
      return value && typeof value === "object" && !Array.isArray(value) && ["x", "y", "width", "height"].every((key) => typeof value[key] === "number" && Number.isFinite(value[key])) && value.width >= 0 && value.height >= 0;
    }
    function boundsCoordinate(bounds, axis) {
      if (axis === "left") return bounds.x;
      if (axis === "center-x") return bounds.x + bounds.width / 2;
      if (axis === "right") return bounds.x + bounds.width;
      if (axis === "top") return bounds.y;
      if (axis === "center-y") return bounds.y + bounds.height / 2;
      return bounds.y + bounds.height;
    }
    function axisGap(firstStart, firstSize, secondStart, secondSize) {
      const firstEnd = firstStart + firstSize;
      const secondEnd = secondStart + secondSize;
      if (firstEnd < secondStart) return secondStart - firstEnd;
      if (secondEnd < firstStart) return firstStart - secondEnd;
      return 0;
    }
    function partialMatch(actual, constraint) {
      if (!constraint || typeof constraint !== "object" || Array.isArray(constraint)) {
        return deepEqual(actual, constraint);
      }
      if (!actual || typeof actual !== "object" || Array.isArray(actual)) return false;
      return Object.keys(constraint).every((key) => partialMatch(actual[key], constraint[key]));
    }
    function evaluateExpression(expression, subject, snapshot) {
      if (["all", "any", "not"].includes(expression.predicate)) {
        return evaluateLogicExpression(expression, subject, snapshot);
      }
      const actual = resolveValue2(expression.actual, subject, snapshot);
      const expected = expression.expected ? resolveValue2(expression.expected, subject, snapshot) : { state: "known", value: null, factPaths: [] };
      const factPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...expected.factPaths])).sort();
      if (expression.predicate === "exists") {
        if (actual.state === "unknown") {
          return makeTrace("exists", TRUTH.UNKNOWN, "required fact is unknown", actual, expected, factPaths);
        }
        const truth = actual.state === "known" && actual.value !== null ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("exists", truth, truth === TRUTH.TRUE ? "fact exists" : "fact is absent", actual, expected, factPaths);
      }
      if (expression.predicate === "fact-present") {
        if (actual.state === "unknown") {
          return makeTrace("fact-present", TRUTH.UNKNOWN, "fact presence is unknown", actual, expected, factPaths);
        }
        const truth = actual.state === "known" ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(
          "fact-present",
          truth,
          truth === TRUTH.TRUE ? "fact path is present" : "fact path is absent",
          actual,
          expected,
          factPaths
        );
      }
      if (actual.state === "unknown" || expected.state === "unknown") {
        return makeTrace(expression.predicate, TRUTH.UNKNOWN, "comparison evidence is unknown", actual, expected, factPaths);
      }
      if (actual.state === "absent" || expected.state === "absent") {
        if (expression.missingPolicy === "unknown") {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "comparison value is absent", actual, expected, factPaths);
        }
        return makeTrace(expression.predicate, TRUTH.FALSE, "comparison value is absent", actual, expected, factPaths);
      }
      if (expression.predicate === "equals") {
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("equals", truth, truth === TRUTH.TRUE ? "values are equal" : "values differ", actual, expected, factPaths);
      }
      if (expression.predicate === "not-equals") {
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.FALSE : TRUTH.TRUE;
        return makeTrace("not-equals", truth, truth === TRUTH.TRUE ? "values differ" : "values are equal", actual, expected, factPaths);
      }
      if (expression.predicate === "one-of") {
        if (!Array.isArray(expected.value)) {
          return makeTrace("one-of", TRUTH.UNKNOWN, "expected value is not an array", actual, expected, factPaths);
        }
        const truth = expected.value.some((candidate) => deepEqual(actual.value, candidate)) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("one-of", truth, truth === TRUTH.TRUE ? "value belongs to the allowed set" : "value is outside the allowed set", actual, expected, factPaths);
      }
      if (expression.predicate === "none-of") {
        if (!Array.isArray(expected.value)) {
          return makeTrace("none-of", TRUTH.UNKNOWN, "expected value is not an array", actual, expected, factPaths);
        }
        const truth = expected.value.some((candidate) => deepEqual(actual.value, candidate)) ? TRUTH.FALSE : TRUTH.TRUE;
        return makeTrace("none-of", truth, truth === TRUTH.TRUE ? "value is outside the forbidden set" : "value belongs to the forbidden set", actual, expected, factPaths);
      }
      if (expression.predicate === "compare") {
        if (!numericValue(actual) || !numericValue(expected)) {
          return makeTrace("compare", TRUTH.UNKNOWN, "comparison requires finite numeric values", actual, expected, factPaths);
        }
        const comparisons = {
          lt: actual.value < expected.value,
          lte: actual.value <= expected.value,
          gt: actual.value > expected.value,
          gte: actual.value >= expected.value
        };
        const truth = comparisons[expression.operator] ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("compare", truth, `numeric comparison ${expression.operator} evaluated`, actual, { state: "known", value: { operator: expression.operator, value: expected.value } }, factPaths);
      }
      if (expression.predicate === "approximately-equals") {
        if (!numericValue(actual) || !numericValue(expected)) {
          return makeTrace(
            "approximately-equals",
            TRUTH.UNKNOWN,
            "approximate comparison requires finite numeric values",
            actual,
            expected,
            factPaths
          );
        }
        const tolerance = expression.tolerance || 0;
        const difference = Math.abs(actual.value - expected.value);
        const truth = difference <= tolerance ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(
          "approximately-equals",
          truth,
          truth === TRUTH.TRUE ? "values are equal within tolerance" : "values differ beyond tolerance",
          actual,
          { state: "known", value: { value: expected.value, tolerance, difference } },
          factPaths
        );
      }
      if (expression.predicate === "between") {
        const range = resolveBounds(expression, subject, snapshot);
        const bounds = expression.bounds || "inclusive";
        const rangeFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...range.factPaths])).sort();
        return evaluateNumericRange("between", actual, range.lower, range.upper, bounds, rangeFactPaths);
      }
      if (expression.predicate === "string-length-between") {
        const range = resolveBounds(expression, subject, snapshot);
        const rangeFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...range.factPaths])).sort();
        if (actual.state === "unknown") {
          return makeTrace("string-length-between", TRUTH.UNKNOWN, "string evidence is unknown", actual, { state: "unknown" }, rangeFactPaths);
        }
        if (actual.state === "absent") {
          return makeTrace("string-length-between", TRUTH.FALSE, "string value is absent", actual, { state: "absent" }, rangeFactPaths);
        }
        if (typeof actual.value !== "string") {
          return makeTrace("string-length-between", TRUTH.UNKNOWN, "actual value is not a string", actual, { state: "unknown" }, rangeFactPaths);
        }
        return evaluateNumericRange(
          "string-length-between",
          { state: "known", value: Array.from(actual.value).length, factPaths: actual.factPaths },
          range.lower,
          range.upper,
          expression.bounds || "inclusive",
          rangeFactPaths
        );
      }
      if (expression.predicate === "matches") {
        if (typeof actual.value !== "string" || typeof expected.value !== "string") {
          return makeTrace("matches", TRUTH.UNKNOWN, "regex comparison requires string values", actual, expected, factPaths);
        }
        let matcher;
        try {
          matcher = new RegExp(expected.value, expression.flags || "u");
        } catch (_error) {
          return makeTrace("matches", TRUTH.UNKNOWN, "regular expression is invalid", actual, expected, factPaths);
        }
        const truth = matcher.test(actual.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("matches", truth, truth === TRUTH.TRUE ? "string matches the pattern" : "string does not match the pattern", actual, { state: "known", value: { pattern: expected.value, flags: expression.flags || "u" } }, factPaths);
      }
      if (["every", "some", "none"].includes(expression.predicate)) {
        if (!knownArray(actual)) {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "collection predicate requires an actual array", actual, expected, factPaths);
        }
        const allowed = Array.isArray(expected.value) ? expected.value : [expected.value];
        const matches = actual.value.map((item) => allowed.some((candidate) => deepEqual(item, candidate)));
        const values = {
          every: matches.every(Boolean),
          some: matches.some(Boolean),
          none: matches.every((match) => !match)
        };
        const truth = values[expression.predicate] ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(expression.predicate, truth, `collection membership ${expression.predicate} evaluated`, actual, { state: "known", value: allowed }, factPaths);
      }
      if (expression.predicate === "count-between") {
        const range = resolveBounds(expression, subject, snapshot);
        const rangeFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...range.factPaths])).sort();
        if (!knownArray(actual)) {
          return makeTrace("count-between", actual.state === "unknown" ? TRUTH.UNKNOWN : TRUTH.FALSE, "count predicate requires an actual array", actual, { state: "unknown" }, rangeFactPaths);
        }
        return evaluateNumericRange(
          "count-between",
          { state: "known", value: actual.value.length, factPaths: actual.factPaths },
          range.lower,
          range.upper,
          expression.bounds || "inclusive",
          rangeFactPaths
        );
      }
      if (expression.predicate === "all-equal") {
        if (!knownArray(actual)) {
          return makeTrace("all-equal", TRUTH.UNKNOWN, "all-equal requires an actual array", actual, expected, factPaths);
        }
        const reference = expression.expected ? expected.value : actual.value[0];
        const truth = actual.value.every((item) => deepEqual(item, reference)) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("all-equal", truth, truth === TRUTH.TRUE ? "all collection values are equal" : "collection values differ", actual, { state: "known", value: reference }, factPaths);
      }
      if (expression.predicate === "unique") {
        if (!knownArray(actual)) {
          return makeTrace("unique", TRUTH.UNKNOWN, "unique requires an actual array", actual, expected, factPaths);
        }
        const identities = actual.value.map(stableStringify2);
        const truth = identities.length === new Set(identities).size ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("unique", truth, truth === TRUTH.TRUE ? "collection values are unique" : "collection contains duplicates", actual, { state: "known", value: "unique values" }, factPaths);
      }
      if (expression.predicate === "sequence-equals") {
        if (!knownArray(actual) || !knownArray(expected)) {
          return makeTrace("sequence-equals", TRUTH.UNKNOWN, "sequence comparison requires two arrays", actual, expected, factPaths);
        }
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("sequence-equals", truth, truth === TRUTH.TRUE ? "sequences are equal" : "sequences differ", actual, expected, factPaths);
      }
      if (expression.predicate === "value-position") {
        if (!knownArray(actual)) {
          return makeTrace("value-position", TRUTH.UNKNOWN, "value-position requires an actual array", actual, expected, factPaths);
        }
        const positions = expression.positions;
        const matchingIndexes = actual.value.map((item, index) => deepEqual(item, expected.value) ? index : -1).filter((index) => index >= 0);
        const allowedIndexes = /* @__PURE__ */ new Set();
        for (const position of positions) {
          if (position === "first") allowedIndexes.add(0);
          else if (position === "last") allowedIndexes.add(Math.max(0, actual.value.length - 1));
          else if (Number.isInteger(position) && position >= 0) allowedIndexes.add(position);
        }
        const withinCount = expression.maxCount === void 0 || matchingIndexes.length <= expression.maxCount;
        const correctlyPositioned = matchingIndexes.every((index) => allowedIndexes.has(index));
        const truth = withinCount && correctlyPositioned ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("value-position", truth, truth === TRUTH.TRUE ? "matching values occupy allowed positions" : "matching values violate position or count constraints", actual, { state: "known", value: { value: expected.value, positions, maxCount: expression.maxCount ?? null } }, factPaths);
      }
      if ([
        "direct-parent",
        "ancestor",
        "direct-child",
        "descendant",
        "before",
        "after",
        "adjacent"
      ].includes(expression.predicate)) {
        return evaluateRelation(expression.predicate, actual, expected, snapshot, factPaths);
      }
      if (["contains", "overlaps", "aligned", "distance"].includes(expression.predicate)) {
        const target = resolveValue2(expression.target, subject, snapshot);
        const geometryFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...target.factPaths, ...expected.factPaths])).sort();
        if (actual.state === "unknown" || target.state === "unknown" || expected.state === "unknown") {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "geometry evidence is unknown", actual, target, geometryFactPaths);
        }
        if (!isBounds(actual.value) || !isBounds(target.value)) {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "geometry predicate requires valid bounds", actual, target, geometryFactPaths);
        }
        let passes = false;
        let measured = null;
        if (expression.predicate === "contains") {
          passes = target.value.x >= actual.value.x && target.value.y >= actual.value.y && target.value.x + target.value.width <= actual.value.x + actual.value.width && target.value.y + target.value.height <= actual.value.y + actual.value.height;
        } else if (expression.predicate === "overlaps") {
          const intersectionWidth = Math.min(actual.value.x + actual.value.width, target.value.x + target.value.width) - Math.max(actual.value.x, target.value.x);
          const intersectionHeight = Math.min(actual.value.y + actual.value.height, target.value.y + target.value.height) - Math.max(actual.value.y, target.value.y);
          passes = intersectionWidth > 0 && intersectionHeight > 0;
        } else if (expression.predicate === "aligned") {
          measured = Math.abs(boundsCoordinate(actual.value, expression.axis) - boundsCoordinate(target.value, expression.axis));
          passes = measured <= (expression.tolerance || 0);
        } else {
          if (!numericValue(expected)) {
            return makeTrace("distance", TRUTH.UNKNOWN, "distance expectation must be a finite number", actual, expected, geometryFactPaths);
          }
          const horizontal = axisGap(actual.value.x, actual.value.width, target.value.x, target.value.width);
          const vertical = axisGap(actual.value.y, actual.value.height, target.value.y, target.value.height);
          measured = expression.axis === "horizontal" ? horizontal : expression.axis === "vertical" ? vertical : Math.sqrt(horizontal ** 2 + vertical ** 2);
          passes = Math.abs(measured - expected.value) <= (expression.tolerance || 0);
        }
        const truth = passes ? TRUTH.TRUE : TRUTH.FALSE;
        const expectedTrace = expression.predicate === "distance" ? { state: "known", value: { distance: expected.value, axis: expression.axis, tolerance: expression.tolerance || 0, measured } } : { state: "known", value: { target: target.value, axis: expression.axis || null, tolerance: expression.tolerance || 0, measured } };
        return makeTrace(expression.predicate, truth, truth === TRUTH.TRUE ? `geometry ${expression.predicate} holds` : `geometry ${expression.predicate} does not hold`, actual, expectedTrace, geometryFactPaths);
      }
      if (expression.predicate === "component-api-valid") {
        const valid = typeof actual.value === "boolean" ? actual.value : actual.value && typeof actual.value === "object" ? actual.value.valid : void 0;
        if (typeof valid !== "boolean") {
          return makeTrace("component-api-valid", TRUTH.UNKNOWN, "component API evidence has no boolean validity", actual, expected, factPaths);
        }
        return makeTrace("component-api-valid", valid ? TRUTH.TRUE : TRUTH.FALSE, valid ? "component API is valid" : "component API is invalid", actual, { state: "known", value: true }, factPaths);
      }
      if (expression.predicate === "matches-effective-baseline") {
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("matches-effective-baseline", truth, truth === TRUTH.TRUE ? "actual value matches effective baseline" : "actual value differs from effective baseline", actual, expected, factPaths);
      }
      if (["binding-satisfies", "paint-state-satisfies"].includes(expression.predicate)) {
        if (!expected.value || typeof expected.value !== "object" || Array.isArray(expected.value)) {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "contract constraint must be an object", actual, expected, factPaths);
        }
        const truth = partialMatch(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(expression.predicate, truth, truth === TRUTH.TRUE ? "contract constraint is satisfied" : "contract constraint is not satisfied", actual, expected, factPaths);
      }
      return makeTrace(expression.predicate, TRUTH.UNKNOWN, "predicate is not implemented", actual, expected, factPaths);
    }
    function scopeApplicability(rule, snapshot) {
      const scope = rule.scope || {};
      let unknown3;
      for (const key of ["platform", "product", "channel", "pageType"]) {
        if (!scope[key]?.length) continue;
        const factPath = `page.context.${key}`;
        const actual = resolveValue2({ fact: factPath }, { unknownFacts: [] }, snapshot);
        const result = { dimension: key === "pageType" ? "page type" : key, actual, expected: scope[key], factPath };
        if (actual.state !== "known" || typeof actual.value !== "string" || !actual.value.trim()) {
          unknown3 = unknown3 || { ...result, applicability: APPLICABILITY.UNKNOWN };
          continue;
        }
        if (!scope[key].includes(actual.value)) return { ...result, applicability: APPLICABILITY.NOT_APPLICABLE };
      }
      return unknown3 || { applicability: APPLICABILITY.APPLICABLE };
    }
    function nodeIndex(snapshot) {
      return new Map(snapshot.nodes.map((node) => [node.id, node]));
    }
    function descendantsOf(root, index) {
      const result = [];
      const visit = (node) => {
        for (const childId of node.childIds || []) {
          const child = index.get(childId);
          if (!child || child.visible !== true) continue;
          result.push(child);
          visit(child);
        }
      };
      visit(root);
      return result;
    }
    function traversalNodes(root, traverse, index) {
      if (traverse === "self") return [root];
      if (traverse === "direct-children") {
        return (root.childIds || []).map((id) => index.get(id)).filter((node) => node?.visible === true);
      }
      if (traverse === "descendants") return descendantsOf(root, index);
      if (traverse === "self-and-descendants") return [root, ...descendantsOf(root, index)];
      if (traverse === "parent") {
        const parent = root.parentId ? index.get(root.parentId) : null;
        return parent?.visible === true ? [parent] : [];
      }
      if (traverse === "ancestors") {
        const result = [];
        let current = root.parentId ? index.get(root.parentId) : null;
        while (current) {
          if (current.visible === true) result.push(current);
          current = current.parentId ? index.get(current.parentId) : null;
        }
        return result;
      }
      if (traverse === "siblings") {
        const parent = root.parentId ? index.get(root.parentId) : null;
        return (parent?.childIds || []).filter((id) => id !== root.id).map((id) => index.get(id)).filter((node) => node?.visible === true);
      }
      throw capabilityError("SELECTOR_NOT_IMPLEMENTED", `Unsupported traversal: ${traverse}`);
    }
    function selectionRoots(snapshot, from, index) {
      if (from === "selection-root" || from === "self") {
        const ids = from === "self" ? snapshot.selection.slice(0, 1) : snapshot.selection;
        return ids.map((id) => index.get(id)).filter((node) => node?.visible === true);
      }
      if (from === "page-descendants") {
        return snapshot.nodes.filter((node) => node.visible === true && node.parentId === null);
      }
      throw capabilityError("SELECTOR_NOT_IMPLEMENTED", `Unsupported selector origin: ${from}`);
    }
    function selectSubjects2(rule, snapshot) {
      const index = nodeIndex(snapshot);
      const roots = selectionRoots(snapshot, rule.select.from, index);
      const candidates = roots.flatMap((root) => traversalNodes(root, rule.select.traverse, index));
      const unique = new Map(candidates.map((node) => [node.id, node]));
      const unknownNodes = [];
      const nodes = Array.from(unique.values()).filter((node) => {
        for (const expression of rule.select.where || []) {
          const result = evaluateExpression(expression, node, snapshot);
          if (result.truth === TRUTH.UNKNOWN) {
            unknownNodes.push(node);
            return false;
          }
          if (result.truth === TRUTH.FALSE) return false;
        }
        return true;
      });
      nodes.sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
      unknownNodes.sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
      return { nodes, unknown: unknownNodes.length > 0, unknownNodes, roots };
    }
    function terminalClassification(rule, truth) {
      if (truth === TRUTH.UNKNOWN) return rule.unknownPolicy;
      if (rule.effect === "allow") return truth === TRUTH.TRUE ? "allowed" : "not-applicable";
      const violation = rule.effect === "require" ? truth === TRUTH.FALSE : truth === TRUTH.TRUE;
      return violation ? "violation" : "compliant";
    }
    function evaluationId(hash2, rule, subject, trace, applicability2) {
      return stableHash2({
        snapshotHash: hash2,
        ruleId: rule.ruleId,
        ruleRevision: rule.revision,
        subjectNodeId: subject.id,
        factPaths: trace.factPaths,
        applicability: applicability2
      });
    }
    function traceNodes(trace) {
      if (!trace || typeof trace !== "object") return [];
      return [trace, ...(trace.children || []).flatMap(traceNodes)];
    }
    function normalizePlatformTrace(rule, subject, trace) {
      if (rule.presentation?.causalRole !== "platform-root") return trace;
      const componentPlatform = subject.component?.platform;
      const candidates = traceNodes(trace).filter((item) => (item.factPaths || []).includes("page.context.platform"));
      const comparison = componentPlatform === "universal" ? candidates.find((item) => item.predicate === "one-of") : candidates.find((item) => item.predicate === "equals" && (item.factPaths || []).includes("component.platform"));
      if (!comparison) return trace;
      return Object.assign({}, trace, {
        reason: "page channel compatibility evaluated",
        actual: comparison.actual,
        expected: comparison.expected
      });
    }
    function makeEvaluation(hash2, rule, subject, applicability2, classification, trace) {
      const normalizedTrace = normalizePlatformTrace(rule, subject, trace);
      return {
        evaluationId: evaluationId(hash2, rule, subject, normalizedTrace, applicability2),
        ruleId: rule.ruleId,
        ruleRevision: rule.revision,
        subjectNodeId: subject.id,
        subjectNodeName: subject.name || subject.id,
        focusNodeId: subject.id,
        focusNodeName: subject.name || subject.id,
        applicability: applicability2,
        classification,
        severity: rule.severity,
        trace: normalizedTrace,
        actionId: null
      };
    }
    function buildCoverage(evaluations) {
      const byClassification = {};
      for (const item of evaluations) {
        byClassification[item.classification] = (byClassification[item.classification] || 0) + 1;
      }
      const ids = evaluations.map((item) => item.evaluationId);
      return {
        total: evaluations.length,
        byClassification,
        unclassified: evaluations.filter((item) => !item.classification).length,
        duplicateEvaluationIds: ids.length - new Set(ids).size
      };
    }
    function isDescendantOrSelf(node, ancestorNodeId, index) {
      let current = node;
      while (current) {
        if (current.id === ancestorNodeId) return true;
        current = current.parentId ? index.get(current.parentId) : null;
      }
      return false;
    }
    function suppressPlatformDependentViolations(evaluations, rules, snapshot, hash2) {
      const index = nodeIndex(snapshot);
      const rulesById = new Map(rules.map((rule) => [rule.ruleId, rule]));
      const platformViolations = evaluations.filter((evaluation) => evaluation.classification === "violation" && rulesById.get(evaluation.ruleId)?.presentation?.causalRole === "platform-root");
      if (!platformViolations.length) return evaluations;
      return evaluations.map((evaluation) => {
        if (evaluation.classification !== "violation" || platformViolations.some((platform) => platform.evaluationId === evaluation.evaluationId) || !(evaluation.trace?.factPaths || []).includes("page.context.platform")) return evaluation;
        const subject = index.get(evaluation.subjectNodeId);
        const cause = platformViolations.find((platform) => subject && isDescendantOrSelf(subject, platform.subjectNodeId, index));
        if (!cause) return evaluation;
        const rule = rulesById.get(evaluation.ruleId);
        if (!rule) return evaluation;
        const trace = makeTrace(
          "causal-suppression",
          TRUTH.UNKNOWN,
          `platform-dependent violation is suppressed by ${cause.ruleId}`,
          { state: "known", value: evaluation.subjectNodeId },
          { state: "known", value: cause.subjectNodeId },
          ["page.context.platform"]
        );
        return Object.assign(
          makeEvaluation(
            hash2,
            rule,
            subject,
            APPLICABILITY.NOT_APPLICABLE,
            "not-applicable",
            trace
          ),
          {
            suppressedByEvaluationId: cause.evaluationId,
            suppressedByRuleId: cause.ruleId
          }
        );
      });
    }
    function causalRelationMatches(root, derived, relation, index) {
      if (relation === "same-subject") {
        return root.subjectNodeId === derived.subjectNodeId;
      }
      if (relation === "same-focus") {
        return root.focusNodeId === derived.focusNodeId;
      }
      if (relation === "descendant-subject") {
        const derivedSubject = index.get(derived.subjectNodeId);
        return Boolean(
          derivedSubject && derivedSubject.id !== root.subjectNodeId && isDescendantOrSelf(derivedSubject, root.subjectNodeId, index)
        );
      }
      return false;
    }
    function groupCausalViolations(evaluations, rules, snapshot) {
      const index = nodeIndex(snapshot);
      const rulesById = new Map(rules.map((rule) => [rule.ruleId, rule]));
      const violations = evaluations.filter((evaluation) => evaluation.classification === "violation");
      const assignmentByDerivedId = /* @__PURE__ */ new Map();
      const derivedByRootId = /* @__PURE__ */ new Map();
      const roots = violations.filter((evaluation) => rulesById.get(evaluation.ruleId)?.causality?.causes?.length).sort((left, right) => left.subjectNodeId.localeCompare(right.subjectNodeId) || left.ruleId.localeCompare(right.ruleId) || left.evaluationId.localeCompare(right.evaluationId));
      for (const root of roots) {
        const rule = rulesById.get(root.ruleId);
        for (const cause of rule.causality.causes) {
          const candidates = violations.filter((evaluation) => evaluation.evaluationId !== root.evaluationId && evaluation.ruleId === cause.ruleId && !assignmentByDerivedId.has(evaluation.evaluationId) && causalRelationMatches(root, evaluation, cause.relation, index)).sort((left, right) => left.subjectNodeId.localeCompare(right.subjectNodeId) || left.evaluationId.localeCompare(right.evaluationId));
          for (const derived of candidates) {
            assignmentByDerivedId.set(derived.evaluationId, {
              rootFindingId: root.evaluationId,
              causalGroupingReason: cause.reason
            });
            if (!derivedByRootId.has(root.evaluationId)) {
              derivedByRootId.set(root.evaluationId, []);
            }
            derivedByRootId.get(root.evaluationId).push(derived.evaluationId);
          }
        }
      }
      return evaluations.map((evaluation) => {
        const derived = assignmentByDerivedId.get(evaluation.evaluationId);
        if (derived) {
          return Object.assign({}, evaluation, derived, { derivedFindingIds: [] });
        }
        const derivedFindingIds = (derivedByRootId.get(evaluation.evaluationId) || []).slice().sort((left, right) => left.localeCompare(right));
        if (!derivedFindingIds.length) return evaluation;
        return Object.assign({}, evaluation, {
          rootFindingId: evaluation.evaluationId,
          derivedFindingIds,
          causalGroupingReason: "explicit source-rule causal relation"
        });
      });
    }
    function evaluateRules3({ snapshot, rules, ruleRelease = "unversioned" }) {
      const hash2 = snapshotHash2(snapshot);
      const evaluations = [];
      for (const ruleInput of rules) {
        const rule = validateRule(ruleInput);
        const index = nodeIndex(snapshot);
        const fallback = index.get(snapshot.selection[0]) || snapshot.nodes[0];
        if (!fallback) continue;
        if (rule.authority?.status !== "active") {
          const trace = makeTrace(rule.assert.predicate, TRUTH.UNKNOWN, "rule authority is not active", { state: "unknown" }, { state: "unknown" }, []);
          evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.UNKNOWN, "not-evaluable", trace));
          continue;
        }
        const scopeResult = scopeApplicability(rule, snapshot);
        let unknownScopeTrace;
        if (scopeResult.applicability !== APPLICABILITY.APPLICABLE) {
          const unknown3 = scopeResult.applicability === APPLICABILITY.UNKNOWN;
          const trace = makeTrace(
            "one-of",
            unknown3 ? TRUTH.UNKNOWN : TRUTH.FALSE,
            `rule ${scopeResult.dimension} scope ${unknown3 ? "is unknown" : "does not apply"}`,
            scopeResult.actual,
            { state: "known", value: scopeResult.expected },
            [scopeResult.factPath]
          );
          if (!unknown3) {
            evaluations.push(makeEvaluation(hash2, rule, fallback, scopeResult.applicability, "not-applicable", trace));
            continue;
          }
          unknownScopeTrace = trace;
        }
        const selected = selectSubjects2(rule, snapshot);
        if (selected.unknown && !selected.nodes.length) {
          const trace = makeTrace(rule.assert.predicate, TRUTH.UNKNOWN, "selector evidence is unknown", { state: "unknown" }, { state: "unknown" }, []);
          evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.UNKNOWN, rule.unknownPolicy, trace));
          continue;
        }
        if (!selected.nodes.length) {
          if (unknownScopeTrace) {
            evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.UNKNOWN, rule.unknownPolicy, unknownScopeTrace));
            continue;
          }
          const trace = makeTrace(rule.assert.predicate, TRUTH.UNKNOWN, "selector matched no visible nodes", { state: "absent" }, { state: "unknown" }, []);
          evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.NOT_APPLICABLE, "not-applicable", trace));
          continue;
        }
        for (const subject of selected.nodes) {
          if (rule.when) {
            const whenTrace = evaluateExpression(rule.when, subject, snapshot);
            if (whenTrace.truth === TRUTH.FALSE) {
              evaluations.push(makeEvaluation(hash2, rule, subject, APPLICABILITY.NOT_APPLICABLE, "not-applicable", whenTrace));
              continue;
            }
            if (whenTrace.truth === TRUTH.UNKNOWN) {
              evaluations.push(makeEvaluation(hash2, rule, subject, APPLICABILITY.UNKNOWN, rule.unknownPolicy, whenTrace));
              continue;
            }
          }
          if (unknownScopeTrace) {
            evaluations.push(makeEvaluation(hash2, rule, subject, APPLICABILITY.UNKNOWN, rule.unknownPolicy, unknownScopeTrace));
            continue;
          }
          const trace = evaluateExpression(rule.assert, subject, snapshot);
          evaluations.push(makeEvaluation(
            hash2,
            rule,
            subject,
            APPLICABILITY.APPLICABLE,
            terminalClassification(rule, trace.truth),
            trace
          ));
        }
      }
      const normalizedEvaluations = groupCausalViolations(suppressPlatformDependentViolations(
        evaluations,
        rules,
        snapshot,
        hash2
      ), rules, snapshot);
      normalizedEvaluations.sort((left, right) => left.subjectNodeId.localeCompare(right.subjectNodeId) || left.ruleId.localeCompare(right.ruleId) || left.evaluationId.localeCompare(right.evaluationId));
      return {
        schemaVersion: "apollo.predicate-result.v1",
        snapshotHash: hash2,
        ruleRelease,
        evaluations: normalizedEvaluations,
        coverage: buildCoverage(normalizedEvaluations)
      };
    }
    module2.exports = {
      APPLICABILITY,
      IMPLEMENTED_PREDICATES,
      TRUTH,
      evaluateExpression,
      evaluateRules: evaluateRules3,
      resolveValue: resolveValue2,
      selectSubjects: selectSubjects2,
      snapshotHash: snapshotHash2,
      stableHash: stableHash2,
      stableStringify: stableStringify2,
      validateRule
    };
  }
});

// src/core/index.ts
var index_exports = {};
__export(index_exports, {
  CAPABILITY_SETS: () => CAPABILITY_SETS,
  CAPABILITY_SET_LABELS: () => CAPABILITY_SET_LABELS,
  COMPILED_SCHEMA_VERSION: () => COMPILED_SCHEMA_VERSION,
  COMPONENT_DEPENDENCY_CAPTURE_LIMIT: () => COMPONENT_DEPENDENCY_CAPTURE_LIMIT,
  COMPONENT_DEPENDENCY_DEPTH_LIMIT: () => COMPONENT_DEPENDENCY_DEPTH_LIMIT,
  EDITOR_SESSION_SCHEMA_VERSION: () => EDITOR_SESSION_SCHEMA_VERSION,
  INSTANCE_CONTENT_REFERENCE_LIMIT: () => INSTANCE_CONTENT_REFERENCE_LIMIT,
  LEGACY_MANUAL_SCHEMA_VERSION: () => LEGACY_MANUAL_SCHEMA_VERSION,
  MANUAL_SCHEMA_VERSION: () => MANUAL_SCHEMA_VERSION,
  PRODUCT_SCOPE_CATALOG: () => PRODUCT_SCOPE_CATALOG,
  PROPERTY_APPLICABILITY: () => PROPERTY_APPLICABILITY,
  PROTECTED_INTERNAL_CAPABILITY_SETS: () => PROTECTED_INTERNAL_CAPABILITY_SETS,
  TARGET_RESOLUTION_SCHEMA: () => TARGET_RESOLUTION_SCHEMA,
  allowPublicComponentProperties: () => allowPublicComponentProperties,
  allowedComponentPropertyNames: () => allowedComponentPropertyNames,
  applyProtectInternalsPolicy: () => applyProtectInternalsPolicy,
  applyTargetRemap: () => applyTargetRemap,
  baselineFactsForRule: () => baselineFactsForRule,
  buildContractReadiness: () => buildContractReadiness,
  buildEditorValidationReport: () => buildEditorValidationReport,
  buildEvaluationDetails: () => buildEvaluationDetails,
  buildExportBundle: () => buildExportBundle,
  buildValidationReportDownload: () => buildValidationReportDownload,
  capabilitiesForSet: () => capabilitiesForSet,
  capabilitySetLabel: () => capabilitySetLabel,
  captureGradientPaintDetails: () => captureGradientPaintDetails,
  capturePropertyActivity: () => capturePropertyActivity,
  captureSupplementalFacts: () => captureSupplementalFacts,
  captureVariantReference: () => captureVariantReference,
  compareInstanceBoundaries: () => compareInstanceBoundaries,
  compileApplicabilityProbe: () => compileApplicabilityProbe,
  compileManualSource: () => compileManualSource,
  componentDependencyKeys: () => componentDependencyKeys,
  componentPropertyName: () => componentPropertyName,
  createEditorSession: () => createEditorSession,
  createWorkspaceFromPreview: () => createWorkspaceFromPreview,
  createZip: () => createZip,
  dependencyBinding: () => dependencyBinding,
  dependencyPinIssue: () => dependencyPinIssue,
  diagnoseRuleApplicability: () => diagnoseRuleApplicability,
  effectiveFacts: () => effectiveFacts,
  evaluateCompiledContract: () => evaluateCompiledContract,
  extractAssetCatalogs: () => extractAssetCatalogs,
  extractVariantEvidence: () => extractVariantEvidence,
  factForCapability: () => factForCapability,
  forbiddenConstraintsForEdit: () => forbiddenConstraintsForEdit,
  gradientPaintIssues: () => gradientPaintIssues,
  groupEvaluationDetails: () => groupEvaluationDetails,
  importWorkspace: () => importWorkspace,
  inspectRuleFacts: () => inspectRuleFacts,
  intrinsicBounds: () => intrinsicBounds,
  isolateInstanceBoundaries: () => isolateInstanceBoundaries,
  linkComponentDependencies: () => linkComponentDependencies,
  matchesComponentIdentity: () => matchesComponentIdentity,
  materializeDependencyFacts: () => materializeDependencyFacts,
  materializeEffectiveBaseline: () => materializeEffectiveBaseline,
  materializeGradientPaintEvidence: () => materializeGradientPaintEvidence,
  materializeInstanceContentReferences: () => materializeInstanceContentReferences,
  materializeNestedInstanceContentReferences: () => materializeNestedInstanceContentReferences,
  materializeSemanticFacts: () => materializeSemanticFacts,
  materializeTargetResolution: () => materializeTargetResolution,
  materializeVariantFacts: () => materializeVariantFacts,
  mergeEditedApplicability: () => mergeEditedApplicability,
  paintDiagnosticSummary: () => paintDiagnosticSummary,
  parseAssetCatalogs: () => parseAssetCatalogs,
  parseEditorSession: () => parseEditorSession,
  planInstanceContentReferences: () => planInstanceContentReferences,
  planNestedInstanceContentReferences: () => planNestedInstanceContentReferences,
  planTargetRemap: () => planTargetRemap,
  prepareAuthoringPreviewContract: () => prepareAuthoringPreviewContract,
  prepareValidationSnapshot: () => prepareValidationSnapshot,
  propertyApplicabilityCondition: () => propertyApplicabilityCondition,
  propertyAvailabilityKey: () => propertyAvailabilityKey,
  readZip: () => readZip,
  relativeTargetPath: () => relativeTargetPath,
  resolveFixedNestedBinding: () => resolveFixedNestedBinding,
  resolveSnapshotTargets: () => resolveSnapshotTargets,
  sameManualComponentFamily: () => sameManualComponentFamily,
  samePreviewComponent: () => samePreviewComponent,
  slug: () => slug,
  snapshotShape: () => snapshotShape,
  stableHash: () => stableHash,
  stableStringify: () => stableStringify,
  supportedSemanticBinding: () => supportedSemanticBinding,
  targetResolutionReason: () => targetResolutionReason,
  textZipEntry: () => textZipEntry,
  uniqueSorted: () => uniqueSorted,
  validateComponentDependencies: () => validateComponentDependencies,
  validateManualSource: () => validateManualSource,
  validateRuleEdit: () => validateRuleEdit,
  validatedDependencyCapture: () => validatedDependencyCapture,
  validationIssueLabel: () => validationIssueLabel,
  validationSnapshotHash: () => validationSnapshotHash,
  variantAvailability: () => variantAvailability,
  withinBoundary: () => withinBoundary,
  zipEntryText: () => zipEntryText
});
module.exports = __toCommonJS(index_exports);

// src/core/types.ts
var LEGACY_MANUAL_SCHEMA_VERSION = "apollo.component-contract.manual.v1-experimental";
var MANUAL_SCHEMA_VERSION = "apollo.component-contract.manual.v2-experimental";
var COMPILED_SCHEMA_VERSION = "apollo.component-contract.v2.1-experimental";

// src/core/capabilities.ts
var CAPABILITY_SETS = {
  "fill@1": [
    "appearance.fill",
    "appearance.fillStyleId"
  ],
  "stroke@1": [
    "appearance.stroke",
    "appearance.strokeStyleId",
    "appearance.strokeWeight",
    "appearance.strokeAlign",
    "appearance.dashPattern"
  ],
  "radius@1": [
    "appearance.radius"
  ],
  "effects@1": [
    "appearance.effects",
    "appearance.effectStyleId"
  ],
  "visual-style@1": [
    "appearance.fill",
    "appearance.stroke",
    "appearance.opacity",
    "appearance.radius",
    "appearance.effects"
  ],
  "auto-layout@1": [
    "layout.mode",
    "layout.padding.top",
    "layout.padding.right",
    "layout.padding.bottom",
    "layout.padding.left",
    "layout.itemSpacing",
    "layout.primaryAxisAlignItems",
    "layout.counterAxisAlignItems",
    "layout.sizingHorizontal",
    "layout.sizingVertical"
  ]
};
var CAPABILITY_SET_LABELS = {
  "fill@1": "\u0417\u0430\u043B\u0438\u0432\u043A\u0430",
  "stroke@1": "\u041E\u0431\u0432\u043E\u0434\u043A\u0430",
  "auto-layout@1": "\u0410\u0432\u0442\u043E\u043B\u0435\u0439\u0430\u0443\u0442",
  "radius@1": "\u0421\u043A\u0440\u0443\u0433\u043B\u0435\u043D\u0438\u0435",
  "effects@1": "\u042D\u0444\u0444\u0435\u043A\u0442\u044B",
  "visual-style@1": "\u0412\u043D\u0435\u0448\u043D\u0438\u0439 \u0432\u0438\u0434"
};
function capabilitiesForSet(capabilitySet) {
  return capabilitySet ? CAPABILITY_SETS[capabilitySet] || [] : [];
}
function factForCapability(capability) {
  if (capability.startsWith("component-property.")) return `component.properties.${capability.slice("component-property.".length)}`;
  if (capability === "visibility") return "visible";
  if (capability === "token.binding") return "variable.bindings";
  return capability;
}
function capabilitySetLabel(capabilitySet) {
  return capabilitySet ? CAPABILITY_SET_LABELS[capabilitySet] || capabilitySet : "";
}

// src/core/property-applicability.ts
var PROPERTY_APPLICABILITY = {
  "appearance.strokeWeight": "stroke-present-either@1",
  "layout.itemSpacing": "flow-gap-either@1",
  "layout.padding.top": "auto-layout-padding-either@1",
  "layout.padding.right": "auto-layout-padding-either@1",
  "layout.padding.bottom": "auto-layout-padding-either@1",
  "layout.padding.left": "auto-layout-padding-either@1",
  "layout.primaryAxisAlignItems": "flow-alignment-either@1",
  "layout.counterAxisAlignItems": "flow-alignment-either@1"
};
var ACTIVITY_FIELDS = {
  "stroke-present-either@1": "strokePresent",
  "flow-gap-either@1": "gapApplicable",
  "auto-layout-padding-either@1": "paddingApplicable",
  "flow-alignment-either@1": "axisAlignmentApplicable"
};
function baselineFactsForRule(rule) {
  const capabilities = rule.capabilitySet ? capabilitiesForSet(rule.capabilitySet).filter((c) => !rule.capabilitySelection || rule.capabilitySelection.includes(c)) : [rule.capability];
  const constraints = rule.permission === "forbidden" && !rule.constraints.length ? [{ type: "propertyForbidden" }] : rule.constraints;
  return [...new Set(capabilities.flatMap((c) => constraints.filter((x) => x.type === "propertyForbidden").map((x) => "fact" in x && x.fact || factForCapability(c))))];
}
function propertyApplicabilityCondition(rule, fact) {
  const policy = rule.propertyApplicability?.[fact];
  if (!policy) return;
  const field = ACTIVITY_FIELDS[policy];
  if (!field) throw new Error(`Unsupported property applicability: ${policy}`);
  return { predicate: "any", args: ["", "baseline.effective."].map((prefix) => ({
    predicate: "equals",
    actual: { fact: `${prefix}propertyActivityV1.${field}` },
    expected: { literal: true },
    missingPolicy: "unknown"
  })) };
}
function capturePropertyActivity(node) {
  const result = {};
  try {
    if (Array.isArray(node.strokes)) result.strokePresent = node.strokes.length > 0;
  } catch {
  }
  try {
    const mode = node.layoutMode;
    if (mode === "HORIZONTAL" || mode === "VERTICAL" || mode === "GRID") {
      result.paddingApplicable = true;
      result.axisAlignmentApplicable = mode !== "GRID";
    } else if (mode === "NONE") {
      result.paddingApplicable = false;
      result.axisAlignmentApplicable = false;
    }
    if (mode === "NONE" || mode === "GRID") result.gapApplicable = false;
    else if (mode === "HORIZONTAL" || mode === "VERTICAL") {
      if (!Array.isArray(node.children)) return result;
      let certain = 0, possible = 0;
      for (const child of node.children) {
        try {
          const visible = child.visible, positioning = child.layoutPositioning;
          if (visible === false || positioning === "ABSOLUTE") continue;
          possible++;
          if (visible === true && positioning === "AUTO") certain++;
        } catch {
          possible++;
        }
      }
      if (certain >= 2) result.gapApplicable = true;
      else if (possible < 2) result.gapApplicable = false;
    } else if (["GROUP", "BOOLEAN_OPERATION", "VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "TEXT"].includes(String(node.type))) {
      result.gapApplicable = false;
      result.paddingApplicable = false;
      result.axisAlignmentApplicable = false;
    }
  } catch {
  }
  return result;
}

// src/core/stable.ts
init_sha256();
function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    const object = value;
    return `{${Object.keys(object).filter((key) => object[key] !== void 0).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(object[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}
function stableHash(value) {
  return sha256Hex(stableStringify(value));
}
function slug(value) {
  const normalized = value.replace(/^\s*(?:❌|🔒|🔄)?\s*\[[DMT]\]\s*/u, "").replace(/([a-z\d])([A-Z])/g, "$1-$2").normalize("NFKD").replace(/[^a-zA-Z0-9а-яА-ЯёЁ]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase();
  return normalized || "target";
}
function uniqueSorted(values) {
  return Array.from(new Set(values.filter(Boolean))).sort((left, right) => left.localeCompare(right));
}

// src/core/snapshot-topology.ts
function snapshotPaths(snapshot) {
  if (snapshot.selection.length !== 1 || snapshot.source?.truncated !== false) return void 0;
  const byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  if (byId.size !== snapshot.nodes.length) return void 0;
  const root = byId.get(snapshot.selection[0]);
  if (!root || root.parentId !== null) return void 0;
  const paths = /* @__PURE__ */ new Map();
  const pathFor = (node, visited = /* @__PURE__ */ new Set()) => {
    const id = String(node.id);
    if (visited.has(id)) return void 0;
    visited.add(id);
    if (node === root) return "";
    const parent = byId.get(String(node.parentId));
    if (!parent || !Array.isArray(parent.childIds) || !parent.childIds.includes(id)) return void 0;
    const parentPath2 = pathFor(parent, visited);
    return parentPath2 === void 0 || typeof node.name !== "string" ? void 0 : [parentPath2, node.name].filter(Boolean).join(" / ");
  };
  for (const node of snapshot.nodes) {
    const path = pathFor(node);
    if (path === void 0 || [...paths.values()].includes(path)) return void 0;
    paths.set(String(node.id), path);
    if (!Array.isArray(node.childIds) || node.childIds.some((id) => !byId.has(String(id)) || byId.get(String(id))?.parentId !== node.id)) return void 0;
  }
  return paths;
}
function snapshotShape(snapshot) {
  const paths = snapshotPaths(snapshot);
  return paths && snapshot.nodes.map((n) => ({ path: paths.get(String(n.id)), type: paths.get(String(n.id)) === "" ? "ROOT" : String(n.type) })).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
}

// src/core/instance-boundaries.ts
var record = (value) => value && typeof value === "object" ? value : {};
var parentPath = (path) => path.split(" / ").slice(0, -1).join(" / ");
var withinBoundary = (path, boundary) => path === boundary || path.startsWith(`${boundary} / `);
function compareInstanceBoundaries(snapshot, reference, nestedVariants = ["apollo.instance-content-references.v2", "apollo.instance-content-references.v3", "apollo.instance-content-references.v4"].includes(snapshot.instanceContentReferences?.schemaVersion || "")) {
  const paths = snapshotPaths(snapshot), shape = snapshotShape(snapshot);
  const boundaries = [];
  const invalid = () => ({ complete: false, boundaries });
  if (!paths || !shape || !reference.complete) return invalid();
  if (!snapshot.source?.componentKey || reference.componentKey !== snapshot.source.componentKey || reference.componentSetKey !== (snapshot.source.componentSetKey || "")) return invalid();
  const actualByPath = new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
  const refByPath = new Map(reference.nodes.map((n) => [n.path, n]));
  if (refByPath.size !== reference.nodes.length) return invalid();
  const ownerFor = (path, nodes) => {
    let parent = parentPath(path);
    while (parent) {
      if (nodes.get(parent)?.type === "INSTANCE") return parent;
      parent = parentPath(parent);
    }
    return "";
  };
  const actualPort = (path) => {
    const node = actualByPath.get(path), component = record(node?.component);
    const property = record(component.propertyReferenceBindings).mainComponent;
    const ownerPath = ownerFor(path, actualByPath), owner = record(actualByPath.get(ownerPath)?.component);
    if (typeof property !== "string" || record(owner.propertyTypes)[property] !== "INSTANCE_SWAP" || typeof record(component.identity).mainComponentId !== "string" || record(owner.properties)[property] !== record(component.identity).mainComponentId) return void 0;
    return { ownerPath, property };
  };
  const referencePort = (path) => {
    const data = reference.nodeProperties[path], property = data?.propertyReferenceBindings?.mainComponent;
    const ownerPath = ownerFor(path, refByPath), owner = reference.nodeProperties[ownerPath];
    if (!property || owner?.propertyTypes[property] !== "INSTANCE_SWAP" || !data?.identity?.mainComponentId || owner.properties[property] !== data.identity.mainComponentId) return void 0;
    return { ownerPath, property };
  };
  const instances = [...actualByPath].filter(([path, n]) => path && n.type === "INSTANCE").sort(([a], [b]) => a.split(" / ").length - b.split(" / ").length);
  for (const [path, node] of instances) {
    if (boundaries.some((b) => withinBoundary(path, b.actualPath))) continue;
    const identity = record(record(node.component).identity), port = actualPort(path);
    let refPath = refByPath.get(path)?.type === "INSTANCE" ? path : void 0;
    if (port) {
      const consumers = instances.filter(([p]) => {
        const other = actualPort(p);
        return other?.ownerPath === port.ownerPath && other.property === port.property;
      });
      const candidates = reference.nodes.filter((n) => {
        if (n.type !== "INSTANCE") return false;
        const other = referencePort(n.path);
        return other?.ownerPath === port.ownerPath && other.property === port.property;
      });
      if (consumers.length !== 1 || candidates.length !== 1 || parentPath(candidates[0].path) !== parentPath(path)) return invalid();
      refPath = candidates[0].path;
    }
    if (refPath === void 0) return invalid();
    const expected = reference.nodeProperties[refPath]?.identity;
    const keysKnown = typeof identity.componentKey === "string" && Boolean(identity.componentKey) && Boolean(expected?.componentKey);
    if (keysKnown && identity.componentKey === expected.componentKey && path === refPath) continue;
    const sameSet = nestedVariants && keysKnown && !port && path === refPath && typeof identity.componentSetKey === "string" && Boolean(identity.componentSetKey) && identity.componentSetKey === expected?.componentSetKey;
    boundaries.push({
      nodeId: String(node.id),
      actualPath: path,
      referencePath: refPath,
      reason: !keysKnown ? "instance-identity-unavailable" : port ? "instance-swap" : sameSet ? "component-variant-changed" : "component-identity-changed",
      ...sameSet ? { componentSetKey: identity.componentSetKey } : {},
      ...identity.componentKey ? { actualComponentKey: identity.componentKey } : {},
      ...expected?.componentKey ? { referenceComponentKey: expected.componentKey } : {},
      ...port || {}
    });
  }
  const prune = (nodes, actual) => nodes.flatMap((n) => {
    const boundary = boundaries.find((b) => withinBoundary(n.path, actual ? b.actualPath : b.referencePath));
    if (!boundary) return [n];
    if (n.path !== (actual ? boundary.actualPath : boundary.referencePath)) return [];
    return [{ path: boundary.referencePath, type: "INSTANCE" }];
  }).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
  return { complete: stableHash(prune(shape, true)) === stableHash(prune(reference.nodes, false)), boundaries };
}
function isolateInstanceBoundaries(snapshot, boundaries) {
  const paths = snapshotPaths(snapshot);
  if (!paths) return;
  snapshot.instanceBoundaries = boundaries;
  for (const node of snapshot.nodes) {
    const path = paths.get(String(node.id));
    const boundary = boundaries.find((b) => withinBoundary(path, b.actualPath));
    if (!boundary) continue;
    node.baseline = { effective: {} };
    node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
    if (node.semantic && typeof node.semantic === "object") delete node.semantic.role;
  }
}

// src/core/variant-facts.ts
var record2 = (x) => x && typeof x === "object" && !Array.isArray(x) ? x : {};
var relativeTargetPath = (path) => path.split(" / ").slice(1).join(" / ");
var propertyAvailabilityKey = (name) => `p_${stableHash(name).slice(0, 16)}`;
var normalizedType = (type, path) => path === "" ? "ROOT" : type;
var ordered = (nodes) => nodes.slice().sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
function extractVariantEvidence(candidates) {
  const structures = {};
  const variants = [];
  for (const candidate of candidates) {
    const f = record2(candidate.figma);
    if (!Array.isArray(f.structureSignature) || !Array.isArray(f.variants?.variantKeys)) continue;
    const base = f.structureSignature;
    for (const variant of f.variants.variantKeys) {
      const patches = variant.key === f.defaultVariantKey ? [] : f.variantStructures?.[variant.key];
      if (!Array.isArray(patches)) continue;
      const tree = new Map(base.map((node) => [String(node.nodeId), { ...node }]));
      let valid = true;
      for (const patch of patches) {
        const id = String(patch.id);
        if (patch.op === "remove") {
          if (!tree.delete(id)) valid = false;
        } else if (patch.op === "update" && tree.has(id)) tree.set(id, { ...tree.get(id), ...patch.value });
        else if (patch.op === "add" && !tree.has(id) && patch.value) tree.set(id, { ...patch.value, nodeId: patch.id });
        else valid = false;
      }
      const pathFor = (id, visited = /* @__PURE__ */ new Set()) => {
        if (visited.has(id)) return void 0;
        visited.add(id);
        const node = tree.get(id);
        if (!node) return void 0;
        if (node.parentId === null) return "";
        const parent = pathFor(String(node.parentId), visited);
        return parent === void 0 || typeof node.name !== "string" ? void 0 : [parent, node.name].filter(Boolean).join(" / ");
      };
      const nodes = [...tree].map(([id, node]) => ({ path: pathFor(id), type: node.type }));
      if (!valid || nodes.some((n) => n.path === void 0 || !n.type) || nodes.filter((n) => n.path === "").length !== 1 || new Set(nodes.map((n) => n.path)).size !== nodes.length || !variant.key || !candidate.componentKey) continue;
      const shape = ordered(nodes.map((n) => ({ path: n.path, type: normalizedType(n.type, n.path) })));
      const structureId = stableHash(shape);
      structures[structureId] = shape;
      variants.push({ componentKey: variant.key, componentSetKey: String(candidate.componentKey), structureId, properties: variant.properties || {} });
    }
  }
  if (!variants.length) return void 0;
  return { schemaVersion: "apollo.variant-anatomy.v1", sourceHash: stableHash(candidates), structures, variants };
}
function captureVariantReference(snapshot, componentKey, componentSetKey, definedProperties) {
  const shape = snapshotShape(snapshot);
  const root = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const component = record2(root?.component);
  const referencesKnown = snapshot.nodes.every((n) => Array.isArray(record2(n.component).propertyReferences));
  const byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  const consumers = /* @__PURE__ */ new Map();
  for (const node of snapshot.nodes) {
    let parent = byId.get(String(node.parentId));
    const visited = /* @__PURE__ */ new Set();
    while (parent && !visited.has(String(parent.id))) {
      visited.add(String(parent.id));
      if (parent.type === "INSTANCE") {
        const names = consumers.get(String(parent.id)) || /* @__PURE__ */ new Set();
        (record2(node.component).propertyReferences || []).forEach((name) => names.add(name));
        consumers.set(String(parent.id), names);
        break;
      }
      parent = byId.get(String(parent.parentId));
    }
  }
  const nodeProperties2 = {};
  for (const node of snapshot.nodes) {
    const component2 = record2(node.component);
    const path = node === root ? "" : relativeTargetPath(String(record2(node.semantic).path || ""));
    nodeProperties2[path] = {
      properties: component2.properties || {},
      propertyTypes: component2.propertyTypes || {},
      propertyReferences: [...consumers.get(String(node.id)) || []],
      ...component2.identity?.componentKey ? { identity: component2.identity } : {},
      ...component2.propertyReferenceBindings ? { propertyReferenceBindings: component2.propertyReferenceBindings } : {},
      ...node === root && definedProperties ? { definedProperties } : {}
    };
  }
  return {
    componentKey,
    componentSetKey,
    complete: Boolean(shape && referencesKnown),
    nodes: shape || [],
    properties: component.properties || {},
    propertyTypes: component.propertyTypes || {},
    propertyReferences: [...consumers.get(String(root?.id)) || []],
    nodeProperties: nodeProperties2,
    ...definedProperties ? { definedProperties } : {}
  };
}
function variantAvailability(snapshot, contract) {
  const unknown3 = (reason) => ({ status: "unknown", reason, targets: {} });
  const evidence = contract.facts.variantEvidence, ref = snapshot.variantReference;
  if (!evidence || !ref?.complete || !snapshotShape(snapshot)) return unknown3("incomplete-variant-evidence");
  if (ref.componentKey !== snapshot.source?.componentKey || ref.componentSetKey !== snapshot.source?.componentSetKey) return unknown3("reference-identity-mismatch");
  const variants = evidence.variants.filter((v) => v.componentKey === ref.componentKey && v.componentSetKey === ref.componentSetKey);
  if (variants.length !== 1) return unknown3("variant-key-unresolved");
  const variant = variants[0], shape = evidence.structures[variant.structureId];
  if (!shape || stableHash(ordered(ref.nodes)) !== stableHash(shape)) return unknown3("reference-catalog-structure-drift");
  const scoped = ["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "");
  const comparison = scoped ? compareInstanceBoundaries(snapshot, ref) : void 0;
  if (scoped ? !comparison?.complete : stableHash(snapshotShape(snapshot)) !== stableHash(shape)) return unknown3("instance-structure-needs-remap");
  const root = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  if (Object.entries(variant.properties).some(([key, value]) => record2(record2(root?.component).properties)[key] !== value || ref.properties[key] !== value)) return unknown3("variant-properties-mismatch");
  const reps = contract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && r.platform === snapshot.context.platform && [r.locator.componentKey, r.locator.componentSetKey].includes(ref.componentSetKey));
  if (reps.length !== 1) return unknown3("representation-unresolved");
  const targets = {};
  const siblings = evidence.variants.filter((v) => v.componentSetKey === variant.componentSetKey);
  for (const target of contract.facts.targets) {
    const hint = target.representationHints?.find((h) => h.representationId === reps[0].id)?.pathHint || target.pathHint;
    const path = hint ? relativeTargetPath(hint) : void 0;
    const witnessed = path !== void 0 && siblings.some((v) => evidence.structures[v.structureId]?.some((n) => n.path === path));
    const isolated = path !== void 0 && comparison?.boundaries.some((b) => withinBoundary(path, b.referencePath) || withinBoundary(path, b.actualPath));
    targets[target.semanticRole] = !witnessed || isolated || target.resolution === "ambiguous" || target.resolution === "unknown" ? { state: "unknown" } : { state: shape.some((n) => n.path === path) ? "present" : "absent", path };
  }
  for (const target of Object.values(targets)) {
    if (target.path !== void 0 && Object.values(targets).filter((t) => t.path === target.path).length > 1) target.state = "unknown";
  }
  return {
    status: comparison?.boundaries.length ? "partial" : "verified",
    reason: comparison?.boundaries.length ? "verified-outside-instance-boundaries" : "catalog-and-live-reference-agree",
    targets,
    ...scoped ? { boundaries: comparison.boundaries } : {}
  };
}
function materializeVariantFacts(snapshot, contract) {
  const availability = variantAvailability(snapshot, contract);
  const scoped = ["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "");
  if (scoped) {
    delete snapshot.instanceBoundaries;
    isolateInstanceBoundaries(snapshot, availability.boundaries || []);
  }
  const ref = snapshot.variantReference;
  const root = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const rootPath = record2(root?.semantic).path;
  const byPath2 = /* @__PURE__ */ new Map();
  const structuralPaths = scoped ? snapshotPaths(snapshot) : void 0;
  for (const node of snapshot.nodes) {
    const path = structuralPaths?.get(String(node.id)) ?? (node === root ? "" : relativeTargetPath(String(record2(node.semantic).path || "")));
    if (node !== root && !record2(node.semantic).path?.startsWith(`${rootPath} / `)) continue;
    byPath2.set(path, [...byPath2.get(path) || [], node]);
  }
  const targetFacts = {};
  const properties = {};
  const propertyAvailable = (name, data) => {
    const type = data.propertyTypes[name];
    if (type === "VARIANT") return true;
    if (["BOOLEAN", "TEXT", "INSTANCE_SWAP"].includes(String(type))) return data.propertyReferences.includes(name);
    if (!Object.prototype.hasOwnProperty.call(data.properties, name) && data.definedProperties?.includes(name)) return false;
    return void 0;
  };
  for (const [role, target] of Object.entries(availability.targets)) {
    if (target.state === "unknown" || target.path === void 0) continue;
    const actual = byPath2.get(target.path) || [];
    if (actual.length === 1) {
      record2(actual[0].semantic).role = role;
      targetFacts[role] = { present: true, referenceState: target.state };
    } else if (actual.length === 0 && target.state === "absent") targetFacts[role] = { present: false, referenceState: "absent" };
  }
  if (availability.status !== "unknown" && ref) {
    const reps = contract.facts.representations.filter((r) => r.kind === "figma" && r.platform === snapshot.context.platform && [r.locator.componentKey, r.locator.componentSetKey].includes(ref.componentSetKey));
    for (const property of contract.facts.semanticApi) {
      const bindings = property.bindings.filter((b) => b.representationId === reps[0]?.id && b.path.startsWith("component.properties."));
      if (bindings.length !== 1) continue;
      const name = bindings[0].path.slice("component.properties.".length);
      const supported = propertyAvailable(name, ref);
      if (supported !== void 0) properties[property.id] = supported;
    }
  }
  for (const node of snapshot.nodes) {
    const componentProperties = {};
    const path = structuralPaths?.get(String(node.id)) ?? (node === root ? "" : relativeTargetPath(String(record2(node.semantic).path || "")));
    const isolated = availability.boundaries?.some((b) => withinBoundary(path, b.actualPath));
    const reference = availability.status !== "unknown" && !isolated ? ref?.nodeProperties?.[path] : void 0;
    if (reference) {
      const names = /* @__PURE__ */ new Set([...Object.keys(reference.properties), ...contract.capabilities.facts.filter((f) => f.startsWith("component.properties.")).map((f) => f.slice("component.properties.".length))]);
      for (const name of names) {
        const supported = propertyAvailable(name, reference);
        if (supported !== void 0) componentProperties[propertyAvailabilityKey(name)] = supported;
      }
    }
    node.variantAvailability = { ...availability, targets: targetFacts, properties, componentProperties, isRoot: node === root };
    const unknown3 = new Set((node.unknownFacts || []).filter((p) => !p.startsWith("variantAvailability.")));
    for (const target of contract.facts.targets) {
      if (targetFacts[target.semanticRole]?.present === void 0) unknown3.add(`variantAvailability.targets.${target.semanticRole}.present`);
    }
    for (const property of contract.facts.semanticApi) {
      if (properties[property.id] === void 0) unknown3.add(`variantAvailability.properties.${property.id}`);
    }
    for (const fact of contract.capabilities.facts.filter((f) => f.startsWith("variantAvailability.componentProperties."))) {
      if (componentProperties[fact.slice("variantAvailability.componentProperties.".length)] === void 0) unknown3.add(fact);
    }
    node.unknownFacts = [...unknown3];
  }
}

// src/core/instance-validation.ts
var EFFECTIVE_FACT_KEYS = [
  "layout",
  "appearance",
  "variable",
  "component",
  "text",
  "visible"
];
function record3(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function semanticRole(node) {
  const semantic = record3(node.semantic);
  return typeof semantic.role === "string" ? semantic.role : "";
}
function intrinsicBounds(value) {
  const bounds = record3(value), result = {};
  for (const key of ["width", "height"]) {
    const size = bounds[key];
    if (typeof size === "number" && Number.isFinite(size) && size >= 0) result[key] = size;
  }
  return result;
}
function effectiveFacts(node, includeDimensions = false) {
  const result = {};
  EFFECTIVE_FACT_KEYS.forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(node, key)) result[key] = node[key];
  });
  if (includeDimensions) {
    const bounds = intrinsicBounds(node.bounds);
    if (Object.keys(bounds).length) result.bounds = bounds;
    if (node.propertyActivityV1) result.propertyActivityV1 = node.propertyActivityV1;
  }
  return result;
}
function cloneSnapshot(snapshot) {
  return JSON.parse(JSON.stringify(snapshot));
}
function materializeEffectiveBaseline(actual, reference, strictInstanceBoundaries = true) {
  const result = cloneSnapshot(actual);
  if (strictInstanceBoundaries) {
    const actualPaths = snapshotPaths(actual), referencePaths = snapshotPaths(reference);
    const ref = captureVariantReference(reference, reference.source?.componentKey || "", reference.source?.componentSetKey || "");
    const comparison = compareInstanceBoundaries(actual, ref);
    const byPath2 = new Map(reference.nodes.map((node) => [referencePaths?.get(String(node.id)), node]));
    const unmatchedNodeIds2 = [];
    let matchedNodes2 = 0;
    result.nodes = result.nodes.map((node) => {
      const path = actualPaths?.get(String(node.id));
      const isolated = path !== void 0 && comparison.boundaries.find((b) => withinBoundary(path, b.actualPath));
      const expected = path !== void 0 && comparison.complete && !isolated ? byPath2.get(path) : void 0;
      if (!expected || expected.type !== node.type) {
        unmatchedNodeIds2.push(String(node.id));
        return { ...node, baseline: { effective: {} }, baselineProvenance: { status: "unresolved", reason: isolated ? isolated.reason : "structural-identity-unresolved" } };
      }
      matchedNodes2++;
      return { ...node, baseline: { effective: effectiveFacts(expected, true) }, baselineProvenance: { status: "matched", referencePath: path } };
    });
    return { snapshot: result, matchedNodes: matchedNodes2, unmatchedNodeIds: unmatchedNodeIds2 };
  }
  const referenceByRole = /* @__PURE__ */ new Map();
  reference.nodes.forEach((candidate) => {
    const node = record3(candidate);
    const role = semanticRole(node);
    if (role && !referenceByRole.has(role)) referenceByRole.set(role, node);
  });
  let matchedNodes = 0;
  const unmatchedNodeIds = [];
  result.nodes = result.nodes.map((candidate, index) => {
    const node = record3(candidate);
    const role = semanticRole(node);
    const referenceNode = referenceByRole.get(role) || (index === 0 ? record3(reference.nodes[0]) : void 0);
    if (!referenceNode || referenceNode.type !== node.type) {
      unmatchedNodeIds.push(String(node.id || `node:${index}`));
      return { ...node, baseline: { effective: {} } };
    }
    matchedNodes += 1;
    return {
      ...node,
      baseline: { effective: effectiveFacts(referenceNode, true) }
    };
  });
  return { snapshot: result, matchedNodes, unmatchedNodeIds };
}
function allowedComponentPropertyNames(contract) {
  const names = /* @__PURE__ */ new Set();
  contract.customizationPolicy.forEach((policy) => {
    if (policy.permission === "forbidden") return;
    const prefixes = ["component.properties.", "component-property."];
    const prefix = prefixes.find((candidate) => policy.capability.startsWith(candidate));
    if (prefix) names.add(policy.capability.slice(prefix.length));
    policy.controlPaths.forEach((path) => {
      if ((path.kind === "host-property" || path.kind === "nested-property") && path.property) {
        names.add(path.property);
      }
    });
  });
  return Array.from(names).sort((left, right) => left.localeCompare(right));
}
function matchesComponentIdentity(mainComponentKey, componentSetKey, acceptedKeys) {
  const accepted = new Set(acceptedKeys.filter(Boolean));
  return accepted.has(mainComponentKey) || Boolean(componentSetKey && accepted.has(componentSetKey));
}

// src/core/component-dependencies.ts
var record4 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var COMPONENT_DEPENDENCY_CAPTURE_LIMIT = 8;
var COMPONENT_DEPENDENCY_DEPTH_LIMIT = 4;
var hash = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
var pathValid = (v) => typeof v === "string" && !v.split(" / ").some((p) => p === ".." || p === "." || p.includes("*") || !p && v !== "");
function validateComponentDependencies(manual) {
  const issues = [], ids = /* @__PURE__ */ new Set();
  const fail = (index, message) => issues.push({ level: "error", code: "COMPONENT_DEPENDENCY", path: `/componentDependencies/${index}`, message });
  if (manual.componentDependencies === void 0) return issues;
  if (!Array.isArray(manual.componentDependencies)) return [{ level: "error", code: "COMPONENT_DEPENDENCY", path: "/componentDependencies", message: "Expected dependency pins and fixed nested bindings." }];
  for (const [i, d] of manual.componentDependencies.entries()) {
    if (!d || !/^[a-z][a-z0-9-]*$/.test(d.id) || ids.has(d.id)) {
      fail(i, "Dependency id must be unique and path-safe.");
      continue;
    }
    ids.add(d.id);
    if (!/^[a-z][a-z0-9.-]*$/.test(d.componentId || "") || d.componentId === manual.component.componentId || !Number.isInteger(d.revision) || d.revision < 1 || !hash(d.manualSourceHash) || !hash(d.compiledHash)) fail(i, "Pin another component by componentId, revision and both SHA-256 hashes.");
    if (!Array.isArray(d.bindings) || !d.bindings.length) {
      fail(i, "Declare at least one fixed nested binding.");
      continue;
    }
    const bindings = /* @__PURE__ */ new Set(), subjects = /* @__PURE__ */ new Set();
    for (const b of d.bindings) {
      if (!b || !/^[a-z][a-z0-9-]*$/.test(b.id) || bindings.has(b.id)) {
        fail(i, "Binding id must be unique and path-safe.");
        continue;
      }
      bindings.add(b.id);
      const subject = JSON.stringify([b.targetRole, b.relativePath]);
      if (subjects.has(subject)) fail(i, "Duplicate nested subject.");
      subjects.add(subject);
      if (manual.targets.filter((t) => t.semanticRole === b.targetRole && t.resolution === "resolved").length !== 1) fail(i, `Unresolved target: ${b.targetRole}.`);
      if (!pathValid(b.relativePath) || !pathValid(b.childPath) || !b.childPath) fail(i, "Use exact relative owner/child paths.");
      if (!Array.isArray(b.ownerComponentSetKeys) || !b.ownerComponentSetKeys.length || b.ownerComponentSetKeys.some((k) => !k)) fail(i, "Owner component set keys are required.");
      if (!b.activeVariant?.property || !Array.isArray(b.activeVariant.values) || !b.activeVariant.values.length || b.activeVariant.values.some((v) => typeof v !== "string" || !v)) fail(i, "Declare the typed owner VARIANT activation.");
    }
  }
  return issues;
}
function dependencyPinIssue(pin, contract) {
  if (!contract) return "dependency-contract-missing";
  if (contract.documentType !== "component-contract" || contract.schemaVersion !== "apollo.component-contract.v2.1-experimental") return "dependency-schema-unsupported";
  if (contract.package?.componentId !== pin.componentId) return "dependency-component-mismatch";
  if (!Array.isArray(contract.rules) || !Array.isArray(contract.facts?.representations) || !Array.isArray(contract.nonExecutableRules) || !Array.isArray(contract.customizationPolicy)) return "dependency-contract-malformed";
  const revisions = [...new Set(contract.rules.map((r) => r.revision))];
  const revision = contract.package.manualRevision ?? (revisions.length === 1 ? revisions[0] : void 0);
  if (revision !== pin.revision || contract.package.manualSourceHash !== pin.manualSourceHash || stableHash(contract) !== pin.compiledHash) return "dependency-pin-mismatch";
  if (contract.runtimePolicy?.engine !== "apollo-predicate-engine" || contract.runtimePolicy?.unknownPolicy !== "fail-closed") return "dependency-runtime-unsupported";
  return void 0;
}
function linkComponentDependencies(manual, inputs) {
  const visit = (d, ancestors, depth) => {
    if (ancestors.includes(d.componentId)) return "dependency-cycle";
    if (depth > COMPONENT_DEPENDENCY_DEPTH_LIMIT) return "dependency-depth-limit";
    const issue = dependencyPinIssue(d, d.contract);
    if (issue) return issue;
    for (const child of d.contract.componentDependencies || []) {
      const nested = visit(child, [...ancestors, d.componentId], depth + 1);
      if (nested) return nested;
    }
    return void 0;
  };
  const pins = Array.isArray(manual.componentDependencies) ? manual.componentDependencies : [];
  return pins.filter((d) => d && Array.isArray(d.bindings)).map((pin) => {
    const candidates = inputs.filter((c) => c?.package?.componentId === pin.componentId);
    const contract = candidates.length === 1 ? candidates[0] : void 0;
    const d = { ...pin, ...contract ? { contract } : {} };
    const issue = candidates.length > 1 ? "dependency-version-conflict" : visit(d, [manual.component.componentId], 1);
    return { ...d, ...issue ? { issue } : {} };
  });
}
function componentDependencyKeys(contract) {
  const keys = /* @__PURE__ */ new Set();
  const visit = (c, depth) => {
    if (depth > COMPONENT_DEPENDENCY_DEPTH_LIMIT) return;
    for (const d of c.componentDependencies || []) if (!d.issue && d.contract && !dependencyPinIssue(d, d.contract)) {
      d.contract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated").forEach((r) => [r.locator.componentKey, r.locator.componentSetKey].forEach((k) => {
        if (typeof k === "string" && k) keys.add(k);
      }));
      visit(d.contract, depth + 1);
    }
  };
  visit(contract, 0);
  return [...keys].sort();
}
function resolveFixedNestedBinding(snapshot, d, b) {
  const unknown3 = (reason) => ({ status: "unknown", reason });
  const root = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  const paths = snapshotPaths(snapshot), ref = snapshot.variantReference;
  const comparison = ref && compareInstanceBoundaries(snapshot, ref);
  if (root.length !== 1 || !paths || snapshot.source?.truncated || !ref?.complete || !comparison?.complete) return unknown3("dependency-topology-unavailable");
  const availability = record4(record4(root[0].variantAvailability).targets)[b.targetRole];
  if (availability?.present === false) return { status: "inactive", reason: "target-absent-in-variant" };
  const targets = snapshot.nodes.filter((n) => record4(n.semantic).role === b.targetRole);
  if (availability?.present !== true || targets.length !== 1) return unknown3("dependency-target-unresolved");
  if (record4(targets[0].visibility).effective === false) return { status: "inactive", reason: "target-hidden" };
  if (record4(targets[0].visibility).effective !== true) return unknown3("dependency-visibility-unavailable");
  const ownerPath = [paths.get(String(targets[0].id)), b.relativePath].filter(Boolean).join(" / ");
  const owners = snapshot.nodes.filter((n) => paths.get(String(n.id)) === ownerPath && n.type === "INSTANCE");
  if (owners.length !== 1) return unknown3("dependency-owner-unresolved");
  const owner = owners[0], component = record4(owner.component), identity = record4(component.identity);
  if (!b.ownerComponentSetKeys.includes(identity.componentSetKey)) return unknown3("dependency-owner-identity-mismatch");
  let selectedReference = ref;
  const boundary = comparison.boundaries.find((x) => withinBoundary(ownerPath, x.actualPath));
  if (boundary) {
    const result = snapshot.instanceContentResults?.find((r) => r.boundaryNodeId === boundary.nodeId && r.lineageProven);
    const attempts = snapshot.instanceContentReferences?.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId) || [];
    if (boundary.nodeId !== owner.id || boundary.reason !== "component-variant-changed" || !result || attempts.length !== 1 || attempts[0].failure || !attempts[0].reference) return unknown3("dependency-owner-lineage-unproven");
    const s = attempts[0].reference;
    selectedReference = captureVariantReference(s, s.source?.componentKey || "", s.source?.componentSetKey || "");
  }
  const originalOwner = selectedReference.nodeProperties[ownerPath];
  const prop = b.activeVariant.property, value = component.properties?.[prop];
  if (!originalOwner || originalOwner.identity?.componentKey !== identity.componentKey || originalOwner.identity?.componentSetKey !== identity.componentSetKey || component.propertyTypes?.[prop] !== "VARIANT" || originalOwner.propertyTypes[prop] !== "VARIANT" || originalOwner.properties[prop] !== value || (owner.unknownFacts || []).some((p) => `component.properties.${prop}` === p || `component.properties.${prop}`.startsWith(p + "."))) return unknown3("dependency-owner-variant-unproven");
  if (!b.activeVariant.values.includes(value)) return { status: "inactive", reason: "owner-variant-inactive" };
  const childPath = [ownerPath, b.childPath].join(" / "), original = selectedReference.nodeProperties[childPath];
  const childContract = d.contract;
  const childKeys = childContract?.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated").flatMap((r) => [r.locator.componentKey, r.locator.componentSetKey]) || [];
  if (!original?.identity || !childKeys.includes(original.identity.componentSetKey || original.identity.componentKey)) return unknown3("dependency-child-lineage-unproven");
  const children = snapshot.nodes.filter((n) => paths.get(String(n.id)) === childPath);
  if (children.length !== 1 || children[0].type !== "INSTANCE") return unknown3("dependency-child-missing-or-ambiguous");
  const node = children[0], childIdentity = record4(record4(node.component).identity);
  return { status: "active", reason: "fixed-child-proven", node, nodeId: String(node.id), identityValid: childKeys.includes(childIdentity.componentSetKey || childIdentity.componentKey) };
}
function validatedDependencyCapture(snapshot, nodeId, childContract) {
  const captures = snapshot.componentDependencyCaptures?.filter((c) => c.nodeId === nodeId) || [];
  if (captures.length !== 1 || !captures[0].snapshot || !captures[0].nodeMap || captures[0].failure) return { reason: captures[0]?.failure || "dependency-reference-not-captured" };
  const capture = captures[0], child = JSON.parse(JSON.stringify(capture.snapshot)), nodeMap = capture.nodeMap;
  if (child.source?.truncated || !child.variantReference?.complete || child.selection.length !== 1 || nodeMap[child.selection[0]] !== nodeId || !snapshot.nodes.find((n) => n.id === nodeId)?.resolvedModes || stableHash(child.context.modes) !== stableHash(snapshot.nodes.find((n) => n.id === nodeId).resolvedModes)) return { reason: "dependency-capture-incomplete" };
  const paths = snapshotPaths(snapshot), prefix = paths?.get(nodeId);
  if (prefix === void 0) return { reason: "dependency-capture-topology-mismatch" };
  const expected = snapshot.nodes.filter((n) => withinBoundary(paths.get(String(n.id)) || "", prefix));
  const mapped = Object.values(nodeMap);
  if (expected.length !== child.nodes.length || mapped.length !== child.nodes.length || new Set(mapped).size !== mapped.length || expected.some((n) => !mapped.includes(String(n.id)))) return { reason: "dependency-capture-topology-mismatch" };
  for (const n of child.nodes) {
    const host = snapshot.nodes.find((h) => h.id === nodeMap[String(n.id)]);
    if (!host || n.type !== host.type || stableHash(effectiveFacts(n, true)) !== stableHash(effectiveFacts(host, true)) || String(n.id) !== child.selection[0] && nodeMap[String(n.parentId)] !== host.parentId) return { reason: "dependency-capture-actual-mismatch" };
  }
  const root = child.nodes.find((n) => child.selection.includes(String(n.id)));
  const identity = record4(record4(root.component).identity);
  if (identity.componentKey !== child.source?.componentKey || identity.componentSetKey !== child.source?.componentSetKey) return { reason: "dependency-capture-identity-mismatch" };
  const reps = childContract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && [r.locator.componentKey, r.locator.componentSetKey].includes(identity.componentSetKey));
  if (reps.length !== 1) return { reason: "dependency-representation-unresolved" };
  child.context = { ...snapshot.context, platform: reps[0].platform, modes: child.context.modes };
  const inverse = new Map(Object.entries(nodeMap).map(([local, host]) => [host, local]));
  child.componentDependencyCaptures = (snapshot.componentDependencyCaptures || []).filter((c) => c.nodeId !== nodeId && inverse.has(c.nodeId)).map((c) => ({
    ...c,
    nodeId: inverse.get(c.nodeId),
    nodeMap: c.nodeMap ? Object.fromEntries(Object.entries(c.nodeMap).map(([local, host]) => [local, inverse.get(host)])) : void 0
  }));
  return { snapshot: child, nodeMap };
}

// src/core/dependency-facts.ts
var record5 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var propertyName = (name) => name.replace(/#[^#]+$/, "");
function parseAssetCatalogs(value) {
  if (!Array.isArray(value) || value.some((c) => !c || typeof c !== "object" || !["catalog", "library", "sourceHash", "generatedAt"].every((k) => typeof c[k] === "string") || !c.catalog || !c.library || !c.sourceHash || !Array.isArray(c.members) || c.members.some((m) => !m || typeof m.componentKey !== "string" || !m.componentKey || typeof m.componentSetKey !== "string" || !m.componentSetKey))) {
    throw new Error("Invalid read-only asset catalog evidence. Rebuild the package from Athena indexes.");
  }
  return value;
}
function dependencyBinding(subject, constraint) {
  const binding = {
    ...subject,
    portNames: [...constraint.dependency?.portNames || []].sort(),
    ...constraint.dependency?.contractDependencyId ? { contractDependencyId: constraint.dependency.contractDependencyId } : {},
    ...constraint.dependency?.field === "variantProperty" ? { variantProperty: constraint.dependency.property } : {}
  };
  return {
    id: `d_${stableHash(binding).slice(0, 20)}`,
    ...binding,
    ...["portName", "width", "height", "variantProperty"].includes(constraint.dependency?.field || "") ? { metrics: true } : {}
  };
}
function extractAssetCatalogs(inputs) {
  return inputs.filter((d) => d.kind === "component-index" && typeof d.catalogName === "string" && typeof d.library === "string" && Array.isArray(d.components)).map((d) => ({
    catalog: String(d.catalogName),
    library: String(d.library),
    sourceHash: stableHash(d),
    generatedAt: String(d.generatedAt || ""),
    members: d.components.flatMap((c) => (Array.isArray(c.variants) ? c.variants : []).filter((v) => typeof v.key === "string" && v.key && typeof c.key === "string" && c.key).map((v) => ({ componentKey: v.key, componentSetKey: c.key }))).sort((a, b) => a.componentKey.localeCompare(b.componentKey))
  })).sort((a, b) => a.catalog.localeCompare(b.catalog));
}
function materializeDependencyFacts(snapshot, contract) {
  const bindings = contract.facts.dependencyBindings || [];
  const root = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  const paths = snapshotPaths(snapshot);
  const reference = snapshot.variantReference;
  const comparison = reference ? compareInstanceBoundaries(snapshot, reference) : void 0;
  const membership = /* @__PURE__ */ new Map();
  for (const catalog of contract.facts.variantEvidence?.assetCatalogs || []) for (const m of catalog.members) {
    membership.set(m.componentKey, [...membership.get(m.componentKey) || [], { catalog: catalog.catalog, library: catalog.library, componentSetKey: m.componentSetKey }]);
  }
  const facts = {};
  for (const b of bindings) {
    const f = {};
    facts[b.id] = f;
    if (b.contractDependencyId) {
      const dependency = contract.componentDependencies?.find((d) => d.id === b.contractDependencyId);
      const binding = dependency?.bindings.find((d) => d.targetRole === b.targetRole && d.relativePath === b.relativePath);
      if (!dependency || !binding || dependency.issue) {
        f.reason = dependency?.issue || "dependency-binding-missing";
        continue;
      }
      const result = resolveFixedNestedBinding(snapshot, dependency, binding);
      f.reason = result.reason;
      if (result.status === "inactive") f.applicable = false;
      if (result.status !== "active" || !result.node) continue;
      f.applicable = true;
      const node = result.node, component2 = record5(node.component), identity2 = record5(component2.identity);
      if (identity2.componentKey) f.componentKey = identity2.componentKey;
      if (identity2.componentSetKey) f.componentSetKey = identity2.componentSetKey;
      if (b.variantProperty && component2.propertyTypes?.[b.variantProperty] === "VARIANT" && !(node.unknownFacts || []).some((p) => `component.properties.${b.variantProperty}` === p || `component.properties.${b.variantProperty}`.startsWith(p + "."))) f.variantProperty = component2.properties?.[b.variantProperty];
      for (const dim of ["width", "height"]) if (typeof record5(node.bounds)[dim] === "number" && Number.isFinite(record5(node.bounds)[dim])) f[dim] = record5(node.bounds)[dim];
      continue;
    }
    if (root.length !== 1 || !paths || snapshot.source?.truncated || !comparison?.complete) {
      f.reason = "reference-or-topology-unavailable";
      continue;
    }
    const availability = record5(record5(root[0].variantAvailability).targets)[b.targetRole];
    if (availability?.present === false) {
      f.applicable = false;
      f.reason = "target-absent-in-variant";
      continue;
    }
    const targets = snapshot.nodes.filter((n) => record5(n.semantic).role === b.targetRole);
    if (targets.length !== 1 || availability?.present !== true) {
      f.reason = "target-unresolved";
      continue;
    }
    const target = targets[0];
    if (record5(target.visibility).effective === false) {
      f.applicable = false;
      f.reason = "target-hidden";
      continue;
    }
    if (record5(target.visibility).effective !== true) {
      f.reason = "visibility-unavailable";
      continue;
    }
    const path = [paths.get(String(target.id)), b.relativePath].filter(Boolean).join(" / ");
    const matches = snapshot.nodes.filter((n) => paths.get(String(n.id)) === path);
    if (matches.length !== 1 || matches[0].type !== "INSTANCE") {
      f.reason = "nested-instance-unresolved";
      continue;
    }
    const owner = matches[0], component = record5(owner.component), identity = record5(component.identity);
    if (!b.portNames.length) {
      f.applicable = true;
      if (typeof identity.componentKey === "string" && identity.componentKey && typeof identity.componentSetKey === "string" && identity.componentSetKey) {
        f.componentSetKey = identity.componentSetKey;
        f.componentKey = identity.componentKey;
      } else f.reason = "component-identity-unavailable";
      continue;
    }
    let portReference = reference;
    const wrapperBoundary = comparison.boundaries.find((boundary2) => withinBoundary(path, boundary2.actualPath));
    if (wrapperBoundary) {
      const resolved = snapshot.instanceContentResults?.find((r) => r.boundaryNodeId === wrapperBoundary.nodeId && (r.status === "matched" || snapshot.instanceContentReferences?.schemaVersion === "apollo.instance-content-references.v4" && r.lineageProven));
      const attempts = snapshot.instanceContentReferences?.attempts.filter((a) => a.boundaryNodeId === wrapperBoundary.nodeId) || [];
      const host = attempts.length === 1 && !attempts[0].failure ? attempts[0].reference : void 0;
      if (wrapperBoundary.reason !== "component-variant-changed" || wrapperBoundary.nodeId !== owner.id || !resolved || !host) {
        f.reason = "wrapper-lineage-changed";
        continue;
      }
      portReference = captureVariantReference(host, host.source?.componentKey || "", host.source?.componentSetKey || "");
    }
    let properties = Object.entries(record5(component.propertyTypes)).filter(([p, t]) => t === "INSTANCE_SWAP" && b.portNames.includes(propertyName(p))).map(([p]) => p);
    const ownerFor = (node) => {
      const seen = /* @__PURE__ */ new Set();
      let current = node;
      while (current.parentId && !seen.has(String(current.parentId))) {
        seen.add(String(current.parentId));
        const parent = snapshot.nodes.find((n) => n.id === current.parentId);
        if (!parent) return void 0;
        if (parent.type === "INSTANCE") return parent;
        current = parent;
      }
      return void 0;
    };
    if (["apollo.instance-content-references.v3", "apollo.instance-content-references.v4"].includes(snapshot.instanceContentReferences?.schemaVersion || "")) {
      const binding = (n) => record5(record5(n.component).propertyReferenceBindings).mainComponent;
      const actualConsumers = snapshot.nodes.filter((n) => n.type === "INSTANCE" && ownerFor(n) === owner && typeof binding(n) === "string" && b.portNames.includes(propertyName(binding(n))));
      const referenceOwner = (p) => {
        let parent = p.split(" / ").slice(0, -1).join(" / ");
        while (parent) {
          if (portReference.nodes.some((n) => n.path === parent && n.type === "INSTANCE")) return parent;
          parent = parent.split(" / ").slice(0, -1).join(" / ");
        }
        return "";
      };
      const referenceConsumers = portReference.nodes.filter((n) => n.type === "INSTANCE" && referenceOwner(n.path) === path && typeof portReference.nodeProperties[n.path]?.propertyReferenceBindings?.mainComponent === "string" && b.portNames.includes(propertyName(portReference.nodeProperties[n.path].propertyReferenceBindings.mainComponent)));
      if (!actualConsumers.length && !referenceConsumers.length) {
        f.applicable = false;
        f.reason = "no-icon-port-in-variant";
        continue;
      }
      if (actualConsumers.length !== 1 || referenceConsumers.length !== 1) {
        f.reason = "swap-consumer-unresolved";
        continue;
      }
      const property2 = binding(actualConsumers[0]);
      const original2 = portReference.nodeProperties[referenceConsumers[0].path], originalOwner = portReference.nodeProperties[path];
      if (!properties.includes(property2) || original2.propertyReferenceBindings?.mainComponent !== property2 || originalOwner?.propertyTypes[property2] !== "INSTANCE_SWAP" || !original2.identity?.mainComponentId || originalOwner.properties[property2] !== original2.identity.mainComponentId) {
        f.reason = "original-port-unproven";
        continue;
      }
      properties = [property2];
    }
    if (!properties.length) {
      const original2 = portReference.nodeProperties[path];
      const referenceHasPort = Object.entries(original2?.propertyTypes || {}).some(([p, t]) => t === "INSTANCE_SWAP" && b.portNames.includes(propertyName(p)));
      if (!original2 || referenceHasPort) f.reason = "swap-port-evidence-unavailable";
      else {
        f.applicable = false;
        f.reason = "no-icon-port-in-variant";
      }
      continue;
    }
    if (properties.length !== 1) {
      f.reason = "ambiguous-swap-port";
      continue;
    }
    const property = properties[0];
    const consumers = snapshot.nodes.filter((n) => n.type === "INSTANCE" && ownerFor(n) === owner && record5(record5(n.component).propertyReferenceBindings).mainComponent === property);
    if (consumers.length !== 1) {
      f.reason = "swap-consumer-unresolved";
      continue;
    }
    const icon = consumers[0], iconIdentity = record5(record5(icon.component).identity);
    if (!iconIdentity.mainComponentId || record5(component.properties)[property] !== iconIdentity.mainComponentId || !iconIdentity.componentKey) {
      f.reason = "swap-binding-unproven";
      continue;
    }
    if (record5(icon.visibility).effective === false) {
      f.applicable = false;
      f.reason = "icon-hidden";
      continue;
    }
    if (record5(icon.visibility).effective !== true) {
      f.reason = "icon-visibility-unavailable";
      continue;
    }
    const boundary = (snapshot.instanceBoundaries || comparison.boundaries).find((b2) => b2.nodeId === String(icon.id));
    const iconPath = paths.get(String(icon.id));
    const original = boundary ? portReference.nodeProperties[boundary.referencePath] : portReference.nodeProperties[iconPath];
    if (original?.propertyReferenceBindings?.mainComponent !== property || !original.identity?.componentKey) {
      f.reason = "original-port-unproven";
      continue;
    }
    f.applicable = true;
    f.changed = iconIdentity.componentKey !== original.identity.componentKey;
    f.componentKey = iconIdentity.componentKey;
    f.referenceComponentKey = original.identity.componentKey;
    if (b.variantProperty) {
      const asset = record5(icon.component), value = record5(asset.properties)[b.variantProperty];
      const unavailable = (icon.unknownFacts || []).some((p) => [`component.properties.${b.variantProperty}`, `component.propertyTypes.${b.variantProperty}`].some((f2) => f2 === p || f2.startsWith(`${p}.`)));
      if (!unavailable && record5(asset.propertyTypes)[b.variantProperty] === "VARIANT" && typeof value === "string" && value.trim()) f.variantProperty = value;
      else f.reason = "asset-variant-property-unavailable";
    }
    if (b.metrics) {
      f.portName = propertyName(property);
      for (const dimension of ["width", "height"]) {
        const value = record5(icon.bounds)[dimension];
        if (typeof value === "number" && Number.isFinite(value) && value > 0) f[dimension] = value;
      }
    }
    const entries = membership.get(iconIdentity.componentKey) || [];
    const catalogs = [...new Set(entries.map((m) => m.catalog))];
    if (catalogs.length === 1 && new Set(entries.map((m) => m.library)).size === 1 && entries.every((m) => m.componentSetKey === iconIdentity.componentSetKey)) f.catalog = catalogs[0];
    else f.reason = entries.length ? "catalog-identity-conflict" : "catalog-key-unknown";
  }
  for (const node of snapshot.nodes) {
    node.dependencies = facts;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "dependencies" && !p.startsWith("dependencies."));
  }
}

// src/core/importer.ts
function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function record6(value) {
  return isRecord(value) ? value : {};
}
function stringValue(value, fallback = "") {
  return typeof value === "string" ? value : fallback;
}
function arrayValue(value) {
  return Array.isArray(value) ? value : [];
}
function collectStrings(value, keyMatcher, result = []) {
  if (Array.isArray(value)) {
    value.forEach((entry) => collectStrings(entry, keyMatcher, result));
    return result;
  }
  if (!isRecord(value)) return result;
  for (const [key, entry] of Object.entries(value)) {
    if (keyMatcher.test(key) && typeof entry === "string" && entry) result.push(entry);
    collectStrings(entry, keyMatcher, result);
  }
  return result;
}
function parseFiles(files) {
  return files.map((file) => {
    let parsed;
    try {
      parsed = JSON.parse(file.text);
    } catch (error) {
      throw new Error(`${file.name}: invalid JSON (${error instanceof Error ? error.message : String(error)})`);
    }
    if (!isRecord(parsed)) throw new Error(`${file.name}: root must be a JSON object.`);
    return { name: file.name, data: parsed };
  });
}
function packageFolder(files) {
  const generated = files.find((file) => /contract\.generated\.json$/i.test(file.name));
  const path = generated?.name || files[0]?.name || "";
  const parts = path.split("/").filter(Boolean);
  const sourceIndex = parts.lastIndexOf("source");
  if (sourceIndex > 0) return parts[sourceIndex - 1];
  return parts.length > 1 ? parts[parts.length - 2] : "";
}
function contractCandidates(parsed) {
  const candidates = [];
  for (const entry of parsed) {
    for (const candidate of arrayValue(entry.data.contracts)) {
      if (isRecord(candidate)) candidates.push({ ...candidate, packageAthena: true });
    }
    const generated = record6(entry.data.generated);
    for (const candidate of arrayValue(generated.contracts)) {
      if (isRecord(candidate)) candidates.push({ ...candidate, packageAthena: true });
    }
  }
  if (candidates.length) return candidates;
  for (const entry of parsed) {
    if (entry.data.documentType !== "component-contract") continue;
    const packageInfo = record6(entry.data.package);
    const familySlug = slug(stringValue(packageInfo.family));
    const library = stringValue(packageInfo.library);
    for (const componentApiEntry of arrayValue(record6(entry.data.facts).componentApi)) {
      if (!isRecord(componentApiEntry)) continue;
      const name = stringValue(componentApiEntry.name);
      const status = stringValue(componentApiEntry.status, "active");
      candidates.push({
        ...componentApiEntry,
        normalizedName: slug(name),
        packageComponentApi: true,
        packageFamily: slug(name) === familySlug,
        role: status !== "deprecated" ? "main" : "supporting",
        source: { ...record6(componentApiEntry.source), library }
      });
    }
  }
  return candidates;
}
function compiledContainsCandidate(data, candidate) {
  if (data.documentType !== "component-contract") return false;
  if (!candidate) return true;
  const candidateId = stringValue(candidate.id);
  const candidateKey = stringValue(candidate.componentKey);
  const packageInfo = record6(data.package);
  if (candidateId && stringValue(packageInfo.id) === candidateId) return true;
  const facts = record6(data.facts);
  const factsComponent = record6(facts.component);
  if (candidateKey && stringValue(factsComponent.componentKey) === candidateKey) return true;
  return arrayValue(facts.componentApi).some((entry) => {
    const componentApi = record6(entry);
    return Boolean(
      candidateId && stringValue(componentApi.id) === candidateId || candidateKey && stringValue(componentApi.componentKey) === candidateKey
    );
  });
}
function chooseContract(candidates, folder, preferredContractId) {
  if (!candidates.length) return void 0;
  if (preferredContractId) {
    const preferred = candidates.find((candidate) => stringValue(candidate.id) === preferredContractId);
    if (preferred) return preferred;
  }
  const folderSlug = slug(folder);
  return candidates.find((candidate) => {
    const name = stringValue(candidate.normalizedName) || slug(stringValue(candidate.name));
    return name === folderSlug;
  }) || candidates.find((candidate) => candidate.packageFamily === true && candidate.role === "main") || candidates.find((candidate) => candidate.role === "main") || candidates[0];
}
function choicesForContract(candidates, selected, representedComponentKeys) {
  if (!selected) return [];
  const normalizedName = stringValue(selected.normalizedName) || slug(stringValue(selected.name));
  const familyName = normalizedName.replace(/-inverted$/i, "");
  const selectedLibrary = stringValue(record6(selected.source).library);
  const matching = candidates.filter((candidate) => {
    const candidateName = stringValue(candidate.normalizedName) || slug(stringValue(candidate.name));
    const candidateLibrary = stringValue(record6(candidate.source).library);
    const candidateKey = stringValue(candidate.componentKey);
    const belongsToRepresentations = representedComponentKeys.size > 0 && representedComponentKeys.has(candidateKey);
    const belongsToSameCompiledPackage = selected.packageComponentApi === true && candidate.packageComponentApi === true;
    const belongsToSameAthenaPackage = selected.packageAthena === true && candidate.packageAthena === true;
    const belongsToDetectedFamily = candidateName.replace(/-inverted$/i, "") === familyName;
    return candidate.role === "main" && stringValue(candidate.status, "active") !== "deprecated" && (belongsToSameCompiledPackage || belongsToSameAthenaPackage || belongsToRepresentations || belongsToDetectedFamily) && (!selectedLibrary || !candidateLibrary || candidateLibrary === selectedLibrary);
  });
  const preferredByRepresentation = /* @__PURE__ */ new Map();
  matching.forEach((candidate) => {
    const candidateName = stringValue(candidate.normalizedName) || slug(stringValue(candidate.name));
    const platform = stringValue(candidate.platform) || "universal";
    const representationId = `${candidateName}.${platform}`;
    const current = preferredByRepresentation.get(representationId);
    if (!current || stringValue(candidate.id) === representationId) {
      preferredByRepresentation.set(representationId, candidate);
    }
  });
  const choiceCandidates = preferredByRepresentation.size ? Array.from(preferredByRepresentation.values()) : [selected];
  const choices = choiceCandidates.map((candidate) => ({
    contractId: stringValue(candidate.id),
    label: stringValue(candidate.name) || stringValue(candidate.normalizedName) || "Component",
    platform: stringValue(candidate.platform) || "universal",
    componentKey: stringValue(candidate.componentKey)
  })).filter((choice) => choice.contractId);
  return Array.from(new Map(choices.map((choice) => [choice.contractId, choice])).values());
}
function componentIdentity(parsed, candidate, folder) {
  const compiled = parsed.find((entry) => compiledContainsCandidate(entry.data, candidate))?.data;
  const packageInfo = record6(compiled?.package);
  const source = record6(candidate?.source);
  const metadata = parsed.map((entry) => record6(entry.data.metadata)).find((entry) => Object.keys(entry).length);
  const family = stringValue(candidate?.name) || stringValue(candidate?.normalizedName) || stringValue(packageInfo.family) || folder || "Imported component";
  const contractId = stringValue(candidate?.id) || stringValue(packageInfo.id) || stringValue(metadata?.componentKey) || `manual.${slug(family)}`;
  const discoveredKeys = collectStrings(parsed.map((entry) => entry.data), /^componentKey$/i);
  const componentKey = stringValue(candidate?.componentKey) || discoveredKeys.find((value) => /^[a-f\d]{20,}$/i.test(value)) || "";
  const semanticId = stringValue(metadata?.componentKey) || stringValue(record6(record6(compiled?.facts).component).componentId) || contractId;
  const platform = stringValue(candidate?.platform) || "universal";
  return {
    componentId: semanticId,
    familyId: semanticId,
    contractId,
    family: family.replace(/^\[[DMT]\]\s*/, ""),
    layer: stringValue(metadata?.layer) || "core",
    library: stringValue(source.library) || stringValue(packageInfo.library) || "Unknown library",
    platform,
    platforms: platform === "universal" ? [] : [platform],
    lifecycle: stringValue(candidate?.status) === "deprecated" ? "deprecated" : stringValue(candidate?.status) === "scheduled" ? "scheduled" : "active",
    componentKey
  };
}
function normalizeManualSource(value) {
  if (value.schemaVersion === MANUAL_SCHEMA_VERSION) {
    return {
      ...value,
      examples: arrayValue(value.examples),
      decisions: arrayValue(value.decisions)
    };
  }
  if (value.schemaVersion !== LEGACY_MANUAL_SCHEMA_VERSION) {
    throw new Error(`Unsupported manual source schema: ${stringValue(value.schemaVersion, "unknown")}.`);
  }
  const legacy = value;
  const component = legacy.component;
  const componentId = component.componentId || component.contractId;
  return {
    ...legacy,
    schemaVersion: MANUAL_SCHEMA_VERSION,
    component: {
      ...component,
      componentId,
      familyId: component.familyId || componentId,
      layer: component.layer || "core",
      platforms: component.platforms || (component.platform === "universal" ? [] : [component.platform]),
      lifecycle: component.lifecycle || "active"
    },
    semantics: {
      purpose: "",
      useWhen: [],
      doNotUseWhen: [],
      relatedComponentIds: [],
      keywords: []
    },
    representations: component.componentKey ? [{
      id: `${componentId}.figma.${component.platform || "universal"}`,
      kind: "figma",
      platform: component.platform || "universal",
      status: "draft",
      locator: { componentKey: component.componentKey }
    }] : [],
    semanticApi: [],
    documentation: [],
    examples: [],
    decisions: [],
    generation: { profiles: [], instructions: [] },
    metadata: {
      ...legacy.metadata,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
}
function variantsFromContract(candidate, identity) {
  const figma = record6(candidate?.figma);
  const variants = record6(figma.variants);
  const variantKeys = arrayValue(variants.variantKeys);
  const result = variantKeys.flatMap((entry, index) => {
    if (!isRecord(entry)) return [];
    const properties = Object.fromEntries(
      Object.entries(record6(entry.properties)).map(([key, value]) => [key, stringValue(value)])
    );
    return [{
      id: stringValue(entry.key) || `variant-${index + 1}`,
      label: stringValue(entry.name) || Object.entries(properties).map(([key, value]) => `${key}=${value}`).join(", "),
      componentKey: stringValue(entry.key) || identity.componentKey,
      properties
    }];
  });
  if (result.length) return result;
  return [{
    id: identity.componentKey || "default",
    label: "Default",
    componentKey: identity.componentKey,
    properties: {}
  }];
}
function nodeProperties(node) {
  const result = {
    visible: node.visible !== false,
    name: stringValue(node.name),
    type: stringValue(node.type)
  };
  if (node.layout !== void 0) result.layout = node.layout;
  if (node.radius !== void 0) result.radius = node.radius;
  if (node.opacity !== void 0) result.opacity = node.opacity;
  if (node.fills !== void 0) result.fills = node.fills;
  if (node.strokes !== void 0) result.strokes = node.strokes;
  if (node.fillToken !== void 0) result.fillToken = node.fillToken;
  if (node.strokeToken !== void 0) result.strokeToken = node.strokeToken;
  if (node.typographyToken !== void 0) result.typographyToken = node.typographyToken;
  if (node.text !== void 0) result.text = node.text;
  if (node.variantProperties !== void 0) result.variantProperties = node.variantProperties;
  return result;
}
function structureFromContract(candidate) {
  const figma = record6(candidate?.figma);
  const raw = arrayValue(figma.structureSignature);
  const ids = raw.map((entry, index) => stringValue(record6(entry).nodeId, String(index + 1)));
  const result = raw.flatMap((entry, index) => {
    if (!isRecord(entry)) return [];
    const parentRaw = entry.parentId;
    const parentId = parentRaw === null || parentRaw === void 0 ? null : String(parentRaw);
    const name = stringValue(entry.name, `Node ${index + 1}`);
    const path = stringValue(entry.path, name);
    const depth = Math.max(0, path.split("/").length - 1);
    return [{
      id: ids[index],
      parentId,
      name,
      type: stringValue(entry.type, "NODE"),
      path,
      semanticRole: slug(name),
      visible: entry.visible !== false,
      order: index,
      depth,
      childIds: [],
      properties: nodeProperties(entry),
      unknownFacts: []
    }];
  });
  const byId = new Map(result.map((node) => [node.id, node]));
  result.forEach((node) => {
    if (node.parentId && byId.has(node.parentId)) byId.get(node.parentId)?.childIds.push(node.id);
  });
  return result;
}
function targetsFromAnatomy(anatomy, family) {
  const used = /* @__PURE__ */ new Map();
  return anatomy.map((node) => {
    const base = node.semanticRole || slug(node.name);
    const count = (used.get(base) || 0) + 1;
    used.set(base, count);
    const semanticRole2 = count === 1 ? base : `${base}-${count}`;
    return {
      id: `target.${semanticRole2}`,
      semanticRole: semanticRole2,
      label: node.name,
      componentFamily: node.type === "INSTANCE" ? node.name : family,
      lineage: node.path.split("/").slice(0, -1).map((part) => slug(part.trim())),
      structuralFingerprint: stableHash({ type: node.type, path: node.path, order: node.order }).slice(0, 16),
      nameHint: node.name,
      pathHint: node.path,
      nodeIdHint: node.id,
      resolution: "resolved"
    };
  });
}
function tokensFromCandidate(candidate) {
  const tokens = record6(record6(candidate?.figma).tokens);
  return uniqueSorted(Object.values(tokens).flatMap((value) => arrayValue(value).map((entry) => stringValue(entry))));
}
function newManual(identity, files, targets, sourceKind) {
  return {
    schemaVersion: MANUAL_SCHEMA_VERSION,
    documentType: "component-contract-manual",
    component: identity,
    semantics: {
      purpose: "",
      useWhen: [],
      doNotUseWhen: [],
      relatedComponentIds: [],
      keywords: []
    },
    representations: identity.componentKey ? [{
      id: `${identity.componentId}.figma.${identity.platform}`,
      kind: "figma",
      platform: identity.platform,
      status: "draft",
      locator: { componentKey: identity.componentKey }
    }] : [],
    semanticApi: [],
    documentation: [],
    examples: [],
    decisions: [],
    generation: { profiles: [], instructions: [] },
    source: {
      kind: sourceKind,
      importedFiles: files.map((file) => file.name).sort((left, right) => left.localeCompare(right)),
      sourceHash: stableHash(files.map((file) => ({ name: file.name, text: file.text }))),
      importedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    targets,
    controlPorts: [],
    rules: [],
    metadata: {
      owners: {
        generated: "athena-cli",
        manual: "design-system-authors",
        runtime: "apollo-runtime"
      },
      revision: 1,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
}
function importWorkspace(files, preferredContractId) {
  if (!files.length) throw new Error("Choose at least one JSON file or ZIP package.");
  const allParsed = parseFiles(files);
  const dependencyEntries = allParsed.filter((p) => /(^|\/)dependencies\//.test(p.name));
  const parsed = allParsed.filter((p) => !dependencyEntries.includes(p));
  const folder = packageFolder(files);
  const candidates = contractCandidates(parsed);
  const defaultCandidate = chooseContract(candidates, folder);
  const representedComponentKeys = new Set(parsed.flatMap((entry) => arrayValue(entry.data.representations).filter((value) => record6(value).kind === "figma").flatMap((value) => {
    const locator = record6(record6(value).locator);
    return [stringValue(locator.componentKey), stringValue(locator.componentSetKey)].filter(Boolean);
  })));
  const componentChoices = choicesForContract(candidates, defaultCandidate, representedComponentKeys);
  const candidate = chooseContract(candidates, folder, preferredContractId);
  const identity = componentIdentity(parsed, candidate, folder);
  const manualEntries = parsed.filter((entry) => entry.data.schemaVersion === MANUAL_SCHEMA_VERSION || entry.data.schemaVersion === LEGACY_MANUAL_SCHEMA_VERSION);
  const manualEntry = candidate ? manualEntries.find((entry) => {
    const component = record6(entry.data.component);
    return stringValue(component.contractId) === identity.contractId || Boolean(identity.componentKey && stringValue(component.componentKey) === identity.componentKey);
  }) || (manualEntries.length === 1 && arrayValue(manualEntries[0].data.representations).some((entry) => {
    const representation = record6(entry);
    const locator = record6(representation.locator);
    return representation.kind === "figma" && (stringValue(locator.componentKey) === identity.componentKey || stringValue(representation.platform) === identity.platform);
  }) ? manualEntries[0] : void 0) : manualEntries[0];
  const anatomy = structureFromContract(candidate);
  const generatedTargets = targetsFromAnatomy(anatomy, identity.family);
  const compiledEntries = parsed.filter((entry) => entry.data.documentType === "component-contract");
  const compiledEntry = compiledEntries.find((entry) => compiledContainsCandidate(entry.data, candidate));
  const warnings = [];
  let manual;
  if (manualEntry) {
    manual = normalizeManualSource(manualEntry.data);
    if (manualEntry.data.schemaVersion === LEGACY_MANUAL_SCHEMA_VERSION) {
      warnings.push("Manual source v1 migrated in memory to v2; export the package to persist the new schema.");
    }
  } else {
    const sourceKind = compiledEntry ? "component-contract-v2" : "athena-package";
    manual = newManual(identity, files, [], sourceKind);
    if (compiledEntry) {
      warnings.push("Compiled v2 imported as read-only evidence; compact manual rules cannot be reconstructed losslessly.");
    }
  }
  if (!identity.componentKey && !manual.component.componentKey) {
    warnings.push("No Figma componentKey found. Anatomy remains available, but live preview cannot be rendered.");
  }
  if (!anatomy.length) {
    warnings.push("No structure signature found. Live Figma preview can repopulate the anatomy tree.");
  }
  if (componentChoices.length > 1) {
    warnings.push(`Package contains ${componentChoices.length} Figma representations; selected ${candidate?.name || identity.family}.`);
  }
  const variantEvidence = extractVariantEvidence(candidates) || compiledEntry?.data.facts && compiledEntry.data.facts.variantEvidence;
  const assetCatalogs = extractAssetCatalogs(parsed.map((p) => p.data));
  const compactAssets = parsed.filter((p) => p.data.schemaVersion === "apollo.asset-catalogs.v1").flatMap((p) => arrayValue(p.data.catalogs));
  if (variantEvidence) {
    const assets = assetCatalogs.length ? assetCatalogs : compactAssets.length ? compactAssets : compiledEntry?.data.facts?.variantEvidence?.assetCatalogs;
    if (assets?.length) variantEvidence.assetCatalogs = parseAssetCatalogs(assets);
  }
  return {
    manual,
    variantEvidence,
    dependencyContracts: dependencyEntries.filter((p) => p.data.documentType === "component-contract").map((p) => p.data).concat(dependencyEntries.length ? [] : (compiledEntry?.data.componentDependencies || []).flatMap((d) => d.contract ? [d.contract] : [])),
    activeContractId: identity.contractId,
    componentChoices,
    variants: variantsFromContract(candidate, manual.component),
    hasVariantEvidence: arrayValue(record6(record6(candidate?.figma).variants).variantKeys).length > 0,
    anatomy,
    tokens: tokensFromCandidate(candidate),
    warnings,
    compiledInput: compiledEntry?.data
  };
}
function createWorkspaceFromPreview(identity, anatomy) {
  const placeholder = [{ name: "figma-selection.json", text: JSON.stringify({ identity }) }];
  return {
    manual: newManual(identity, placeholder, [], "figma-selection"),
    activeContractId: identity.contractId,
    variants: [{ id: identity.componentKey || "selection", label: "Current", componentKey: identity.componentKey, properties: {} }],
    hasVariantEvidence: true,
    anatomy,
    tokens: [],
    warnings: []
  };
}

// src/core/validator.ts
var KNOWN_CONSTRAINTS = /* @__PURE__ */ new Set([
  "propertyDomain",
  "presence",
  "propertyForbidden",
  "quantity",
  "positionOrder",
  "relationship",
  "tokenBinding",
  "layoutConstraint",
  "dependencyDomain"
]);
function validateManualSource(manual) {
  const issues = validateComponentDependencies(manual);
  const error = (code, path, message) => {
    issues.push({ level: "error", code, path, message });
  };
  const warning = (code, path, message) => {
    issues.push({ level: "warning", code, path, message });
  };
  if (manual.schemaVersion !== "apollo.component-contract.manual.v2-experimental") {
    error("SCHEMA_VERSION", "/schemaVersion", "Unsupported manual source schema version.");
  }
  if (!manual.component.componentId.trim()) error("COMPONENT_SEMANTIC_ID", "/component/componentId", "Stable componentId is required.");
  if (!manual.component.familyId.trim()) error("COMPONENT_FAMILY_ID", "/component/familyId", "Stable familyId is required.");
  if (!manual.component.contractId.trim()) error("COMPONENT_ID", "/component/contractId", "Contract id is required.");
  if (!manual.component.family.trim()) error("COMPONENT_FAMILY", "/component/family", "Component family is required.");
  if (!manual.component.componentKey.trim()) {
    warning("COMPONENT_KEY", "/component/componentKey", "Live Figma preview is unavailable without componentKey.");
  }
  if (!manual.semantics.purpose.trim()) warning("SEMANTICS_PURPOSE", "/semantics/purpose", "Component purpose is empty.");
  const representationIds = /* @__PURE__ */ new Set();
  manual.representations.forEach((representation, index) => {
    const path = `/representations/${index}`;
    if (!representation.id.trim()) error("REPRESENTATION_ID", `${path}/id`, "Representation id is required.");
    if (representationIds.has(representation.id)) error("REPRESENTATION_DUPLICATE", `${path}/id`, `Duplicate representation id: ${representation.id}.`);
    representationIds.add(representation.id);
    if (!representation.platform.trim()) error("REPRESENTATION_PLATFORM", `${path}/platform`, "Representation platform is required.");
    if (!Object.keys(representation.locator).length) warning("REPRESENTATION_LOCATOR", `${path}/locator`, "Representation locator is empty.");
  });
  const propertyIds = /* @__PURE__ */ new Set();
  manual.semanticApi.forEach((property, index) => {
    const path = `/semanticApi/${index}`;
    if (!property.id.trim()) error("SEMANTIC_PROPERTY_ID", `${path}/id`, "Semantic property id is required.");
    if (propertyIds.has(property.id)) error("SEMANTIC_PROPERTY_DUPLICATE", `${path}/id`, `Duplicate semantic property id: ${property.id}.`);
    propertyIds.add(property.id);
    property.bindings.forEach((binding, bindingIndex) => {
      if (!representationIds.has(binding.representationId)) {
        error("SEMANTIC_PROPERTY_REPRESENTATION", `${path}/bindings/${bindingIndex}/representationId`, `Unknown representation: ${binding.representationId}.`);
      }
      if (!binding.path.trim()) error("SEMANTIC_PROPERTY_PATH", `${path}/bindings/${bindingIndex}/path`, "Binding path is required.");
    });
  });
  const documentIds = /* @__PURE__ */ new Set();
  manual.documentation.forEach((document, index) => {
    const path = `/documentation/${index}`;
    if (!document.id.trim()) error("DOCUMENT_ID", `${path}/id`, "Documentation id is required.");
    if (documentIds.has(document.id)) error("DOCUMENT_DUPLICATE", `${path}/id`, `Duplicate document id: ${document.id}.`);
    documentIds.add(document.id);
    if (!document.path.trim()) error("DOCUMENT_PATH", `${path}/path`, "Documentation path is required.");
  });
  const exampleIds = /* @__PURE__ */ new Set();
  manual.examples.forEach((example, index) => {
    const path = `/examples/${index}`;
    if (!example.id.trim()) error("EXAMPLE_ID", `${path}/id`, "Example id is required.");
    if (exampleIds.has(example.id)) error("EXAMPLE_DUPLICATE", `${path}/id`, `Duplicate example id: ${example.id}.`);
    exampleIds.add(example.id);
    example.ruleIds?.forEach((ruleId, ruleIndex) => {
      if (!manual.rules.some((rule) => rule.id === ruleId)) {
        warning("EXAMPLE_RULE", `${path}/ruleIds/${ruleIndex}`, `Example references unknown rule: ${ruleId}.`);
      }
    });
  });
  const decisionIds = /* @__PURE__ */ new Set();
  manual.decisions.forEach((decision, index) => {
    const path = `/decisions/${index}`;
    if (!decision.id.trim()) error("DECISION_ID", `${path}/id`, "Decision id is required.");
    if (decisionIds.has(decision.id)) error("DECISION_DUPLICATE", `${path}/id`, `Duplicate decision id: ${decision.id}.`);
    decisionIds.add(decision.id);
    if (!decision.summary.trim()) error("DECISION_SUMMARY", `${path}/summary`, "Decision summary is required.");
  });
  const profileIds = /* @__PURE__ */ new Set();
  manual.generation.profiles.forEach((profile, index) => {
    const path = `/generation/profiles/${index}`;
    if (!profile.id.trim()) error("GENERATION_PROFILE_ID", `${path}/id`, "Generation profile id is required.");
    if (profileIds.has(profile.id)) error("GENERATION_PROFILE_DUPLICATE", `${path}/id`, `Duplicate generation profile id: ${profile.id}.`);
    profileIds.add(profile.id);
    if (!representationIds.has(profile.representationId)) {
      error("GENERATION_REPRESENTATION", `${path}/representationId`, `Unknown representation: ${profile.representationId}.`);
    }
  });
  const targetIds = /* @__PURE__ */ new Set();
  const roles = /* @__PURE__ */ new Set();
  manual.targets.forEach((target, index) => {
    const path = `/targets/${index}`;
    if (!target.id.trim()) error("TARGET_ID", `${path}/id`, "Target id is required.");
    if (targetIds.has(target.id)) error("TARGET_DUPLICATE", `${path}/id`, `Duplicate target id: ${target.id}.`);
    targetIds.add(target.id);
    if (!target.semanticRole.trim()) error("TARGET_ROLE", `${path}/semanticRole`, "Semantic role is required.");
    if (roles.has(target.semanticRole)) {
      warning("TARGET_ROLE_DUPLICATE", `${path}/semanticRole`, `Semantic role is not unique: ${target.semanticRole}.`);
    }
    roles.add(target.semanticRole);
    if (target.resolution && target.resolution !== "resolved") {
      warning("TARGET_UNRESOLVED", path, `Target resolution is ${target.resolution}.`);
    }
    target.representationHints?.forEach((hint, hintIndex) => {
      if (!representationIds.has(hint.representationId)) {
        error("TARGET_REPRESENTATION", `${path}/representationHints/${hintIndex}/representationId`, `Unknown representation: ${hint.representationId}.`);
      }
    });
  });
  const portIds = /* @__PURE__ */ new Set();
  manual.controlPorts.forEach((port, index) => {
    const path = `/controlPorts/${index}`;
    if (!port.id.trim()) error("PORT_ID", `${path}/id`, "Control port id is required.");
    if (portIds.has(port.id)) error("PORT_DUPLICATE", `${path}/id`, `Duplicate control port: ${port.id}.`);
    portIds.add(port.id);
    if (!targetIds.has(port.targetId)) error("PORT_TARGET", `${path}/targetId`, `Unknown target: ${port.targetId}.`);
  });
  const ruleIds = /* @__PURE__ */ new Set();
  manual.rules.forEach((rule, index) => {
    const path = `/rules/${index}`;
    if (!rule.id.trim()) error("RULE_ID", `${path}/id`, "Rule id is required.");
    if (ruleIds.has(rule.id)) error("RULE_DUPLICATE", `${path}/id`, `Duplicate rule id: ${rule.id}.`);
    ruleIds.add(rule.id);
    if (!targetIds.has(rule.targetId)) error("RULE_TARGET", `${path}/targetId`, `Unknown target: ${rule.targetId}.`);
    if (rule.targetScope && rule.targetScope !== "self" && rule.targetScope !== "self-and-descendants") {
      error("RULE_TARGET_SCOPE", `${path}/targetScope`, `Unknown target scope: ${rule.targetScope}.`);
    }
    const baselineOnly = rule.permission !== "allowed" && (rule.constraints.length ? rule.constraints.every((constraint) => constraint.type === "propertyForbidden") : rule.permission === "forbidden");
    if (rule.boundaryPolicy !== void 0 && (rule.boundaryPolicy !== "component-owned@1" || rule.targetScope !== "self-and-descendants" || !baselineOnly || !manual.componentDependencies?.length)) {
      error("RULE_BOUNDARY_POLICY", `${path}/boundaryPolicy`, "Component-owned policy requires recursive baseline comparisons and explicit component dependencies.");
    }
    if (rule.targetApplicability !== void 0 && (rule.targetApplicability !== "visible-target@1" || !baselineOnly || !baselineFactsForRule(rule).length || baselineFactsForRule(rule).some((fact) => ![
      "appearance.fill",
      "appearance.stroke",
      "appearance.strokeWeight",
      "appearance.opacity",
      "appearance.radius",
      "appearance.effects",
      "appearance.typography"
    ].includes(fact)))) {
      error("RULE_TARGET_APPLICABILITY", `${path}/targetApplicability`, "Visible-target policy applies only to style baseline comparisons, never presence or visibility requirements.");
    }
    if (!rule.capability.trim() && !rule.capabilitySet) error("RULE_CAPABILITY", `${path}/capability`, "Capability or capability set is required.");
    if (rule.capabilitySelection && !rule.capabilitySet) {
      error("RULE_CAPABILITY_SELECTION_SET", `${path}/capabilitySelection`, "Capability selection requires a capability set.");
    }
    if (rule.capabilitySet) {
      const registered = capabilitiesForSet(rule.capabilitySet);
      if (!registered.length) {
        error("RULE_CAPABILITY_SET", `${path}/capabilitySet`, `Unknown capability set: ${rule.capabilitySet}.`);
      }
      if (rule.capabilitySelection) {
        if (!rule.capabilitySelection.length) {
          error("RULE_CAPABILITY_SELECTION_EMPTY", `${path}/capabilitySelection`, "Select at least one capability from the set.");
        }
        const duplicates = rule.capabilitySelection.filter((value, valueIndex, values) => values.indexOf(value) !== valueIndex);
        if (duplicates.length) {
          error("RULE_CAPABILITY_SELECTION_DUPLICATE", `${path}/capabilitySelection`, "Capability selection contains duplicates.");
        }
        const unknown3 = rule.capabilitySelection.filter((value) => !registered.includes(value));
        if (unknown3.length) {
          error("RULE_CAPABILITY_SELECTION_UNKNOWN", `${path}/capabilitySelection`, `Capabilities are not part of ${rule.capabilitySet}: ${unknown3.join(", ")}.`);
        }
      }
    }
    if (rule.permission === "constrained" && !rule.constraints.length) {
      error("RULE_CONSTRAINT", `${path}/constraints`, "Constrained permission requires at least one constraint.");
    }
    if (rule.status === "reviewed" && !rule.rationale.trim()) {
      error("RULE_RATIONALE", `${path}/rationale`, "Reviewed rule requires rationale.");
    }
    if (!rule.owner.trim()) warning("RULE_OWNER", `${path}/owner`, "Rule owner is not assigned.");
    const route = rule.execution?.route || "auto";
    const predicateRoute = rule.status !== "deprecated" && (route === "predicate" || route === "auto" && rule.permission !== "allowed");
    if (rule.propertyApplicability !== void 0) {
      const gates = rule.propertyApplicability;
      const facts = baselineFactsForRule(rule);
      if (!gates || typeof gates !== "object" || Array.isArray(gates)) {
        error("RULE_PROPERTY_APPLICABILITY", `${path}/propertyApplicability`, "Property applicability must be an exact-property policy map.");
      } else for (const [fact, policy] of Object.entries(gates)) {
        if (!Object.prototype.hasOwnProperty.call(PROPERTY_APPLICABILITY, fact) || policy !== PROPERTY_APPLICABILITY[fact] || !facts.includes(fact) || rule.permission === "allowed") {
          error("RULE_PROPERTY_APPLICABILITY", `${path}/propertyApplicability/${fact}`, `Unsupported policy or no baseline comparison for ${fact}.`);
        }
      }
    }
    const applicabilityKeys = /* @__PURE__ */ new Set(["variants", "modes", "platforms", "products", "channels", "context", "scopeStatus", "conditionSubject"]);
    if (rule.applicability.conditionSubject !== void 0 && !["target", "component-root"].includes(rule.applicability.conditionSubject)) {
      error("RULE_CONDITION_SUBJECT", `${path}/applicability/conditionSubject`, "Choose target or component-root for variant/context conditions.");
    }
    Object.keys(rule.applicability).forEach((key) => {
      if (!applicabilityKeys.has(key)) error("RULE_APPLICABILITY_FIELD", `${path}/applicability/${key}`, `Unsupported applicability field: ${key}.`);
    });
    for (const key of ["platforms", "products", "channels"]) {
      const values = rule.applicability[key];
      if (values !== void 0 && (!Array.isArray(values) || values.some((value) => typeof value !== "string" || !value.trim()))) {
        error("RULE_SCOPE_VALUES", `${path}/applicability/${key}`, "Scope must be an array of non-empty strings; [] means all.");
      }
    }
    if (rule.applicability.variants !== "all") {
      Object.entries(rule.applicability.variants).forEach(([property, values]) => {
        if (!property.trim() || !Array.isArray(values) || !values.length || values.some((value) => typeof value !== "string" || !value.trim())) {
          error("RULE_VARIANTS", `${path}/applicability/variants`, "Variant scope requires a property and at least one non-empty value.");
        }
      });
    }
    if (predicateRoute && rule.applicability.context && Object.keys(rule.applicability.context).some((key) => !key.startsWith("semanticApi.") || !manual.semanticApi.some((property) => key === `semanticApi.${property.id}`))) {
      error("RULE_CONTEXT_UNMAPPED", `${path}/applicability/context`, "Context conditions have no explicit runtime fact binding. Keep this rule context-only until mapped; do not run it unconditionally.");
    }
    if (predicateRoute && rule.applicability.scopeStatus === "needs-confirmation") {
      error("RULE_SCOPE_UNCONFIRMED", `${path}/applicability/scopeStatus`, "Confirm the rule scope before enabling a predicate check.");
    }
    if (route === "delegated" && !rule.execution?.externalRuleIds?.length) {
      error("RULE_DELEGATION", `${path}/execution/externalRuleIds`, "Delegated rule requires externalRuleIds.");
    }
    if (route === "context-only" && !rule.execution?.missingFacts?.length) {
      error("RULE_CONTEXT_FACTS", `${path}/execution/missingFacts`, "Context-only rule requires missingFacts.");
    }
    if (Array.isArray(rule.applicability.modes)) {
      warning("RULE_MODES_LEGACY", `${path}/applicability/modes`, "Legacy mode list does not identify its variable collection. Re-select modes in the Editor.");
    } else if (rule.applicability.modes !== "all") {
      Object.entries(rule.applicability.modes).forEach(([collectionId, modeIds]) => {
        if (!collectionId.trim() || !modeIds.length) {
          error("RULE_MODES", `${path}/applicability/modes`, "Mode scope requires a collection id and at least one mode id.");
        }
      });
    }
    rule.controlPaths.forEach((controlPath, controlIndex) => {
      if (controlPath.kind === "inherited-port" && (!controlPath.port || !portIds.has(controlPath.port))) {
        error("CONTROL_PORT", `${path}/controlPaths/${controlIndex}/port`, "Inherited control path must reference a local control port.");
      }
    });
    rule.constraints.forEach((constraint, constraintIndex) => {
      const constraintPath = `${path}/constraints/${constraintIndex}`;
      if (!KNOWN_CONSTRAINTS.has(constraint.type)) {
        error("CONSTRAINT_TYPE", `${constraintPath}/type`, `Unknown constraint type: ${constraint.type}.`);
      }
      if (constraint.type === "dependencyDomain") {
        const d = constraint.dependency;
        const invalid = (message) => error("CONSTRAINT_DEPENDENCY", `${constraintPath}/dependency`, message);
        if (!d || !Array.isArray(d.subjects) || !d.subjects.length) {
          invalid("Declare at least one dependency subject.");
          return;
        }
        if (manual.targets.find((t) => t.id === rule.targetId)?.semanticRole !== "root" || rule.targetScope === "self-and-descendants" || rule.capabilitySet) invalid("Dependency rules are rooted at the host; choose nested subjects in the constraint, not a capability group or descendant scope.");
        if (constraint.fact) invalid("Dependency field is explicit; do not also override fact.");
        if (!["componentSetKey", "catalog", "portName", "width", "height", "variantProperty"].includes(d.field)) invalid("Choose componentSetKey, catalog, portName, width, height or variantProperty.");
        if (d.field === "variantProperty" ? typeof d.property !== "string" || !d.property.trim() || d.property !== d.property.trim() : d.property !== void 0) invalid("Only variantProperty requires an exact nonempty VARIANT property name.");
        if (d.activePorts !== void 0 && (d.field !== "variantProperty" || !Array.isArray(d.activePorts) || !d.activePorts.length || d.activePorts.some((p) => !d.portNames?.includes(p)) || new Set(d.activePorts).size !== d.activePorts.length)) invalid("Variant property filters require unique active ports from the declared consumer domain.");
        if (!["require-domain", "allow-unchanged"].includes(d.baselinePolicy)) invalid("Choose an explicit baseline policy.");
        if (new Set(d.subjects.map((s) => JSON.stringify(s))).size !== d.subjects.length) invalid("Duplicate subjects.");
        for (const s of d.subjects) {
          if (manual.targets.filter((t) => t.semanticRole === s.targetRole && t.resolution === "resolved").length !== 1) invalid(`Unresolved semantic target: ${s.targetRole}.`);
          if (typeof s.relativePath !== "string" || s.relativePath.split(" / ").some((p) => p === ".." || p === "." || !p && s.relativePath !== "")) invalid("Use an exact relative instance path, without wildcards.");
        }
        if (d.contractDependencyId) {
          const declared = manual.componentDependencies?.find((p) => p.id === d.contractDependencyId);
          if (!declared || d.subjects.some((s) => declared.bindings.filter((b) => b.targetRole === s.targetRole && b.relativePath === s.relativePath).length !== 1)) invalid("Fixed nested subject must match one declared component dependency binding.");
          if (d.portNames?.length || d.catalogs || d.activePorts || d.baselinePolicy !== "require-domain" || ["catalog", "portName"].includes(d.field)) invalid("Fixed nested components do not use icon ports, catalog filters or unchanged exemptions.");
        }
        if (d.field !== "componentSetKey" && !d.contractDependencyId && (!d.portNames?.length || d.portNames.some((p) => typeof p !== "string" || !p.trim() || p.includes("#")) || new Set(d.portNames).size !== d.portNames.length)) invalid("Asset policy requires unique exact port names without Figma suffixes.");
        if (d.field === "componentSetKey" && (d.portNames?.length || d.baselinePolicy === "allow-unchanged")) invalid("Component set checks cannot skip unchanged wrappers or select icon ports.");
        const assetMetric = ["portName", "width", "height", "variantProperty"].includes(d.field);
        const numeric = ["width", "height"].includes(d.field);
        if (assetMetric && d.baselinePolicy !== "require-domain") invalid("Adapter and asset dimensions apply to unchanged assets too.");
        if (d.catalogs !== void 0 && (!assetMetric || !Array.isArray(d.catalogs) || !d.catalogs.length || d.catalogs.some((c) => typeof c !== "string" || !c.trim()) || new Set(d.catalogs).size !== d.catalogs.length)) invalid("Catalog filter needs unique nonempty catalog names on an asset metric.");
        if (d.tolerance !== void 0 && (!numeric || typeof d.tolerance !== "number" || !Number.isFinite(d.tolerance) || d.tolerance < 0)) invalid("Only asset dimensions support a finite nonnegative px tolerance.");
        const outputs = d.cases?.flatMap((c) => Array.isArray(c.values) ? c.values : []) || constraint.values || [];
        if (outputs.some((v) => numeric ? typeof v !== "number" || !Number.isFinite(v) || v <= 0 : typeof v !== "string" || !v.trim())) invalid("Dimensions require positive numbers; keys, catalogs and ports require nonempty strings.");
        if (d.cases) {
          if (!d.sourceFact || !manual.semanticApi.some((p) => d.sourceFact === `semanticApi.${p.id}`)) invalid("Mapping needs an explicitly bound host semanticApi fact.");
          if (constraint.values?.length || !d.cases.length) invalid("Use a nonempty mapping or a fixed domain, not both.");
          const seen = /* @__PURE__ */ new Set();
          for (const c of d.cases) {
            if (!Array.isArray(c.when) || !c.when.length || !Array.isArray(c.values) || !c.values.length) {
              invalid("Each mapping case needs input and output values.");
              continue;
            }
            for (const v of c.when) {
              const key = JSON.stringify(v);
              if (seen.has(key)) invalid("Mapping cases must not overlap.");
              seen.add(key);
            }
          }
        } else if (d.sourceFact || !constraint.values?.length) invalid("A fixed dependency domain requires allowed values.");
      }
      if (constraint.type === "propertyDomain" && !constraint.values?.length) {
        error("CONSTRAINT_VALUES", `${constraintPath}/values`, "Property domain requires allowed values.");
      }
      if (constraint.type === "quantity" && constraint.min === void 0 && constraint.max === void 0) {
        error("CONSTRAINT_RANGE", constraintPath, "Quantity requires min or max.");
      }
      if (constraint.targetRoles !== void 0) {
        if (constraint.type !== "quantity" || constraint.targetRole || !Array.isArray(constraint.targetRoles) || !constraint.targetRoles.length || new Set(constraint.targetRoles).size !== constraint.targetRoles.length || constraint.targetRoles.some((role) => !/^[a-zA-Z0-9_-]+$/.test(role) || manual.targets.filter((target) => target.semanticRole === role).length !== 1)) {
          error("CONSTRAINT_TARGET_ROLES", `${constraintPath}/targetRoles`, "Quantity requires a unique list of declared semantic roles; do not also set targetRole.");
        }
        if (constraint.visibleOnly !== true) error("CONSTRAINT_VISIBLE_ONLY", `${constraintPath}/visibleOnly`, "Explicit targetRoles quantity currently supports visibleOnly=true; hidden-target counting is not implemented.");
      }
      if (constraint.visibleOnly !== void 0 && (typeof constraint.visibleOnly !== "boolean" || constraint.type !== "quantity" || !constraint.targetRoles?.length)) {
        error("CONSTRAINT_VISIBLE_ONLY", `${constraintPath}/visibleOnly`, "visibleOnly requires an explicit targetRoles quantity.");
      }
      if (constraint.type === "positionOrder" && !constraint.order?.length) {
        error("CONSTRAINT_ORDER", `${constraintPath}/order`, "Position/order requires semantic roles.");
      }
      if (constraint.type === "relationship" && (!constraint.relation || !constraint.targetRole)) {
        error("CONSTRAINT_RELATION", constraintPath, "Relationship requires relation and target role.");
      }
      if (constraint.type === "tokenBinding" && !constraint.tokenIds?.length && !constraint.bindingRequired) {
        error("CONSTRAINT_TOKEN", constraintPath, "Token binding requires token ids or bindingRequired.");
      }
    });
  });
  return issues.sort((left, right) => left.level.localeCompare(right.level) || left.path.localeCompare(right.path) || left.code.localeCompare(right.code));
}

// src/core/context-catalog.ts
var PRODUCT_SCOPE_CATALOG = [
  { value: "ab", label: "\u0410\u043B\u044C\u0444\u0430-\u0411\u0438\u0437\u043D\u0435\u0441", description: "Product manifest: products/ab" },
  { value: "abm", label: "\u0410\u043B\u044C\u0444\u0430-\u0411\u0438\u0437\u043D\u0435\u0441 \u041C\u043E\u0431\u0430\u0439\u043B", description: "Product id: abm" },
  { value: "am", label: "\u0410\u043B\u044C\u0444\u0430-\u041C\u043E\u0431\u0430\u0439\u043B", description: "Product id: am" },
  { value: "ao", label: "\u0410\u043B\u044C\u0444\u0430-\u041E\u043D\u043B\u0430\u0439\u043D", description: "Product id: ao" },
  { value: "site", label: "\u0421\u0430\u0439\u0442", description: "Product id: site" }
];

// src/core/compiler.ts
function roleFilter(role) {
  return {
    predicate: "equals",
    actual: { fact: "semantic.role" },
    expected: { literal: role }
  };
}
function targetSelector(target, targetScope, baselineApplicabilityFact) {
  const ownTarget = roleFilter(target.semanticRole);
  const targetFilter = targetScope === "self-and-descendants" ? [{
    predicate: "any",
    args: [
      ownTarget,
      {
        predicate: "ancestor",
        actual: { fact: "id" },
        expected: { fact: `relations.${target.semanticRole}` }
      }
    ]
  }] : [ownTarget];
  const where = baselineApplicabilityFact ? [
    ...targetFilter,
    {
      predicate: "fact-present",
      actual: { fact: baselineApplicabilityFact }
    }
  ] : targetFilter;
  return {
    from: "selection-root",
    traverse: "self-and-descendants",
    where
  };
}
function targetQuery(role, project) {
  const query = {
    from: "selection-root",
    traverse: "self-and-descendants",
    where: [roleFilter(role)]
  };
  if (project) query.project = { fact: project };
  return { query };
}
function availabilityEquals(fact, value) {
  return { predicate: "equals", actual: { fact }, expected: { literal: value }, missingPolicy: "unknown" };
}
function applyVariantTargetAvailability(select, conditions, target) {
  const present = `variantAvailability.targets.${target.semanticRole}.present`;
  conditions.push(availabilityEquals(present, true));
  select.where = [{ predicate: "any", args: [
    { predicate: "all", args: select.where },
    { predicate: "all", args: [availabilityEquals("variantAvailability.isRoot", true), availabilityEquals(present, false)] }
  ] }];
}
function propertyAvailabilityCondition(fact) {
  if (fact.startsWith("semanticApi.")) return availabilityEquals(`variantAvailability.properties.${fact.slice("semanticApi.".length)}`, true);
  if (fact.startsWith("component.properties.")) return availabilityEquals(`variantAvailability.componentProperties.${propertyAvailabilityKey(fact.slice("component.properties.".length))}`, true);
  return void 0;
}
function applyExplicitRuleScope(select, conditions, source, target) {
  if (source.boundaryPolicy === "component-owned@1") conditions.push(availabilityEquals("ruleScopeV1.local", true));
  if (source.targetApplicability === "visible-target@1") {
    const fact = `ruleScopeV1.targets.${target.semanticRole}.visible`;
    conditions.push(availabilityEquals(fact, true));
    select.where = [{ predicate: "any", args: [
      { predicate: "all", args: select.where || [] },
      { predicate: "all", args: [availabilityEquals("ruleScopeV1.isRoot", true), availabilityEquals(fact, false)] }
    ] }];
  }
}
function availabilityFactFor(constraint, capability) {
  return constraint.type === "relationship" ? "" : constraint.fact || factForCapability(capability);
}
function constraintsFor(rule) {
  return rule.permission === "forbidden" && !rule.constraints.length ? [{ type: "propertyForbidden" }] : rule.constraints;
}
function capabilitiesFor(rule) {
  const registered = rule.capabilitySet ? capabilitiesForSet(rule.capabilitySet) : [rule.capability];
  return rule.capabilitySet && rule.capabilitySelection ? registered.filter((capability) => rule.capabilitySelection.includes(capability)) : registered;
}
function conditionFor(rule) {
  const conditions = [];
  const prefix = rule.applicability.conditionSubject === "component-root" ? "host." : "";
  for (const [fact, value] of Object.entries(rule.applicability.context || {})) {
    conditions.push({ predicate: "equals", actual: { fact: `${prefix}${fact}` }, expected: { literal: value } });
  }
  if (rule.applicability.variants !== "all") {
    for (const [property, values] of Object.entries(rule.applicability.variants)) {
      conditions.push({
        predicate: "one-of",
        actual: { fact: `${prefix}component.properties.${property}` },
        expected: { literal: values },
        missingPolicy: "unknown"
      });
    }
  }
  if (rule.applicability.modes !== "all") {
    if (Array.isArray(rule.applicability.modes)) {
      if (rule.applicability.modes.length) {
        conditions.push({
          predicate: "one-of",
          actual: { fact: "page.context.modes.active" },
          expected: { literal: rule.applicability.modes },
          missingPolicy: "unknown"
        });
      }
    } else {
      for (const [collectionId, modeIds] of Object.entries(rule.applicability.modes)) {
        if (!modeIds.length) continue;
        conditions.push({
          predicate: "one-of",
          actual: { fact: `page.context.modes.${collectionId}` },
          expected: { literal: modeIds },
          missingPolicy: "unknown"
        });
      }
    }
  }
  if (!conditions.length) return void 0;
  return conditions.length === 1 ? conditions[0] : { predicate: "all", args: conditions };
}
function scopeFor(rule) {
  return {
    platform: rule.applicability.platforms.length ? rule.applicability.platforms : void 0,
    product: rule.applicability.products?.length ? rule.applicability.products : void 0,
    channel: rule.applicability.channels?.length ? rule.applicability.channels : void 0
  };
}
function compileApplicabilityProbe(manual, source, variantAvailability2 = false) {
  const unsupported = [];
  const list = (value, path) => {
    if (value === void 0) return [];
    if (Array.isArray(value) && value.every((item) => typeof item === "string" && item.trim())) return value;
    unsupported.push(path);
    return [];
  };
  const applicability2 = {
    variants: "all",
    modes: "all",
    platforms: list(source.applicability.platforms, "platforms"),
    products: list(source.applicability.products, "products"),
    channels: list(source.applicability.channels, "channels"),
    context: {}
  };
  if (applicability2.products?.some((product) => !PRODUCT_SCOPE_CATALOG.some((choice) => choice.value === product))) {
    unsupported.push(`products:unmapped:${applicability2.products.join(",")}`);
    applicability2.products = [];
  }
  for (const key of Object.keys(source.applicability)) {
    if (!["variants", "modes", "platforms", "products", "channels", "context", "scopeStatus", "conditionSubject"].includes(key)) unsupported.push(key);
  }
  if (source.applicability.conditionSubject === "component-root" || source.applicability.conditionSubject === "target") {
    applicability2.conditionSubject = source.applicability.conditionSubject;
  } else if (source.applicability.conditionSubject !== void 0) unsupported.push("conditionSubject");
  const domains = (value, path) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      unsupported.push(path);
      return {};
    }
    const result = {};
    for (const [key, input] of Object.entries(value)) {
      const values = list(input, `${path}.${key}`);
      if (key.trim() && values.length) result[key] = values;
      else unsupported.push(`${path}.${key}`);
    }
    return result;
  };
  if (source.applicability.variants !== "all") applicability2.variants = domains(source.applicability.variants, "variants");
  if (source.applicability.modes !== "all") applicability2.modes = Array.isArray(source.applicability.modes) ? list(source.applicability.modes, "modes") : domains(source.applicability.modes, "modes");
  const context = source.applicability.context;
  if (context !== void 0 && (!context || typeof context !== "object" || Array.isArray(context))) unsupported.push("context");
  for (const [fact, value] of Object.entries(context && typeof context === "object" && !Array.isArray(context) ? context : {})) {
    if (manual.semanticApi.some((property) => fact === `semanticApi.${property.id}`)) applicability2.context[fact] = value;
    else unsupported.push(`context.${fact}`);
  }
  if (source.applicability.scopeStatus === "needs-confirmation") unsupported.push("scopeStatus:needs-confirmation");
  const target = manual.targets.find((entry) => entry.id === source.targetId);
  const invalidTargetScope = source.targetScope && !["self", "self-and-descendants"].includes(source.targetScope);
  const targetUncertain = !target || target.resolution !== "resolved" || Boolean(invalidTargetScope);
  if (targetUncertain) unsupported.push("target");
  if (invalidTargetScope) unsupported.push("targetScope");
  const safe = { ...source, applicability: applicability2 };
  let select = target ? targetSelector(target, source.targetScope === "self-and-descendants" ? "self-and-descendants" : "self") : { from: "selection-root", traverse: "self" };
  let when = targetUncertain ? void 0 : conditionFor(safe);
  if (source.propertyApplicability) unsupported.push("propertyApplicability:per-assertion");
  if (variantAvailability2 && target && !targetUncertain) {
    const assertions = capabilitiesFor(source).flatMap((capability) => constraintsFor(source).map((constraint) => ({
      ...assertionFor(constraint, target, capability),
      fact: availabilityFactFor(constraint, capability)
    })));
    if (assertions.some((assertion) => assertion.selectRoot)) {
      select = { from: "selection-root", traverse: "self" };
    } else if (assertions.length && assertions.every((assertion) => assertion.expression)) {
      const conditions = when ? [when] : [];
      applyVariantTargetAvailability(select, conditions, target);
      const propertyConditions = assertions.map((assertion) => propertyAvailabilityCondition(assertion.fact));
      if (propertyConditions.every(Boolean)) conditions.push(propertyConditions.length === 1 ? propertyConditions[0] : { predicate: "any", args: propertyConditions });
      when = { predicate: "all", args: conditions };
    }
  }
  const rule = {
    schemaVersion: "apollo.rule-ir.v1",
    ruleId: `editor:applicability:${source.id}`,
    revision: manual.metadata.revision,
    source: { path: "contract.manual.json", anchor: source.id },
    authority: { status: "active", provenance: "editor-coverage-probe" },
    effect: "require",
    scope: scopeFor(safe),
    select,
    when,
    assert: { predicate: "equals", actual: { literal: true }, expected: { literal: true } },
    severity: "info",
    unknownPolicy: "human-review"
  };
  return { rule, unsupported: uniqueSorted(unsupported) };
}
function assertionFor(constraint, target, capability) {
  const fact = constraint.fact || factForCapability(capability);
  if (constraint.type === "propertyDomain") {
    return {
      selectRoot: false,
      expression: {
        predicate: "one-of",
        actual: { fact },
        expected: { literal: constraint.values || [] }
      }
    };
  }
  if (constraint.type === "presence") {
    const expected = constraint.expected !== false;
    return {
      selectRoot: true,
      expression: {
        predicate: "count-between",
        actual: targetQuery(target.semanticRole),
        lower: { literal: expected ? 1 : 0 },
        upper: { literal: expected ? 9999 : 0 },
        bounds: "inclusive"
      }
    };
  }
  if (constraint.type === "propertyForbidden") {
    const baselineFact = `baseline.effective.${fact}`;
    return {
      selectRoot: false,
      // Dimensions apply to the target, even if capture failed to supply its
      // reference size. Let the interpreter report unknown, not an empty selector.
      baselineApplicabilityFact: /^bounds\.(width|height)$/.test(fact) ? void 0 : /^appearance\.(fill|stroke)$/.test(fact) ? `paintEvidenceV1.${fact.split(".")[1]}` : baselineFact,
      expression: {
        predicate: "matches-effective-baseline",
        actual: { fact },
        expected: { fact: baselineFact },
        .../^(bounds\.(width|height)|appearance\.(fill|stroke))$/.test(fact) ? { missingPolicy: "unknown" } : {}
      }
    };
  }
  if (constraint.type === "quantity") {
    const roles = constraint.targetRoles;
    const query = roles ? {
      from: "selection-root",
      traverse: "self-and-descendants",
      where: [
        { predicate: "one-of", actual: { fact: "semantic.role" }, expected: { literal: roles } },
        ...constraint.visibleOnly ? [{ predicate: "equals", actual: { fact: "visibility.effective" }, expected: { literal: true } }] : []
      ]
    } : void 0;
    return {
      selectRoot: true,
      expression: {
        predicate: "count-between",
        actual: query ? { query } : targetQuery(constraint.targetRole || target.semanticRole),
        lower: { literal: constraint.min ?? 0 },
        upper: { literal: constraint.max ?? 9999 },
        bounds: "inclusive"
      }
    };
  }
  if (constraint.type === "positionOrder") {
    return {
      selectRoot: true,
      expression: {
        predicate: "sequence-equals",
        actual: {
          query: {
            from: "selection-root",
            traverse: "direct-children",
            project: { fact: "semantic.role" }
          }
        },
        expected: { literal: constraint.order || [] }
      }
    };
  }
  if (constraint.type === "relationship") {
    return {
      selectRoot: false,
      expression: {
        predicate: constraint.relation,
        actual: { fact: "id" },
        expected: { fact: `relations.${constraint.targetRole}` }
      }
    };
  }
  if (constraint.type === "tokenBinding") {
    const expected = {};
    if (constraint.bindingRequired !== void 0) expected.required = constraint.bindingRequired;
    if (constraint.tokenIds?.length) expected.tokenIds = constraint.tokenIds;
    return {
      selectRoot: false,
      expression: {
        predicate: "binding-satisfies",
        actual: { fact: constraint.fact || `variable.bindings.${fact.replace(/\./g, "_")}` },
        expected: { literal: expected }
      }
    };
  }
  if (constraint.type === "layoutConstraint") {
    if (constraint.operator === "between" || constraint.min !== void 0 || constraint.max !== void 0) {
      return {
        selectRoot: false,
        expression: {
          predicate: "between",
          actual: { fact },
          lower: { literal: constraint.min ?? Number.MIN_SAFE_INTEGER },
          upper: { literal: constraint.max ?? Number.MAX_SAFE_INTEGER },
          bounds: "inclusive"
        }
      };
    }
    return {
      selectRoot: false,
      expression: {
        predicate: "equals",
        actual: { fact },
        expected: { literal: constraint.value }
      }
    };
  }
  return { selectRoot: false, reason: `Constraint ${constraint.type} is not compilable.` };
}
function sourceCapabilities(rule) {
  const selectors = ["selection-root", String(rule.select.traverse || "self")];
  const serialized = JSON.stringify(rule);
  const facts = Array.from(serialized.matchAll(/"fact":"([^"]+)"/g)).map((match) => match[1]);
  const operators = Array.from(serialized.matchAll(/"predicate":"([^"]+)"/g)).map((match) => match[1]);
  return {
    selectors: uniqueSorted(selectors),
    facts: uniqueSorted(facts),
    operators: uniqueSorted(operators),
    remediations: rule.remediation ? [String(rule.remediation.kind || "")].filter(Boolean) : []
  };
}
function compileManualSource(manual, variantEvidence, dependencyContracts = []) {
  if (variantEvidence) {
    const keys = new Set(manual.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated").flatMap((r) => [r.locator.componentKey, r.locator.componentSetKey]).filter(Boolean));
    const variants = variantEvidence.variants.filter((v) => keys.has(v.componentSetKey) || keys.has(v.componentKey));
    const structures = Object.fromEntries([...new Set(variants.map((v) => v.structureId))].filter((id) => variantEvidence.structures[id]).map((id) => [id, variantEvidence.structures[id]]));
    variantEvidence = { ...variantEvidence, variants, structures };
  }
  const issues = validateManualSource(manual);
  const componentDependencies = linkComponentDependencies(manual, dependencyContracts);
  componentDependencies.forEach((d, index) => {
    if (d.issue) issues.push({ level: "error", code: "COMPONENT_DEPENDENCY_LINK", path: `/componentDependencies/${index}`, message: d.issue });
  });
  const manualSourceHash = stableHash(manual);
  const targets = new Map(manual.targets.map((target) => [target.id, target]));
  const rules = [];
  const dependencyBindings = /* @__PURE__ */ new Map();
  const nonExecutableRules = [];
  const byConstraintType = {};
  const byExecutionRoute = {};
  for (const [ruleIndex, sourceRule] of manual.rules.entries()) {
    if (sourceRule.status === "deprecated") continue;
    const target = targets.get(sourceRule.targetId);
    if (!target) continue;
    const requestedRoute = sourceRule.execution?.route || "auto";
    const executionRoute = requestedRoute === "auto" ? sourceRule.permission === "allowed" ? "policy-only" : "predicate" : requestedRoute;
    byExecutionRoute[executionRoute] = (byExecutionRoute[executionRoute] || 0) + 1;
    const ruleErrors = issues.filter((issue) => issue.level === "error" && issue.path.startsWith(`/rules/${ruleIndex}/`));
    if (ruleErrors.length) {
      nonExecutableRules.push({
        id: sourceRule.id,
        sourceRuleId: sourceRule.id,
        reason: ruleErrors.map((issue) => `${issue.code}: ${issue.message}`).join(" ")
      });
      continue;
    }
    if (executionRoute === "policy-only" || executionRoute === "delegated") continue;
    if (executionRoute === "context-only") {
      nonExecutableRules.push({
        id: sourceRule.id,
        sourceRuleId: sourceRule.id,
        reason: `Missing runtime facts: ${(sourceRule.execution?.missingFacts || []).join(", ")}.`
      });
      continue;
    }
    const registeredCapabilities = sourceRule.capabilitySet ? capabilitiesForSet(sourceRule.capabilitySet) : [sourceRule.capability];
    const capabilities = capabilitiesFor(sourceRule);
    if (sourceRule.capabilitySet && !registeredCapabilities.length) {
      nonExecutableRules.push({
        id: sourceRule.id,
        sourceRuleId: sourceRule.id,
        reason: `Unknown capability set: ${sourceRule.capabilitySet}.`
      });
      continue;
    }
    if (sourceRule.capabilitySet && !capabilities.length) {
      nonExecutableRules.push({
        id: sourceRule.id,
        sourceRuleId: sourceRule.id,
        reason: `Capability set has no selected capabilities: ${sourceRule.capabilitySet}.`
      });
      continue;
    }
    const constraints = constraintsFor(sourceRule);
    if (!constraints.length) {
      nonExecutableRules.push({
        id: sourceRule.id,
        sourceRuleId: sourceRule.id,
        reason: "Rule has no normative constraint to compile."
      });
      continue;
    }
    capabilities.forEach((capability, capabilityIndex) => {
      constraints.forEach((constraint, constraintIndex) => {
        byConstraintType[constraint.type] = (byConstraintType[constraint.type] || 0) + 1;
        if (constraint.type === "dependencyDomain" && constraint.dependency) {
          const dependency = constraint.dependency;
          dependency.subjects.forEach((subject, subjectIndex) => {
            const binding = dependencyBinding(subject, constraint);
            dependencyBindings.set(binding.id, { ...dependencyBindings.get(binding.id), ...binding });
            const prefix = `dependencies.${binding.id}`;
            const domain = (values) => dependency.tolerance !== void 0 ? { predicate: "any", args: values.map((value) => ({
              predicate: "between",
              actual: { fact: `${prefix}.${dependency.field}` },
              lower: { literal: Number(value) - dependency.tolerance },
              upper: { literal: Number(value) + dependency.tolerance },
              bounds: "inclusive",
              missingPolicy: "unknown"
            })) } : { predicate: "one-of", actual: { fact: `${prefix}.${dependency.field}` }, expected: { literal: values }, missingPolicy: "unknown" };
            const assert = dependency.cases ? { predicate: "any", args: dependency.cases.map((c) => ({ predicate: "all", args: [
              { predicate: "one-of", actual: { fact: dependency.sourceFact }, expected: { literal: c.when }, missingPolicy: "unknown" },
              domain(c.values)
            ] })) } : domain(constraint.values || []);
            const conditions2 = [availabilityEquals(`${prefix}.applicable`, true)];
            if (dependency.catalogs) conditions2.push({ predicate: "one-of", actual: { fact: `${prefix}.catalog` }, expected: { literal: dependency.catalogs }, missingPolicy: "unknown" });
            if (dependency.activePorts) conditions2.push({ predicate: "one-of", actual: { fact: `${prefix}.portName` }, expected: { literal: dependency.activePorts }, missingPolicy: "unknown" });
            if (conditionFor(sourceRule)) conditions2.push(conditionFor(sourceRule));
            if (dependency.baselinePolicy === "allow-unchanged") conditions2.push(availabilityEquals(`${prefix}.changed`, true));
            rules.push({
              schemaVersion: "apollo.rule-ir.v1",
              ruleId: `${sourceRule.id}.${capabilityIndex + 1}.${constraintIndex + 1}.${subjectIndex + 1}`,
              revision: manual.metadata.revision,
              source: { path: "contract.manual.json", checksum: manualSourceHash, anchor: sourceRule.id },
              authority: { status: sourceRule.status === "reviewed" ? "active" : sourceRule.status, provenance: sourceRule.owner },
              effect: "require",
              scope: scopeFor(sourceRule),
              select: { from: "selection-root", traverse: "self" },
              when: { predicate: "all", args: conditions2 },
              assert,
              severity: sourceRule.severity,
              unknownPolicy: "human-review",
              presentation: {
                title: sourceRule.message || sourceRule.rationale,
                group: `${capability} \xB7 ${subject.targetRole}`,
                ...["portName", "width", "height", "variantProperty"].includes(dependency.field) ? { dependency: { bindingId: binding.id, field: dependency.field, targetRole: subject.targetRole, ...dependency.property ? { property: dependency.property } : {} } } : {}
              },
              manual: { permission: sourceRule.permission, controlPaths: sourceRule.controlPaths }
            });
          });
          return;
        }
        const assertion = assertionFor(constraint, target, capability);
        if (!assertion.expression) {
          nonExecutableRules.push({
            id: `${sourceRule.id}.${constraintIndex + 1}`,
            sourceRuleId: sourceRule.id,
            reason: assertion.reason || "Unsupported constraint."
          });
          return;
        }
        const ruleId = [sourceRule.id, capabilityIndex + 1, constraintIndex + 1].join(".");
        const conditions = conditionFor(sourceRule) ? [conditionFor(sourceRule)] : [];
        const activity = constraint.type === "propertyForbidden" ? propertyApplicabilityCondition(sourceRule, constraint.fact || factForCapability(capability)) : void 0;
        if (activity) conditions.push(activity);
        const eq = (fact, value) => ({ predicate: "equals", actual: { fact }, expected: { literal: value } });
        if (constraint.targetRoles?.length) {
          conditions.push(...constraint.targetRoles.map((role) => eq(`semanticTargets.${role}.resolved`, true)));
          if (constraint.visibleOnly) conditions.push(...constraint.targetRoles.map((role) => eq(`semanticTargets.${role}.visibilityKnown`, true)));
        }
        if (variantEvidence && assertion.selectRoot && !constraint.targetRoles?.length && ["presence", "quantity"].includes(constraint.type)) {
          conditions.push(eq(`semanticTargets.${constraint.targetRole || target.semanticRole}.resolved`, true));
        }
        const select = assertion.selectRoot ? { from: "selection-root", traverse: "self" } : targetSelector(target, sourceRule.targetScope || "self", activity ? void 0 : assertion.baselineApplicabilityFact);
        if (variantEvidence && !assertion.selectRoot) {
          applyVariantTargetAvailability(select, conditions, target);
          const fact = availabilityFactFor(constraint, capability);
          const propertyCondition = propertyAvailabilityCondition(fact);
          if (propertyCondition) conditions.push(propertyCondition);
        }
        applyExplicitRuleScope(select, conditions, sourceRule, target);
        const rule = {
          schemaVersion: "apollo.rule-ir.v1",
          ruleId,
          revision: manual.metadata.revision,
          source: {
            path: "contract.manual.json",
            checksum: manualSourceHash,
            anchor: sourceRule.id
          },
          authority: {
            status: sourceRule.status === "reviewed" ? "active" : sourceRule.status,
            provenance: sourceRule.owner || "design-system-authors"
          },
          effect: "require",
          scope: scopeFor(sourceRule),
          select,
          when: activity || constraint.targetRoles?.length || variantEvidence || sourceRule.boundaryPolicy || sourceRule.targetApplicability ? conditions.length ? { predicate: "all", args: conditions } : void 0 : conditionFor(sourceRule),
          assert: activity ? { ...assertion.expression, missingPolicy: "unknown" } : assertion.expression,
          severity: sourceRule.severity,
          unknownPolicy: "human-review",
          remediation: sourceRule.remediationIntent ? { kind: sourceRule.remediationIntent, safety: "compiler-review-required" } : null,
          presentation: {
            title: sourceRule.message || sourceRule.rationale || sourceRule.id,
            group: capability,
            remediation: sourceRule.remediationMessage,
            ...activity ? { propertyApplicability: sourceRule.propertyApplicability?.[constraint.fact || factForCapability(capability)] } : {},
            ...sourceRule.boundaryPolicy ? { boundaryPolicy: sourceRule.boundaryPolicy } : {},
            ...sourceRule.targetApplicability ? { targetApplicability: sourceRule.targetApplicability } : {}
          },
          manual: {
            permission: sourceRule.permission,
            targetScope: sourceRule.targetScope || "self",
            controlPaths: sourceRule.controlPaths
          }
        };
        rules.push(rule);
      });
    });
  }
  rules.sort((left, right) => left.ruleId.localeCompare(right.ruleId));
  nonExecutableRules.sort((left, right) => left.id.localeCompare(right.id));
  const capabilityParts = rules.map(sourceCapabilities);
  const contract = {
    schemaVersion: COMPILED_SCHEMA_VERSION,
    documentType: "component-contract",
    package: {
      id: manual.component.contractId,
      componentId: manual.component.componentId,
      family: manual.component.family,
      library: manual.component.library,
      sourcePath: "contract.manual.json",
      sourceGeneratedAt: manual.metadata.updatedAt || manual.metadata.createdAt || manual.source.importedAt,
      // Last compiler-output revision; presentation-only Editor patches keep
      // compiled bytes and pinned dependency hashes stable.
      sourceExportVersion: "component-contract-editor@0.2.35",
      ...componentDependencies.length ? { manualRevision: manual.metadata.revision } : {},
      snapshotProfile: dependencyBindings.size ? "dependency-facts-v5" : variantEvidence ? "variant-facts-v4" : "component-facts-v2",
      ...variantEvidence ? { generatedFactsHash: stableHash(variantEvidence) } : {},
      manualSourceHash
    },
    status: issues.some((issue) => issue.level === "error") || nonExecutableRules.length > 0 || manual.rules.some((rule) => rule.status !== "reviewed" && rule.status !== "deprecated") ? "draft" : "ready",
    ...componentDependencies.length ? { componentDependencies } : {},
    facts: {
      ...dependencyBindings.size ? { dependencyBindings: [...dependencyBindings.values()].sort((a, b) => a.id.localeCompare(b.id)) } : {},
      ...variantEvidence ? { variantEvidence } : {},
      component: manual.component,
      semantics: manual.semantics,
      representations: manual.representations,
      semanticApi: manual.semanticApi,
      documentation: manual.documentation,
      examples: manual.examples,
      decisions: manual.decisions,
      generation: manual.generation,
      targets: manual.targets,
      controlPorts: manual.controlPorts
    },
    customizationPolicy: manual.rules.map((rule) => ({
      id: rule.id,
      targetId: rule.targetId,
      ...rule.targetScope ? { targetScope: rule.targetScope } : {},
      ...rule.boundaryPolicy ? { boundaryPolicy: rule.boundaryPolicy } : {},
      ...rule.targetApplicability ? { targetApplicability: rule.targetApplicability } : {},
      capability: rule.capability,
      ...rule.capabilitySet ? { capabilitySet: rule.capabilitySet } : {},
      ...rule.capabilitySelection ? { capabilitySelection: rule.capabilitySelection } : {},
      ...rule.propertyApplicability ? { propertyApplicability: rule.propertyApplicability } : {},
      permission: rule.permission,
      controlPaths: rule.controlPaths,
      applicability: rule.applicability,
      severity: rule.severity,
      status: rule.status,
      owner: rule.owner,
      ...rule.sourceRefs?.length ? { sourceRefs: rule.sourceRefs } : {},
      execution: rule.execution || { route: "auto" }
    })).sort((left, right) => left.id.localeCompare(right.id)),
    rules,
    nonExecutableRules,
    capabilities: {
      selectors: uniqueSorted(capabilityParts.flatMap((part) => part.selectors)),
      facts: uniqueSorted(capabilityParts.flatMap((part) => part.facts)),
      operators: uniqueSorted(capabilityParts.flatMap((part) => part.operators)),
      remediations: uniqueSorted(capabilityParts.flatMap((part) => part.remediations))
    },
    coverage: {
      sourceRules: manual.rules.length,
      policyRules: manual.rules.length,
      policyOnlyRules: manual.rules.filter((rule) => rule.permission === "allowed").length,
      compiledRules: rules.length,
      nonExecutableRules: nonExecutableRules.length,
      byConstraintType: Object.fromEntries(
        Object.entries(byConstraintType).sort(([left], [right]) => left.localeCompare(right))
      ),
      byExecutionRoute: Object.fromEntries(
        Object.entries(byExecutionRoute).sort(([left], [right]) => left.localeCompare(right))
      )
    },
    runtimePolicy: {
      engine: "apollo-predicate-engine",
      unknownPolicy: "fail-closed",
      compiledIsSourceOfTruth: false,
      gradientPaintFactsVersion: 1,
      ...manual.rules.some((rule) => rule.boundaryPolicy || rule.targetApplicability) ? { ruleScopeFactsVersion: 1 } : {}
    }
  };
  return { contract, issues };
}

// src/core/runtime.ts
var import_predicate_engine = __toESM(require_predicate_engine());

// src/core/semantic-facts.ts
function supportedSemanticBinding(binding) {
  return binding.path.startsWith("component.properties.") && ["identity", "number-to-string", "boolean-string", "pascal-case"].includes(binding.transform || "identity");
}
function decode(value, property, transform = "identity") {
  if (transform === "number-to-string") {
    if (!["number", "enum"].includes(property.valueType) || typeof value !== "string" || !/^-?\d+(\.\d+)?$/.test(value)) return void 0;
    const number = Number(value);
    return Number.isFinite(number) ? number : void 0;
  }
  if (transform === "boolean-string") {
    if (property.valueType !== "boolean") return void 0;
    return value === "True" || value === "true" ? true : value === "False" || value === "false" ? false : void 0;
  }
  if (transform === "pascal-case") {
    const matches = (property.domain || []).filter((entry) => typeof entry === "string" && entry.charAt(0).toUpperCase() + entry.slice(1) === value);
    return matches.length === 1 ? matches[0] : void 0;
  }
  if (property.valueType === "boolean") return typeof value === "boolean" ? value : void 0;
  if (property.valueType === "number") return typeof value === "number" && Number.isFinite(value) ? value : void 0;
  if (["enum", "string", "content"].includes(property.valueType)) return typeof value === "string" || typeof value === "number" ? value : void 0;
  return void 0;
}
function materializeSemanticFacts(snapshot, contract) {
  if (!contract.facts.semanticApi.length) return;
  const keys = [snapshot.source?.componentKey, snapshot.source?.componentSetKey].filter(Boolean);
  const representations = contract.facts.representations.filter((rep) => rep.kind === "figma" && rep.platform === snapshot.context.platform && rep.status !== "deprecated" && keys.some((key) => key === rep.locator.componentKey || key === rep.locator.componentSetKey));
  for (const node of snapshot.nodes.filter((entry) => snapshot.selection.includes(String(entry.id)))) {
    const values = /* @__PURE__ */ Object.create(null);
    const evidence = /* @__PURE__ */ Object.create(null);
    const unknown3 = new Set(Array.isArray(node.unknownFacts) ? node.unknownFacts : []);
    const component = node.component;
    for (const property of contract.facts.semanticApi) {
      const fact = `semanticApi.${property.id}`;
      let reason = "representation-unresolved";
      if (representations.length === 1) {
        const bindings = property.bindings.filter((binding) => binding.representationId === representations[0].id);
        reason = bindings.length === 1 ? "unsupported-binding" : "binding-missing-or-ambiguous";
        if (bindings.length === 1 && supportedSemanticBinding(bindings[0])) {
          const binding = bindings[0];
          const raw = component?.properties?.[binding.path.slice("component.properties.".length)];
          const sourceUnknown = Array.from(unknown3).some((path) => binding.path === path || binding.path.startsWith(`${path}.`));
          const value = sourceUnknown ? void 0 : decode(raw, property, binding.transform);
          reason = value === void 0 ? "source-missing-unknown-or-incompatible" : "resolved";
          if (value !== void 0) {
            values[property.id] = value;
            unknown3.delete(fact);
          }
          evidence[property.id] = { reason, representationId: representations[0].id, path: binding.path, transform: binding.transform || "identity" };
        }
      }
      if (!Object.prototype.hasOwnProperty.call(evidence, property.id)) evidence[property.id] = { reason };
      if (!Object.prototype.hasOwnProperty.call(values, property.id)) unknown3.add(fact);
    }
    node.semanticApi = values;
    node.semanticBindingEvidence = evidence;
    node.unknownFacts = Array.from(unknown3);
  }
}

// src/core/component-facts.ts
function unknown(node, path) {
  return (node.unknownFacts || []).some((entry) => path === entry || path.startsWith(`${entry}.`));
}
function materializeComponentFacts(snapshot, contract) {
  const roots = snapshot.nodes.filter((node) => snapshot.selection.includes(String(node.id)));
  const root = roots.length === 1 ? roots[0] : void 0;
  const index = new Map(snapshot.nodes.map((node) => [String(node.id), node]));
  const visibility = (node) => {
    const visited = /* @__PURE__ */ new Set();
    let current = node;
    let uncertain = false;
    let hidden = false;
    while (current) {
      const id = String(current.id);
      if (visited.has(id)) return void 0;
      visited.add(id);
      if (unknown(current, "visible") || typeof current.visible !== "boolean") uncertain = true;
      else if (current.visible === false) hidden = true;
      if (current === root) return hidden ? false : uncertain ? void 0 : true;
      current = index.get(String(current.parentId));
    }
    return void 0;
  };
  const host = root ? { component: root.component || {}, semanticApi: root.semanticApi || {} } : {};
  const hostUnknown = root ? (root.unknownFacts || []).filter((path) => /^(component|semanticApi)(\.|$)/.test(path)).map((path) => `host.${path}`) : ["host"];
  const targets = {};
  const targetsUnknown = [];
  if (["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) {
    const roles = /* @__PURE__ */ new Map();
    for (const node of snapshot.nodes) {
      const role = node.semantic?.role;
      if (role) roles.set(role, [...roles.get(role) || [], String(node.id)]);
    }
    const relations = Object.fromEntries([...roles].filter(([, ids]) => ids.length === 1).map(([role, ids]) => [role, ids[0]]));
    snapshot.nodes.forEach((node) => {
      node.relations = { ...relations };
    });
  }
  for (const target of contract.facts.targets) {
    const candidates = snapshot.nodes.filter((node) => node.semantic?.role === target.semanticRole);
    const verified = root?.variantAvailability?.targets?.[target.semanticRole];
    if (verified?.present === false && candidates.length === 0) {
      targets[target.semanticRole] = { resolved: true, visibilityKnown: true, present: false };
    } else if (root && !snapshot.source?.truncated && (target.resolution === "resolved" || verified?.present === true) && candidates.length === 1 && !unknown(candidates[0], "semantic.role")) {
      targets[target.semanticRole] = { resolved: true, ...verified ? { present: true } : {} };
      if (visibility(candidates[0]) !== void 0) targets[target.semanticRole].visibilityKnown = true;
      else targetsUnknown.push(`semanticTargets.${target.semanticRole}.visibilityKnown`);
    } else targetsUnknown.push(`semanticTargets.${target.semanticRole}`);
  }
  for (const node of snapshot.nodes) {
    const paths = new Set((node.unknownFacts || []).filter((path) => path !== "host" && !path.startsWith("host.") && path !== "visibility.effective" && !path.startsWith("semanticTargets.")));
    const effective = visibility(node);
    node.visibility = effective === void 0 ? {} : { effective };
    if (effective === void 0) paths.add("visibility.effective");
    node.host = JSON.parse(JSON.stringify(host));
    node.semanticTargets = targets;
    hostUnknown.forEach((path) => paths.add(path));
    targetsUnknown.forEach((path) => paths.add(path));
    node.unknownFacts = [...paths];
  }
}

// src/core/nested-instance-content-reference.ts
var INSTANCE_CONTENT_REFERENCE_LIMIT = 8;
var record7 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var clone = (v) => JSON.parse(JSON.stringify(v));
var referenceFor = (s) => captureVariantReference(s, s.source?.componentKey || "", s.source?.componentSetKey || "");
var nodesByPath = (s) => {
  const paths = snapshotPaths(s);
  return paths && new Map(s.nodes.map((n) => [paths.get(String(n.id)), n]));
};
function planNestedInstanceContentReferences(snapshot, reference, parent) {
  const comparison = compareInstanceBoundaries(snapshot, referenceFor(reference), true);
  return comparison.complete ? comparison.boundaries.filter((b) => b.actualPath !== parent.actualPath && withinBoundary(b.actualPath, parent.actualPath)) : [];
}
function materializeNestedInstanceContentReferences(snapshot) {
  const evidence = snapshot.instanceContentReferences;
  const actual = nodesByPath(snapshot), original = snapshot.variantReference;
  const results = [];
  snapshot.instanceContentResults = results;
  const comparison = original && compareInstanceBoundaries(snapshot, original, true);
  const roots = comparison?.complete ? comparison.boundaries : [];
  snapshot.instanceBoundaries = [...roots];
  const base = evidence.base;
  const baseRef = base && captureVariantReference(base, base.source?.componentKey || "", base.source?.componentSetKey || "", original?.definedProperties);
  const baseValid = actual && original?.complete && baseRef?.complete && base.source?.rootNodeId && base.source.rootNodeId !== snapshot.source?.rootNodeId && stableHash(baseRef) === stableHash(original) && base.context.platform === snapshot.context.platform && stableHash(base.context.modes) === stableHash(snapshot.context.modes);
  let visited = 0;
  const visit = (boundary, context, parentId) => {
    const result = { boundaryNodeId: boundary.nodeId, status: "unresolved", reason: "reference-not-captured", matchedNodeIds: [] };
    results.push(result);
    if (actual) {
      for (const [path, node] of actual) if (withinBoundary(path, boundary.actualPath)) {
        node.baseline = { effective: {} };
        node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
        if (node.semantic) delete record7(node.semantic).role;
      }
    }
    const fail = (reason) => {
      result.reason = reason;
      return result;
    };
    if (++visited > INSTANCE_CONTENT_REFERENCE_LIMIT) return fail("reference-capture-limit");
    if (!baseValid) return fail("original-host-evidence-invalid");
    const variant = boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
    if (!boundary.actualComponentKey || !variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) return fail("explicit-swap-port-required");
    const attempts = evidence.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId);
    if (attempts.length !== 1) return fail(attempts.length ? "ambiguous-reference" : "reference-not-captured");
    const attempt = attempts[0], reference = attempt.reference;
    if (attempt.parentBoundaryNodeId !== parentId) return fail("reference-parent-mismatch");
    if (attempt.failure || !reference) return fail(attempt.failure || "reference-not-captured");
    if (variant && attempt.strategy !== "pristine-host-variant-properties") return fail("variant-capture-strategy-unproven");
    const expected = nodesByPath(reference), contextNodes = nodesByPath(context);
    const refId = reference.source?.rootNodeId;
    if (!expected || !contextNodes || !refId || refId === snapshot.source?.rootNodeId || refId === base.source?.rootNodeId || refId === context.source?.rootNodeId || reference.context.platform !== snapshot.context.platform || stableHash(reference.context.modes) !== stableHash(snapshot.context.modes)) return fail("replacement-reference-incomplete");
    const change = compareInstanceBoundaries(reference, referenceFor(context), true), refBoundary = change.boundaries[0];
    if (!change.complete || change.boundaries.length !== 1 || refBoundary.reason !== boundary.reason || refBoundary.referencePath !== boundary.referencePath || refBoundary.ownerPath !== boundary.ownerPath || refBoundary.property !== boundary.property || refBoundary.actualComponentKey !== boundary.actualComponentKey || refBoundary.componentSetKey !== boundary.componentSetKey) return fail("replacement-identity-or-port-mismatch");
    for (const [path, node] of contextNodes) {
      if (withinBoundary(path, boundary.referencePath)) continue;
      const other = expected.get(path);
      if (!other) return fail("host-context-changed");
      const before = clone(effectiveFacts(node)), after = clone(effectiveFacts(other));
      if (!variant && path === boundary.ownerPath && boundary.property) {
        delete record7(record7(before.component).properties)[boundary.property];
        delete record7(record7(after.component).properties)[boundary.property];
      }
      if (stableHash(before) !== stableHash(after)) return fail("host-context-changed");
    }
    const remainder = compareInstanceBoundaries(snapshot, referenceFor(reference), true);
    if (!remainder.complete) return fail("replacement-structure-needs-remap");
    const children = remainder.boundaries.filter((b) => withinBoundary(b.actualPath, boundary.actualPath));
    if (children.some((b) => b.actualPath === boundary.actualPath)) return fail("replacement-nested-identity-unresolved");
    const pairs = [];
    for (const [path, node] of actual) {
      if (!withinBoundary(path, boundary.actualPath) || children.some((b) => withinBoundary(path, b.actualPath))) continue;
      const relative2 = path.slice(boundary.actualPath.length), other = expected.get(refBoundary.actualPath + relative2);
      if (!other || other.type !== node.type) return fail("replacement-structure-needs-remap");
      if (node.type === "INSTANCE") {
        const a = record7(record7(node.component).identity), b = record7(record7(other.component).identity);
        if (!a.componentKey || a.componentKey !== b.componentKey || (a.componentSetKey || "") !== (b.componentSetKey || "")) return fail("replacement-nested-identity-unresolved");
      }
      pairs.push([path, node, other]);
    }
    if (variant) {
      const props = (n) => {
        const c = record7(n?.component);
        return Object.fromEntries(Object.entries(record7(c.propertyTypes)).filter(([, t]) => t === "VARIANT").map(([p]) => [p, record7(c.properties)[p]]));
      };
      const expectedProperties = props(expected.get(refBoundary.actualPath));
      if (!Object.keys(expectedProperties).length || stableHash(props(actual.get(boundary.actualPath))) !== stableHash(expectedProperties)) return fail("variant-properties-mismatch");
    }
    result.lineageProven = true;
    for (const [path, node, other] of pairs) {
      node.baseline = { effective: clone(effectiveFacts(
        other,
        snapshot.source?.geometryCaptureVersion === 1 && reference.source?.geometryCaptureVersion === 1
      )) };
      if (variant && path === boundary.actualPath) {
        const originalComponent = record7(contextNodes.get(boundary.referencePath)?.component), current = record7(node.component);
        const baseline = record7(record7(record7(node.baseline).effective).component), available = record7(record7(node.variantAvailability).componentProperties);
        for (const [name, type] of Object.entries(record7(current.propertyTypes))) {
          if (type !== "VARIANT" || record7(originalComponent.propertyTypes)[name] !== "VARIANT" || !Object.prototype.hasOwnProperty.call(record7(originalComponent.properties), name)) continue;
          record7(baseline.properties)[name] = originalComponent.properties[name];
          available[propertyAvailabilityKey(name)] = true;
          node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== `variantAvailability.componentProperties.${propertyAvailabilityKey(name)}`);
        }
        if (node.variantAvailability) record7(node.variantAvailability).componentProperties = available;
      }
      node.baselineProvenance = {
        status: "matched",
        kind: variant ? "independent-host-variant" : "independent-host-swap",
        boundaryNodeId: boundary.nodeId,
        componentKey: boundary.actualComponentKey,
        ownerPath: boundary.ownerPath,
        property: boundary.property,
        ...variant ? { componentSetKey: boundary.componentSetKey } : {},
        referencePath: refBoundary.actualPath + path.slice(boundary.actualPath.length)
      };
      result.matchedNodeIds.push(String(node.id));
    }
    let complete = true;
    for (const child of children) {
      snapshot.instanceBoundaries.push(child);
      const childResult = visit(child, reference, boundary.nodeId);
      complete = complete && childResult.status === "matched";
      result.matchedNodeIds.push(...childResult.matchedNodeIds);
    }
    result.status = complete ? "matched" : "partial";
    result.reason = complete ? variant ? "independent-host-variant-reference" : "independent-host-swap-reference" : "nested-content-reference-unresolved";
    return result;
  };
  for (const boundary of roots) visit(boundary, base);
}

// src/core/instance-content-reference.ts
var record8 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var clone2 = (v) => JSON.parse(JSON.stringify(v));
function planInstanceContentReferences(snapshot) {
  if (!snapshot.variantReference) return [];
  const comparison = compareInstanceBoundaries(snapshot, snapshot.variantReference);
  return comparison.complete ? comparison.boundaries : [];
}
function byPath(snapshot) {
  const paths = snapshotPaths(snapshot);
  return paths && new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
}
function subtree(nodes, root) {
  return new Map([...nodes].filter(([p]) => withinBoundary(p, root)).map(([p, n]) => [p === root ? "" : p.slice(root.length + 3), n]));
}
function materializeInstanceContentReferences(snapshot) {
  const evidence = snapshot.instanceContentReferences;
  if (!evidence) return;
  if (evidence.schemaVersion === "apollo.instance-content-references.v4") {
    materializeNestedInstanceContentReferences(snapshot);
    return;
  }
  const boundaries = planInstanceContentReferences(snapshot);
  const results = [];
  snapshot.instanceContentResults = results;
  const original = snapshot.variantReference;
  const actualNodes = byPath(snapshot);
  const base = evidence.base;
  const baseNodes = base && byPath(base);
  const baseReference = base && captureVariantReference(
    base,
    base.source?.componentKey || "",
    base.source?.componentSetKey || "",
    original?.definedProperties
  );
  const nestedVariants = ["apollo.instance-content-references.v2", "apollo.instance-content-references.v3"].includes(evidence.schemaVersion);
  const baseValid = (evidence.schemaVersion === "apollo.instance-content-references.v1" || nestedVariants) && actualNodes && baseNodes && original?.complete && baseReference?.complete && base.source?.rootNodeId && base.source.rootNodeId !== snapshot.source?.rootNodeId && stableHash(baseReference) === stableHash(original) && stableHash(base.context.modes) === stableHash(snapshot.context.modes) && base.context.platform === snapshot.context.platform;
  for (const boundary of boundaries) {
    const result = { boundaryNodeId: boundary.nodeId, status: "unresolved", reason: "reference-not-captured", matchedNodeIds: [] };
    results.push(result);
    if (actualNodes) for (const node of subtree(actualNodes, boundary.actualPath).values()) {
      node.baseline = { effective: {} };
      node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
      if (node.semantic && typeof node.semantic === "object") delete record8(node.semantic).role;
    }
    if (!baseValid) {
      result.reason = "original-host-evidence-invalid";
      continue;
    }
    const variant = nestedVariants && boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
    if (!boundary.actualComponentKey || !variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) {
      result.reason = "explicit-swap-port-required";
      continue;
    }
    const attempts = evidence.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId);
    if (attempts.length !== 1) {
      result.reason = attempts.length ? "ambiguous-reference" : "reference-not-captured";
      continue;
    }
    const attempt = attempts[0], reference = attempt.reference;
    if (attempt.failure || !reference) {
      result.reason = attempt.failure || "reference-not-captured";
      continue;
    }
    if (variant && evidence.schemaVersion === "apollo.instance-content-references.v3" && attempt.strategy !== "pristine-host-variant-properties") {
      result.reason = "variant-capture-strategy-unproven";
      continue;
    }
    const refNodes = byPath(reference);
    const independent = reference.source?.rootNodeId && reference.source.rootNodeId !== snapshot.source?.rootNodeId && reference.source.rootNodeId !== base.source?.rootNodeId;
    if (!independent || !refNodes || stableHash(reference.context.modes) !== stableHash(snapshot.context.modes) || reference.context.platform !== snapshot.context.platform) {
      result.reason = "replacement-reference-incomplete";
      continue;
    }
    const comparison = compareInstanceBoundaries(reference, original, nestedVariants);
    const refBoundary = comparison.boundaries[0];
    if (!comparison.complete || comparison.boundaries.length !== 1 || refBoundary.reason !== boundary.reason || refBoundary.referencePath !== boundary.referencePath || refBoundary.ownerPath !== boundary.ownerPath || refBoundary.property !== boundary.property || refBoundary.actualComponentKey !== boundary.actualComponentKey || refBoundary.componentSetKey !== boundary.componentSetKey) {
      result.reason = "replacement-identity-or-port-mismatch";
      continue;
    }
    let hostIntact = true;
    for (const [path, node] of baseNodes) {
      if (withinBoundary(path, boundary.referencePath)) continue;
      const other = refNodes.get(path);
      if (!other) {
        hostIntact = false;
        break;
      }
      const expected2 = clone2(effectiveFacts(node)), observed = clone2(effectiveFacts(other));
      if (!variant && path === boundary.ownerPath && boundary.property) {
        delete record8(record8(expected2.component).properties)[boundary.property];
        delete record8(record8(observed.component).properties)[boundary.property];
      }
      if (stableHash(expected2) !== stableHash(observed)) {
        hostIntact = false;
        break;
      }
    }
    if (!hostIntact) {
      result.reason = "host-context-changed";
      continue;
    }
    const actual = subtree(actualNodes, boundary.actualPath), expected = subtree(refNodes, refBoundary.actualPath);
    const shape = (nodes) => [...nodes].map(([p, n]) => [p, n.type]).sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    if (stableHash(shape(actual)) !== stableHash(shape(expected))) {
      result.reason = "replacement-structure-needs-remap";
      continue;
    }
    const identityKnown = [...actual].every(([path, node]) => {
      if (node.type !== "INSTANCE") return true;
      const a = record8(record8(node.component).identity), b = record8(record8(expected.get(path)?.component).identity);
      return Boolean(a.componentKey && b.componentKey && a.componentKey === b.componentKey && (a.componentSetKey || "") === (b.componentSetKey || ""));
    });
    if (!identityKnown) {
      result.reason = "replacement-nested-identity-unresolved";
      continue;
    }
    if (variant) {
      const variantProperties = (node) => {
        const component = record8(node?.component);
        return Object.fromEntries(Object.entries(record8(component.propertyTypes)).filter(([, type]) => type === "VARIANT").map(([name]) => [name, record8(component.properties)[name]]));
      };
      const expectedProperties = variantProperties(expected.get(""));
      if (!Object.keys(expectedProperties).length || stableHash(variantProperties(actual.get(""))) !== stableHash(expectedProperties)) {
        result.reason = "variant-properties-mismatch";
        continue;
      }
    }
    for (const [path, node] of actual) {
      node.baseline = { effective: clone2(effectiveFacts(
        expected.get(path),
        snapshot.source?.geometryCaptureVersion === 1 && reference.source?.geometryCaptureVersion === 1
      )) };
      if (variant && path === "") {
        const originalComponent = record8(baseNodes.get(boundary.referencePath)?.component);
        const current = record8(node.component), baseline = record8(record8(record8(node.baseline).effective).component);
        const available = record8(record8(node.variantAvailability).componentProperties);
        for (const [name, type] of Object.entries(record8(current.propertyTypes))) {
          if (type !== "VARIANT" || record8(originalComponent.propertyTypes)[name] !== "VARIANT" || !Object.prototype.hasOwnProperty.call(record8(originalComponent.properties), name)) continue;
          record8(baseline.properties)[name] = originalComponent.properties[name];
          available[propertyAvailabilityKey(name)] = true;
          node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== `variantAvailability.componentProperties.${propertyAvailabilityKey(name)}`);
        }
        if (node.variantAvailability) record8(node.variantAvailability).componentProperties = available;
      }
      node.baselineProvenance = {
        status: "matched",
        kind: variant ? "independent-host-variant" : "independent-host-swap",
        boundaryNodeId: boundary.nodeId,
        componentKey: boundary.actualComponentKey,
        ownerPath: boundary.ownerPath,
        property: boundary.property,
        ...variant ? { componentSetKey: boundary.componentSetKey } : {},
        referencePath: [refBoundary.actualPath, path].filter(Boolean).join(" / ")
      };
      result.matchedNodeIds.push(String(node.id));
    }
    result.status = "matched";
    result.reason = variant ? "independent-host-variant-reference" : "independent-host-swap-reference";
  }
}

// src/core/target-resolution.ts
var TARGET_RESOLUTION_SCHEMA = "apollo.target-resolution.v1";
var record9 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
function resolveSnapshotTargets(snapshot, contract) {
  const paths = snapshotPaths(snapshot);
  const byId = new Map(snapshot.nodes.map((node) => [String(node.id), node]));
  const keys = [snapshot.source?.componentKey, snapshot.source?.componentSetKey].filter(Boolean);
  const representations = contract.facts.representations.filter((rep) => rep.kind === "figma" && rep.status !== "deprecated" && rep.platform === snapshot.context.platform && keys.some((key) => key === rep.locator.componentKey || key === rep.locator.componentSetKey));
  const targets = contract.facts.targets.map((target) => {
    const result = {
      targetId: target.id,
      semanticRole: target.semanticRole,
      resolution: "unknown",
      reason: "topology-incomplete-or-ambiguous"
    };
    if (!paths) return result;
    if (representations.length !== 1) return { ...result, reason: "representation-unresolved" };
    if (target.resolution !== "resolved") return { ...result, reason: "authoring-target-unresolved" };
    const hints = target.representationHints?.filter((h) => h.representationId === representations[0].id) || [];
    if (hints.length > 1) return { ...result, resolution: "ambiguous", reason: "representation-hints-ambiguous" };
    const hint = hints[0];
    if (!hint && ![representations[0].locator.componentKey, representations[0].locator.componentSetKey].includes(contract.facts.component.componentKey)) {
      return { ...result, reason: "representation-hint-missing" };
    }
    const pathHint = hint?.pathHint || target.pathHint;
    if (!pathHint) return { ...result, reason: "path-hint-missing" };
    const path = pathHint.split(" / ").slice(1).join(" / ");
    const candidates = snapshot.nodes.filter((node2) => paths.get(String(node2.id)) === path);
    if (candidates.length !== 1) return { ...result, reason: "path-needs-remap" };
    const node = candidates[0];
    const fingerprint = hint?.structuralFingerprint || target.structuralFingerprint;
    if (path !== "" && !fingerprint) return { ...result, reason: "structural-anchor-missing" };
    if (fingerprint) {
      const types = path === "" ? ["INSTANCE", "COMPONENT", "COMPONENT_SET"] : [String(node.type)];
      if (!types.some((type) => stableHash({ type, path: pathHint, order: node.order }).slice(0, 16) === fingerprint)) {
        return { ...result, reason: "structural-anchor-changed" };
      }
    }
    const declaredLineage = hint?.pathHint ? void 0 : target.lineage;
    const hintLineage = pathHint.split("/").slice(0, -1).map((part) => slug(part.trim()));
    if (declaredLineage && stableHash(declaredLineage) !== stableHash(hintLineage)) return { ...result, reason: "lineage-hint-conflict" };
    let current = node;
    const actualSegments = [];
    while (current && current.parentId !== null) {
      if (current.type === "INSTANCE") return { ...result, reason: "nested-lineage-unproven" };
      actualSegments.unshift(String(current.name));
      current = byId.get(String(current.parentId));
    }
    if (stableHash(actualSegments) !== stableHash(pathHint.split(" / ").slice(1))) return { ...result, reason: "lineage-hint-conflict" };
    return { ...result, resolution: "resolved", reason: "exact-structural-anchor", nodeId: String(node.id) };
  });
  for (const target of targets) {
    if (targets.filter((other) => other.semanticRole === target.semanticRole).length > 1 || target.nodeId && targets.filter((other) => other.nodeId === target.nodeId).length > 1) {
      target.resolution = "ambiguous";
      target.reason = "target-collision";
    }
  }
  return { schemaVersion: TARGET_RESOLUTION_SCHEMA, manualSourceHash: contract.package.manualSourceHash, targets };
}
function materializeTargetResolution(snapshot, contract) {
  const evidence = resolveSnapshotTargets(snapshot, contract);
  snapshot.targetResolution = evidence;
  const bindings = new Map(evidence.targets.filter((t) => t.resolution === "resolved").map((t) => [t.nodeId, t.semanticRole]));
  const relations = Object.fromEntries([...bindings].map(([id, role]) => [role, id]));
  for (const node of snapshot.nodes) {
    const role = bindings.get(String(node.id));
    node.semantic = { ...record9(node.semantic), role: role || "" };
    node.relations = { ...relations };
    node.unknownFacts = (node.unknownFacts || []).filter((path) => path !== "semantic.role");
  }
}
function targetResolutionReason(reason) {
  const labels = {
    "topology-incomplete-or-ambiguous": "\u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0441\u043D\u0438\u043C\u043A\u0430 \u043D\u0435\u043F\u043E\u043B\u043D\u0430 \u0438\u043B\u0438 \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u0430",
    "representation-unresolved": "\u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 Figma-\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442 \u0438 \u0435\u0433\u043E \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430",
    "authoring-target-unresolved": "\u0446\u0435\u043B\u044C \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430 \u0432 manual source",
    "representation-hints-ambiguous": "\u0434\u043B\u044F \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0437\u0430\u0434\u0430\u043D\u044B \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0438\u0435 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438",
    "representation-hint-missing": "\u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043D\u0435\u0442 \u044F\u0432\u043D\u043E\u0439 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0446\u0435\u043B\u0438",
    "path-hint-missing": "\u043D\u0435\u0442 \u044F\u0432\u043D\u043E\u0433\u043E \u043F\u0443\u0442\u0438 \u043A \u0446\u0435\u043B\u0438",
    "path-needs-remap": "\u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u043F\u0443\u0442\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D; \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u044F \u0438\u043C\u0435\u043D\u0438 \u0438\u043B\u0438 node ID \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E",
    "structural-anchor-missing": "\u043D\u0435\u0442 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u043D\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0446\u0435\u043B\u0438",
    "structural-anchor-changed": "\u0442\u0438\u043F \u0438\u043B\u0438 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0446\u0435\u043B\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430",
    "lineage-hint-conflict": "lineage \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u043D\u043E\u043C\u0443 \u043F\u0443\u0442\u0438",
    "nested-lineage-unproven": "\u0434\u043B\u044F \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0443\u0436\u043D\u044B Athena variant facts \u0438 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0439 \u044D\u0442\u0430\u043B\u043E\u043D",
    "target-collision": "\u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0446\u0435\u043B\u0435\u0439 \u043F\u0440\u0435\u0442\u0435\u043D\u0434\u0443\u044E\u0442 \u043D\u0430 \u043E\u0434\u0438\u043D \u0441\u043B\u043E\u0439 \u0438\u043B\u0438 semantic role",
    "exact-structural-anchor": "\u0442\u043E\u0447\u043D\u044B\u0439 \u043F\u0443\u0442\u044C \u0438 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u043D\u0430\u044F \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B"
  };
  return labels[reason] || reason;
}

// src/core/gradient-paint-facts.ts
var TYPES = /* @__PURE__ */ new Set(["GRADIENT_LINEAR", "GRADIENT_RADIAL", "GRADIENT_ANGULAR", "GRADIENT_DIAMOND"]);
var record10 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var unit = (v) => finite(v) && v >= 0 && v <= 1;
var transformValid = (v) => Array.isArray(v) && v.length === 2 && v.every((row) => Array.isArray(row) && row.length === 3 && row.every(finite));
var colorValid = (v) => ["r", "g", "b", "a"].every((key) => unit(record10(v)[key]));
function captureGradientPaintDetails(value) {
  const paint = record10(value), facts = {};
  if (!TYPES.has(String(paint.type))) return facts;
  if (transformValid(paint.gradientTransform)) facts.gradientTransform = paint.gradientTransform.map((row) => row.slice());
  if (Array.isArray(paint.gradientStops)) facts.gradientStops = paint.gradientStops.map((raw) => {
    const stop = record10(raw), result = {};
    if (unit(stop.position)) result.position = stop.position;
    if (colorValid(stop.color)) result.color = Object.fromEntries(["r", "g", "b", "a"].map((key) => [key, record10(stop.color)[key]]));
    if (stop.boundVariables === void 0 || stop.boundVariables && typeof stop.boundVariables === "object" && !Array.isArray(stop.boundVariables) && !Object.prototype.hasOwnProperty.call(stop.boundVariables, "color")) result.tokenId = null;
    else {
      const alias = record10(record10(stop.boundVariables).color);
      if (alias.type === "VARIABLE_ALIAS" && typeof alias.id === "string" && alias.id.trim()) result.tokenId = alias.id;
    }
    return result;
  });
  if (typeof paint.blendMode === "string") facts.blendMode = paint.blendMode;
  return facts;
}
function gradientPaintIssues(value) {
  if (!Array.isArray(value)) return [];
  const issues = [];
  value.forEach((raw, index) => {
    const paint = record10(raw);
    if (!TYPES.has(String(paint.type))) return;
    const prefix = `[${index}]`;
    if (!transformValid(paint.gradientTransform)) issues.push(`${prefix}.gradientTransform`);
    if (!Array.isArray(paint.gradientStops) || !paint.gradientStops.length) issues.push(`${prefix}.gradientStops`);
    else paint.gradientStops.forEach((rawStop, stopIndex) => {
      const stop = record10(rawStop), path = `${prefix}.gradientStops[${stopIndex}]`;
      if (!unit(stop.position)) issues.push(`${path}.position`);
      if (!colorValid(stop.color)) issues.push(`${path}.color`);
      if (!(stop.tokenId === null || typeof stop.tokenId === "string" && Boolean(stop.tokenId.trim()))) issues.push(`${path}.tokenId`);
    });
  });
  return issues;
}
function materializeGradientPaintEvidence(snapshot) {
  for (const node of snapshot.nodes) {
    const unknown3 = new Set(node.unknownFacts || []);
    const issues = [];
    const present = {};
    for (const [prefix, source] of [["", node], ["baseline.effective.", record10(record10(node.baseline).effective)]]) {
      const appearance = record10(source.appearance);
      for (const kind of ["fill", "stroke"]) {
        if (Object.prototype.hasOwnProperty.call(appearance, kind)) present[kind] = true;
        const missing = Object.prototype.hasOwnProperty.call(appearance, kind) && !Array.isArray(appearance[kind]) ? [""] : gradientPaintIssues(appearance[kind]);
        if (!missing.length) continue;
        const fact = `${prefix}appearance.${kind}`;
        unknown3.add(fact);
        issues.push({ fact, missing: missing.map((path) => `${fact}${path}`) });
      }
    }
    node.paintEvidenceV1 = present;
    node.unknownFacts = [...unknown3].sort();
    if (issues.length) {
      node.gradientPaintIssues = issues;
    } else delete node.gradientPaintIssues;
  }
}

// src/core/rule-scope-facts.ts
var record11 = (value) => value && typeof value === "object" ? value : {};
var unknown2 = (node, fact) => (node.unknownFacts || []).some((path) => fact === path || fact.startsWith(path + "."));
function materializeRuleScopeFacts(snapshot, contract) {
  const roots = snapshot.nodes.filter((node) => snapshot.selection.includes(String(node.id)));
  const root = roots.length === 1 ? roots[0] : void 0;
  const paths = snapshotPaths(snapshot);
  const childPaths = [];
  let ownershipUnknown = !paths;
  if (contract.customizationPolicy.some((rule) => rule.boundaryPolicy === "component-owned@1")) {
    for (const dependency of contract.componentDependencies || []) {
      if (dependency.issue || dependencyPinIssue(dependency, dependency.contract)) {
        ownershipUnknown = true;
        continue;
      }
      for (const binding of dependency.bindings) {
        const resolved = resolveFixedNestedBinding(snapshot, dependency, binding);
        if (resolved.status === "inactive") continue;
        if (resolved.status !== "active" || !resolved.nodeId || !resolved.identityValid || !validatedDependencyCapture(snapshot, resolved.nodeId, dependency.contract).snapshot) {
          ownershipUnknown = true;
          continue;
        }
        const path = paths?.get(resolved.nodeId);
        if (path) childPaths.push(path);
        else ownershipUnknown = true;
      }
    }
  }
  const targets = {};
  for (const target of contract.facts.targets) {
    const candidates = snapshot.nodes.filter((node) => record11(node.semantic).role === target.semanticRole && !unknown2(node, "semantic.role"));
    const available = record11(record11(root?.variantAvailability).targets)[target.semanticRole];
    const verified = record11(root?.semanticTargets)[target.semanticRole];
    const fact = {};
    if (paths && verified?.resolved === true && target.resolution === "resolved" && contract.facts.targets.filter((other) => other.semanticRole === target.semanticRole).length === 1) {
      if (available?.present === false && candidates.length === 0) fact.visible = false;
      else if (candidates.length === 1 && !unknown2(candidates[0], "visibility.effective") && typeof record11(candidates[0].visibility).effective === "boolean") fact.visible = record11(candidates[0].visibility).effective;
    }
    targets[target.semanticRole] = fact;
  }
  for (const node of snapshot.nodes) {
    const path = paths?.get(String(node.id));
    const local = path !== void 0 && childPaths.some((child) => withinBoundary(path, child)) ? false : ownershipUnknown ? void 0 : true;
    node.ruleScopeV1 = { isRoot: node === root, ...local !== void 0 ? { local } : {}, targets };
    const missing = (node.unknownFacts || []).filter((path2) => path2 !== "ruleScopeV1" && !path2.startsWith("ruleScopeV1."));
    if (local === void 0) missing.push("ruleScopeV1.local");
    for (const [role, fact] of Object.entries(targets)) if (fact.visible === void 0) missing.push(`ruleScopeV1.targets.${role}.visible`);
    node.unknownFacts = missing;
  }
}

// src/core/runtime.ts
function prepareValidationSnapshot(source, contract) {
  const snapshot = JSON.parse(JSON.stringify(source));
  delete snapshot.snapshotHash;
  materializeSemanticFacts(snapshot, contract);
  if (!contract.facts.variantEvidence && (snapshot.targetResolution?.schemaVersion === TARGET_RESOLUTION_SCHEMA || contract.runtimePolicy.ruleScopeFactsVersion === 1)) materializeTargetResolution(snapshot, contract);
  if (["variant-facts-v3", "variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) materializeVariantFacts(snapshot, contract);
  if (["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) materializeInstanceContentReferences(snapshot);
  if (["component-facts-v2", "variant-facts-v3", "variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) materializeComponentFacts(snapshot, contract);
  if (contract.package.snapshotProfile === "dependency-facts-v5") materializeDependencyFacts(snapshot, contract);
  if (contract.runtimePolicy.gradientPaintFactsVersion === 1) materializeGradientPaintEvidence(snapshot);
  if (contract.runtimePolicy.ruleScopeFactsVersion === 1) materializeRuleScopeFacts(snapshot, contract);
  return snapshot;
}
function validationSnapshotHash(snapshot, contract) {
  return (0, import_predicate_engine.snapshotHash)(prepareValidationSnapshot(snapshot, contract));
}
function prepareAuthoringPreviewContract(contract) {
  return {
    ...contract,
    rules: contract.rules.map((rule) => {
      const authority = rule.authority;
      if (authority?.status !== "draft") return rule;
      return {
        ...rule,
        authority: { ...authority, status: "active" }
      };
    })
  };
}
function evaluateCompiledContract(snapshot, contract, ancestry = []) {
  const prepared = prepareValidationSnapshot(snapshot, contract);
  const result = (0, import_predicate_engine.evaluateRules)({
    snapshot: prepared,
    rules: contract.rules,
    ruleRelease: contract.package.manualSourceHash
  });
  if (!contract.componentDependencies?.length) return result;
  const runs = [];
  const evaluations = result.evaluations.slice();
  const ancestors = [...ancestry, contract.package.componentId];
  for (const d of contract.componentDependencies) for (const b of d.bindings) {
    const run = { dependencyId: d.id, bindingId: b.id, componentId: d.componentId, revision: d.revision, compiledHash: d.compiledHash };
    runs.push(run);
    const issue = d.issue || dependencyPinIssue(d, d.contract) || (ancestors.includes(d.componentId) ? "dependency-cycle" : ancestors.length > COMPONENT_DEPENDENCY_DEPTH_LIMIT ? "dependency-depth-limit" : void 0);
    if (issue) {
      Object.assign(run, { status: "not-executed", reason: issue });
      continue;
    }
    const resolved = resolveFixedNestedBinding(prepared, d, b);
    if (resolved.status === "inactive") {
      Object.assign(run, { status: "not-applicable", reason: resolved.reason });
      continue;
    }
    Object.assign(run, { nodeId: resolved.nodeId });
    if (resolved.status !== "active" || !resolved.nodeId || !resolved.identityValid) {
      Object.assign(run, { status: "not-executed", reason: resolved.identityValid === false ? "dependency-child-identity-mismatch" : resolved.reason });
      continue;
    }
    const capture = validatedDependencyCapture(prepared, resolved.nodeId, d.contract);
    if (!capture.snapshot || !capture.nodeMap) {
      Object.assign(run, { status: "not-executed", reason: capture.reason });
      continue;
    }
    const output = evaluateCompiledContract(capture.snapshot, d.contract, ancestors);
    const childEvaluations = output.evaluations;
    const unsupported = d.contract.nonExecutableRules.length || d.contract.customizationPolicy.some((p) => p.status !== "deprecated" && ["delegated", "context-only"].includes(p.execution.route));
    const incomplete = unsupported || childEvaluations.some((e) => ["not-executed", "human-review", "not-evaluable", "unknown"].includes(String(e.classification)) || ["rule authority is not active", "selector matched no visible nodes"].includes(String(e.trace?.reason))) || (output.dependencyRuns || []).some((r) => r.status === "not-executed" || r.status === "incomplete");
    Object.assign(run, {
      status: incomplete ? "incomplete" : "executed",
      snapshotHash: output.snapshotHash,
      evaluations: childEvaluations.length,
      ...incomplete ? { reason: "dependency-check-incomplete" } : {}
    });
    for (const e of childEvaluations) evaluations.push({
      ...e,
      evaluationId: stableHash({ dependencyId: d.id, bindingId: b.id, nodeId: resolved.nodeId, evaluationId: e.evaluationId }),
      subjectNodeId: capture.nodeMap[String(e.subjectNodeId)] || resolved.nodeId,
      focusNodeId: capture.nodeMap[String(e.focusNodeId)] || resolved.nodeId,
      dependency: {
        componentId: d.componentId,
        dependencyId: d.id,
        bindingId: b.id,
        ruleId: e.ruleId,
        revision: d.revision,
        compiledHash: d.compiledHash,
        ...e.dependency ? { nested: e.dependency } : {}
      }
    });
  }
  const byClassification = {};
  evaluations.forEach((e) => {
    const k = String(e.classification);
    byClassification[k] = (byClassification[k] || 0) + 1;
  });
  return { ...result, evaluations, dependencyRuns: runs, coverage: {
    total: evaluations.length,
    byClassification,
    unclassified: evaluations.filter((e) => !e.classification).length,
    duplicateEvaluationIds: evaluations.length - new Set(evaluations.map((e) => e.evaluationId)).size
  } };
}

// src/core/evaluation-view.ts
var CLASSIFICATION_LABELS = {
  compliant: "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E",
  violation: "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0438\u0435",
  "human-review": "\u041D\u0443\u0436\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430",
  "not-evaluable": "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C",
  "not-applicable": "\u041D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F",
  "not-executed": "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E",
  allowed: "\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043E"
};
var REASON_LABELS = {
  "actual value differs from effective baseline": "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0442\u043B\u0438\u0447\u0430\u0435\u0442\u0441\u044F \u043E\u0442 \u044D\u0442\u0430\u043B\u043E\u043D\u0430 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430",
  "actual value matches effective baseline": "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u044D\u0442\u0430\u043B\u043E\u043D\u043E\u043C \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430",
  "comparison value is absent": "\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0438\u043B\u0438 \u044D\u0442\u0430\u043B\u043E\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442",
  "rule authority is not active": "\u041F\u0440\u0430\u0432\u0438\u043B\u043E \u0435\u0449\u0451 \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u043E",
  "rule scope does not apply": "\u041F\u0440\u0430\u0432\u0438\u043B\u043E \u043D\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u044D\u0442\u043E\u043C \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0438",
  "rule product scope does not apply": "\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 Product \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u043B\u0430\u0441\u044C",
  "rule channel scope does not apply": "\u0422\u0435\u043A\u0443\u0449\u0438\u0439 Channel \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u043B\u0430\u0441\u044C",
  "rule product scope is unknown": "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445: Product \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u0438\u043B\u0438 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D; \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430",
  "rule platform scope is unknown": "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445: \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u0430 \u0438\u043B\u0438 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430",
  "rule channel scope is unknown": "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445: Channel \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u0438\u043B\u0438 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D",
  "rule page type scope is unknown": "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445: \u0442\u0438\u043F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u0438\u043B\u0438 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D",
  "rule platform scope does not apply": "\u0422\u0435\u043A\u0443\u0449\u0430\u044F \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430 \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u043B\u0430\u0441\u044C",
  "rule page type scope does not apply": "\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0442\u0438\u043F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u043B\u0430\u0441\u044C",
  "selector evidence is unknown": "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0432\u044B\u0431\u043E\u0440\u0430 \u0441\u043B\u043E\u044F",
  "selector matched no visible nodes": "\u041F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0439 \u0432\u0438\u0434\u0438\u043C\u044B\u0439 \u0441\u043B\u043E\u0439 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D",
  "value is outside the allowed set": "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043D\u0430\u0431\u043E\u0440",
  "value belongs to the allowed set": "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043D\u0430\u0431\u043E\u0440"
};
function record12(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function unavailableTrace(trace) {
  const children = Array.isArray(trace.children) ? trace.children : [];
  if (children.length) return children.some((child) => unavailableTrace(record12(child)));
  return trace.truth === "false" && trace.actual === false && Array.isArray(trace.factPaths) && trace.factPaths.some((path) => String(path).startsWith("variantAvailability."));
}
function activityTrace(trace, truth) {
  if (trace.predicate === "any" && trace.truth === truth && Array.isArray(trace.factPaths) && trace.factPaths.length === 2 && trace.factPaths.every((p) => String(p).includes("propertyActivityV1."))) return true;
  return Array.isArray(trace.children) && trace.children.some((t) => activityTrace(record12(t), truth));
}
function falseScopeCondition(trace, path) {
  if (trace.truth !== "false") return false;
  if (trace.predicate === "equals") {
    return trace.actual === false && trace.expected === true && Array.isArray(trace.factPaths) && trace.factPaths.includes(path);
  }
  return (trace.predicate === "all" || trace.predicate === "any") && Array.isArray(trace.children) && trace.children.some((child) => falseScopeCondition(record12(child), path));
}
function dependencyDisplayTrace(trace) {
  const children = Array.isArray(trace.children) ? trace.children.map(record12) : [];
  const branches = children.filter((child) => child.predicate === "all" && Array.isArray(child.children) && record12(child.children[0]).truth === "true");
  let selected = trace;
  if (trace.predicate === "any" && branches.length === 1) selected = record12(branches[0].children[1]);
  if (selected.predicate === "any" && Array.isArray(selected.children) && selected.children.length === 1) selected = record12(selected.children[0]);
  return selected;
}
function buildEvaluationDetails(result, contract, anatomy) {
  const rules = new Map(contract.rules.map((rule) => [rule.ruleId, rule]));
  const dependencyRules = /* @__PURE__ */ new Map();
  const collect = (current, depth = 0) => {
    if (depth > 4) return;
    for (const d of current.componentDependencies || []) if (d.contract) {
      dependencyRules.set(d.compiledHash, d.contract.rules);
      collect(d.contract, depth + 1);
    }
  };
  collect(contract);
  const nodes = new Map(anatomy.map((node) => [node.id, node]));
  const evaluations = Array.isArray(result.evaluations) ? result.evaluations : [];
  return evaluations.map((candidate, index) => {
    const evaluation = record12(candidate);
    const ruleId = String(evaluation.ruleId || "");
    const nodeId = String(evaluation.subjectNodeId || "");
    const provenance = record12(evaluation.dependency);
    const rule = provenance.compiledHash ? dependencyRules.get(String(provenance.compiledHash))?.find((r) => r.ruleId === ruleId) : rules.get(ruleId);
    const presentation = record12(rule?.presentation);
    const dependency = record12(presentation.dependency);
    const originalTrace = record12(evaluation.trace);
    const trace = dependency.field && ["violation", "compliant", "human-review"].includes(String(evaluation.classification)) ? dependencyDisplayTrace(originalTrace) : originalTrace;
    const factPaths = Array.isArray(trace.factPaths) ? trace.factPaths.filter((value) => typeof value === "string") : [];
    const factPath = factPaths.find((path) => !path.startsWith("baseline.effective.")) || factPaths[0] || "";
    const node = nodes.get(nodeId);
    const reason = typeof trace.reason === "string" ? trace.reason : "";
    const classification = String(evaluation.classification || "unknown");
    const scopeMismatch = /^rule (?:product|platform|channel|page type) scope does not apply$/.test(reason);
    const scopeUnknown = /^rule (?:product|platform|channel|page type) scope is unknown$/.test(reason);
    const conditionalMismatch = classification === "not-applicable" && trace.truth === "false" && !scopeMismatch;
    const activityPolicy = presentation.propertyApplicability;
    const inactive = activityPolicy && conditionalMismatch && activityTrace(trace, "false");
    const unknownActivity = activityPolicy && ["human-review", "not-evaluable"].includes(classification) && activityTrace(trace, "unknown");
    const unavailable = conditionalMismatch && unavailableTrace(trace);
    const childOwned = presentation.boundaryPolicy === "component-owned@1" && conditionalMismatch && falseScopeCondition(trace, "ruleScopeV1.local");
    const hiddenTarget = presentation.targetApplicability === "visible-target@1" && conditionalMismatch && factPaths.some((path) => /^ruleScopeV1\.targets\..+\.visible$/.test(path) && falseScopeCondition(trace, path));
    const missingDimension = ["human-review", "not-evaluable"].includes(classification) && ["baseline.effective.bounds.width", "baseline.effective.bounds.height"].some((path) => factPaths.includes(path)) && ["absent", "unknown"].includes(String(record12(trace.expected).state));
    const missingDimensionPath = factPaths.find((path) => /^baseline\.effective\.bounds\.(width|height)$/.test(path));
    const showComparison = !unavailable && !childOwned && !hiddenTarget && (scopeMismatch || conditionalMismatch || trace.actual !== void 0 || trace.expected !== void 0);
    return {
      id: String(evaluation.evaluationId || `${ruleId}:${nodeId}:${index}`),
      classification,
      classificationLabel: CLASSIFICATION_LABELS[classification] || classification,
      severity: String(evaluation.severity || rule?.severity || "info"),
      ruleId,
      ruleTitle: typeof presentation.title === "string" && presentation.title ? presentation.title : String(evaluation.ruleTitle || ruleId),
      capability: dependency.field ? `${String(dependency.targetRole)} \xB7 ${{ width: "\u0428\u0438\u0440\u0438\u043D\u0430 \u0438\u043A\u043E\u043D\u043A\u0438, px", height: "\u0412\u044B\u0441\u043E\u0442\u0430 \u0438\u043A\u043E\u043D\u043A\u0438, px", portName: "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u043E\u0440\u0442", variantProperty: `\u0412\u0430\u0440\u0438\u0430\u043D\u0442 \u0438\u043A\u043E\u043D\u043A\u0438 \xB7 ${String(dependency.property || "")}` }[String(dependency.field)] || dependency.field}` : typeof presentation.group === "string" ? presentation.group : String(evaluation.capability || factPath),
      nodeId,
      nodeName: node?.name || String(evaluation.subjectNodeName || nodeId),
      nodePath: node?.path || String(evaluation.subjectNodeName || nodeId),
      factPath,
      reason,
      reasonLabel: Array.isArray(evaluation.evidenceIssues) && evaluation.evidenceIssues.length ? `\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445 ${evaluation.evidenceIssues.some((path) => /gradient(Stops|Transform)/.test(String(path))) ? "\u0433\u0440\u0430\u0434\u0438\u0435\u043D\u0442\u0430" : "\u0437\u0430\u043B\u0438\u0432\u043A\u0438 \u0438\u043B\u0438 \u043E\u0431\u0432\u043E\u0434\u043A\u0438"}: ${evaluation.evidenceIssues.join(", ")}. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0437\u0430\u0445\u0432\u0430\u0442 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0430 \u0438 \u044D\u0442\u0430\u043B\u043E\u043D\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043D\u0435\u043F\u043E\u043B\u043D\u0430\u044F.` : missingDimension ? `\u041D\u0435\u0442 \u0440\u0430\u0437\u043C\u0435\u0440\u0430 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0433\u043E \u044D\u0442\u0430\u043B\u043E\u043D\u0430: ${missingDimensionPath}. \u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E.` : childOwned ? "\u041E\u0431\u043B\u0430\u0441\u0442\u044C \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u043C\u0443 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u043C\u0443 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0443; \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u0435\u0433\u043E \u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438" : hiddenTarget ? "\u0426\u0435\u043B\u044C \u0434\u043E\u043A\u0430\u0437\u0430\u043D\u043D\u043E \u0441\u043A\u0440\u044B\u0442\u0430 \u0438\u043B\u0438 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0435; \u0441\u0442\u0438\u043B\u0435\u0432\u043E\u0435 \u043F\u0440\u0430\u0432\u0438\u043B\u043E \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u0443\u0441\u043B\u043E\u0432\u0438\u044E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430" : inactive ? activityPolicy === "stroke-present-either@1" ? "\u041E\u0431\u0432\u043E\u0434\u043A\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438 \u0432 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0435, \u0438 \u0432 \u044D\u0442\u0430\u043B\u043E\u043D\u0435; \u0442\u043E\u043B\u0449\u0438\u043D\u0430 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u0443\u0441\u043B\u043E\u0432\u0438\u044E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430" : activityPolicy === "auto-layout-padding-either@1" ? "Auto layout \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438 \u0432 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0435, \u0438 \u0432 \u044D\u0442\u0430\u043B\u043E\u043D\u0435; padding \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u0443\u0441\u043B\u043E\u0432\u0438\u044E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430" : activityPolicy === "flow-alignment-either@1" ? "\u0413\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u043B\u0438 \u0432\u0435\u0440\u0442\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 auto layout \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438 \u0432 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0435, \u0438 \u0432 \u044D\u0442\u0430\u043B\u043E\u043D\u0435; \u0432\u044B\u0440\u0430\u0432\u043D\u0438\u0432\u0430\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u0443\u0441\u043B\u043E\u0432\u0438\u044E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430" : "\u0412 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0435 \u0438 \u044D\u0442\u0430\u043B\u043E\u043D\u0435 \u043D\u0435\u0442 \u0434\u0432\u0443\u0445 \u0443\u0447\u0430\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0432 auto layout \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432; gap \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u0443\u0441\u043B\u043E\u0432\u0438\u044E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430" : unknownActivity ? "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445 \u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E\u0441\u0442\u0438 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430 \u0432 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0435 \u0438\u043B\u0438 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u043C \u044D\u0442\u0430\u043B\u043E\u043D\u0435; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043D\u0435\u043F\u043E\u043B\u043D\u0430\u044F" : unavailable ? "\u042D\u043B\u0435\u043C\u0435\u043D\u0442 \u0438\u043B\u0438 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0435; \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u043E\u043C \u0438 reference \u0438\u0437 Figma" : conditionalMismatch ? "\u0423\u0441\u043B\u043E\u0432\u0438\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E; \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u043B\u043E\u0441\u044C" : dependency.field && trace.predicate === "between" && trace.truth === "false" ? "\u0420\u0430\u0437\u043C\u0435\u0440 \u0438\u043A\u043E\u043D\u043A\u0438 \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D \u0438\u0437 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430" : REASON_LABELS[reason] || reason || "Predicate Engine \u0432\u0435\u0440\u043D\u0443\u043B \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0431\u0435\u0437 \u043F\u043E\u044F\u0441\u043D\u0435\u043D\u0438\u044F",
      actual: trace.actual,
      expected: trace.expected,
      actualLabel: scopeMismatch || scopeUnknown ? "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438" : conditionalMismatch ? "\u0421\u0446\u0435\u043D\u0430\u0440\u0438\u0439 \u0441\u0435\u0439\u0447\u0430\u0441" : "\u0421\u0435\u0439\u0447\u0430\u0441",
      expectedLabel: scopeMismatch || scopeUnknown ? "\u041F\u0440\u0430\u0432\u0438\u043B\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0434\u043B\u044F" : conditionalMismatch ? "\u041F\u0440\u0430\u0432\u0438\u043B\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u043F\u0440\u0438" : "\u0414\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C",
      comparisonSymbol: classification === "not-applicable" ? "\u2260" : "\u2192",
      showComparison,
      scopeMismatch
    };
  });
}

// src/core/evaluation-groups.ts
var severityRank = { info: 0, warning: 1, error: 2 };
function groupEvaluationDetails(details) {
  const groups = [];
  const byDifference = /* @__PURE__ */ new Map();
  for (const detail of details) {
    const canGroup = detail.classification === "violation" && Boolean(detail.nodeId && detail.factPath) && detail.reason === "actual value differs from effective baseline" && detail.showComparison && !detail.scopeMismatch && detail.actual !== void 0 && detail.expected !== void 0 && Object.prototype.hasOwnProperty.call(severityRank, detail.severity);
    const key = canGroup ? stableStringify({
      nodeId: detail.nodeId,
      nodePath: detail.nodePath,
      factPath: detail.factPath,
      actual: detail.actual,
      expected: detail.expected,
      reason: detail.reason,
      actualLabel: detail.actualLabel,
      expectedLabel: detail.expectedLabel,
      comparisonSymbol: detail.comparisonSymbol
    }) : "";
    const existing = key ? byDifference.get(key) : void 0;
    if (existing) {
      existing.evaluations.push(detail);
      if (severityRank[detail.severity] > severityRank[existing.severity]) existing.severity = detail.severity;
    } else {
      const group = { ...detail, evaluations: [detail] };
      groups.push(group);
      if (key) byDifference.set(key, group);
    }
  }
  return groups;
}

// src/core/quick-policy.ts
var PROTECTED_INTERNAL_CAPABILITY_SETS = ["auto-layout@1", "visual-style@1"];
function cloneManual(source) {
  return JSON.parse(JSON.stringify(source));
}
function applicability(source) {
  return {
    variants: "all",
    modes: "all",
    platforms: source.component.platform === "universal" ? [] : [source.component.platform]
  };
}
function uniqueRuleId(source, base) {
  const ids = new Set(source.rules.map((rule) => rule.id));
  if (!ids.has(base)) return base;
  let suffix = 2;
  while (ids.has(`${base}-${suffix}`)) suffix += 1;
  return `${base}-${suffix}`;
}
function sameRule(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function finish(source, next, createdRuleIds, updatedRuleIds, conflictingRuleIds = []) {
  const changed = createdRuleIds.length > 0 || updatedRuleIds.length > 0;
  if (changed) {
    next.rules.sort((left, right) => left.id.localeCompare(right.id));
    next.metadata.revision = source.metadata.revision + 1;
  }
  return { manual: next, changed, createdRuleIds, updatedRuleIds, conflictingRuleIds };
}
function applyProtectInternalsPolicy(source, target) {
  const next = cloneManual(source);
  const createdRuleIds = [];
  const updatedRuleIds = [];
  PROTECTED_INTERNAL_CAPABILITY_SETS.forEach((capabilitySet) => {
    const existingIndex = next.rules.findIndex((rule) => rule.targetId === target.id && rule.capabilitySet === capabilitySet);
    const rationale = capabilitySet === "auto-layout@1" ? "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u044F\u044F \u0433\u0435\u043E\u043C\u0435\u0442\u0440\u0438\u044F \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u043D\u0430\u043F\u0440\u044F\u043C\u0443\u044E." : "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0435\u0435 \u0432\u0438\u0437\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u043D\u0430\u043F\u0440\u044F\u043C\u0443\u044E.";
    const baseId = `component:${source.component.contractId}.${target.semanticRole}.${slug(capabilitySet)}`;
    if (existingIndex < 0) {
      const id = uniqueRuleId(next, baseId);
      next.rules.push({
        id,
        targetId: target.id,
        targetScope: "self-and-descendants",
        capability: "",
        capabilitySet,
        permission: "forbidden",
        controlPaths: [],
        constraints: [],
        applicability: applicability(source),
        severity: "error",
        rationale,
        remediationIntent: "restore-effective-baseline",
        status: "draft",
        owner: source.metadata.owners.manual
      });
      createdRuleIds.push(id);
      return;
    }
    const existing = next.rules[existingIndex];
    const normalized = {
      ...existing,
      targetScope: "self-and-descendants",
      capability: "",
      capabilitySet,
      capabilitySelection: void 0,
      permission: "forbidden",
      controlPaths: [],
      constraints: [],
      applicability: applicability(source),
      severity: "error",
      rationale: existing.rationale || rationale,
      remediationIntent: existing.remediationIntent || "restore-effective-baseline",
      status: sameRule(existing, {
        ...existing,
        targetScope: "self-and-descendants",
        capability: "",
        capabilitySet,
        capabilitySelection: void 0,
        permission: "forbidden",
        controlPaths: [],
        constraints: [],
        applicability: applicability(source),
        severity: "error",
        rationale: existing.rationale || rationale,
        remediationIntent: existing.remediationIntent || "restore-effective-baseline"
      }) ? existing.status : "draft"
    };
    if (!sameRule(existing, normalized)) {
      next.rules[existingIndex] = normalized;
      updatedRuleIds.push(existing.id);
    }
  });
  return finish(source, next, createdRuleIds, updatedRuleIds);
}
function componentPropertyName(capability) {
  const prefixes = ["component.properties.", "component-property."];
  const prefix = prefixes.find((value) => capability.startsWith(value));
  return prefix ? capability.slice(prefix.length) || null : null;
}
function allowPublicComponentProperties(source, target, properties) {
  const next = cloneManual(source);
  const createdRuleIds = [];
  const conflictingRuleIds = [];
  const normalizedProperties = Array.from(new Set(properties.map((value) => value.trim()).filter(Boolean))).sort();
  normalizedProperties.forEach((property) => {
    const existing = next.rules.find((rule) => rule.targetId === target.id && componentPropertyName(rule.capability) === property);
    if (existing) {
      if (existing.permission !== "allowed") conflictingRuleIds.push(existing.id);
      return;
    }
    const capability = `component.properties.${property}`;
    const baseId = `component:${source.component.contractId}.${target.semanticRole}.${slug(capability)}`;
    const id = uniqueRuleId(next, baseId);
    next.rules.push({
      id,
      targetId: target.id,
      targetScope: "self",
      capability,
      permission: "allowed",
      controlPaths: [{ kind: "host-property", property, required: true, exclusive: true }],
      constraints: [],
      applicability: applicability(source),
      severity: "info",
      rationale: `\u041F\u0443\u0431\u043B\u0438\u0447\u043D\u043E\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u043E \xAB${property}\xBB \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u043C \u0441\u043F\u043E\u0441\u043E\u0431\u043E\u043C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430.`,
      status: "draft",
      owner: source.metadata.owners.manual
    });
    createdRuleIds.push(id);
  });
  return finish(source, next, createdRuleIds, [], conflictingRuleIds);
}
function sameManualComponentFamily(left, right) {
  const baseFamily = (source) => slug(source.component.family).replace(/-inverted$/i, "");
  return left.component.componentId === right.component.componentId && left.component.library === right.component.library && baseFamily(left) === baseFamily(right);
}
function samePreviewComponent(left, right) {
  const sameFamilyAndPlatform = left.component.family === right.component.family && left.component.platform === right.component.platform;
  if (!sameFamilyAndPlatform) return false;
  return left.component.contractId === right.component.contractId || left.component.library === right.component.library;
}

// src/core/exporter.ts
function buildExportBundle(manual, variantEvidence, dependencyContracts) {
  const result = compileManualSource(manual, variantEvidence, dependencyContracts);
  return {
    manual,
    compiled: result.contract,
    validation: {
      schemaVersion: "apollo.component-contract-validation.v1",
      valid: !result.issues.some((issue) => issue.level === "error"),
      issues: result.issues
    },
    coverage: result.contract.coverage
  };
}

// src/core/zip.ts
var encoder = new TextEncoder();
var decoder = new TextDecoder();
function crc32(data) {
  let crc = 4294967295;
  for (const byte of data) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = crc >>> 1 ^ 3988292384 & -(crc & 1);
    }
  }
  return (crc ^ 4294967295) >>> 0;
}
function u16(value) {
  return new Uint8Array([value & 255, value >>> 8 & 255]);
}
function u32(value) {
  return new Uint8Array([
    value & 255,
    value >>> 8 & 255,
    value >>> 16 & 255,
    value >>> 24 & 255
  ]);
}
function concat(parts) {
  const output = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
  let offset = 0;
  parts.forEach((part) => {
    output.set(part, offset);
    offset += part.length;
  });
  return output;
}
function createZip(entries) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  const sorted = entries.slice().sort((left, right) => left.name.localeCompare(right.name));
  for (const entry of sorted) {
    const name = encoder.encode(entry.name);
    const crc = crc32(entry.data);
    const local = concat([
      u32(67324752),
      u16(20),
      u16(2048),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(entry.data.length),
      u32(entry.data.length),
      u16(name.length),
      u16(0),
      name,
      entry.data
    ]);
    localParts.push(local);
    centralParts.push(concat([
      u32(33639248),
      u16(20),
      u16(20),
      u16(2048),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(entry.data.length),
      u32(entry.data.length),
      u16(name.length),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(0),
      u32(offset),
      name
    ]));
    offset += local.length;
  }
  const central = concat(centralParts);
  const end = concat([
    u32(101010256),
    u16(0),
    u16(0),
    u16(sorted.length),
    u16(sorted.length),
    u32(central.length),
    u32(offset),
    u16(0)
  ]);
  return concat([...localParts, central, end]);
}
function findEnd(view) {
  const minimum = Math.max(0, view.byteLength - 65535 - 22);
  for (let offset = view.byteLength - 22; offset >= minimum; offset -= 1) {
    if (view.getUint32(offset, true) === 101010256) return offset;
  }
  throw new Error("ZIP end-of-central-directory record was not found.");
}
async function inflateRaw(data) {
  if (typeof DecompressionStream === "undefined") {
    throw new Error("This runtime cannot read deflated ZIP entries. Use uncompressed ZIP or JSON files.");
  }
  const input = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
  const stream = new Blob([input]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
async function readZip(input) {
  const buffer = input.buffer.slice(input.byteOffset, input.byteOffset + input.byteLength);
  const view = new DataView(buffer);
  const endOffset = findEnd(view);
  const count = view.getUint16(endOffset + 10, true);
  let centralOffset = view.getUint32(endOffset + 16, true);
  const result = [];
  for (let index = 0; index < count; index += 1) {
    if (view.getUint32(centralOffset, true) !== 33639248) throw new Error("Invalid ZIP central directory.");
    const method = view.getUint16(centralOffset + 10, true);
    const compressedSize = view.getUint32(centralOffset + 20, true);
    const nameLength = view.getUint16(centralOffset + 28, true);
    const extraLength = view.getUint16(centralOffset + 30, true);
    const commentLength = view.getUint16(centralOffset + 32, true);
    const localOffset = view.getUint32(centralOffset + 42, true);
    const nameBytes = new Uint8Array(buffer, centralOffset + 46, nameLength);
    const name = decoder.decode(nameBytes);
    if (view.getUint32(localOffset, true) !== 67324752) throw new Error(`Invalid ZIP entry: ${name}.`);
    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const dataOffset = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = new Uint8Array(buffer, dataOffset, compressedSize);
    let data;
    if (method === 0) data = new Uint8Array(compressed);
    else if (method === 8) data = await inflateRaw(compressed);
    else throw new Error(`ZIP compression method ${method} is not supported for ${name}.`);
    if (!name.endsWith("/")) result.push({ name, data });
    centralOffset += 46 + nameLength + extraLength + commentLength;
  }
  return result;
}
function textZipEntry(name, value) {
  return { name, data: encoder.encode(`${JSON.stringify(value, null, 2)}
`) };
}
function zipEntryText(entry) {
  return decoder.decode(entry.data);
}

// src/core/session.ts
var EDITOR_SESSION_SCHEMA_VERSION = "apollo.component-contract-editor.session.v1";
function jsonClone(value) {
  return JSON.parse(JSON.stringify(value));
}
function createEditorSession(workspace, ui, savedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  const { compiledInput: _compiledInput, ...persistedWorkspace } = workspace;
  return jsonClone({
    schemaVersion: EDITOR_SESSION_SCHEMA_VERSION,
    savedAt,
    workspace: persistedWorkspace,
    ui
  });
}
function parseEditorSession(value) {
  if (!value || typeof value !== "object") return null;
  const candidate = value;
  if (candidate.schemaVersion !== EDITOR_SESSION_SCHEMA_VERSION) return null;
  if (!candidate.workspace || !candidate.ui) return null;
  const manual = candidate.workspace.manual;
  if (!manual || manual.documentType !== "component-contract-manual" || !manual.component?.contractId) return null;
  if (!["authoring", "validation"].includes(candidate.ui.workspaceMode)) return null;
  return jsonClone(candidate);
}

// src/core/rule-editing.ts
function validateRuleEdit(manual, rule, editingId) {
  const rules = manual.rules.slice();
  const existing = editingId ? rules.findIndex((entry) => entry.id === editingId) : -1;
  const index = existing < 0 ? rules.length : existing;
  rules[index] = rule;
  if (rule.status !== "reviewed") return [];
  return validateManualSource({ ...manual, rules }).filter((issue) => issue.level === "error" && (issue.path.startsWith(`/rules/${index}/`) || issue.code === "RULE_DUPLICATE" && rules.some((entry, i) => i !== index && entry.id === rule.id)));
}
function validationIssueLabel(issue) {
  const labels = {
    RULE_RATIONALE: "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043E\u0431\u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 (Rationale) \u0434\u043B\u044F reviewed-\u043F\u0440\u0430\u0432\u0438\u043B\u0430.",
    RULE_PROPERTY_APPLICABILITY: "\u0423\u0441\u043B\u043E\u0432\u0438\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E\u0441\u0442\u0438 \u0434\u043E\u043B\u0436\u043D\u043E \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E strokeWeight \u0438\u043B\u0438 itemSpacing \u0441 baseline \u0432 \u044D\u0442\u043E\u043C \u043F\u0440\u0430\u0432\u0438\u043B\u0435.",
    RULE_BOUNDARY_POLICY: "\u0413\u0440\u0430\u043D\u0438\u0446\u0430 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u043A \u0440\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u043E\u043C\u0443 \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 baseline \u043F\u0440\u0438 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u043D\u044B\u0445 component dependencies.",
    RULE_TARGET_APPLICABILITY: "\u0423\u0441\u043B\u043E\u0432\u0438\u0435 \u0432\u0438\u0434\u0438\u043C\u043E\u0441\u0442\u0438 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u043A \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441\u0442\u0438\u043B\u0435\u0439 \u0441 baseline, \u043D\u0435 \u043A presence/visibility \u0438 \u0434\u0440\u0443\u0433\u0438\u043C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F\u043C.",
    RULE_SCOPE_UNCONFIRMED: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430 (Scope status).",
    RULE_CONTEXT_UNMAPPED: "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u0435\u0449\u0451 \u043D\u0435 \u0441\u0432\u044F\u0437\u0430\u043D \u0441 runtime-\u0434\u0430\u043D\u043D\u044B\u043C\u0438. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 Context only \u0434\u043E \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0441\u0432\u044F\u0437\u0438.",
    RULE_DELEGATION: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 External Rule IDs \u0434\u043B\u044F \u0434\u0435\u043B\u0435\u0433\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0430\u0432\u0438\u043B\u0430.",
    RULE_CONTEXT_FACTS: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u044E\u0449\u0438\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0432 Missing facts.",
    RULE_DUPLICATE: "Rule ID \u0443\u0436\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0434\u0440\u0443\u0433\u0438\u043C \u043F\u0440\u0430\u0432\u0438\u043B\u043E\u043C.",
    RULE_CAPABILITY: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u043E \u0438\u043B\u0438 \u0433\u0440\u0443\u043F\u043F\u0443 \u0441\u0432\u043E\u0439\u0441\u0442\u0432.",
    CONSTRAINT_VALUES: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B \u043E\u0434\u043D\u043E \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435.",
    CONSTRAINT_RANGE: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043C\u0438\u043D\u0438\u043C\u0443\u043C \u0438\u043B\u0438 \u043C\u0430\u043A\u0441\u0438\u043C\u0443\u043C.",
    CONSTRAINT_ORDER: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u0441\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0440\u043E\u043B\u0435\u0439.",
    CONSTRAINT_RELATION: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0432\u044F\u0437\u044C \u0438 \u0446\u0435\u043B\u0435\u0432\u0443\u044E \u0440\u043E\u043B\u044C.",
    CONSTRAINT_TOKEN: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0442\u043E\u043A\u0435\u043D\u044B \u0438\u043B\u0438 \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438."
  };
  return labels[issue.code] || issue.message;
}
function mergeEditedApplicability(previous, edited) {
  return { ...previous, ...edited };
}
function forbiddenConstraintsForEdit(previous, next, fallback) {
  const selection = (v) => JSON.stringify(v ? [...v].sort() : null);
  if (previous?.permission === "forbidden" && previous.capability === next.capability && previous.capabilitySet === next.capabilitySet && selection(previous.capabilitySelection) === selection(next.capabilitySelection)) {
    return JSON.parse(JSON.stringify(previous.constraints));
  }
  return fallback;
}

// src/core/validation-coverage.ts
var import_predicate_engine2 = __toESM(require_predicate_engine());
function diagnoseRuleApplicability(manual, rule, snapshot, variantAvailability2 = false) {
  const probe = compileApplicabilityProbe(manual, rule, variantAvailability2);
  if (!snapshot) return { status: "unknown", unsupportedConditions: ["snapshot", ...probe.unsupported], evaluations: [] };
  const result = (0, import_predicate_engine2.evaluateRules)({ snapshot, rules: [probe.rule], ruleRelease: "editor-coverage" });
  const evaluations = result.evaluations;
  const subjects = (0, import_predicate_engine2.selectSubjects)(probe.rule, snapshot);
  const scopeMismatch = evaluations.some((entry) => /^rule (?:product|platform|channel|page type) scope does not apply$/.test(String(entry.trace.reason)));
  const allConditionsFalse = evaluations.length > 0 && !subjects.unknown && evaluations.every((entry) => entry.applicability === "not-applicable" && entry.trace.truth === "false");
  const status = scopeMismatch || allConditionsFalse ? "not-applicable" : !probe.unsupported.length && !subjects.unknown && evaluations.length > 0 && evaluations.every((entry) => entry.applicability === "applicable") ? "applicable" : "unknown";
  return { status, unsupportedConditions: probe.unsupported, evaluations };
}
function inspectRuleFacts(manual, rule, snapshot) {
  const paths = Array.from(new Set(rule.execution?.missingFacts || []));
  if (!paths.length) return [];
  const probe = compileApplicabilityProbe(manual, rule);
  const selected = snapshot ? (0, import_predicate_engine2.selectSubjects)(probe.rule, snapshot) : { nodes: [], unknown: true };
  return paths.map((path) => {
    const rootFact = path.startsWith("semanticApi.");
    const nodes = rootFact ? snapshot?.nodes.filter((node) => snapshot.selection.includes(String(node.id))) || [] : selected.nodes;
    const subjects = nodes.map((node) => ({
      nodeId: String(node.id),
      state: (0, import_predicate_engine2.resolveValue)({ fact: path }, node, snapshot).state
    }));
    const uncertain = !snapshot || !subjects.length || (rootFact ? subjects.length !== 1 : selected.unknown || probe.unsupported.includes("target"));
    const state = uncertain || subjects.some((entry) => entry.state === "unknown") ? "unknown" : subjects.every((entry) => entry.state === "known") ? "available" : "unavailable";
    return { path, state, scope: rootFact ? "component-root" : "rule-target", subjects };
  });
}
function buildContractReadiness(compiled, manual) {
  const active = manual.rules.filter((rule) => rule.status !== "deprecated");
  const excluded = new Set(compiled.contract.nonExecutableRules.map((entry) => entry.sourceRuleId));
  const delegated = active.filter((rule) => rule.execution?.route === "delegated").map((rule) => rule.id);
  const contextOnly = active.filter((rule) => rule.execution?.route === "context-only").map((rule) => rule.id);
  const ruleIds = /* @__PURE__ */ new Set([...excluded, ...delegated, ...contextOnly]);
  for (const [index, rule] of manual.rules.entries()) {
    if (rule.status === "deprecated") continue;
    if (!manual.targets.some((target) => target.id === rule.targetId) || compiled.issues.some((issue) => issue.level === "error" && issue.path.startsWith(`/rules/${index}/`))) ruleIds.add(rule.id);
  }
  const unreviewedRuleIds = active.filter((rule) => rule.status !== "reviewed").map((rule) => rule.id).sort();
  const unresolvedTargetIds = manual.targets.filter((target) => target.resolution !== "resolved" && active.some((rule) => rule.targetId === target.id)).map((target) => target.id).sort();
  const errors = compiled.issues.filter((issue) => issue.level === "error");
  return {
    status: compiled.contract.status === "ready" && !ruleIds.size && !unreviewedRuleIds.length && !unresolvedTargetIds.length && !errors.length ? "ready" : "draft",
    activeRules: active.length,
    deprecatedRules: manual.rules.length - active.length,
    unimplementedRules: ruleIds.size,
    unimplementedRuleIds: Array.from(ruleIds).sort(),
    contextOnlyRules: contextOnly.length,
    delegatedRules: delegated.length,
    compilerExcludedRules: Array.from(excluded).filter((id) => !contextOnly.includes(id)).length,
    unreviewedRuleIds,
    unresolvedTargetIds,
    validationErrors: errors.length
  };
}

// src/core/validation-report.ts
function buildEditorValidationReport(result, compiled, manual, snapshot) {
  const evaluations = Array.isArray(result.evaluations) ? result.evaluations.slice() : [];
  const engineEvaluations = evaluations.length;
  const checkedSnapshot = snapshot ? prepareValidationSnapshot(snapshot, compiled.contract) : void 0;
  if (compiled.contract.runtimePolicy.gradientPaintFactsVersion === 1 && checkedSnapshot) {
    evaluations.forEach((evaluation, index) => {
      if (!["human-review", "not-evaluable"].includes(String(evaluation.classification))) return;
      const rule = compiled.contract.rules.find((rule2) => rule2.ruleId === evaluation.ruleId);
      const assertion = rule?.assert;
      const field = assertion?.actual?.fact;
      if (field !== "appearance.fill" && field !== "appearance.stroke") return;
      const issues = checkedSnapshot.nodes.filter((node) => !evaluation.subjectNodeId || node.id === evaluation.subjectNodeId).flatMap((node) => node.gradientPaintIssues || []).filter((issue) => issue.fact === field || issue.fact === `baseline.effective.${field}`).flatMap((issue) => issue.missing);
      if (issues.length) evaluations[index] = { ...evaluation, evidenceIssues: [...new Set(issues)] };
    });
  }
  const contractReadiness = buildContractReadiness(compiled, manual);
  const pending = /* @__PURE__ */ new Map();
  const add = (id, reason) => {
    if (!pending.has(id)) pending.set(id, /* @__PURE__ */ new Set());
    pending.get(id).add(reason);
  };
  const dependencyRuns = result.dependencyRuns || [];
  dependencyRuns.filter((run) => run.status === "not-executed" || run.status === "incomplete").forEach((run) => {
    add(`component-dependency:${run.dependencyId}:${run.bindingId}`, `\u0412\u043B\u043E\u0436\u0435\u043D\u043D\u044B\u0439 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442 ${run.componentId} r${run.revision} \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E: ${run.reason}.`);
  });
  compiled.contract.nonExecutableRules.forEach((entry) => {
    const index = manual.rules.findIndex((rule) => rule.id === entry.sourceRuleId);
    const errors = compiled.issues.filter((issue) => issue.level === "error" && issue.path.startsWith(`/rules/${index}/`));
    if (errors.length) add(entry.sourceRuleId, errors.map(validationIssueLabel).join(" "));
    else if (manual.rules[index]?.execution?.route !== "context-only") add(entry.sourceRuleId, entry.reason);
  });
  manual.rules.forEach((rule) => {
    if (rule.status === "deprecated") return;
    const target = manual.targets.find((entry) => entry.id === rule.targetId);
    if (!target) add(rule.id, "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u0446\u0435\u043B\u044C \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u0432 manual source.");
    const binding = checkedSnapshot?.targetResolution?.targets.find((entry) => entry.targetId === rule.targetId);
    if (binding && binding.resolution !== "resolved") add(rule.id, `\u0426\u0435\u043B\u044C \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F: ${targetResolutionReason(binding.reason)}. \u0420\u0443\u0447\u043D\u0430\u044F \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430.`);
    if (rule.execution?.route === "delegated") add(rule.id, `\u0412\u043D\u0435\u0448\u043D\u0438\u0435 \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u043D\u044F\u043B\u0438\u0441\u044C \u0432 \u044D\u0442\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435: ${(rule.execution.externalRuleIds || []).join(", ")}.`);
    if (rule.execution?.route === "context-only") add(rule.id, "\u041F\u0440\u0430\u0432\u0438\u043B\u043E \u043F\u043E\u043A\u0430 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u043A \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435 (context-only).");
  });
  compiled.contract.rules.forEach((rule) => {
    const sourceId = String(rule.source?.anchor || rule.ruleId);
    const matches = evaluations.filter((entry) => entry.ruleId === rule.ruleId);
    if (!matches.length) add(sourceId, "Predicate Engine \u043D\u0435 \u0432\u0435\u0440\u043D\u0443\u043B \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0434\u043B\u044F \u0438\u0441\u043F\u043E\u043B\u043D\u044F\u0435\u043C\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.");
    matches.forEach((entry) => {
      const reason = String(entry.trace?.reason || "");
      if (reason === "selector matched no visible nodes" || reason === "rule authority is not active") {
        add(sourceId, reason === "rule authority is not active" ? "\u041F\u0440\u0430\u0432\u0438\u043B\u043E \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u043E." : "\u0426\u0435\u043B\u0435\u0432\u043E\u0439 \u0441\u043B\u043E\u0439 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D; \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E.");
      }
    });
  });
  if (checkedSnapshot?.targetResolution) {
    for (let index = evaluations.length - 1; index >= 0; index--) {
      const entry = evaluations[index];
      if (entry.trace?.reason !== "selector matched no visible nodes") continue;
      const atomic = compiled.contract.rules.find((rule) => rule.ruleId === entry.ruleId);
      const sourceId = String(atomic?.source?.anchor || "");
      const source = manual.rules.find((rule) => rule.id === sourceId);
      const binding = checkedSnapshot.targetResolution.targets.find((target) => target.targetId === source?.targetId);
      if (binding && binding.resolution !== "resolved") evaluations.splice(index, 1);
    }
  }
  const globalErrors = compiled.issues.filter((issue) => issue.level === "error" && !issue.path.startsWith("/rules/"));
  if (snapshot?.source?.truncated) add("snapshot-capture", `\u0421\u043D\u0438\u043C\u043E\u043A \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D ${snapshot.source.nodeLimit} \u0443\u0437\u043B\u0430\u043C\u0438; \u0447\u0430\u0441\u0442\u044C \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430.`);
  const boundaries = checkedSnapshot?.instanceBoundaries || [];
  boundaries.forEach((boundary) => {
    const content = checkedSnapshot?.instanceContentResults?.find((entry) => entry.boundaryNodeId === boundary.nodeId);
    if (content?.status === "matched") return;
    if (content?.status === "partial" && content.lineageProven && boundaries.some((b) => b.nodeId !== boundary.nodeId && withinBoundary(b.actualPath, boundary.actualPath))) return;
    const location = `\u0412\u043B\u043E\u0436\u0435\u043D\u043D\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C \xAB${boundary.actualPath}\xBB \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430: ${boundary.reason === "instance-swap" ? `\u0437\u0430\u043C\u0435\u043D\u0430 \u0447\u0435\u0440\u0435\u0437 ${boundary.property}` : boundary.reason === "component-variant-changed" ? "\u0432\u044B\u0431\u0440\u0430\u043D \u0434\u0440\u0443\u0433\u043E\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442 \u0442\u043E\u0433\u043E \u0436\u0435 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430" : boundary.reason === "component-identity-changed" ? "\u0438\u0437\u043C\u0435\u043D\u0451\u043D \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442" : "\u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445 \u043E\u0431 \u0438\u0434\u0435\u043D\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u0438 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430"}.`;
    if (!checkedSnapshot?.instanceContentReferences) {
      add(`instance-boundary:${boundary.nodeId}`, `${location} Baseline \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F. \u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u0437\u0430\u043C\u0435\u043D\u044B \u0438 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430/reference.`);
      return;
    }
    const labels = {
      "reference-not-captured": "\u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0439 \u044D\u0442\u0430\u043B\u043E\u043D \u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D",
      "reference-parent-mismatch": "\u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0445 \u044D\u0442\u0430\u043B\u043E\u043D\u043E\u0432 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438",
      "nested-content-reference-unresolved": "\u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D, \u043D\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0439 \u0437\u0430\u043C\u0435\u043D\u044B \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E \u043D\u0435 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E",
      "original-host-evidence-invalid": "\u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u044D\u0442\u0430\u043B\u043E\u043D host \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D",
      "explicit-swap-port-required": "\u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439 INSTANCE_SWAP port",
      "ambiguous-reference": "\u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u044D\u0442\u0430\u043B\u043E\u043D\u043E\u0432 \u043E\u0434\u043D\u043E\u0439 \u0437\u0430\u043C\u0435\u043D\u044B",
      "replacement-reference-incomplete": "\u044D\u0442\u0430\u043B\u043E\u043D \u043D\u0435\u043F\u043E\u043B\u043E\u043D \u0438\u043B\u0438 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 modes/\u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0443",
      "replacement-identity-or-port-mismatch": "identity \u0438\u043B\u0438 port \u044D\u0442\u0430\u043B\u043E\u043D\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442 \u0441 \u0437\u0430\u043C\u0435\u043D\u043E\u0439",
      "host-context-changed": "\u043F\u0440\u0438 \u043F\u043E\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u0438 \u044D\u0442\u0430\u043B\u043E\u043D\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u043E\u043A\u0440\u0443\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u043C\u043E\u0433\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E",
      "replacement-structure-needs-remap": "\u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043D\u043E\u0432\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0430 \u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u043E",
      "replacement-nested-identity-unresolved": "\u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B \u043A\u043B\u044E\u0447\u0438 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u044B\u0445 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043E\u0432 \u043D\u043E\u0432\u043E\u0439 \u0438\u043A\u043E\u043D\u043A\u0438",
      "variant-properties-mismatch": "variant properties \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u043C\u0443 \u044D\u0442\u0430\u043B\u043E\u043D\u0443 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430",
      "variant-properties-unavailable": "\u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u044B VARIANT-\u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E main component",
      "variant-switch-identity-mismatch": "\u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 VARIANT-\u0441\u0432\u043E\u0439\u0441\u0442\u0432 \u043D\u0435 \u043F\u0440\u0438\u0432\u0435\u043B\u043E \u043A \u043E\u0436\u0438\u0434\u0430\u0435\u043C\u043E\u043C\u0443 component key",
      "variant-capture-strategy-unproven": "\u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430 \u0441 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435\u043C \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u0447\u043D\u043E\u0433\u043E host-\u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430",
      "variable-modes-unavailable": "\u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0441\u0442\u0438 variable modes",
      "reference-capture-limit": "\u0434\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 8 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0445 \u044D\u0442\u0430\u043B\u043E\u043D\u043E\u0432 \u0437\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443",
      "replacement-component-unavailable": "\u043D\u043E\u0432\u044B\u0439 main component \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0438\u043B\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F",
      "reference-capture-failed": "Figma \u043D\u0435 \u043F\u043E\u0437\u0432\u043E\u043B\u0438\u043B\u0430 \u043F\u043E\u0441\u0442\u0440\u043E\u0438\u0442\u044C \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0439 \u044D\u0442\u0430\u043B\u043E\u043D"
    };
    add(`instance-boundary:${boundary.nodeId}`, `${location} \u041F\u0440\u0438\u0447\u0438\u043D\u0430: ${labels[content?.reason || ""] || "\u043D\u0435\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u044D\u0442\u0430\u043B\u043E\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E"}. Baseline \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F. \u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u0437\u0430\u043C\u0435\u043D\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C\u0438 \u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438; \u044D\u0442\u043E\u0442 \u043F\u0443\u043D\u043A\u0442 \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043A \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E.`);
  });
  globalErrors.forEach((issue) => add("contract-validation", `${issue.path}: ${validationIssueLabel(issue)}`));
  let excludedRules = 0;
  let notExecuted = 0;
  let unknownApplicabilityRules = 0;
  pending.forEach((reasons, sourceId) => {
    const packageGapReasons = Array.from(reasons);
    const rule = manual.rules.find((entry) => entry.id === sourceId);
    const applicability2 = rule ? diagnoseRuleApplicability(
      manual,
      rule,
      checkedSnapshot,
      ["variant-facts-v3", "variant-facts-v4", "dependency-facts-v5"].includes(compiled.contract.package.snapshotProfile || "")
    ) : void 0;
    const excluded = applicability2?.status === "not-applicable";
    if (excluded) excludedRules++;
    else {
      notExecuted++;
      if (applicability2?.status === "unknown") {
        unknownApplicabilityRules++;
        reasons.add("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E\u0441\u0442\u044C \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430; \u043F\u0440\u0430\u0432\u0438\u043B\u043E \u043D\u0435 \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u0438\u0437 \u043F\u043E\u043B\u043D\u043E\u0442\u044B \u043F\u0440\u043E\u0433\u043E\u043D\u0430.");
        if (applicability2.unsupportedConditions.length) reasons.add(`\u0422\u0440\u0435\u0431\u0443\u044E\u0442 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F: ${applicability2.unsupportedConditions.join(", ")}.`);
      }
    }
    const facts = rule ? inspectRuleFacts(manual, rule, checkedSnapshot) : [];
    if (facts.length && !excluded) {
      const available = facts.filter((fact) => fact.state === "available").map((fact) => fact.path);
      const missing = facts.filter((fact) => fact.state !== "available").map((fact) => fact.path);
      if (missing.length) reasons.add(`\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E runtime-\u0434\u0430\u043D\u043D\u044B\u0445: ${missing.join(", ")}.`);
      if (available.length) reasons.add(`\u0423\u0436\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B: ${available.join(", ")}.`);
      if (!missing.length) reasons.add("\u0412\u0441\u0435 \u0437\u0430\u044F\u0432\u043B\u0435\u043D\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u044B \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B, \u043D\u043E \u044D\u0442\u043E \u043D\u0435 \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442, \u0447\u0442\u043E \u043F\u0440\u0430\u0432\u0438\u043B\u043E \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u043E.");
    }
    const evidence = applicability2?.evaluations.find((entry) => entry.applicability === "not-applicable" && entry.trace.truth === "false");
    const boundary = boundaries.find((b) => sourceId === `instance-boundary:${b.nodeId}`);
    evaluations.push({
      evaluationId: `editor:${excluded ? "not-applicable" : "not-executed"}:${sourceId}`,
      ruleId: sourceId,
      classification: excluded ? "not-applicable" : "not-executed",
      severity: rule?.severity || "error",
      origin: "editor-coverage",
      applicability: applicability2?.status || "unknown",
      ruleTitle: rule?.message || rule?.rationale || sourceId,
      capability: rule?.capability || rule?.capabilitySet || "",
      subjectNodeName: manual.targets.find((target) => target.id === rule?.targetId)?.label || manual.component.family,
      ...boundary ? { subjectNodeId: boundary.nodeId, subjectNodeName: boundary.actualPath, focusNodeId: boundary.nodeId, ruleTitle: "\u041D\u0435\u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430" } : {},
      trace: excluded && evidence ? evidence.trace : { reason: Array.from(reasons).join(" ") },
      applicabilityEvidence: applicability2,
      factAvailability: facts,
      packageGapReasons
    });
  });
  const inconclusive = evaluations.filter((entry) => ["human-review", "not-evaluable", "unknown"].includes(String(entry.classification))).length;
  const complete = notExecuted === 0 && inconclusive === 0 && evaluations.length > 0;
  const scenarioCoverage = { complete, notExecuted, inconclusive, engineEvaluations, excludedRules, unknownApplicabilityRules };
  return {
    ...result,
    evaluations,
    contractReadiness,
    scenarioCoverage,
    // Compatibility alias: this now describes the current scenario, not package readiness.
    editorCoverage: scenarioCoverage
  };
}

// src/version.ts
var EDITOR_VERSION = "component-contract-editor@0.2.36";

// src/core/validation-export.ts
function buildValidationReportDownload(input) {
  const { manual, compiled, evaluatedContract, anatomy, engineResult, result } = input;
  const snapshot = prepareValidationSnapshot(input.snapshot, evaluatedContract);
  const engineSnapshotHash = validationSnapshotHash(snapshot, evaluatedContract);
  if (engineResult.snapshotHash !== engineSnapshotHash) {
    throw new Error("\u0421\u043D\u0438\u043C\u043E\u043A \u043E\u0442\u0447\u0451\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441\u043E \u0441\u043D\u0438\u043C\u043A\u043E\u043C \u0434\u0432\u0438\u0436\u043A\u0430. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443.");
  }
  const manualHash = stableHash(manual);
  if (compiled.contract.package.manualSourceHash !== manualHash || evaluatedContract.package.manualSourceHash !== manualHash) {
    throw new Error("\u041D\u0435\u043B\u044C\u0437\u044F \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0442\u0447\u0451\u0442: \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442 \u0438 manual source \u043E\u0442\u043D\u043E\u0441\u044F\u0442\u0441\u044F \u043A \u0440\u0430\u0437\u043D\u044B\u043C \u0440\u0435\u0432\u0438\u0437\u0438\u044F\u043C. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443.");
  }
  const generatedAt = input.generatedAt || (/* @__PURE__ */ new Date()).toISOString();
  const classifications = {};
  result.evaluations.forEach((entry) => {
    const key = String(entry.classification || "unknown");
    classifications[key] = (classifications[key] || 0) + 1;
  });
  const activatedDraftRuleIds = compiled.contract.rules.filter((rule) => rule.authority?.status === "draft" && evaluatedContract.rules.find((entry) => entry.ruleId === rule.ruleId)?.authority?.status === "active").map((rule) => rule.ruleId);
  const report = {
    schemaVersion: "apollo.editor-validation-report.v1",
    documentType: "component-contract-validation-report",
    generatedAt,
    editorVersion: EDITOR_VERSION,
    component: manual.component,
    run: {
      trigger: input.trigger,
      capture: input.capture,
      snapshotCapturedAt: snapshot.generatedAt,
      context: snapshot.context,
      manualRevision: manual.metadata.revision,
      manualSourceHash: manualHash,
      snapshotHash: stableHash(snapshot),
      engineSnapshotHash,
      snapshotEncoding: "json-canonical-v1",
      evaluatedContractHash: stableHash(evaluatedContract)
    },
    summary: {
      ...result.editorCoverage,
      coverageModel: "contract-and-scenario-v1",
      contractReadiness: result.contractReadiness,
      scenarioCoverage: result.scenarioCoverage,
      classifications,
      sourceRules: manual.rules.length,
      compiledChecks: compiled.contract.rules.length,
      capturedNodes: snapshot.nodes.length,
      compilerCoverage: compiled.contract.coverage
    },
    sources: { manual, compiledContract: compiled.contract, compilerIssues: compiled.issues },
    runtime: { evaluatedContract, activatedDraftRuleIds },
    snapshot,
    // Snapshot already carries observed properties. Keep only diagnostic target locators here.
    anatomy: anatomy.map(({ properties: _properties, ...locator }) => locator),
    results: {
      engine: engineResult,
      editor: result,
      details: buildEvaluationDetails(result, evaluatedContract, anatomy)
    },
    privacy: {
      containsLayerTextAndProperties: true,
      containsManualSource: true,
      includesPreviewImage: false,
      automaticallyUploaded: false
    }
  };
  return {
    fileName: `${slug(manual.component.family)}.validation-report.${generatedAt.replace(/[^0-9TZ-]/g, "-")}.json`,
    json: JSON.stringify(report, null, 2)
  };
}

// src/core/diagnostic-values.ts
function paintDiagnosticSummary(value) {
  if (!Array.isArray(value) || !value.length || !value.every((item) => item && typeof item === "object" && typeof item.type === "string")) return null;
  return value.map((paint, index) => {
    if (String(paint.type).startsWith("GRADIENT_")) {
      return [
        `${value.length > 1 ? `${index + 1}. ` : ""}${paint.type}`,
        ...Array.isArray(paint.gradientStops) ? paint.gradientStops.map((stop, i) => `Stop ${i + 1} @ ${stop.position}: RGBA (0\u20131) ${JSON.stringify(stop.color)} \xB7 Token ID: ${stop.tokenId === null ? "\u043D\u0435\u0442 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438" : stop.tokenId || "\u043D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445"}`) : ["Stops: \u043D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445"],
        `Transform: ${paint.gradientTransform ? JSON.stringify(paint.gradientTransform) : "\u043D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445"}`,
        ...paint.blendMode === void 0 ? [] : [`Blend: ${paint.blendMode}`],
        ...paint.opacity === void 0 ? [] : [`Opacity: ${paint.opacity}`],
        ...paint.visible === false ? ["\u0421\u043A\u0440\u044B\u0442\u0430"] : []
      ].join("\n");
    }
    const color = paint.color;
    const hex = color && ["r", "g", "b"].every((key) => typeof color[key] === "number") ? `#${["r", "g", "b"].map((key) => Math.round(color[key]).toString(16).padStart(2, "0")).join("").toUpperCase()}` : "";
    return [
      `${value.length > 1 ? `${index + 1}. ` : ""}${paint.type}${hex ? ` \xB7 ${hex}` : ""}`,
      `Token ID: ${typeof paint.tokenId === "string" && paint.tokenId ? paint.tokenId : "\u043D\u0435\u0442 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0432 \u0441\u043D\u0438\u043C\u043A\u0435"}`,
      ...paint.opacity === void 0 ? [] : [`Opacity: ${paint.opacity}`],
      ...paint.visible === false ? ["\u0421\u043A\u0440\u044B\u0442\u0430"] : []
    ].join("\n");
  }).join("\n\n");
}

// src/core/capture-facts.ts
function captureSupplementalFacts(node, mixed) {
  const text = {};
  const parent = {};
  const unknownFacts = [];
  const read = (source, key, output, fact) => {
    let value;
    try {
      value = source[key];
    } catch {
      value = void 0;
    }
    if (value === mixed || value === void 0 || typeof value === "number" && !Number.isFinite(value)) unknownFacts.push(fact);
    else if (value === null || ["string", "boolean", "number"].includes(typeof value)) output[key] = value;
    else unknownFacts.push(fact);
  };
  if (node.type === "TEXT") {
    for (const key of ["textAutoResize", "textAlignHorizontal", "textAlignVertical", "textTruncation", "maxLines"]) read(node, key, text, `text.${key}`);
  }
  const sourceParent = node.parent;
  if (sourceParent && !["PAGE", "DOCUMENT"].includes(String(sourceParent.type))) {
    const layout = {};
    read(sourceParent, "layoutMode", layout, "parent.layout.mode");
    if ("layoutMode" in layout) {
      layout.mode = layout.layoutMode;
      delete layout.layoutMode;
    }
    parent.layout = layout;
    read(sourceParent, "clipsContent", parent, "parent.clipsContent");
  } else unknownFacts.push("parent");
  return { text, parent, unknownFacts };
}

// src/core/target-remap.ts
var clone3 = (value) => JSON.parse(JSON.stringify(value));
var record13 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
var relative = (path) => path === void 0 ? void 0 : path.split(" / ").slice(1).join(" / ");
var includesPath = (ancestor, path) => ancestor === "" || ancestor === path || path.startsWith(`${ancestor} / `);
var declaredPath = (target, representationId) => target.representationHints?.find((h) => h.representationId === representationId)?.pathHint || target.pathHint;
function references(value, keys, role) {
  if (typeof value === "string") return keys.has(value) || ["relations", "semanticTargets", "variantAvailability.targets"].some((prefix) => value === `${prefix}.${role}` || value.startsWith(`${prefix}.${role}.`));
  if (Array.isArray(value)) return value.some((entry) => references(entry, keys, role));
  return Boolean(value && typeof value === "object" && Object.values(value).some((entry) => references(entry, keys, role)));
}
function affectedRules(manual, target, representationId, nextPath) {
  const before = relative(declaredPath(target, representationId));
  const after = relative(nextPath);
  const keys = new Set([
    target.id,
    target.semanticRole,
    declaredPath(target, representationId) || "",
    ...manual.controlPorts.filter((port) => port.targetId === target.id).map((port) => port.id)
  ].filter(Boolean));
  return manual.rules.flatMap((rule) => {
    if (rule.status === "deprecated") return [];
    const reasons = [];
    if (rule.targetId === target.id) reasons.push("\u0446\u0435\u043B\u044C \u043F\u0440\u0430\u0432\u0438\u043B\u0430");
    if (references(rule.constraints, keys, target.semanticRole)) reasons.push("\u0441\u0432\u044F\u0437\u044C \u0438\u043B\u0438 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u044C");
    if (references(rule.controlPaths, keys, target.semanticRole)) reasons.push("\u0443\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0449\u0438\u0439 \u043F\u0443\u0442\u044C / port");
    if (references(rule.applicability.context, keys, target.semanticRole)) reasons.push("\u0443\u0441\u043B\u043E\u0432\u0438\u0435");
    if (rule.targetScope === "self-and-descendants") {
      const owner = manual.targets.find((t) => t.id === rule.targetId);
      const path = owner && relative(declaredPath(owner, representationId));
      if (path !== void 0 && (before !== void 0 && includesPath(path, before) || includesPath(path, after))) reasons.push("\u043E\u0445\u0432\u0430\u0442 \u043F\u043E\u0442\u043E\u043C\u043A\u043E\u0432");
    }
    return reasons.length ? [{ id: rule.id, title: rule.message || rule.rationale || rule.id, status: rule.status, reasons }] : [];
  });
}
function hasFact(node, path) {
  if ((node.unknownFacts || []).some((p) => path === p || path.startsWith(`${p}.`))) return false;
  if (path.startsWith("component.properties.")) return Object.prototype.hasOwnProperty.call(record13(record13(node.component).properties), path.slice("component.properties.".length));
  let current = node;
  for (const part of path.split(".")) {
    if (!current || typeof current !== "object" || !Object.prototype.hasOwnProperty.call(current, part)) return false;
    current = current[part];
  }
  return current !== void 0;
}
function requiredFacts(rule) {
  const registered = rule.capabilitySet ? [...capabilitiesForSet(rule.capabilitySet)] : [rule.capability];
  const capabilities = rule.capabilitySet && rule.capabilitySelection ? registered.filter((c) => rule.capabilitySelection.includes(c)) : registered;
  const constraints = rule.constraints.length ? rule.constraints : rule.permission === "forbidden" ? [{ type: "propertyForbidden" }] : [];
  return [...new Set(capabilities.flatMap((capability) => !constraints.length ? [factForCapability(capability)] : constraints.flatMap((constraint) => {
    const fact = constraint.fact || factForCapability(capability);
    return constraint.type === "propertyForbidden" ? [fact, `baseline.effective.${fact}`] : ["propertyDomain", "layoutConstraint"].includes(constraint.type) ? [fact] : constraint.type === "tokenBinding" ? ["variable.bindings"] : [];
  })))];
}
function planTargetRemap(input) {
  const { manual, snapshot, variantEvidence, targetId, nodeId } = input;
  const plan = {
    planHash: "",
    manualSourceHash: stableHash(manual),
    snapshotHash: stableHash(snapshot),
    evidenceHash: stableHash(variantEvidence || null),
    targetId,
    nodeId,
    affectedRules: [],
    affectedExamples: [],
    capabilities: [],
    blockers: [],
    warnings: [],
    changed: false,
    canApply: false
  };
  const finish2 = () => {
    plan.blockers = [...new Set(plan.blockers)];
    plan.warnings = [...new Set(plan.warnings)];
    plan.canApply = plan.changed && !plan.blockers.length;
    plan.planHash = stableHash({ ...plan, planHash: void 0 });
    return plan;
  };
  const targets = manual.targets.filter((t) => t.id === targetId);
  if (targets.length !== 1) {
    plan.blockers.push("\u0418\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0446\u0435\u043B\u044C \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0435\u0451 ID \u043D\u0435 \u0443\u043D\u0438\u043A\u0430\u043B\u0435\u043D.");
    return finish2();
  }
  const target = targets[0];
  plan.before = clone3(target);
  if (manual.targets.filter((t) => t.semanticRole === target.semanticRole).length !== 1) plan.blockers.push("Semantic role \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u0446\u0435\u043B\u0438 \u043D\u0435 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u0430.");
  const paths = snapshotPaths(snapshot);
  if (!paths) {
    plan.blockers.push("\u041D\u0443\u0436\u0435\u043D \u043F\u043E\u043B\u043D\u044B\u0439 \u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u0441\u043D\u0438\u043C\u043E\u043A \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u0431\u0435\u0437 \u0443\u0441\u0435\u0447\u0435\u043D\u0438\u044F \u0438 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u043E\u0432 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B.");
    return finish2();
  }
  const node = snapshot.nodes.find((n) => n.id === nodeId);
  if (!node) {
    plan.blockers.push("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u043E\u0431\u044A\u0435\u043A\u0442 \u0438\u0437 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u0441\u043D\u0438\u043C\u043A\u0430.");
    return finish2();
  }
  const keys = [snapshot.source?.componentKey, snapshot.source?.componentSetKey].filter(Boolean);
  const reps = manual.representations.filter((rep2) => rep2.kind === "figma" && rep2.status !== "deprecated" && rep2.platform === snapshot.context.platform && keys.some((key) => key === rep2.locator.componentKey || key === rep2.locator.componentSetKey));
  if (reps.length !== 1) {
    plan.blockers.push("\u0421\u043D\u0438\u043C\u043E\u043A \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 Figma-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u044D\u0442\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430.");
    return finish2();
  }
  const rep = reps[0];
  plan.representationId = rep.id;
  const hints = target.representationHints?.filter((h) => h.representationId === rep.id) || [];
  if (hints.length > 1) {
    plan.blockers.push("\u0414\u043B\u044F \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0443\u0436\u0435 \u0437\u0430\u0434\u0430\u043D\u044B \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0438\u0435 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438; \u0441\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442.");
    return finish2();
  }
  if (target.resolution !== "resolved" && manual.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated").length > 1) {
    plan.blockers.push("\u0413\u043B\u043E\u0431\u0430\u043B\u044C\u043D\u043E \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u0443\u044E \u0446\u0435\u043B\u044C \u0441 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u043C\u0438 Figma-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u043C\u0438 \u043D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043E\u0434\u043D\u0438\u043C \u0441\u043D\u0438\u043C\u043A\u043E\u043C. \u041D\u0443\u0436\u043D\u0430 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 scope \u043F\u0440\u0438\u0432\u044F\u0437\u043E\u043A.");
  }
  const oldPath = declaredPath(target, rep.id);
  plan.previousPath = oldPath;
  const path = paths.get(nodeId);
  if ((target.semanticRole === "root" || oldPath !== void 0 && relative(oldPath) === "") !== (path === "")) plan.blockers.push("\u041A\u043E\u0440\u043D\u0435\u0432\u0443\u044E \u0446\u0435\u043B\u044C \u043D\u0435\u043B\u044C\u0437\u044F \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u0442\u044C \u043D\u0430 \u043F\u043E\u0442\u043E\u043C\u043A\u0430, \u0430 \u0446\u0435\u043B\u044C \u043F\u043E\u0442\u043E\u043C\u043A\u0430 \u2014 \u043D\u0430 \u043A\u043E\u0440\u0435\u043D\u044C.");
  const root = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const prefix = oldPath?.split(" / ")[0] || manual.component.family;
  const nextPath = [prefix, path].filter(Boolean).join(" / ");
  plan.nextPath = nextPath;
  const lineage = [];
  let current = node;
  while (current) {
    const identity = record13(record13(current.component).identity);
    lineage.unshift({
      name: String(current.name),
      type: String(current.type),
      ...identity.componentKey ? { componentKey: String(identity.componentKey) } : {},
      ...identity.componentSetKey ? { componentSetKey: String(identity.componentSetKey) } : {}
    });
    current = current.parentId === null ? void 0 : snapshot.nodes.find((n) => n.id === current.parentId);
  }
  plan.candidate = { name: String(node.name), type: String(node.type), lineage };
  if (lineage.slice(1).some((n) => n.name.includes(" / "))) plan.blockers.push("\u0418\u043C\u044F \u0441\u043B\u043E\u044F \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435\u043B\u044C \u043F\u0443\u0442\u0438 \xAB / \xBB; \u0442\u0430\u043A\u0430\u044F \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u0430.");
  for (const other of manual.targets.filter((t) => t.id !== targetId)) {
    if (relative(declaredPath(other, rep.id)) === path) plan.blockers.push(`\u041E\u0431\u044A\u0435\u043A\u0442 \u0443\u0436\u0435 \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u0451\u043D \u0437\u0430 ${other.id}; \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u0431\u044A\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u0435 \u0446\u0435\u043B\u0435\u0439 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043E.`);
  }
  const fingerprint = stableHash({ type: node.type, path: nextPath, order: node.order }).slice(0, 16);
  plan.changed = oldPath !== nextPath || (hints[0]?.structuralFingerprint || target.structuralFingerprint) !== fingerprint || target.resolution !== "resolved";
  if (!plan.changed) plan.blockers.push("\u042D\u0442\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0443\u0436\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0430. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 node ID \u0441\u0430\u043C\u043E \u043F\u043E \u0441\u0435\u0431\u0435 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u0435\u0440\u0435\u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438.");
  plan.after = { ...clone3(target), resolution: "resolved", representationHints: [
    ...(target.representationHints || []).filter((h) => h.representationId !== rep.id).map(clone3),
    { representationId: rep.id, nameHint: String(node.name), pathHint: nextPath, structuralFingerprint: fingerprint }
  ] };
  plan.affectedRules = affectedRules(manual, target, rep.id, nextPath);
  const affected = new Set(plan.affectedRules.map((rule) => rule.id));
  plan.affectedExamples = manual.examples.filter((example) => example.status !== "deprecated" && (example.ruleIds?.some((id) => affected.has(id)) || references([example.input, example.expected], /* @__PURE__ */ new Set([target.id, target.semanticRole]), target.semanticRole))).map((e) => e.id);
  const proposed = { ...manual, targets: manual.targets.map((t) => t.id === targetId ? plan.after : t) };
  const compiled = compileManualSource(proposed, variantEvidence).contract;
  if (variantEvidence) {
    const availability = variantAvailability(snapshot, compiled);
    if (availability.targets[target.semanticRole]?.state !== "present") plan.blockers.push(`\u041D\u043E\u0432\u0430\u044F \u0446\u0435\u043B\u044C \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430 Athena \u0438 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u043C \u044D\u0442\u0430\u043B\u043E\u043D\u043E\u043C (${availability.reason}). \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u044B; \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043F\u0435\u0440\u0435\u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0443 \u0434\u043B\u044F \u043E\u0431\u0445\u043E\u0434\u0430 drift \u0438\u043B\u0438 instance swap.`);
  } else {
    const resolution = resolveSnapshotTargets(snapshot, compiled).targets.find((t) => t.targetId === targetId);
    if (resolution?.resolution !== "resolved") plan.blockers.push(`\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043D\u0435 \u0434\u043E\u043A\u0430\u0437\u0430\u043D\u0430: ${targetResolutionReason(resolution?.reason || "topology-incomplete-or-ambiguous")}.`);
  }
  const prepared = prepareValidationSnapshot(snapshot, compiled);
  const candidate = prepared.nodes.find((n) => n.id === nodeId);
  for (const rule of manual.rules.filter((rule2) => affected.has(rule2.id))) {
    if (rule.targetId === targetId) {
      const deferred = ["delegated", "context-only", "policy-only"].includes(rule.execution?.route || "");
      if (deferred) plan.warnings.push(`${rule.id}: \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u043E\u0442\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0430\u0432\u0438\u043B\u0430 (${rule.execution.route}) \u043D\u0435 \u0434\u043E\u043A\u0430\u0437\u0430\u043D\u0430 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438; \u043C\u0430\u0440\u0448\u0440\u0443\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442\u0441\u044F, \u043D\u0443\u0436\u0435\u043D review \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430.`);
      for (const fact of deferred ? [] : requiredFacts(rule)) {
        const available = hasFact(candidate, fact);
        plan.capabilities.push({ ruleId: rule.id, path: fact, available });
        if (!available) plan.blockers.push(`${rule.id}: \u0443 \u043D\u043E\u0432\u043E\u0433\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u043E ${fact}.`);
      }
      for (const control of deferred ? [] : rule.controlPaths) {
        if (control.kind === "host-property" && control.property && !hasFact(root, `component.properties.${control.property}`)) plan.blockers.push(`${rule.id}: \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0449\u0435\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u043E host \xAB${control.property}\xBB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E.`);
        if (control.kind === "nested-property") plan.warnings.push(`${rule.id}: \u0441\u0432\u044F\u0437\u044C \u0441 nested property \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C; \u043E\u043D\u0430 \u043D\u0435 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.`);
      }
    }
    for (const constraint of rule.constraints) {
      for (const subject of constraint.dependency?.subjects || []) {
        if (subject.targetRole === target.semanticRole && ![...paths.values()].includes([path, subject.relativePath].filter(Boolean).join(" / "))) {
          plan.blockers.push(`${rule.id}: \u043D\u043E\u0432\u044B\u0439 \u043E\u0431\u044A\u0435\u043A\u0442 \u043D\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 declared dependency path \xAB${subject.relativePath}\xBB.`);
        }
      }
    }
  }
  if (plan.affectedRules.some((rule) => manual.rules.find((r) => r.id === rule.id)?.targetScope === "self-and-descendants")) plan.warnings.push("\u041E\u0445\u0432\u0430\u0442 \u043F\u0440\u0430\u0432\u0438\u043B \u0441 \u043F\u043E\u0442\u043E\u043C\u043A\u0430\u043C\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0441\u044F; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0432\u0435\u0441\u044C \u043D\u043E\u0432\u044B\u0439 subtree. \u0414\u0440\u0443\u0433\u0438\u0435 semantic targets \u043D\u0435 \u043F\u0435\u0440\u0435\u043C\u0435\u0449\u0430\u044E\u0442\u0441\u044F \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u044D\u0442\u043E\u0439 \u0446\u0435\u043B\u044C\u044E.");
  plan.warnings.push("\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u0441 \u0442\u0435\u043A\u0443\u0449\u0438\u043C \u0441\u043D\u0438\u043C\u043A\u043E\u043C. \u0412\u0441\u0435 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u0438 modes \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E review; Product, conditions, severity, constraints \u0438 control paths \u043D\u0435 \u043C\u0435\u043D\u044F\u044E\u0442\u0441\u044F.");
  return finish2();
}
function applyTargetRemap(input, expectedPlanHash, confirmed, updatedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  if (!confirmed) throw new Error("\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u044B\u0439 review \u0437\u0430\u0442\u0440\u043E\u043D\u0443\u0442\u044B\u0445 \u043F\u0440\u0430\u0432\u0438\u043B.");
  const plan = planTargetRemap(input);
  if (plan.planHash !== expectedPlanHash) throw new Error("\u041A\u043E\u043D\u0442\u0440\u0430\u043A\u0442, \u0441\u043D\u0438\u043C\u043E\u043A \u0438\u043B\u0438 Athena facts \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435\u043C.");
  if (!plan.canApply || !plan.after) throw new Error(plan.blockers.join(" ") || "\u041F\u0435\u0440\u0435\u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430.");
  if (!Number.isFinite(Date.parse(updatedAt))) throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.");
  const next = clone3(input.manual);
  next.targets = next.targets.map((target) => target.id === input.targetId ? clone3(plan.after) : target);
  const affected = new Set(plan.affectedRules.map((rule) => rule.id));
  next.rules = next.rules.map((rule) => affected.has(rule.id) ? { ...rule, status: "draft" } : rule);
  next.examples = next.examples.map((example) => plan.affectedExamples.includes(example.id) ? { ...example, status: "draft" } : example);
  next.metadata.revision += 1;
  next.metadata.updatedAt = updatedAt;
  return next;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CAPABILITY_SETS,
  CAPABILITY_SET_LABELS,
  COMPILED_SCHEMA_VERSION,
  COMPONENT_DEPENDENCY_CAPTURE_LIMIT,
  COMPONENT_DEPENDENCY_DEPTH_LIMIT,
  EDITOR_SESSION_SCHEMA_VERSION,
  INSTANCE_CONTENT_REFERENCE_LIMIT,
  LEGACY_MANUAL_SCHEMA_VERSION,
  MANUAL_SCHEMA_VERSION,
  PRODUCT_SCOPE_CATALOG,
  PROPERTY_APPLICABILITY,
  PROTECTED_INTERNAL_CAPABILITY_SETS,
  TARGET_RESOLUTION_SCHEMA,
  allowPublicComponentProperties,
  allowedComponentPropertyNames,
  applyProtectInternalsPolicy,
  applyTargetRemap,
  baselineFactsForRule,
  buildContractReadiness,
  buildEditorValidationReport,
  buildEvaluationDetails,
  buildExportBundle,
  buildValidationReportDownload,
  capabilitiesForSet,
  capabilitySetLabel,
  captureGradientPaintDetails,
  capturePropertyActivity,
  captureSupplementalFacts,
  captureVariantReference,
  compareInstanceBoundaries,
  compileApplicabilityProbe,
  compileManualSource,
  componentDependencyKeys,
  componentPropertyName,
  createEditorSession,
  createWorkspaceFromPreview,
  createZip,
  dependencyBinding,
  dependencyPinIssue,
  diagnoseRuleApplicability,
  effectiveFacts,
  evaluateCompiledContract,
  extractAssetCatalogs,
  extractVariantEvidence,
  factForCapability,
  forbiddenConstraintsForEdit,
  gradientPaintIssues,
  groupEvaluationDetails,
  importWorkspace,
  inspectRuleFacts,
  intrinsicBounds,
  isolateInstanceBoundaries,
  linkComponentDependencies,
  matchesComponentIdentity,
  materializeDependencyFacts,
  materializeEffectiveBaseline,
  materializeGradientPaintEvidence,
  materializeInstanceContentReferences,
  materializeNestedInstanceContentReferences,
  materializeSemanticFacts,
  materializeTargetResolution,
  materializeVariantFacts,
  mergeEditedApplicability,
  paintDiagnosticSummary,
  parseAssetCatalogs,
  parseEditorSession,
  planInstanceContentReferences,
  planNestedInstanceContentReferences,
  planTargetRemap,
  prepareAuthoringPreviewContract,
  prepareValidationSnapshot,
  propertyApplicabilityCondition,
  propertyAvailabilityKey,
  readZip,
  relativeTargetPath,
  resolveFixedNestedBinding,
  resolveSnapshotTargets,
  sameManualComponentFamily,
  samePreviewComponent,
  slug,
  snapshotShape,
  stableHash,
  stableStringify,
  supportedSemanticBinding,
  targetResolutionReason,
  textZipEntry,
  uniqueSorted,
  validateComponentDependencies,
  validateManualSource,
  validateRuleEdit,
  validatedDependencyCapture,
  validationIssueLabel,
  validationSnapshotHash,
  variantAvailability,
  withinBoundary,
  zipEntryText
});
