"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vendor/sha256.ts
var sha256_exports = {};
__export(sha256_exports, {
  sha256Hex: () => sha256Hex
});
function utf8Bytes(input) {
  const bytes = new Uint8Array(input.length * 3);
  let length = 0;
  for (let index = 0; index < input.length; index += 1) {
    let codePoint = input.charCodeAt(index);
    if (codePoint >= 55296 && codePoint <= 56319) {
      const low = input.charCodeAt(index + 1);
      if (low >= 56320 && low <= 57343) {
        codePoint = 65536 + (codePoint - 55296 << 10) + (low - 56320);
        index += 1;
      } else codePoint = 65533;
    } else if (codePoint >= 56320 && codePoint <= 57343) codePoint = 65533;
    if (codePoint <= 127) {
      bytes[length++] = codePoint;
    } else if (codePoint <= 2047) {
      bytes[length++] = 192 | codePoint >>> 6;
      bytes[length++] = 128 | codePoint & 63;
    } else if (codePoint <= 65535) {
      bytes[length++] = 224 | codePoint >>> 12;
      bytes[length++] = 128 | codePoint >>> 6 & 63;
      bytes[length++] = 128 | codePoint & 63;
    } else {
      bytes[length++] = 240 | codePoint >>> 18;
      bytes[length++] = 128 | codePoint >>> 12 & 63;
      bytes[length++] = 128 | codePoint >>> 6 & 63;
      bytes[length++] = 128 | codePoint & 63;
    }
  }
  return bytes.subarray(0, length);
}
function sha256Hex(input) {
  const rightRotate = (value, amount) => value >>> amount | value << 32 - amount;
  const maxWord = Math.pow(2, 32);
  const words = [];
  const hash2 = [];
  const constants = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate += 1) {
    if (isComposite[candidate]) continue;
    for (let multiple = candidate * candidate; multiple < 313; multiple += candidate) {
      isComposite[multiple] = true;
    }
    hash2[primeCounter] = Math.pow(candidate, 0.5) * maxWord | 0;
    constants[primeCounter] = Math.pow(candidate, 1 / 3) * maxWord | 0;
    primeCounter += 1;
  }
  const bytes = utf8Bytes(input);
  const bitLength = bytes.length * 8;
  const paddedLength = bytes.length + 9 + 63 >> 6 << 6;
  const padded = new Uint8Array(paddedLength);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / maxWord), false);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const w15 = words[index - 15];
      const w2 = words[index - 2];
      const s0 = rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ w15 >>> 3;
      const s1 = rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ w2 >>> 10;
      words[index] = words[index - 16] + s0 + words[index - 7] + s1 | 0;
    }
    const working = hash2.slice(0, 8);
    for (let index = 0; index < 64; index += 1) {
      const s1 = rightRotate(working[4], 6) ^ rightRotate(working[4], 11) ^ rightRotate(working[4], 25);
      const choice = working[4] & working[5] ^ ~working[4] & working[6];
      const temp1 = working[7] + s1 + choice + constants[index] + words[index] | 0;
      const s0 = rightRotate(working[0], 2) ^ rightRotate(working[0], 13) ^ rightRotate(working[0], 22);
      const majority = working[0] & working[1] ^ working[0] & working[2] ^ working[1] & working[2];
      const temp2 = s0 + majority | 0;
      working.unshift(temp1 + temp2 | 0);
      working[4] = working[4] + temp1 | 0;
      working.pop();
    }
    for (let index = 0; index < 8; index += 1) {
      hash2[index] = hash2[index] + working[index] | 0;
    }
  }
  return hash2.slice(0, 8).map((value) => (value >>> 0).toString(16).padStart(8, "0")).join("");
}
var init_sha256 = __esm({
  "vendor/sha256.ts"() {
    "use strict";
  }
});

// schemas/apollo-predicate-capabilities.v1.json
var require_apollo_predicate_capabilities_v1 = __commonJS({
  "schemas/apollo-predicate-capabilities.v1.json"(exports2, module2) {
    module2.exports = {
      schemaVersion: "apollo.predicate-capabilities.v1",
      documentType: "predicate-capability-registry",
      status: "mvp",
      semantics: {
        truthValues: ["true", "false", "unknown"],
        applicabilityValues: ["applicable", "not-applicable", "unknown"],
        unknownPolicy: "fail-closed",
        hiddenNodePolicy: "excluded-from-audit",
        orderingPolicy: "document-order-then-stable-id",
        verdictOwner: "predicate-engine",
        agentMayChangeVerdict: false
      },
      selectors: [
        "selection-root",
        "self",
        "direct-children",
        "descendants",
        "self-and-descendants",
        "parent",
        "ancestors",
        "siblings",
        "page-descendants",
        "where"
      ],
      factFamilies: [
        "node.identity",
        "node.type",
        "node.order",
        "node.bounds",
        "component.identity",
        "component.lifecycle",
        "component.properties",
        "baseline.effective",
        "override.actual",
        "layout.properties",
        "paint.state",
        "style.identity",
        "variable.binding",
        "text.content",
        "ownership.owner",
        "ownership.contour",
        "slot.identity",
        "page.context",
        "relation.measurement"
      ],
      predicates: [
        { id: "all", family: "logic", arity: "many" },
        { id: "any", family: "logic", arity: "many" },
        { id: "not", family: "logic", arity: "one" },
        { id: "exists", family: "value", arity: "one" },
        { id: "fact-present", family: "value", arity: "one" },
        { id: "equals", family: "value", arity: "two" },
        { id: "not-equals", family: "value", arity: "two" },
        { id: "one-of", family: "value", arity: "many" },
        { id: "none-of", family: "value", arity: "many" },
        { id: "compare", family: "value", arity: "two" },
        { id: "approximately-equals", family: "value", arity: "two" },
        { id: "between", family: "value", arity: "three" },
        { id: "string-length-between", family: "value", arity: "three" },
        { id: "matches", family: "value", arity: "two" },
        { id: "every", family: "collection", arity: "many" },
        { id: "some", family: "collection", arity: "many" },
        { id: "none", family: "collection", arity: "many" },
        { id: "count-between", family: "collection", arity: "three" },
        { id: "all-equal", family: "collection", arity: "many" },
        { id: "unique", family: "collection", arity: "many" },
        { id: "sequence-equals", family: "collection", arity: "many" },
        { id: "value-position", family: "collection", arity: "many" },
        { id: "direct-parent", family: "relation", arity: "two" },
        { id: "ancestor", family: "relation", arity: "two" },
        { id: "direct-child", family: "relation", arity: "two" },
        { id: "descendant", family: "relation", arity: "two" },
        { id: "before", family: "relation", arity: "two" },
        { id: "after", family: "relation", arity: "two" },
        { id: "adjacent", family: "relation", arity: "two" },
        { id: "contains", family: "geometry", arity: "two" },
        { id: "overlaps", family: "geometry", arity: "two" },
        { id: "aligned", family: "geometry", arity: "two" },
        { id: "distance", family: "geometry", arity: "three" },
        { id: "component-api-valid", family: "contract", arity: "one" },
        { id: "matches-effective-baseline", family: "contract", arity: "two" },
        { id: "binding-satisfies", family: "contract", arity: "two" },
        { id: "paint-state-satisfies", family: "contract", arity: "two" }
      ],
      gates: [
        "active-authority",
        "supported-capabilities",
        "complete-required-evidence",
        "unambiguous-component-identity",
        "no-authority-conflict"
      ],
      terminalClassifications: [
        "violation",
        "compliant",
        "allowed",
        "human-review",
        "not-applicable",
        "not-evaluable"
      ]
    };
  }
});

// predicate/index.js
var require_predicate = __commonJS({
  "predicate/index.js"(exports2, module2) {
    "use strict";
    var { sha256Hex: sha256Hex2 } = (init_sha256(), __toCommonJS(sha256_exports));
    var crypto = { createHash: function(algorithm) {
      if (algorithm !== "sha256") throw new Error("Only SHA-256 is supported");
      let value = "";
      return {
        update: function(next) {
          value += String(next);
          return this;
        },
        digest: function(format) {
          if (format !== "hex") throw new Error("Only hex digest is supported");
          return sha256Hex2(value);
        }
      };
    } };
    var registry = require_apollo_predicate_capabilities_v1();
    var TRUTH = Object.freeze({ TRUE: "true", FALSE: "false", UNKNOWN: "unknown" });
    var APPLICABILITY = Object.freeze({
      APPLICABLE: "applicable",
      NOT_APPLICABLE: "not-applicable",
      UNKNOWN: "unknown"
    });
    var IMPLEMENTED_PREDICATES = /* @__PURE__ */ new Set([
      "all",
      "any",
      "not",
      "exists",
      "fact-present",
      "equals",
      "not-equals",
      "one-of",
      "none-of",
      "compare",
      "approximately-equals",
      "between",
      "string-length-between",
      "matches",
      "every",
      "some",
      "none",
      "count-between",
      "all-equal",
      "unique",
      "sequence-equals",
      "value-position",
      "direct-parent",
      "ancestor",
      "direct-child",
      "descendant",
      "before",
      "after",
      "adjacent",
      "contains",
      "overlaps",
      "aligned",
      "distance",
      "component-api-valid",
      "matches-effective-baseline",
      "binding-satisfies",
      "paint-state-satisfies"
    ]);
    var REGISTERED_PREDICATES = new Set(registry.predicates.map((predicate) => predicate.id));
    var SELECTOR_ORIGINS = /* @__PURE__ */ new Set(["selection-root", "self", "page-descendants"]);
    var QUERY_ORIGINS = /* @__PURE__ */ new Set(["subject", "selection-root", "page-descendants"]);
    var SELECTOR_TRAVERSALS = /* @__PURE__ */ new Set([
      "self",
      "direct-children",
      "descendants",
      "self-and-descendants",
      "parent",
      "ancestors",
      "siblings"
    ]);
    var DERIVE_OPERATORS = /* @__PURE__ */ new Set([
      "add",
      "subtract",
      "multiply",
      "divide",
      "length",
      "absolute-difference"
    ]);
    var CAUSAL_RELATIONS = /* @__PURE__ */ new Set([
      "same-subject",
      "same-focus",
      "descendant-subject"
    ]);
    function stableStringify2(value) {
      if (Array.isArray(value)) return `[${value.map(stableStringify2).join(",")}]`;
      if (value && typeof value === "object") {
        return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify2(value[key])}`).join(",")}}`;
      }
      return JSON.stringify(value);
    }
    function stableHash2(value) {
      return crypto.createHash("sha256").update(stableStringify2(value)).digest("hex");
    }
    function snapshotHash2(snapshot) {
      if (typeof snapshot.snapshotHash === "string" && snapshot.snapshotHash) return snapshot.snapshotHash;
      const normalized = { ...snapshot };
      delete normalized.generatedAt;
      delete normalized.snapshotHash;
      return stableHash2(normalized);
    }
    function capabilityError(code, message) {
      const error = new Error(message);
      error.code = code;
      return error;
    }
    function validateValueRef(valueRef, location) {
      if (!valueRef || typeof valueRef !== "object" || Array.isArray(valueRef)) {
        throw capabilityError("RULE_IR_INVALID", `${location} must be a value reference object`);
      }
      const kinds = ["literal", "fact", "query", "derive"].filter((key) => Object.prototype.hasOwnProperty.call(valueRef, key));
      if (kinds.length !== 1) {
        throw capabilityError(
          "RULE_IR_INVALID",
          `${location} must contain exactly one of literal, fact, query or derive`
        );
      }
      if (kinds[0] === "literal") return;
      if (kinds[0] === "fact") {
        if (typeof valueRef.fact !== "string" || !valueRef.fact) {
          throw capabilityError("RULE_IR_INVALID", `${location}.fact must be a non-empty string`);
        }
        return;
      }
      if (kinds[0] === "query") {
        const query = valueRef.query;
        if (!query || typeof query !== "object" || Array.isArray(query)) {
          throw capabilityError("RULE_IR_INVALID", `${location}.query must be an object`);
        }
        if (!QUERY_ORIGINS.has(query.from)) {
          throw capabilityError("SELECTOR_UNKNOWN", `Unknown query origin: ${query.from}`);
        }
        if (!SELECTOR_TRAVERSALS.has(query.traverse)) {
          throw capabilityError("SELECTOR_UNKNOWN", `Unknown query traversal: ${query.traverse}`);
        }
        for (const [index, expression] of (query.where || []).entries()) {
          validateExpressionCapabilities(expression, `${location}.query.where[${index}]`);
        }
        if (query.project !== void 0) {
          validateValueRef(query.project, `${location}.query.project`);
        }
        return;
      }
      const derive = valueRef.derive;
      if (!derive || typeof derive !== "object" || Array.isArray(derive)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.derive must be an object`);
      }
      if (!DERIVE_OPERATORS.has(derive.operator)) {
        throw capabilityError(
          "RULE_IR_INVALID",
          `${location}.derive.operator is unsupported: ${derive.operator}`
        );
      }
      if (!Array.isArray(derive.args) || derive.args.length === 0) {
        throw capabilityError("RULE_IR_INVALID", `${location}.derive.args must not be empty`);
      }
      if (derive.operator === "length" && derive.args.length !== 1) {
        throw capabilityError("RULE_IR_INVALID", `${location}.derive.length requires one arg`);
      }
      if (["subtract", "divide", "absolute-difference"].includes(derive.operator) && derive.args.length !== 2) {
        throw capabilityError(
          "RULE_IR_INVALID",
          `${location}.derive.${derive.operator} requires two args`
        );
      }
      for (const [index, value] of derive.args.entries()) {
        validateValueRef(value, `${location}.derive.args[${index}]`);
      }
    }
    function validateExpressionCapabilities(expression, location) {
      if (!expression || typeof expression !== "object" || Array.isArray(expression)) {
        throw capabilityError("RULE_IR_INVALID", `${location} must be an expression object`);
      }
      const predicate = expression.predicate;
      if (typeof predicate !== "string" || !predicate) {
        throw capabilityError("RULE_IR_INVALID", `${location}.predicate is required`);
      }
      if (!REGISTERED_PREDICATES.has(predicate)) {
        throw capabilityError("PREDICATE_UNKNOWN", `Unknown predicate: ${predicate}`);
      }
      if (!IMPLEMENTED_PREDICATES.has(predicate)) {
        throw capabilityError("PREDICATE_NOT_IMPLEMENTED", `Predicate is not implemented yet: ${predicate}`);
      }
      const args = expression.args || [];
      if (["all", "any"].includes(predicate) && (!Array.isArray(args) || args.length === 0)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate} requires at least one arg`);
      }
      if (predicate === "not" && (!Array.isArray(args) || args.length !== 1)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.not requires exactly one arg`);
      }
      if (!["all", "any", "not"].includes(predicate) && !expression.actual) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate}.actual is required`);
      }
      for (const key of ["actual", "expected", "target", "lower", "upper"]) {
        if (expression[key] !== void 0) validateValueRef(expression[key], `${location}.${key}`);
      }
      if ([
        "equals",
        "not-equals",
        "one-of",
        "none-of",
        "compare",
        "approximately-equals",
        "matches",
        "every",
        "some",
        "none",
        "sequence-equals",
        "value-position",
        "direct-parent",
        "ancestor",
        "direct-child",
        "descendant",
        "before",
        "after",
        "adjacent",
        "matches-effective-baseline",
        "binding-satisfies",
        "paint-state-satisfies"
      ].includes(predicate) && !expression.expected) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate}.expected is required`);
      }
      if (predicate === "compare" && !["lt", "lte", "gt", "gte"].includes(expression.operator)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.compare.operator must be lt, lte, gt or gte`);
      }
      if (["between", "string-length-between", "count-between"].includes(predicate) && (!expression.lower || !expression.upper)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.between requires lower and upper values`);
      }
      if (expression.bounds && !["inclusive", "exclusive", "inclusive-lower", "inclusive-upper"].includes(expression.bounds)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.bounds is invalid`);
      }
      if (predicate === "value-position") {
        if (!Array.isArray(expression.positions) || expression.positions.length === 0) {
          throw capabilityError("RULE_IR_INVALID", `${location}.value-position.positions requires at least one position`);
        }
        if (expression.maxCount !== void 0 && (!Number.isInteger(expression.maxCount) || expression.maxCount < 0)) {
          throw capabilityError("RULE_IR_INVALID", `${location}.value-position.maxCount must be a non-negative integer`);
        }
      }
      if (["contains", "overlaps", "aligned", "distance"].includes(predicate) && !expression.target) {
        throw capabilityError("RULE_IR_INVALID", `${location}.${predicate}.target is required`);
      }
      if (predicate === "distance" && !expression.expected) {
        throw capabilityError("RULE_IR_INVALID", `${location}.distance.expected is required`);
      }
      if (predicate === "aligned" && !["left", "center-x", "right", "top", "center-y", "bottom"].includes(expression.axis)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.aligned.axis is invalid`);
      }
      if (predicate === "distance" && !["horizontal", "vertical", "euclidean"].includes(expression.axis)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.distance.axis is invalid`);
      }
      if (expression.tolerance !== void 0 && (typeof expression.tolerance !== "number" || !Number.isFinite(expression.tolerance) || expression.tolerance < 0)) {
        throw capabilityError("RULE_IR_INVALID", `${location}.tolerance must be a non-negative finite number`);
      }
      for (const [index, child] of args.entries()) {
        validateExpressionCapabilities(child, `${location}.args[${index}]`);
      }
    }
    function validateRule(rule) {
      if (!rule || rule.schemaVersion !== "apollo.rule-ir.v1") {
        throw capabilityError("RULE_IR_INVALID", "RuleIR schemaVersion must be apollo.rule-ir.v1");
      }
      if (!["require", "forbid", "allow"].includes(rule.effect)) {
        throw capabilityError("RULE_IR_INVALID", `Unsupported rule effect: ${rule.effect}`);
      }
      for (const [dimension, values] of Object.entries(rule.scope || {})) {
        if (!["platform", "product", "channel", "pageType"].includes(dimension) || values !== void 0 && (!Array.isArray(values) || values.some((value) => typeof value !== "string" || !value.trim()))) {
          throw capabilityError("RULE_IR_INVALID", `Unsupported or invalid scope dimension: ${dimension}`);
        }
      }
      if (!rule.select || !SELECTOR_ORIGINS.has(rule.select.from)) {
        throw capabilityError("SELECTOR_UNKNOWN", `Unknown selector origin: ${rule.select?.from}`);
      }
      if (!SELECTOR_TRAVERSALS.has(rule.select.traverse)) {
        throw capabilityError("SELECTOR_UNKNOWN", `Unknown selector traversal: ${rule.select.traverse}`);
      }
      validateExpressionCapabilities(rule.assert, "assert");
      if (rule.when) validateExpressionCapabilities(rule.when, "when");
      for (const [index, expression] of (rule.select?.where || []).entries()) {
        validateExpressionCapabilities(expression, `select.where[${index}]`);
      }
      if (rule.causality !== void 0 && rule.causality !== null) {
        if (typeof rule.causality !== "object" || Array.isArray(rule.causality) || !Array.isArray(rule.causality.causes) || !rule.causality.causes.length) {
          throw capabilityError(
            "RULE_IR_INVALID",
            "causality.causes must be a non-empty array"
          );
        }
        for (const [index, cause] of rule.causality.causes.entries()) {
          if (!cause || typeof cause !== "object" || Array.isArray(cause)) {
            throw capabilityError("RULE_IR_INVALID", `causality.causes[${index}] must be an object`);
          }
          if (typeof cause.ruleId !== "string" || !cause.ruleId) {
            throw capabilityError(
              "RULE_IR_INVALID",
              `causality.causes[${index}].ruleId must be a non-empty string`
            );
          }
          if (!CAUSAL_RELATIONS.has(cause.relation)) {
            throw capabilityError(
              "RULE_IR_INVALID",
              `causality.causes[${index}].relation is unsupported: ${cause.relation}`
            );
          }
          if (typeof cause.reason !== "string" || !cause.reason) {
            throw capabilityError(
              "RULE_IR_INVALID",
              `causality.causes[${index}].reason must be a non-empty string`
            );
          }
        }
      }
      return rule;
    }
    function unknownFactMatches(unknownFacts, factPath) {
      return (unknownFacts || []).some((unknownPath) => unknownPath === factPath || factPath.startsWith(`${unknownPath}.`));
    }
    function readObjectPath(root2, factPath) {
      let current = root2;
      for (const part of factPath.split(".")) {
        if (current === null || current === void 0 || typeof current !== "object") {
          return { state: "absent", value: void 0 };
        }
        if (!Object.prototype.hasOwnProperty.call(current, part)) {
          return { state: "absent", value: void 0 };
        }
        current = current[part];
      }
      return { state: "known", value: current };
    }
    function resolveQueryValue(query, subject, snapshot) {
      const index = nodeIndex(snapshot);
      const roots = query.from === "subject" ? [subject] : selectionRoots(snapshot, query.from, index);
      const candidates = roots.flatMap((root2) => traversalNodes(root2, query.traverse, index));
      const unique = new Map(candidates.map((node) => [node.id, node]));
      const nodes = Array.from(unique.values()).sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
      const selected = [];
      const factPaths = /* @__PURE__ */ new Set();
      for (const node of nodes) {
        let matches2 = true;
        for (const expression of query.where || []) {
          const trace = evaluateExpression(expression, node, snapshot);
          for (const factPath of trace.factPaths) factPaths.add(factPath);
          if (trace.truth === TRUTH.UNKNOWN) {
            return { state: "unknown", value: void 0, factPaths: Array.from(factPaths).sort() };
          }
          if (trace.truth === TRUTH.FALSE) {
            matches2 = false;
            break;
          }
        }
        if (!matches2) continue;
        if (query.project === void 0) {
          selected.push(node.id);
          continue;
        }
        const projected = resolveValue(query.project, node, snapshot);
        for (const factPath of projected.factPaths) factPaths.add(factPath);
        if (projected.state !== "known") {
          return { state: "unknown", value: void 0, factPaths: Array.from(factPaths).sort() };
        }
        selected.push(projected.value);
      }
      return { state: "known", value: selected, factPaths: Array.from(factPaths).sort() };
    }
    function resolveDerivedValue(derive, subject, snapshot) {
      const resolved = derive.args.map((value) => resolveValue(value, subject, snapshot));
      const factPaths = Array.from(new Set(resolved.flatMap((value) => value.factPaths))).sort();
      if (resolved.some((value) => value.state !== "known")) {
        return { state: "unknown", value: void 0, factPaths };
      }
      const values = resolved.map((value) => value.value);
      if (derive.operator === "length") {
        const value = values[0];
        if (!Array.isArray(value) && typeof value !== "string") {
          return { state: "unknown", value: void 0, factPaths };
        }
        return {
          state: "known",
          value: Array.isArray(value) ? value.length : Array.from(value).length,
          factPaths
        };
      }
      if (!values.every((value) => typeof value === "number" && Number.isFinite(value))) {
        return { state: "unknown", value: void 0, factPaths };
      }
      if (derive.operator === "add") {
        return { state: "known", value: values.reduce((sum, value) => sum + value, 0), factPaths };
      }
      if (derive.operator === "multiply") {
        return { state: "known", value: values.reduce((product, value) => product * value, 1), factPaths };
      }
      if (derive.operator === "subtract") {
        return { state: "known", value: values[0] - values[1], factPaths };
      }
      if (derive.operator === "absolute-difference") {
        return { state: "known", value: Math.abs(values[0] - values[1]), factPaths };
      }
      if (values[1] === 0) return { state: "unknown", value: void 0, factPaths };
      return { state: "known", value: values[0] / values[1], factPaths };
    }
    function resolveValue(valueRef, subject, snapshot) {
      if (!valueRef || typeof valueRef !== "object" || Array.isArray(valueRef)) {
        return { state: "unknown", value: void 0, factPaths: [] };
      }
      if (Object.prototype.hasOwnProperty.call(valueRef, "literal")) {
        return { state: "known", value: valueRef.literal, factPaths: [] };
      }
      if (Object.prototype.hasOwnProperty.call(valueRef, "query")) {
        return resolveQueryValue(valueRef.query, subject, snapshot);
      }
      if (Object.prototype.hasOwnProperty.call(valueRef, "derive")) {
        return resolveDerivedValue(valueRef.derive, subject, snapshot);
      }
      if (typeof valueRef.fact !== "string" || !valueRef.fact) {
        return { state: "unknown", value: void 0, factPaths: [] };
      }
      const factPath = valueRef.fact;
      if (unknownFactMatches(subject.unknownFacts, factPath)) {
        return { state: "unknown", value: void 0, factPaths: [factPath] };
      }
      if (factPath.startsWith("page.context.")) {
        const contextFactPath = factPath.slice("page.context.".length);
        if (unknownFactMatches(snapshot.context?.unknownFacts, contextFactPath)) {
          return { state: "unknown", value: void 0, factPaths: [factPath] };
        }
        const resolved = readObjectPath(snapshot.context, contextFactPath);
        return { ...resolved, factPaths: [factPath] };
      }
      return { ...readObjectPath(subject, factPath), factPaths: [factPath] };
    }
    function deepEqual(left, right) {
      return stableStringify2(left) === stableStringify2(right);
    }
    function makeTrace(predicate, truth, reason, actual, expected, factPaths, children) {
      const trace = {
        predicate,
        truth,
        reason,
        actual: actual.state === "known" ? actual.value : { state: actual.state },
        expected: expected.state === "known" ? expected.value : { state: expected.state },
        factPaths
      };
      if (children) trace.children = children;
      return trace;
    }
    function combineLogic(predicate, children) {
      const truths = children.map((child) => child.truth);
      if (predicate === "all") {
        if (truths.includes(TRUTH.FALSE)) return TRUTH.FALSE;
        return truths.includes(TRUTH.UNKNOWN) ? TRUTH.UNKNOWN : TRUTH.TRUE;
      }
      if (predicate === "any") {
        if (truths.includes(TRUTH.TRUE)) return TRUTH.TRUE;
        return truths.includes(TRUTH.UNKNOWN) ? TRUTH.UNKNOWN : TRUTH.FALSE;
      }
      return truths[0] === TRUTH.UNKNOWN ? TRUTH.UNKNOWN : truths[0] === TRUTH.TRUE ? TRUTH.FALSE : TRUTH.TRUE;
    }
    function evaluateLogicExpression(expression, subject, snapshot) {
      const children = expression.args.map((child) => evaluateExpression(child, subject, snapshot));
      const truth = combineLogic(expression.predicate, children);
      const factPaths = Array.from(new Set(children.flatMap((child) => child.factPaths))).sort();
      const reason = expression.predicate === "not" ? "logical negation evaluated" : `logical ${expression.predicate} evaluated`;
      return makeTrace(
        expression.predicate,
        truth,
        reason,
        { state: "known", value: children.map((child) => child.truth) },
        { state: "known", value: expression.predicate === "all" ? "all true" : expression.predicate === "any" ? "at least one true" : "negated" },
        factPaths,
        children
      );
    }
    function numericValue(resolved) {
      return resolved.state === "known" && typeof resolved.value === "number" && Number.isFinite(resolved.value);
    }
    function knownArray(resolved) {
      return resolved.state === "known" && Array.isArray(resolved.value);
    }
    function resolveBounds(expression, subject, snapshot) {
      const lower = resolveValue(expression.lower, subject, snapshot);
      const upper = resolveValue(expression.upper, subject, snapshot);
      return {
        lower,
        upper,
        factPaths: Array.from(/* @__PURE__ */ new Set([...lower.factPaths, ...upper.factPaths])).sort()
      };
    }
    function evaluateNumericRange(predicate, actual, lower, upper, bounds, factPaths) {
      if ([actual, lower, upper].some((value) => value.state === "unknown")) {
        return makeTrace(predicate, TRUTH.UNKNOWN, "range evidence is unknown", actual, { state: "unknown" }, factPaths);
      }
      if ([actual, lower, upper].some((value) => value.state === "absent")) {
        return makeTrace(predicate, TRUTH.FALSE, "range value is absent", actual, { state: "absent" }, factPaths);
      }
      if (![actual, lower, upper].every(numericValue) || lower.value > upper.value) {
        return makeTrace(predicate, TRUTH.UNKNOWN, "range requires ordered finite numeric bounds", actual, { state: "known", value: { lower: lower.value, upper: upper.value } }, factPaths);
      }
      const lowerPass = ["inclusive", "inclusive-lower"].includes(bounds) ? actual.value >= lower.value : actual.value > lower.value;
      const upperPass = ["inclusive", "inclusive-upper"].includes(bounds) ? actual.value <= upper.value : actual.value < upper.value;
      const truth = lowerPass && upperPass ? TRUTH.TRUE : TRUTH.FALSE;
      return makeTrace(predicate, truth, `numeric range ${bounds} evaluated`, actual, { state: "known", value: { lower: lower.value, upper: upper.value, bounds } }, factPaths);
    }
    function resolveNodePair(actual, expected, snapshot) {
      if (typeof actual.value !== "string" || typeof expected.value !== "string") {
        return { state: "invalid", actualNode: null, expectedNode: null };
      }
      const index = nodeIndex(snapshot);
      const actualNode = index.get(actual.value) || null;
      const expectedNode = index.get(expected.value) || null;
      if (!actualNode || !expectedNode) {
        return { state: "missing", actualNode, expectedNode };
      }
      return { state: "known", actualNode, expectedNode };
    }
    function isAncestorNode(ancestorNode, descendantNode, index) {
      let current = descendantNode.parentId ? index.get(descendantNode.parentId) : null;
      while (current) {
        if (current.id === ancestorNode.id) return true;
        current = current.parentId ? index.get(current.parentId) : null;
      }
      return false;
    }
    function siblingPosition(node, parent3, index) {
      if (!parent3) return null;
      const visibleIds = (parent3.childIds || []).filter((id) => index.get(id)?.visible === true);
      const position = visibleIds.indexOf(node.id);
      return position >= 0 ? position : null;
    }
    function evaluateRelation(predicate, actual, expected, snapshot, factPaths) {
      const pair = resolveNodePair(actual, expected, snapshot);
      if (pair.state !== "known") {
        return makeTrace(predicate, TRUTH.UNKNOWN, pair.state === "missing" ? "relation node is outside the snapshot" : "relation operands must be node ids", actual, expected, factPaths);
      }
      const { actualNode, expectedNode } = pair;
      const index = nodeIndex(snapshot);
      let passes = false;
      if (predicate === "direct-parent") passes = actualNode.parentId === expectedNode.id;
      else if (predicate === "ancestor") passes = isAncestorNode(expectedNode, actualNode, index);
      else if (predicate === "direct-child") passes = expectedNode.parentId === actualNode.id;
      else if (predicate === "descendant") passes = isAncestorNode(actualNode, expectedNode, index);
      else {
        const sameParent = actualNode.parentId !== null && actualNode.parentId === expectedNode.parentId;
        const parent3 = sameParent ? index.get(actualNode.parentId) : null;
        const actualPosition = siblingPosition(actualNode, parent3, index);
        const expectedPosition = siblingPosition(expectedNode, parent3, index);
        if (sameParent && actualPosition !== null && expectedPosition !== null) {
          if (predicate === "before") passes = actualPosition < expectedPosition;
          else if (predicate === "after") passes = actualPosition > expectedPosition;
          else passes = Math.abs(actualPosition - expectedPosition) === 1;
        }
      }
      const truth = passes ? TRUTH.TRUE : TRUTH.FALSE;
      return makeTrace(predicate, truth, truth === TRUTH.TRUE ? `node relation ${predicate} holds` : `node relation ${predicate} does not hold`, actual, expected, factPaths);
    }
    function isBounds(value) {
      return value && typeof value === "object" && !Array.isArray(value) && ["x", "y", "width", "height"].every((key) => typeof value[key] === "number" && Number.isFinite(value[key])) && value.width >= 0 && value.height >= 0;
    }
    function boundsCoordinate(bounds, axis) {
      if (axis === "left") return bounds.x;
      if (axis === "center-x") return bounds.x + bounds.width / 2;
      if (axis === "right") return bounds.x + bounds.width;
      if (axis === "top") return bounds.y;
      if (axis === "center-y") return bounds.y + bounds.height / 2;
      return bounds.y + bounds.height;
    }
    function axisGap(firstStart, firstSize, secondStart, secondSize) {
      const firstEnd = firstStart + firstSize;
      const secondEnd = secondStart + secondSize;
      if (firstEnd < secondStart) return secondStart - firstEnd;
      if (secondEnd < firstStart) return firstStart - secondEnd;
      return 0;
    }
    function partialMatch(actual, constraint) {
      if (!constraint || typeof constraint !== "object" || Array.isArray(constraint)) {
        return deepEqual(actual, constraint);
      }
      if (!actual || typeof actual !== "object" || Array.isArray(actual)) return false;
      return Object.keys(constraint).every((key) => partialMatch(actual[key], constraint[key]));
    }
    function evaluateExpression(expression, subject, snapshot) {
      if (["all", "any", "not"].includes(expression.predicate)) {
        return evaluateLogicExpression(expression, subject, snapshot);
      }
      const actual = resolveValue(expression.actual, subject, snapshot);
      const expected = expression.expected ? resolveValue(expression.expected, subject, snapshot) : { state: "known", value: null, factPaths: [] };
      const factPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...expected.factPaths])).sort();
      if (expression.predicate === "exists") {
        if (actual.state === "unknown") {
          return makeTrace("exists", TRUTH.UNKNOWN, "required fact is unknown", actual, expected, factPaths);
        }
        const truth = actual.state === "known" && actual.value !== null ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("exists", truth, truth === TRUTH.TRUE ? "fact exists" : "fact is absent", actual, expected, factPaths);
      }
      if (expression.predicate === "fact-present") {
        if (actual.state === "unknown") {
          return makeTrace("fact-present", TRUTH.UNKNOWN, "fact presence is unknown", actual, expected, factPaths);
        }
        const truth = actual.state === "known" ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(
          "fact-present",
          truth,
          truth === TRUTH.TRUE ? "fact path is present" : "fact path is absent",
          actual,
          expected,
          factPaths
        );
      }
      if (actual.state === "unknown" || expected.state === "unknown") {
        return makeTrace(expression.predicate, TRUTH.UNKNOWN, "comparison evidence is unknown", actual, expected, factPaths);
      }
      if (actual.state === "absent" || expected.state === "absent") {
        if (expression.missingPolicy === "unknown") {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "comparison value is absent", actual, expected, factPaths);
        }
        return makeTrace(expression.predicate, TRUTH.FALSE, "comparison value is absent", actual, expected, factPaths);
      }
      if (expression.predicate === "equals") {
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("equals", truth, truth === TRUTH.TRUE ? "values are equal" : "values differ", actual, expected, factPaths);
      }
      if (expression.predicate === "not-equals") {
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.FALSE : TRUTH.TRUE;
        return makeTrace("not-equals", truth, truth === TRUTH.TRUE ? "values differ" : "values are equal", actual, expected, factPaths);
      }
      if (expression.predicate === "one-of") {
        if (!Array.isArray(expected.value)) {
          return makeTrace("one-of", TRUTH.UNKNOWN, "expected value is not an array", actual, expected, factPaths);
        }
        const truth = expected.value.some((candidate) => deepEqual(actual.value, candidate)) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("one-of", truth, truth === TRUTH.TRUE ? "value belongs to the allowed set" : "value is outside the allowed set", actual, expected, factPaths);
      }
      if (expression.predicate === "none-of") {
        if (!Array.isArray(expected.value)) {
          return makeTrace("none-of", TRUTH.UNKNOWN, "expected value is not an array", actual, expected, factPaths);
        }
        const truth = expected.value.some((candidate) => deepEqual(actual.value, candidate)) ? TRUTH.FALSE : TRUTH.TRUE;
        return makeTrace("none-of", truth, truth === TRUTH.TRUE ? "value is outside the forbidden set" : "value belongs to the forbidden set", actual, expected, factPaths);
      }
      if (expression.predicate === "compare") {
        if (!numericValue(actual) || !numericValue(expected)) {
          return makeTrace("compare", TRUTH.UNKNOWN, "comparison requires finite numeric values", actual, expected, factPaths);
        }
        const comparisons = {
          lt: actual.value < expected.value,
          lte: actual.value <= expected.value,
          gt: actual.value > expected.value,
          gte: actual.value >= expected.value
        };
        const truth = comparisons[expression.operator] ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("compare", truth, `numeric comparison ${expression.operator} evaluated`, actual, { state: "known", value: { operator: expression.operator, value: expected.value } }, factPaths);
      }
      if (expression.predicate === "approximately-equals") {
        if (!numericValue(actual) || !numericValue(expected)) {
          return makeTrace(
            "approximately-equals",
            TRUTH.UNKNOWN,
            "approximate comparison requires finite numeric values",
            actual,
            expected,
            factPaths
          );
        }
        const tolerance = expression.tolerance || 0;
        const difference = Math.abs(actual.value - expected.value);
        const truth = difference <= tolerance ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(
          "approximately-equals",
          truth,
          truth === TRUTH.TRUE ? "values are equal within tolerance" : "values differ beyond tolerance",
          actual,
          { state: "known", value: { value: expected.value, tolerance, difference } },
          factPaths
        );
      }
      if (expression.predicate === "between") {
        const range = resolveBounds(expression, subject, snapshot);
        const bounds = expression.bounds || "inclusive";
        const rangeFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...range.factPaths])).sort();
        return evaluateNumericRange("between", actual, range.lower, range.upper, bounds, rangeFactPaths);
      }
      if (expression.predicate === "string-length-between") {
        const range = resolveBounds(expression, subject, snapshot);
        const rangeFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...range.factPaths])).sort();
        if (actual.state === "unknown") {
          return makeTrace("string-length-between", TRUTH.UNKNOWN, "string evidence is unknown", actual, { state: "unknown" }, rangeFactPaths);
        }
        if (actual.state === "absent") {
          return makeTrace("string-length-between", TRUTH.FALSE, "string value is absent", actual, { state: "absent" }, rangeFactPaths);
        }
        if (typeof actual.value !== "string") {
          return makeTrace("string-length-between", TRUTH.UNKNOWN, "actual value is not a string", actual, { state: "unknown" }, rangeFactPaths);
        }
        return evaluateNumericRange(
          "string-length-between",
          { state: "known", value: Array.from(actual.value).length, factPaths: actual.factPaths },
          range.lower,
          range.upper,
          expression.bounds || "inclusive",
          rangeFactPaths
        );
      }
      if (expression.predicate === "matches") {
        if (typeof actual.value !== "string" || typeof expected.value !== "string") {
          return makeTrace("matches", TRUTH.UNKNOWN, "regex comparison requires string values", actual, expected, factPaths);
        }
        let matcher;
        try {
          matcher = new RegExp(expected.value, expression.flags || "u");
        } catch (_error) {
          return makeTrace("matches", TRUTH.UNKNOWN, "regular expression is invalid", actual, expected, factPaths);
        }
        const truth = matcher.test(actual.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("matches", truth, truth === TRUTH.TRUE ? "string matches the pattern" : "string does not match the pattern", actual, { state: "known", value: { pattern: expected.value, flags: expression.flags || "u" } }, factPaths);
      }
      if (["every", "some", "none"].includes(expression.predicate)) {
        if (!knownArray(actual)) {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "collection predicate requires an actual array", actual, expected, factPaths);
        }
        const allowed = Array.isArray(expected.value) ? expected.value : [expected.value];
        const matches2 = actual.value.map((item) => allowed.some((candidate) => deepEqual(item, candidate)));
        const values = {
          every: matches2.every(Boolean),
          some: matches2.some(Boolean),
          none: matches2.every((match) => !match)
        };
        const truth = values[expression.predicate] ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(expression.predicate, truth, `collection membership ${expression.predicate} evaluated`, actual, { state: "known", value: allowed }, factPaths);
      }
      if (expression.predicate === "count-between") {
        const range = resolveBounds(expression, subject, snapshot);
        const rangeFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...range.factPaths])).sort();
        if (!knownArray(actual)) {
          return makeTrace("count-between", actual.state === "unknown" ? TRUTH.UNKNOWN : TRUTH.FALSE, "count predicate requires an actual array", actual, { state: "unknown" }, rangeFactPaths);
        }
        return evaluateNumericRange(
          "count-between",
          { state: "known", value: actual.value.length, factPaths: actual.factPaths },
          range.lower,
          range.upper,
          expression.bounds || "inclusive",
          rangeFactPaths
        );
      }
      if (expression.predicate === "all-equal") {
        if (!knownArray(actual)) {
          return makeTrace("all-equal", TRUTH.UNKNOWN, "all-equal requires an actual array", actual, expected, factPaths);
        }
        const reference = expression.expected ? expected.value : actual.value[0];
        const truth = actual.value.every((item) => deepEqual(item, reference)) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("all-equal", truth, truth === TRUTH.TRUE ? "all collection values are equal" : "collection values differ", actual, { state: "known", value: reference }, factPaths);
      }
      if (expression.predicate === "unique") {
        if (!knownArray(actual)) {
          return makeTrace("unique", TRUTH.UNKNOWN, "unique requires an actual array", actual, expected, factPaths);
        }
        const identities = actual.value.map(stableStringify2);
        const truth = identities.length === new Set(identities).size ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("unique", truth, truth === TRUTH.TRUE ? "collection values are unique" : "collection contains duplicates", actual, { state: "known", value: "unique values" }, factPaths);
      }
      if (expression.predicate === "sequence-equals") {
        if (!knownArray(actual) || !knownArray(expected)) {
          return makeTrace("sequence-equals", TRUTH.UNKNOWN, "sequence comparison requires two arrays", actual, expected, factPaths);
        }
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("sequence-equals", truth, truth === TRUTH.TRUE ? "sequences are equal" : "sequences differ", actual, expected, factPaths);
      }
      if (expression.predicate === "value-position") {
        if (!knownArray(actual)) {
          return makeTrace("value-position", TRUTH.UNKNOWN, "value-position requires an actual array", actual, expected, factPaths);
        }
        const positions = expression.positions;
        const matchingIndexes = actual.value.map((item, index) => deepEqual(item, expected.value) ? index : -1).filter((index) => index >= 0);
        const allowedIndexes = /* @__PURE__ */ new Set();
        for (const position of positions) {
          if (position === "first") allowedIndexes.add(0);
          else if (position === "last") allowedIndexes.add(Math.max(0, actual.value.length - 1));
          else if (Number.isInteger(position) && position >= 0) allowedIndexes.add(position);
        }
        const withinCount = expression.maxCount === void 0 || matchingIndexes.length <= expression.maxCount;
        const correctlyPositioned = matchingIndexes.every((index) => allowedIndexes.has(index));
        const truth = withinCount && correctlyPositioned ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("value-position", truth, truth === TRUTH.TRUE ? "matching values occupy allowed positions" : "matching values violate position or count constraints", actual, { state: "known", value: { value: expected.value, positions, maxCount: expression.maxCount ?? null } }, factPaths);
      }
      if ([
        "direct-parent",
        "ancestor",
        "direct-child",
        "descendant",
        "before",
        "after",
        "adjacent"
      ].includes(expression.predicate)) {
        return evaluateRelation(expression.predicate, actual, expected, snapshot, factPaths);
      }
      if (["contains", "overlaps", "aligned", "distance"].includes(expression.predicate)) {
        const target = resolveValue(expression.target, subject, snapshot);
        const geometryFactPaths = Array.from(/* @__PURE__ */ new Set([...actual.factPaths, ...target.factPaths, ...expected.factPaths])).sort();
        if (actual.state === "unknown" || target.state === "unknown" || expected.state === "unknown") {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "geometry evidence is unknown", actual, target, geometryFactPaths);
        }
        if (!isBounds(actual.value) || !isBounds(target.value)) {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "geometry predicate requires valid bounds", actual, target, geometryFactPaths);
        }
        let passes = false;
        let measured = null;
        if (expression.predicate === "contains") {
          passes = target.value.x >= actual.value.x && target.value.y >= actual.value.y && target.value.x + target.value.width <= actual.value.x + actual.value.width && target.value.y + target.value.height <= actual.value.y + actual.value.height;
        } else if (expression.predicate === "overlaps") {
          const intersectionWidth = Math.min(actual.value.x + actual.value.width, target.value.x + target.value.width) - Math.max(actual.value.x, target.value.x);
          const intersectionHeight = Math.min(actual.value.y + actual.value.height, target.value.y + target.value.height) - Math.max(actual.value.y, target.value.y);
          passes = intersectionWidth > 0 && intersectionHeight > 0;
        } else if (expression.predicate === "aligned") {
          measured = Math.abs(boundsCoordinate(actual.value, expression.axis) - boundsCoordinate(target.value, expression.axis));
          passes = measured <= (expression.tolerance || 0);
        } else {
          if (!numericValue(expected)) {
            return makeTrace("distance", TRUTH.UNKNOWN, "distance expectation must be a finite number", actual, expected, geometryFactPaths);
          }
          const horizontal = axisGap(actual.value.x, actual.value.width, target.value.x, target.value.width);
          const vertical = axisGap(actual.value.y, actual.value.height, target.value.y, target.value.height);
          measured = expression.axis === "horizontal" ? horizontal : expression.axis === "vertical" ? vertical : Math.sqrt(horizontal ** 2 + vertical ** 2);
          passes = Math.abs(measured - expected.value) <= (expression.tolerance || 0);
        }
        const truth = passes ? TRUTH.TRUE : TRUTH.FALSE;
        const expectedTrace = expression.predicate === "distance" ? { state: "known", value: { distance: expected.value, axis: expression.axis, tolerance: expression.tolerance || 0, measured } } : { state: "known", value: { target: target.value, axis: expression.axis || null, tolerance: expression.tolerance || 0, measured } };
        return makeTrace(expression.predicate, truth, truth === TRUTH.TRUE ? `geometry ${expression.predicate} holds` : `geometry ${expression.predicate} does not hold`, actual, expectedTrace, geometryFactPaths);
      }
      if (expression.predicate === "component-api-valid") {
        const valid = typeof actual.value === "boolean" ? actual.value : actual.value && typeof actual.value === "object" ? actual.value.valid : void 0;
        if (typeof valid !== "boolean") {
          return makeTrace("component-api-valid", TRUTH.UNKNOWN, "component API evidence has no boolean validity", actual, expected, factPaths);
        }
        return makeTrace("component-api-valid", valid ? TRUTH.TRUE : TRUTH.FALSE, valid ? "component API is valid" : "component API is invalid", actual, { state: "known", value: true }, factPaths);
      }
      if (expression.predicate === "matches-effective-baseline") {
        const truth = deepEqual(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace("matches-effective-baseline", truth, truth === TRUTH.TRUE ? "actual value matches effective baseline" : "actual value differs from effective baseline", actual, expected, factPaths);
      }
      if (["binding-satisfies", "paint-state-satisfies"].includes(expression.predicate)) {
        if (!expected.value || typeof expected.value !== "object" || Array.isArray(expected.value)) {
          return makeTrace(expression.predicate, TRUTH.UNKNOWN, "contract constraint must be an object", actual, expected, factPaths);
        }
        const truth = partialMatch(actual.value, expected.value) ? TRUTH.TRUE : TRUTH.FALSE;
        return makeTrace(expression.predicate, truth, truth === TRUTH.TRUE ? "contract constraint is satisfied" : "contract constraint is not satisfied", actual, expected, factPaths);
      }
      return makeTrace(expression.predicate, TRUTH.UNKNOWN, "predicate is not implemented", actual, expected, factPaths);
    }
    function scopeApplicability(rule, snapshot) {
      const scope = rule.scope || {};
      let unknown12;
      for (const key of ["platform", "product", "channel", "pageType"]) {
        if (!scope[key]?.length) continue;
        const factPath = `page.context.${key}`;
        const actual = resolveValue({ fact: factPath }, { unknownFacts: [] }, snapshot);
        const result = { dimension: key === "pageType" ? "page type" : key, actual, expected: scope[key], factPath };
        if (actual.state !== "known" || typeof actual.value !== "string" || !actual.value.trim()) {
          unknown12 = unknown12 || { ...result, applicability: APPLICABILITY.UNKNOWN };
          continue;
        }
        if (!scope[key].includes(actual.value)) return { ...result, applicability: APPLICABILITY.NOT_APPLICABLE };
      }
      return unknown12 || { applicability: APPLICABILITY.APPLICABLE };
    }
    function nodeIndex(snapshot) {
      return new Map(snapshot.nodes.map((node) => [node.id, node]));
    }
    function descendantsOf(root2, index) {
      const result = [];
      const visit = (node) => {
        for (const childId of node.childIds || []) {
          const child = index.get(childId);
          if (!child || child.visible !== true) continue;
          result.push(child);
          visit(child);
        }
      };
      visit(root2);
      return result;
    }
    function traversalNodes(root2, traverse, index) {
      if (traverse === "self") return [root2];
      if (traverse === "direct-children") {
        return (root2.childIds || []).map((id) => index.get(id)).filter((node) => node?.visible === true);
      }
      if (traverse === "descendants") return descendantsOf(root2, index);
      if (traverse === "self-and-descendants") return [root2, ...descendantsOf(root2, index)];
      if (traverse === "parent") {
        const parent3 = root2.parentId ? index.get(root2.parentId) : null;
        return parent3?.visible === true ? [parent3] : [];
      }
      if (traverse === "ancestors") {
        const result = [];
        let current = root2.parentId ? index.get(root2.parentId) : null;
        while (current) {
          if (current.visible === true) result.push(current);
          current = current.parentId ? index.get(current.parentId) : null;
        }
        return result;
      }
      if (traverse === "siblings") {
        const parent3 = root2.parentId ? index.get(root2.parentId) : null;
        return (parent3?.childIds || []).filter((id) => id !== root2.id).map((id) => index.get(id)).filter((node) => node?.visible === true);
      }
      throw capabilityError("SELECTOR_NOT_IMPLEMENTED", `Unsupported traversal: ${traverse}`);
    }
    function selectionRoots(snapshot, from, index) {
      if (from === "selection-root" || from === "self") {
        const ids = from === "self" ? snapshot.selection.slice(0, 1) : snapshot.selection;
        return ids.map((id) => index.get(id)).filter((node) => node?.visible === true);
      }
      if (from === "page-descendants") {
        return snapshot.nodes.filter((node) => node.visible === true && node.parentId === null);
      }
      throw capabilityError("SELECTOR_NOT_IMPLEMENTED", `Unsupported selector origin: ${from}`);
    }
    function selectSubjects(rule, snapshot) {
      const index = nodeIndex(snapshot);
      const roots = selectionRoots(snapshot, rule.select.from, index);
      const candidates = roots.flatMap((root2) => traversalNodes(root2, rule.select.traverse, index));
      const unique = new Map(candidates.map((node) => [node.id, node]));
      const unknownNodes = [];
      const nodes = Array.from(unique.values()).filter((node) => {
        for (const expression of rule.select.where || []) {
          const result = evaluateExpression(expression, node, snapshot);
          if (result.truth === TRUTH.UNKNOWN) {
            unknownNodes.push(node);
            return false;
          }
          if (result.truth === TRUTH.FALSE) return false;
        }
        return true;
      });
      nodes.sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
      unknownNodes.sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
      return { nodes, unknown: unknownNodes.length > 0, unknownNodes, roots };
    }
    function terminalClassification(rule, truth) {
      if (truth === TRUTH.UNKNOWN) return rule.unknownPolicy;
      if (rule.effect === "allow") return truth === TRUTH.TRUE ? "allowed" : "not-applicable";
      const violation = rule.effect === "require" ? truth === TRUTH.FALSE : truth === TRUTH.TRUE;
      return violation ? "violation" : "compliant";
    }
    function evaluationId(hash2, rule, subject, trace, applicability) {
      return stableHash2({
        snapshotHash: hash2,
        ruleId: rule.ruleId,
        ruleRevision: rule.revision,
        subjectNodeId: subject.id,
        factPaths: trace.factPaths,
        applicability
      });
    }
    function traceNodes(trace) {
      if (!trace || typeof trace !== "object") return [];
      return [trace, ...(trace.children || []).flatMap(traceNodes)];
    }
    function normalizePlatformTrace(rule, subject, trace) {
      if (rule.presentation?.causalRole !== "platform-root") return trace;
      const componentPlatform = subject.component?.platform;
      const candidates = traceNodes(trace).filter((item) => (item.factPaths || []).includes("page.context.platform"));
      const comparison = componentPlatform === "universal" ? candidates.find((item) => item.predicate === "one-of") : candidates.find((item) => item.predicate === "equals" && (item.factPaths || []).includes("component.platform"));
      if (!comparison) return trace;
      return Object.assign({}, trace, {
        reason: "page channel compatibility evaluated",
        actual: comparison.actual,
        expected: comparison.expected
      });
    }
    function makeEvaluation(hash2, rule, subject, applicability, classification, trace) {
      const normalizedTrace = normalizePlatformTrace(rule, subject, trace);
      return {
        evaluationId: evaluationId(hash2, rule, subject, normalizedTrace, applicability),
        ruleId: rule.ruleId,
        ruleRevision: rule.revision,
        subjectNodeId: subject.id,
        subjectNodeName: subject.name || subject.id,
        focusNodeId: subject.id,
        focusNodeName: subject.name || subject.id,
        applicability,
        classification,
        severity: rule.severity,
        trace: normalizedTrace,
        actionId: null
      };
    }
    function buildCoverage(evaluations) {
      const byClassification = {};
      for (const item of evaluations) {
        byClassification[item.classification] = (byClassification[item.classification] || 0) + 1;
      }
      const ids = evaluations.map((item) => item.evaluationId);
      return {
        total: evaluations.length,
        byClassification,
        unclassified: evaluations.filter((item) => !item.classification).length,
        duplicateEvaluationIds: ids.length - new Set(ids).size
      };
    }
    function isDescendantOrSelf(node, ancestorNodeId, index) {
      let current = node;
      while (current) {
        if (current.id === ancestorNodeId) return true;
        current = current.parentId ? index.get(current.parentId) : null;
      }
      return false;
    }
    function suppressPlatformDependentViolations(evaluations, rules, snapshot, hash2) {
      const index = nodeIndex(snapshot);
      const rulesById = new Map(rules.map((rule) => [rule.ruleId, rule]));
      const platformViolations = evaluations.filter((evaluation) => evaluation.classification === "violation" && rulesById.get(evaluation.ruleId)?.presentation?.causalRole === "platform-root");
      if (!platformViolations.length) return evaluations;
      return evaluations.map((evaluation) => {
        if (evaluation.classification !== "violation" || platformViolations.some((platform) => platform.evaluationId === evaluation.evaluationId) || !(evaluation.trace?.factPaths || []).includes("page.context.platform")) return evaluation;
        const subject = index.get(evaluation.subjectNodeId);
        const cause = platformViolations.find((platform) => subject && isDescendantOrSelf(subject, platform.subjectNodeId, index));
        if (!cause) return evaluation;
        const rule = rulesById.get(evaluation.ruleId);
        if (!rule) return evaluation;
        const trace = makeTrace(
          "causal-suppression",
          TRUTH.UNKNOWN,
          `platform-dependent violation is suppressed by ${cause.ruleId}`,
          { state: "known", value: evaluation.subjectNodeId },
          { state: "known", value: cause.subjectNodeId },
          ["page.context.platform"]
        );
        return Object.assign(
          makeEvaluation(
            hash2,
            rule,
            subject,
            APPLICABILITY.NOT_APPLICABLE,
            "not-applicable",
            trace
          ),
          {
            suppressedByEvaluationId: cause.evaluationId,
            suppressedByRuleId: cause.ruleId
          }
        );
      });
    }
    function causalRelationMatches(root2, derived, relation, index) {
      if (relation === "same-subject") {
        return root2.subjectNodeId === derived.subjectNodeId;
      }
      if (relation === "same-focus") {
        return root2.focusNodeId === derived.focusNodeId;
      }
      if (relation === "descendant-subject") {
        const derivedSubject = index.get(derived.subjectNodeId);
        return Boolean(
          derivedSubject && derivedSubject.id !== root2.subjectNodeId && isDescendantOrSelf(derivedSubject, root2.subjectNodeId, index)
        );
      }
      return false;
    }
    function groupCausalViolations(evaluations, rules, snapshot) {
      const index = nodeIndex(snapshot);
      const rulesById = new Map(rules.map((rule) => [rule.ruleId, rule]));
      const violations = evaluations.filter((evaluation) => evaluation.classification === "violation");
      const assignmentByDerivedId = /* @__PURE__ */ new Map();
      const derivedByRootId = /* @__PURE__ */ new Map();
      const roots = violations.filter((evaluation) => rulesById.get(evaluation.ruleId)?.causality?.causes?.length).sort((left, right) => left.subjectNodeId.localeCompare(right.subjectNodeId) || left.ruleId.localeCompare(right.ruleId) || left.evaluationId.localeCompare(right.evaluationId));
      for (const root2 of roots) {
        const rule = rulesById.get(root2.ruleId);
        for (const cause of rule.causality.causes) {
          const candidates = violations.filter((evaluation) => evaluation.evaluationId !== root2.evaluationId && evaluation.ruleId === cause.ruleId && !assignmentByDerivedId.has(evaluation.evaluationId) && causalRelationMatches(root2, evaluation, cause.relation, index)).sort((left, right) => left.subjectNodeId.localeCompare(right.subjectNodeId) || left.evaluationId.localeCompare(right.evaluationId));
          for (const derived of candidates) {
            assignmentByDerivedId.set(derived.evaluationId, {
              rootFindingId: root2.evaluationId,
              causalGroupingReason: cause.reason
            });
            if (!derivedByRootId.has(root2.evaluationId)) {
              derivedByRootId.set(root2.evaluationId, []);
            }
            derivedByRootId.get(root2.evaluationId).push(derived.evaluationId);
          }
        }
      }
      return evaluations.map((evaluation) => {
        const derived = assignmentByDerivedId.get(evaluation.evaluationId);
        if (derived) {
          return Object.assign({}, evaluation, derived, { derivedFindingIds: [] });
        }
        const derivedFindingIds = (derivedByRootId.get(evaluation.evaluationId) || []).slice().sort((left, right) => left.localeCompare(right));
        if (!derivedFindingIds.length) return evaluation;
        return Object.assign({}, evaluation, {
          rootFindingId: evaluation.evaluationId,
          derivedFindingIds,
          causalGroupingReason: "explicit source-rule causal relation"
        });
      });
    }
    function evaluateRules2({ snapshot, rules, ruleRelease = "unversioned" }) {
      const hash2 = snapshotHash2(snapshot);
      const evaluations = [];
      for (const ruleInput of rules) {
        const rule = validateRule(ruleInput);
        const index = nodeIndex(snapshot);
        const fallback = index.get(snapshot.selection[0]) || snapshot.nodes[0];
        if (!fallback) continue;
        if (rule.authority?.status !== "active") {
          const trace = makeTrace(rule.assert.predicate, TRUTH.UNKNOWN, "rule authority is not active", { state: "unknown" }, { state: "unknown" }, []);
          evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.UNKNOWN, "not-evaluable", trace));
          continue;
        }
        const scopeResult = scopeApplicability(rule, snapshot);
        let unknownScopeTrace;
        if (scopeResult.applicability !== APPLICABILITY.APPLICABLE) {
          const unknown12 = scopeResult.applicability === APPLICABILITY.UNKNOWN;
          const trace = makeTrace(
            "one-of",
            unknown12 ? TRUTH.UNKNOWN : TRUTH.FALSE,
            `rule ${scopeResult.dimension} scope ${unknown12 ? "is unknown" : "does not apply"}`,
            scopeResult.actual,
            { state: "known", value: scopeResult.expected },
            [scopeResult.factPath]
          );
          if (!unknown12) {
            evaluations.push(makeEvaluation(hash2, rule, fallback, scopeResult.applicability, "not-applicable", trace));
            continue;
          }
          unknownScopeTrace = trace;
        }
        const selected = selectSubjects(rule, snapshot);
        if (selected.unknown && !selected.nodes.length) {
          const trace = makeTrace(rule.assert.predicate, TRUTH.UNKNOWN, "selector evidence is unknown", { state: "unknown" }, { state: "unknown" }, []);
          evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.UNKNOWN, rule.unknownPolicy, trace));
          continue;
        }
        if (!selected.nodes.length) {
          if (unknownScopeTrace) {
            evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.UNKNOWN, rule.unknownPolicy, unknownScopeTrace));
            continue;
          }
          const trace = makeTrace(rule.assert.predicate, TRUTH.UNKNOWN, "selector matched no visible nodes", { state: "absent" }, { state: "unknown" }, []);
          evaluations.push(makeEvaluation(hash2, rule, fallback, APPLICABILITY.NOT_APPLICABLE, "not-applicable", trace));
          continue;
        }
        for (const subject of selected.nodes) {
          if (rule.when) {
            const whenTrace = evaluateExpression(rule.when, subject, snapshot);
            if (whenTrace.truth === TRUTH.FALSE) {
              evaluations.push(makeEvaluation(hash2, rule, subject, APPLICABILITY.NOT_APPLICABLE, "not-applicable", whenTrace));
              continue;
            }
            if (whenTrace.truth === TRUTH.UNKNOWN) {
              evaluations.push(makeEvaluation(hash2, rule, subject, APPLICABILITY.UNKNOWN, rule.unknownPolicy, whenTrace));
              continue;
            }
          }
          if (unknownScopeTrace) {
            evaluations.push(makeEvaluation(hash2, rule, subject, APPLICABILITY.UNKNOWN, rule.unknownPolicy, unknownScopeTrace));
            continue;
          }
          const trace = evaluateExpression(rule.assert, subject, snapshot);
          evaluations.push(makeEvaluation(
            hash2,
            rule,
            subject,
            APPLICABILITY.APPLICABLE,
            terminalClassification(rule, trace.truth),
            trace
          ));
        }
      }
      const normalizedEvaluations = groupCausalViolations(suppressPlatformDependentViolations(
        evaluations,
        rules,
        snapshot,
        hash2
      ), rules, snapshot);
      normalizedEvaluations.sort((left, right) => left.subjectNodeId.localeCompare(right.subjectNodeId) || left.ruleId.localeCompare(right.ruleId) || left.evaluationId.localeCompare(right.evaluationId));
      return {
        schemaVersion: "apollo.predicate-result.v1",
        snapshotHash: hash2,
        ruleRelease,
        evaluations: normalizedEvaluations,
        coverage: buildCoverage(normalizedEvaluations)
      };
    }
    module2.exports = {
      APPLICABILITY,
      IMPLEMENTED_PREDICATES,
      TRUTH,
      evaluateExpression,
      evaluateRules: evaluateRules2,
      resolveValue,
      selectSubjects,
      snapshotHash: snapshotHash2,
      stableHash: stableHash2,
      stableStringify: stableStringify2,
      validateRule
    };
  }
});

// src/runtime.ts
var runtime_exports = {};
__export(runtime_exports, {
  evaluateCompiledContract: () => evaluateCompiledContract,
  prepareAuthoringPreviewContract: () => prepareAuthoringPreviewContract,
  prepareValidationSnapshot: () => prepareValidationSnapshot,
  validationSnapshotHash: () => validationSnapshotHash
});
module.exports = __toCommonJS(runtime_exports);

// src/text-content-facts.ts
var record = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
function assertNativeRuleFactPolicies(contract) {
  const facts = new Set(contract.capabilities.facts);
  const visit = (value) => {
    if (!value || typeof value !== "object") return;
    if (typeof value.fact === "string") facts.add(value.fact);
    for (const child of Object.values(value)) visit(child);
  };
  visit(contract.rules);
  for (const [prefix, version] of [
    ["textContentV1.", contract.runtimePolicy.textContentFactsVersion],
    ["nativeTargetPropertiesV1.", contract.runtimePolicy.nativeTargetPropertyFactsVersion]
  ]) {
    if (version !== void 0 && version !== 1 || [...facts].some((f) => f.startsWith(prefix)) && version !== 1 || version === 1 && contract.package.sourceExportVersion !== (contract.runtimePolicy.declaredTargetConfigurationVersion === 2 ? "component-contract-editor@0.2.103" : contract.runtimePolicy.declaredTargetConfigurationVersion === 1 ? "component-contract-editor@0.2.99" : contract.runtimePolicy.declaredTargetIdentityVersion === 3 ? "component-contract-editor@0.2.95" : "component-contract-editor@0.2.94"))
      throw new Error("NATIVE_RULE_FACT_POLICY_UNSUPPORTED");
  }
}
function materializeTextContent(snapshot, contract) {
  if (contract.runtimePolicy.textContentFactsVersion !== 1) return;
  for (const node of snapshot.nodes) {
    delete node.textContentV1;
    const prior = node.unknownFacts || [];
    node.unknownFacts = prior.filter((p) => p !== "textContentV1" && !p.startsWith("textContentV1."));
    if (node.type !== "TEXT") continue;
    const text3 = record(node.text), facts = {};
    const known2 = (fact2) => !prior.some((p) => p === fact2 || fact2.startsWith(p + "."));
    if (known2("text.characters") && typeof text3.characters === "string") facts.characterCount = Array.from(text3.characters).length;
    const lh = record(text3.lineHeight);
    const pixels = lh.unit === "PIXELS" ? lh.value : lh.unit === "PERCENT" && typeof text3.fontSize === "number" ? text3.fontSize * lh.value / 100 : void 0;
    const height = record(node.bounds).height, count = height / pixels;
    if (["text.lineHeight", "text.fontSize", "bounds.height", "text.textAutoResize", "text.textTruncation", "text.paragraphSpacing", "text.maxHeight"].every(known2) && ["HEIGHT", "WIDTH_AND_HEIGHT"].includes(text3.textAutoResize) && text3.textTruncation === "DISABLED" && text3.paragraphSpacing === 0 && text3.maxHeight === null && typeof pixels === "number" && Number.isFinite(pixels) && pixels > 0 && typeof height === "number" && Number.isFinite(height) && height >= 0 && Math.abs(count - Math.round(count)) < 0.01) facts.lineCount = Math.round(count);
    node.textContentV1 = facts;
    for (const key of ["characterCount", "lineCount"]) if (facts[key] === void 0) node.unknownFacts.push(`textContentV1.${key}`);
  }
}

// src/stable.ts
init_sha256();
function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    const object2 = value;
    return `{${Object.keys(object2).filter((key) => object2[key] !== void 0).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(object2[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}
function stableHash(value) {
  return sha256Hex(stableStringify(value));
}
function slug(value) {
  const normalized = value.replace(/^\s*(?:❌|🔒|🔄)?\s*\[[DMT]\]\s*/u, "").replace(/([a-z\d])([A-Z])/g, "$1-$2").normalize("NFKD").replace(/[^a-zA-Z0-9а-яА-ЯёЁ]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase();
  return normalized || "target";
}

// src/occurrence-address.ts
function occurrenceSegment(name, sourceId, localId) {
  if (sourceId !== void 0) return "@source:" + encodeURIComponent(sourceId);
  if (localId !== void 0) return "@local:" + encodeURIComponent(localId);
  return name.startsWith("@") || name.includes(" / ") ? "@name:" + encodeURIComponent(name) : name;
}
function diagnosticStructure(nodes, names) {
  const byPath2 = new Map(nodes.map((n) => [n.path, n]));
  if (byPath2.size !== nodes.length || byPath2.get("")?.type !== "ROOT") return void 0;
  const parent3 = (path) => path.split(" / ").slice(0, -1).join(" / ");
  if (nodes.some((n) => n.path && !byPath2.has(parent3(n.path)))) return void 0;
  const visit = (path) => {
    const node = byPath2.get(path);
    const name = path ? names[path] : "";
    if (typeof name !== "string") return void 0;
    const children = nodes.filter((n) => n.path && parent3(n.path) === path).map((n) => visit(n.path));
    if (children.some((n) => n === void 0)) return void 0;
    return { name, type: node.type, children: children.sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))) };
  };
  return visit("");
}
function selectedTargetPathHint(target, representationId, componentKey, requireVariant = false) {
  const variants = target.variantHints?.filter((h) => h.representationId === representationId && h.componentKey === componentKey) || [];
  if (variants.length > 1) return void 0;
  if (variants.length === 1) return variants[0].pathHint;
  const hints = target.representationHints?.filter((h) => h.representationId === representationId) || [];
  if (hints.length > 1) return void 0;
  const path = hints[0]?.pathHint || target.pathHint;
  return requireVariant && path?.split(" / ").length !== 1 ? void 0 : path;
}

// src/snapshot-topology.ts
function snapshotPaths(snapshot) {
  if (snapshot.selection.length !== 1 || snapshot.source?.truncated !== false || snapshot.source.captureTopology?.complete === false) return void 0;
  const byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  if (byId.size !== snapshot.nodes.length) return void 0;
  const root2 = byId.get(snapshot.selection[0]);
  if (!root2 || root2.parentId !== null) return void 0;
  const paths = /* @__PURE__ */ new Map();
  const pathFor = (node, visited = /* @__PURE__ */ new Set()) => {
    const id = String(node.id);
    if (visited.has(id)) return void 0;
    visited.add(id);
    if (node === root2) return "";
    const parent3 = byId.get(String(node.parentId));
    if (!parent3 || !Array.isArray(parent3.childIds) || !parent3.childIds.includes(id)) return void 0;
    const parentPath3 = pathFor(parent3, visited);
    if (parentPath3 === void 0 || typeof node.name !== "string") return void 0;
    let segment = node.name;
    if (snapshot.source?.occurrenceAddressVersion === 1) {
      const siblings = snapshot.nodes.filter((n) => n.parentId === node.parentId && n.name === node.name);
      const source = node.component?.sourceIdentity;
      segment = siblings.length > 1 ? occurrenceSegment(
        node.name,
        typeof source?.sourceNodeId === "string" && source.sourceNodeId ? source.sourceNodeId : void 0,
        typeof source?.sourceNodeId === "string" && source.sourceNodeId ? void 0 : id
      ) : occurrenceSegment(node.name);
    }
    return [parentPath3, segment].filter(Boolean).join(" / ");
  };
  for (const node of snapshot.nodes) {
    const path = pathFor(node);
    if (path === void 0 || [...paths.values()].includes(path)) return void 0;
    paths.set(String(node.id), path);
    if (!Array.isArray(node.childIds) || new Set(node.childIds).size !== node.childIds.length || node.childIds.some((id) => !byId.has(String(id)) || byId.get(String(id))?.parentId !== node.id)) return void 0;
  }
  return paths;
}
function snapshotShape(snapshot) {
  const paths = snapshotPaths(snapshot);
  return paths && snapshot.nodes.map((n) => ({ path: paths.get(String(n.id)), type: paths.get(String(n.id)) === "" ? "ROOT" : String(n.type) })).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
}

// src/capture-representation.ts
function matchesCaptureRepresentation(rep, componentKey, componentSetKey = "") {
  if (rep.kind !== "figma" || rep.status === "deprecated" || !componentKey) return false;
  const set = rep.locator.componentSetKey;
  if (typeof set === "string" && set) return Boolean(componentSetKey && set === componentSetKey);
  const key = rep.locator.componentKey;
  return typeof key === "string" && Boolean(key) && (key === componentKey || key === componentSetKey);
}

// src/instance-correspondence.ts
var record2 = (value) => value && typeof value === "object" ? value : {};
var parentPath = (path) => path.split(" / ").slice(0, -1).join(" / ");
var leaf = (path) => path.split(" / ").slice(-1)[0];
function compareInstanceCorrespondence(snapshot, reference, nestedVariants) {
  const paths = snapshotPaths(snapshot), boundaries = [];
  const referencePaths = {};
  const invalid = () => ({ complete: false, boundaries, referencePaths });
  if (!paths || !reference.complete || !snapshot.source?.componentKey || reference.componentKey !== snapshot.source.componentKey || reference.componentSetKey !== (snapshot.source.componentSetKey || "")) return invalid();
  const actual = new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
  const expected = new Map(reference.nodes.map((n) => [n.path, n]));
  if (expected.size !== reference.nodes.length || expected.get("")?.type !== "ROOT") return invalid();
  for (const n of reference.nodes) if (n.path && !expected.has(parentPath(n.path))) return invalid();
  const aIdentity = (n) => record2(record2(n.component).identity);
  const rIdentity = (path) => reference.nodeProperties[path]?.identity;
  const unknown12 = (n, fact2) => (n.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + "."));
  const knownIdentity = (n) => Boolean(typeof aIdentity(n).componentKey === "string" && aIdentity(n).componentKey && !unknown12(n, "component.identity.componentKey") && !unknown12(n, "component.identity.componentSetKey"));
  const compatible = (n, path) => {
    const a = aIdentity(n), b = rIdentity(path);
    if (!knownIdentity(n) || !b?.componentKey) return false;
    if (a.componentSetKey || b.componentSetKey) return Boolean(a.componentSetKey && a.componentSetKey === b.componentSetKey);
    return a.componentKey === b.componentKey;
  };
  const ownerFor = (path, nodes) => {
    let p = parentPath(path);
    while (p) {
      if (nodes.get(p)?.type === "INSTANCE") return p;
      p = parentPath(p);
    }
    return "";
  };
  const actualPort = (path) => {
    const node = actual.get(path), c = record2(node.component), property = record2(c.propertyReferenceBindings).mainComponent;
    if (property === void 0) return void 0;
    const ownerPath = ownerFor(path, actual), ownerNode = actual.get(ownerPath), owner = record2(ownerNode?.component);
    if (typeof property !== "string" || !knownIdentity(node) || typeof c.identity?.mainComponentId !== "string" || record2(owner.propertyTypes)[property] !== "INSTANCE_SWAP" || record2(owner.properties)[property] !== c.identity.mainComponentId || unknown12(node, "component.propertyReferenceBindings.mainComponent") || unknown12(ownerNode, "component.properties." + property) || unknown12(ownerNode, "component.propertyTypes." + property)) return null;
    return { ownerPath, property };
  };
  const referencePort = (path) => {
    const c = reference.nodeProperties[path], property = c?.propertyReferenceBindings?.mainComponent;
    if (property === void 0) return void 0;
    const ownerPath = ownerFor(path, expected), owner = reference.nodeProperties[ownerPath];
    if (!property || !c.identity?.mainComponentId || owner?.propertyTypes[property] !== "INSTANCE_SWAP" || owner.properties[property] !== c.identity.mainComponentId) return null;
    return { ownerPath, property };
  };
  const sourcePort = (path, referenceSide) => {
    if (snapshot.source?.instanceSourceIdentityVersion !== 1) return void 0;
    const type = (referenceSide ? expected : actual).get(path)?.type;
    if (type !== "INSTANCE" && (snapshot.source?.occurrenceAddressVersion !== 1 || reference.occurrenceAddressVersion !== 1)) return void 0;
    const node = actual.get(path), c = referenceSide ? reference.nodeProperties[path] : record2(node?.component);
    const source = c?.sourceIdentity;
    if (source === void 0) return void 0;
    const ownerPath = ownerFor(path, referenceSide ? expected : actual);
    const ownerNode = actual.get(ownerPath);
    const owner = referenceSide ? reference.nodeProperties[ownerPath]?.identity : ownerNode && aIdentity(ownerNode);
    if (!source || source.version !== 1 || typeof source.sourceNodeId !== "string" || !source.sourceNodeId || typeof source.ownerComponentKey !== "string" || typeof source.ownerMainComponentId !== "string" || typeof owner?.componentKey !== "string" || !owner.componentKey || typeof owner.mainComponentId !== "string" || !owner.mainComponentId || source.ownerComponentKey !== owner.componentKey || source.ownerMainComponentId !== owner.mainComponentId || !referenceSide && (!node || type === "INSTANCE" && !knownIdentity(node) || !ownerNode || !knownIdentity(ownerNode) || ["version", "sourceNodeId", "ownerComponentKey", "ownerMainComponentId"].some((field) => unknown12(node, "component.sourceIdentity." + field)) || unknown12(ownerNode, "component.identity.mainComponentId"))) return null;
    return {
      ownerPath,
      sourceNodeId: source.sourceNodeId,
      ownerMainComponentId: source.ownerMainComponentId,
      ownerComponentKey: owner.componentKey,
      ownerComponentSetKey: owner.componentSetKey || ""
    };
  };
  const sameSourceOwner = (a, b) => a.ownerMainComponentId === b.ownerMainComponentId || snapshot.source?.instanceMainComponentAliasesVersion === 1 && a.ownerComponentKey === b.ownerComponentKey && a.ownerComponentSetKey === b.ownerComponentSetKey;
  const verifiedSlot = (actualPath, referencePath) => {
    const node = actual.get(actualPath), ref = reference.nodeProperties[referencePath];
    const property = record2(record2(node?.component).propertyReferenceBindings).slotContentId;
    if (!node || node.type !== "SLOT" || typeof property !== "string" || !property || ref?.propertyReferenceBindings?.slotContentId !== property || unknown12(node, "component.propertyReferenceBindings.slotContentId")) return false;
    const actualOwnerPath = ownerFor(actualPath, actual);
    const expectedOwnerPath = ownerFor(referencePath, expected);
    const actualOwner = actual.get(actualOwnerPath);
    const expectedOwner = reference.nodeProperties[expectedOwnerPath];
    if (!actualOwner || referencePaths[actualOwnerPath] !== expectedOwnerPath || record2(record2(actualOwner.component).propertyTypes)[property] !== "SLOT" || expectedOwner?.propertyTypes[property] !== "SLOT" || unknown12(actualOwner, `component.propertyTypes.${property}`)) return false;
    const actualConsumers = [...actual].filter(([p, n]) => n.type === "SLOT" && ownerFor(p, actual) === actualOwnerPath && record2(record2(n.component).propertyReferenceBindings).slotContentId === property);
    const expectedConsumers = reference.nodes.filter((n) => n.type === "SLOT" && ownerFor(n.path, expected) === expectedOwnerPath && reference.nodeProperties[n.path]?.propertyReferenceBindings?.slotContentId === property);
    return actualConsumers.length === 1 && expectedConsumers.length === 1;
  };
  const visibilityPort = (path, referenceSide) => {
    if (snapshot.source?.propertyReferenceIdentityVersion !== 1) return void 0;
    const node = actual.get(path), c = referenceSide ? reference.nodeProperties[path] : record2(node?.component);
    const property = c?.propertyReferenceBindings?.visible;
    if (property === void 0) return void 0;
    const ownerPath = ownerFor(path, referenceSide ? expected : actual);
    const owner = referenceSide ? reference.nodeProperties[ownerPath] : record2(actual.get(ownerPath)?.component);
    if (typeof property !== "string" || owner?.propertyTypes?.[property] !== "BOOLEAN" || typeof owner.properties?.[property] !== "boolean" || !referenceSide && (!node || !knownIdentity(node) || unknown12(node, "component.propertyReferenceBindings.visible") || unknown12(actual.get(ownerPath), `component.propertyTypes.${property}`) || unknown12(actual.get(ownerPath), `component.properties.${property}`))) return null;
    return { ownerPath, property };
  };
  referencePaths[""] = "";
  const root2 = actual.get(""), rootIdentity = root2 && aIdentity(root2);
  if (!root2 || !knownIdentity(root2) || rootIdentity?.componentKey !== reference.componentKey || (rootIdentity.componentSetKey || "") !== reference.componentSetKey) {
    if (reference.occurrenceAddressVersion === 1) delete referencePaths[""];
    return invalid();
  }
  const visit = (actualParent, expectedParent) => {
    const children = [...actual].filter(([p]) => p !== "" && parentPath(p) === actualParent);
    const refChildren = reference.nodes.filter((n) => n.path !== "" && parentPath(n.path) === expectedParent);
    if (children.length !== refChildren.length) return false;
    const claimed = /* @__PURE__ */ new Set();
    for (const [path, node] of children) {
      let candidates = refChildren.filter((n) => n.type === node.type && leaf(n.path) === leaf(path));
      const port = node.type === "INSTANCE" ? actualPort(path) : void 0;
      const visiblePort = node.type === "INSTANCE" && !port ? visibilityPort(path, false) : void 0;
      const source = sourcePort(path, false);
      let sourceCandidate;
      let uniqueVisibilityPort = false;
      if (port === null || visiblePort === null || source === null) return false;
      if (source) {
        const owner = referencePaths[source.ownerPath];
        const consumers = [...actual].filter(([p, n]) => {
          const other = sourcePort(p, false);
          return other?.ownerPath === source.ownerPath && other.sourceNodeId === source.sourceNodeId;
        });
        const matches2 = reference.nodes.filter((n) => {
          if (n.type !== node.type) return false;
          const other = sourcePort(n.path, true);
          return other?.ownerPath === owner && other.sourceNodeId === source.sourceNodeId && sameSourceOwner(source, other);
        });
        if (owner === void 0 || consumers.length !== 1 || matches2.length !== 1 || parentPath(matches2[0].path) !== expectedParent) return false;
        sourceCandidate = matches2[0];
      }
      if (node.type === "INSTANCE") {
        const typed = refChildren.filter((n) => n.type === "INSTANCE");
        if (port) {
          const owner = referencePaths[port.ownerPath];
          const consumers = [...actual].filter(([p, n]) => {
            if (n.type !== "INSTANCE") return false;
            const other = actualPort(p);
            return other?.ownerPath === port.ownerPath && other.property === port.property;
          });
          const refConsumers = reference.nodes.filter((n) => {
            if (n.type !== "INSTANCE") return false;
            const other = referencePort(n.path);
            return other?.ownerPath === owner && other.property === port.property;
          });
          if (owner === void 0 || consumers.length !== 1 || refConsumers.length !== 1 || parentPath(refConsumers[0].path) !== expectedParent) return false;
          candidates = refConsumers;
        } else if (visiblePort) {
          const owner = referencePaths[visiblePort.ownerPath];
          const consumers = [...actual].filter(([p, n]) => n.type === "INSTANCE" && (() => {
            const other = visibilityPort(p, false);
            return other?.ownerPath === visiblePort.ownerPath && other.property === visiblePort.property;
          })());
          const matches2 = typed.filter((n) => {
            const other = visibilityPort(n.path, true);
            return other?.ownerPath === owner && other.property === visiblePort.property;
          });
          if (owner !== void 0 && consumers.length === 1 && matches2.length === 1) {
            candidates = matches2;
            uniqueVisibilityPort = true;
          } else if (sourceCandidate) candidates = [sourceCandidate];
          else {
            const identities = typed.filter((n) => compatible(node, n.path));
            if (identities.length !== 1 || children.filter(([, n]) => n.type === "INSTANCE" && compatible(n, identities[0].path)).length !== 1) return false;
            candidates = identities;
          }
        } else if (sourceCandidate) {
          candidates = [sourceCandidate];
        } else {
          const identities = typed.filter((n) => compatible(node, n.path));
          if (identities.length) {
            if (identities.length !== 1 || children.filter(([, n]) => n.type === "INSTANCE" && compatible(n, identities[0].path)).length !== 1) return false;
            candidates = identities;
          }
        }
      } else if (sourceCandidate) candidates = [sourceCandidate];
      if (candidates.length !== 1 || claimed.has(candidates[0].path)) return false;
      if (source && candidates[0].path !== sourceCandidate?.path) return false;
      if (reference.occurrenceAddressVersion === 1 && /^@(source|local):/.test(leaf(candidates[0].path)) && !sourceCandidate && !port && !uniqueVisibilityPort) return false;
      const refPath = candidates[0].path;
      claimed.add(refPath);
      referencePaths[path] = refPath;
      if (node.type === "SLOT" && verifiedSlot(path, refPath)) continue;
      if (node.type === "INSTANCE") {
        const identity = aIdentity(node), other = rIdentity(refPath), refPort = referencePort(refPath);
        if (refPort === null || sourcePort(refPath, true) === null || Boolean(port) !== Boolean(refPort)) return false;
        const keysKnown = knownIdentity(node) && Boolean(other?.componentKey);
        const sameSet = Boolean(identity.componentSetKey && identity.componentSetKey === other?.componentSetKey);
        const sameIdentity = keysKnown && identity.componentKey === other.componentKey && (identity.componentSetKey || "") === (other?.componentSetKey || "");
        if (!sameIdentity) {
          const variant = nestedVariants && keysKnown && !port && sameSet;
          boundaries.push({
            nodeId: String(node.id),
            actualPath: path,
            referencePath: refPath,
            reason: !keysKnown ? "instance-identity-unavailable" : port ? "instance-swap" : variant ? "component-variant-changed" : "component-identity-changed",
            ...identity.componentKey ? { actualComponentKey: identity.componentKey } : {},
            ...other?.componentKey ? { referenceComponentKey: other.componentKey } : {},
            ...variant ? { componentSetKey: identity.componentSetKey } : {},
            ...port ? { ownerPath: referencePaths[port.ownerPath], property: port.property } : {}
          });
          continue;
        }
      }
      if (!visit(path, refPath)) return false;
    }
    return claimed.size === refChildren.length;
  };
  const complete = visit("", "");
  if (!complete && snapshot.source?.occurrenceAddressVersion === 1 && reference.occurrenceAddressVersion === 1) {
    const claimed = new Set(Object.values(referencePaths));
    const nodes = [...actual].filter(([p]) => p).sort(([a], [b]) => a.split(" / ").length - b.split(" / ").length);
    for (const [path, node] of nodes) {
      if (referencePaths[path] !== void 0 || actualPort(path) !== void 0 || visibilityPort(path, false) === null) continue;
      const source = sourcePort(path, false), parent3 = referencePaths[parentPath(path)];
      if (!source || parent3 === void 0) continue;
      const owner = referencePaths[source.ownerPath], ownerIdentity = aIdentity(actual.get(source.ownerPath)), expectedOwner = owner !== void 0 ? rIdentity(owner) : void 0;
      if (owner === void 0 || !expectedOwner || ownerIdentity.componentKey !== expectedOwner.componentKey || snapshot.source?.instanceMainComponentAliasesVersion === 1 && (ownerIdentity.componentSetKey || "") !== (expectedOwner.componentSetKey || "") || ownerIdentity.mainComponentId !== expectedOwner.mainComponentId && snapshot.source?.instanceMainComponentAliasesVersion !== 1) continue;
      const consumers = nodes.filter(([p]) => {
        const s = sourcePort(p, false);
        return s?.ownerPath === source.ownerPath && s.sourceNodeId === source.sourceNodeId;
      });
      const candidates = reference.nodes.filter((n) => n.type === node.type && parentPath(n.path) === parent3 && (() => {
        const s = sourcePort(n.path, true);
        return s?.ownerPath === owner && s.sourceNodeId === source.sourceNodeId && sameSourceOwner(source, s);
      })());
      if (consumers.length !== 1 || candidates.length !== 1 || claimed.has(candidates[0].path) || referencePort(candidates[0].path) !== void 0 || visibilityPort(candidates[0].path, true) === null) continue;
      const refPath = candidates[0].path, a = aIdentity(node), b = rIdentity(refPath);
      if (node.type === "INSTANCE") {
        if (!knownIdentity(node) || !b?.componentKey) continue;
        const same2 = a.componentKey === b.componentKey && (a.componentSetKey || "") === (b.componentSetKey || "");
        if (!same2) {
          if (!nestedVariants || !a.componentSetKey || a.componentSetKey !== b.componentSetKey) continue;
          boundaries.push({ nodeId: String(node.id), actualPath: path, referencePath: refPath, reason: "component-variant-changed", actualComponentKey: a.componentKey, referenceComponentKey: b.componentKey, componentSetKey: a.componentSetKey });
        }
      }
      referencePaths[path] = refPath;
      claimed.add(refPath);
    }
  }
  return { complete, boundaries, referencePaths };
}

// src/instance-boundaries.ts
var record3 = (value) => value && typeof value === "object" ? value : {};
var parentPath2 = (path) => path.split(" / ").slice(0, -1).join(" / ");
var withinBoundary = (path, boundary) => path === boundary || path.startsWith(`${boundary} / `);
var correspondingPath = (comparison, actualPath) => comparison?.referencePaths ? comparison.referencePaths[actualPath] : actualPath;
function compareInstanceBoundaries(snapshot, reference, nestedVariants = ["apollo.instance-content-references.v2", "apollo.instance-content-references.v3", "apollo.instance-content-references.v4"].includes(snapshot.instanceContentReferences?.schemaVersion || "")) {
  if (!reference.nodeProperties || typeof reference.nodeProperties !== "object" || Array.isArray(reference.nodeProperties)) {
    return { complete: false, boundaries: [], referencePaths: {} };
  }
  if (snapshot.source?.instanceIdentityVersion === 1) return compareInstanceCorrespondence(snapshot, reference, nestedVariants);
  const paths = snapshotPaths(snapshot), shape = snapshotShape(snapshot);
  const boundaries = [];
  const invalid = () => ({ complete: false, boundaries });
  if (!paths || !shape || !reference.complete) return invalid();
  if (!snapshot.source?.componentKey || reference.componentKey !== snapshot.source.componentKey || reference.componentSetKey !== (snapshot.source.componentSetKey || "")) return invalid();
  const actualByPath = new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
  const refByPath = new Map(reference.nodes.map((n) => [n.path, n]));
  if (refByPath.size !== reference.nodes.length) return invalid();
  const ownerFor = (path, nodes) => {
    let parent3 = parentPath2(path);
    while (parent3) {
      if (nodes.get(parent3)?.type === "INSTANCE") return parent3;
      parent3 = parentPath2(parent3);
    }
    return "";
  };
  const actualPort = (path) => {
    const node = actualByPath.get(path), component = record3(node?.component);
    const property = record3(component.propertyReferenceBindings).mainComponent;
    const ownerPath = ownerFor(path, actualByPath), owner = record3(actualByPath.get(ownerPath)?.component);
    if (typeof property !== "string" || record3(owner.propertyTypes)[property] !== "INSTANCE_SWAP" || typeof record3(component.identity).mainComponentId !== "string" || record3(owner.properties)[property] !== record3(component.identity).mainComponentId) return void 0;
    return { ownerPath, property };
  };
  const referencePort = (path) => {
    const data = reference.nodeProperties[path], property = data?.propertyReferenceBindings?.mainComponent;
    const ownerPath = ownerFor(path, refByPath), owner = reference.nodeProperties[ownerPath];
    if (!property || owner?.propertyTypes[property] !== "INSTANCE_SWAP" || !data?.identity?.mainComponentId || owner.properties[property] !== data.identity.mainComponentId) return void 0;
    return { ownerPath, property };
  };
  const instances = [...actualByPath].filter(([path, n]) => path && n.type === "INSTANCE").sort(([a], [b]) => a.split(" / ").length - b.split(" / ").length);
  for (const [path, node] of instances) {
    if (boundaries.some((b) => withinBoundary(path, b.actualPath))) continue;
    const identity = record3(record3(node.component).identity), port = actualPort(path);
    let refPath = refByPath.get(path)?.type === "INSTANCE" ? path : void 0;
    if (port) {
      const consumers = instances.filter(([p]) => {
        const other = actualPort(p);
        return other?.ownerPath === port.ownerPath && other.property === port.property;
      });
      const candidates = reference.nodes.filter((n) => {
        if (n.type !== "INSTANCE") return false;
        const other = referencePort(n.path);
        return other?.ownerPath === port.ownerPath && other.property === port.property;
      });
      if (consumers.length !== 1 || candidates.length !== 1 || parentPath2(candidates[0].path) !== parentPath2(path)) return invalid();
      refPath = candidates[0].path;
    }
    if (refPath === void 0) return invalid();
    const expected = reference.nodeProperties[refPath]?.identity;
    const keysKnown = typeof identity.componentKey === "string" && Boolean(identity.componentKey) && Boolean(expected?.componentKey);
    if (keysKnown && identity.componentKey === expected.componentKey && path === refPath) continue;
    const sameSet = nestedVariants && keysKnown && !port && path === refPath && typeof identity.componentSetKey === "string" && Boolean(identity.componentSetKey) && identity.componentSetKey === expected?.componentSetKey;
    boundaries.push({
      nodeId: String(node.id),
      actualPath: path,
      referencePath: refPath,
      reason: !keysKnown ? "instance-identity-unavailable" : port ? "instance-swap" : sameSet ? "component-variant-changed" : "component-identity-changed",
      ...sameSet ? { componentSetKey: identity.componentSetKey } : {},
      ...identity.componentKey ? { actualComponentKey: identity.componentKey } : {},
      ...expected?.componentKey ? { referenceComponentKey: expected.componentKey } : {},
      ...port || {}
    });
  }
  const prune = (nodes, actual) => nodes.flatMap((n) => {
    const boundary = boundaries.find((b) => withinBoundary(n.path, actual ? b.actualPath : b.referencePath));
    if (!boundary) return [n];
    if (n.path !== (actual ? boundary.actualPath : boundary.referencePath)) return [];
    return [{ path: boundary.referencePath, type: "INSTANCE" }];
  }).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
  return { complete: stableHash(prune(shape, true)) === stableHash(prune(reference.nodes, false)), boundaries };
}
function isolateInstanceBoundaries(snapshot, boundaries) {
  const paths = snapshotPaths(snapshot);
  if (!paths) return;
  snapshot.instanceBoundaries = boundaries;
  for (const node of snapshot.nodes) {
    const path = paths.get(String(node.id));
    const boundary = boundaries.find((b) => withinBoundary(path, b.actualPath));
    if (!boundary) continue;
    node.baseline = { effective: {} };
    node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
    if (node.semantic && typeof node.semantic === "object") delete node.semantic.role;
  }
}

// src/component-property-identity.ts
function resolveComponentProperty(requested, data, allowedTypes) {
  const names = [.../* @__PURE__ */ new Set([
    ...Object.keys(data.properties || {}),
    ...Object.keys(data.propertyTypes || {}),
    ...data.definedProperties || [],
    ...data.propertyReferences || []
  ])];
  const explicitId = /#[^#]+$/.test(requested);
  const candidates = names.filter((name2) => explicitId ? name2 === requested : name2.replace(/#[^#]+$/, "") === requested);
  if (!candidates.length) return { reason: "property-missing" };
  if (candidates.length !== 1) return { reason: "property-ambiguous" };
  const name = candidates[0], type = data.propertyTypes?.[name], alias = name !== requested;
  if (alias && !["BOOLEAN", "TEXT", "VARIANT", "INSTANCE_SWAP"].includes(String(type)) || allowedTypes && type !== void 0 && !allowedTypes.includes(String(type))) {
    return { reason: "property-type-incompatible" };
  }
  return { name, match: alias ? "alias" : "exact" };
}

// src/declared-target-membership.ts
function declaredTargetMembershipKey(targetId) {
  return `t_${stableHash(targetId)}`;
}
function matchesDeclaredTarget(node, role, contract) {
  const targets = contract.facts.targets.filter((target) => target.semanticRole === role);
  if (targets.length !== 1) return false;
  return node.declaredTargetMembershipV1?.[declaredTargetMembershipKey(targets[0].id)] === true;
}

// src/root-target.ts
function isDeclaredRootTarget(target) {
  if (target?.semanticRole === "root") return true;
  if (!target || target.resolution !== "resolved" || target.lineage?.length !== 0) return false;
  const paths = [
    target.pathHint,
    ...(target.representationHints || []).map((h) => h.pathHint),
    ...(target.variantHints || []).map((h) => h.pathHint)
  ].filter((path) => path !== void 0);
  return paths.length > 0 && paths.every((path) => typeof path === "string" && path.length > 0 && path === path.trim() && path.split(" / ").length === 1);
}
function declaredRootAliasRoles(targets) {
  const roots = targets.filter((t) => t.resolution === "resolved" && isDeclaredRootTarget(t));
  const roles = new Set(roots.map((t) => t.semanticRole));
  return roots.length > 1 && roles.size === roots.length ? roles : /* @__PURE__ */ new Set();
}
function matchesTargetRole(node, role, contract) {
  if ([1, 2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0)) return matchesDeclaredTarget(node, role, contract);
  return node.semantic?.role === role || contract.runtimePolicy.rootTargetAliasesVersion === 1 && node.rootTargetAliasesV1?.[role] === true;
}

// src/public-swap-reference.ts
var parent = (path) => path.split(" / ").slice(0, -1).join(" / ");
var inside = (path, boundary) => path === boundary || path.startsWith(boundary + " / ");
function publicSwapSlots(reference, shape) {
  const root2 = reference.nodeProperties[""], slots = [];
  if (!reference.complete || reference.occurrenceAddressVersion !== 1 || !root2?.identity) return slots;
  for (const target of shape.targets) {
    if (target.resolution !== "resolved") continue;
    const bindings = target.identityBindingsV1?.filter((b) => b.componentKey === reference.componentKey && b.componentSetKey === reference.componentSetKey) || [];
    if (bindings.length !== 1 || bindings[0].nodeType !== "INSTANCE" || !bindings[0].nativeSource) continue;
    const binding = bindings[0], source = binding.nativeSource;
    if (source.ownerComponentKey !== root2.identity.componentKey) continue;
    const policies = shape.policies.filter((p) => p.targetId === target.id && p.targetScope === "self" && p.capability === "component.swap" && p.permission === "allowed" && p.status !== "deprecated" && p.applicability.scopeStatus === "confirmed" && p.applicability.variants === "all" && p.applicability.modes === "all" && (!p.applicability.platforms.length || shape.representations.some((r) => r.id === binding.representationId && p.applicability.platforms.includes(r.platform))) && !p.targetApplicability && !p.propertyApplicability);
    const candidates = reference.nodes.filter((n) => {
      const value2 = reference.nodeProperties[n.path], native = value2?.sourceIdentity;
      return n.type === "INSTANCE" && native?.version === 1 && native.sourceNodeId === source.sourceNodeId && native.ownerComponentKey === source.ownerComponentKey && native.ownerMainComponentId === root2.identity.mainComponentId;
    });
    if (candidates.length !== 1) continue;
    const path = candidates[0].path, value = reference.nodeProperties[path], property = value.propertyReferenceBindings?.mainComponent;
    let owner = parent(path);
    while (owner && !["INSTANCE", "COMPONENT", "SLOT"].includes(reference.nodes.find((n) => n.path === owner)?.type || "")) owner = parent(owner);
    if (owner !== "" || !property || !root2.definedProperties?.includes(property) || root2.propertyTypes[property] !== "INSTANCE_SWAP" || reference.propertyTypes[property] !== "INSTANCE_SWAP" || typeof root2.properties[property] !== "string" || reference.properties[property] !== root2.properties[property] || !value.identity?.componentKey || typeof value.identity.componentSetKey !== "string" || !value.identity.mainComponentId || root2.properties[property] !== value.identity.mainComponentId || reference.nodes.filter((n) => reference.nodeProperties[n.path]?.propertyReferenceBindings?.mainComponent === property).length !== 1 || !policies.some((p) => p.controlPaths.some((c) => c.kind === "slot-api" && c.target === target.id && c.property === property && c.contentOwnership === "external" && c.exclusive === true && c.ownerTargetId === void 0))) continue;
    slots.push({
      referencePath: path,
      bindingPath: binding.referencePath,
      canonicalPath: [parent(path), "@public-swap:" + encodeURIComponent(source.sourceNodeId)].filter(Boolean).join(" / "),
      property
    });
  }
  return slots.filter((s) => !slots.some((other) => other !== s && (inside(s.referencePath, other.referencePath) || inside(other.referencePath, s.referencePath) || s.canonicalPath === other.canonicalPath || s.property === other.property)));
}
function projectPublicSwapStructure(nodes, slots, bindingSide = false) {
  const pathFor = (s) => bindingSide ? s.bindingPath : s.referencePath;
  return nodes.filter((n) => !slots.some((s) => n.path !== pathFor(s) && inside(n.path, pathFor(s)))).map((n) => ({ path: slots.find((s) => n.path === pathFor(s))?.canonicalPath || n.path, type: n.type })).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
}
function projectPublicSwapNames(names, slots, bindingSide = false) {
  const result = Object.assign({}, names);
  for (const slot of slots) {
    const path = bindingSide ? slot.bindingPath : slot.referencePath;
    if (Object.prototype.hasOwnProperty.call(names, path)) result[slot.canonicalPath] = slot.canonicalPath.split(" / ").slice(-1)[0];
  }
  return result;
}
function projectPublicSwapReference(reference, shape) {
  const slots = publicSwapSlots(reference, shape), projected = JSON.parse(JSON.stringify(reference));
  projected.nodes = projectPublicSwapStructure(reference.nodes, slots);
  for (const slot of slots) {
    const value = projected.nodeProperties[slot.referencePath];
    for (const path of Object.keys(projected.nodeProperties)) if (inside(path, slot.referencePath)) delete projected.nodeProperties[path];
    projected.nodeProperties[slot.canonicalPath] = {
      properties: {},
      propertyTypes: {},
      propertyReferences: [],
      diagnosticName: slot.canonicalPath.split(" / ").slice(-1)[0],
      propertyReferenceBindings: value.propertyReferenceBindings,
      sourceIdentity: value.sourceIdentity
    };
    delete projected.properties[slot.property];
    delete projected.nodeProperties[""].properties[slot.property];
  }
  return projected;
}

// src/variant-facts.ts
var record4 = (x) => x && typeof x === "object" && !Array.isArray(x) ? x : {};
var relativeTargetPath = (path) => path.split(" / ").slice(1).join(" / ");
var propertyAvailabilityKey = (name) => `p_${stableHash(name).slice(0, 16)}`;
var ordered = (nodes) => nodes.slice().sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
function captureVariantReference(snapshot, componentKey, componentSetKey, definedProperties) {
  const shape = snapshotShape(snapshot);
  const paths = snapshotPaths(snapshot);
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const component = record4(root2?.component);
  const referencesKnown = snapshot.nodes.every((n) => Array.isArray(record4(n.component).propertyReferences));
  const byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  const consumers = /* @__PURE__ */ new Map();
  for (const node of snapshot.nodes) {
    let parent3 = byId.get(String(node.parentId));
    const visited = /* @__PURE__ */ new Set();
    while (parent3 && !visited.has(String(parent3.id))) {
      visited.add(String(parent3.id));
      if (parent3.type === "INSTANCE") {
        const names = consumers.get(String(parent3.id)) || /* @__PURE__ */ new Set();
        (record4(node.component).propertyReferences || []).forEach((name) => names.add(name));
        consumers.set(String(parent3.id), names);
        break;
      }
      parent3 = byId.get(String(parent3.parentId));
    }
  }
  const nodeProperties = {};
  for (const node of snapshot.nodes) {
    const component2 = record4(node.component);
    const path = paths?.get(String(node.id)) ?? (node === root2 ? "" : relativeTargetPath(String(record4(node.semantic).path || "")));
    nodeProperties[path] = {
      properties: component2.properties || {},
      propertyTypes: component2.propertyTypes || {},
      propertyReferences: [...consumers.get(String(node.id)) || []],
      ...snapshot.source?.occurrenceAddressVersion === 1 ? { diagnosticName: String(node.name) } : {},
      ...component2.identity?.componentKey ? { identity: component2.identity } : {},
      ...component2.propertyReferenceBindings ? { propertyReferenceBindings: component2.propertyReferenceBindings } : {},
      ...node === root2 && definedProperties ? { definedProperties } : {}
    };
    if (snapshot.source?.instanceSourceIdentityVersion === 1 && component2.sourceIdentity) nodeProperties[path].sourceIdentity = component2.sourceIdentity;
  }
  return {
    componentKey,
    componentSetKey,
    complete: Boolean(shape && referencesKnown),
    nodes: shape || [],
    ...snapshot.source?.occurrenceAddressVersion === 1 ? { occurrenceAddressVersion: 1 } : {},
    properties: component.properties || {},
    propertyTypes: component.propertyTypes || {},
    propertyReferences: [...consumers.get(String(root2?.id)) || []],
    nodeProperties,
    ...definedProperties ? { definedProperties } : {}
  };
}
function variantAvailability(snapshot, contract) {
  const unknown12 = (reason) => ({ status: "unknown", reason, targets: {} });
  const evidence = contract.facts.variantEvidence, ref = snapshot.variantReference;
  if (!evidence || !ref?.complete || !ref.nodeProperties || typeof ref.nodeProperties !== "object" || Array.isArray(ref.nodeProperties) || !snapshotShape(snapshot)) return unknown12("incomplete-variant-evidence");
  if (ref.componentKey !== snapshot.source?.componentKey || ref.componentSetKey !== (snapshot.source?.componentSetKey ?? "")) return unknown12("reference-identity-mismatch");
  const variants = evidence.variants.filter((v) => v.componentKey === ref.componentKey && (v.componentSetKey === ref.componentSetKey || ref.componentSetKey === "" && v.componentSetKey === v.componentKey));
  if (variants.length !== 1) return unknown12("variant-key-unresolved");
  const variant = variants[0], shape = evidence.structures[variant.structureId];
  const externalSlots = contract.runtimePolicy?.declaredTargetConfigurationVersion === 2 ? publicSwapSlots(ref, { targets: contract.facts.targets, policies: contract.customizationPolicy, representations: contract.facts.representations }) : [];
  const occurrenceMode = evidence.occurrenceAddressVersion === 1;
  if (occurrenceMode && contract.runtimePolicy?.occurrenceAddressVersion !== 1) return unknown12("occurrence-policy-version-unavailable");
  if (occurrenceMode && ref.occurrenceAddressVersion !== 1) return unknown12("occurrence-reference-version-unavailable");
  if (occurrenceMode) {
    const catalogs = evidence.occurrences?.filter((o) => o.componentKey === variant.componentKey && o.componentSetKey === variant.componentSetKey) || [];
    const expected = shape && catalogs.length === 1 ? diagnosticStructure(projectPublicSwapStructure(shape, externalSlots, true), projectPublicSwapNames(catalogs[0].namesByPath, externalSlots, true)) : void 0;
    const observed = diagnosticStructure(projectPublicSwapStructure(ref.nodes, externalSlots), projectPublicSwapNames(Object.fromEntries(Object.entries(ref.nodeProperties).map(([p, n]) => [p, n.diagnosticName])), externalSlots));
    if (expected === void 0 || observed === void 0 || stableHash(expected) !== stableHash(observed)) return unknown12("reference-catalog-structure-drift");
  } else if (!shape || (externalSlots.length ? stableHash(projectPublicSwapStructure(ref.nodes, externalSlots)) !== stableHash(projectPublicSwapStructure(shape, externalSlots, true)) : stableHash(ordered(ref.nodes)) !== stableHash(shape))) return unknown12("reference-catalog-structure-drift");
  const scoped = ["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "");
  const comparison = scoped ? compareInstanceBoundaries(snapshot, ref) : void 0;
  if (occurrenceMode && comparison?.referencePaths?.[""] !== "") return unknown12("root-correspondence-unavailable");
  if (scoped ? !comparison?.complete && !occurrenceMode : stableHash(snapshotShape(snapshot)) !== stableHash(shape)) return unknown12("instance-structure-needs-remap");
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const standaloneRaw = ref.componentSetKey === "" && variant.componentSetKey === variant.componentKey && Object.keys(variant.properties).length === 1 && typeof variant.properties.raw === "string" && !Object.prototype.hasOwnProperty.call(ref.propertyTypes, "raw") && !Object.prototype.hasOwnProperty.call(record4(record4(root2?.component).propertyTypes), "raw");
  if (Object.entries(variant.properties).some(([key, value]) => !(standaloneRaw && key === "raw") && (record4(record4(root2?.component).properties)[key] !== value || ref.properties[key] !== value))) return unknown12("variant-properties-mismatch");
  const reps = contract.facts.representations.filter((r) => r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
  if (reps.length !== 1) return unknown12("representation-unresolved");
  const targets = {};
  const siblings = evidence.variants.filter((v) => v.componentSetKey === variant.componentSetKey);
  for (const target of contract.facts.targets) {
    const bindings = target.variantHints?.filter((h) => h.representationId === reps[0].id && h.componentKey === ref.componentKey) || [];
    const defaultHint = target.representationHints?.find((h) => h.representationId === reps[0].id)?.pathHint || target.pathHint;
    const hint = bindings.length === 1 ? bindings[0].pathHint : bindings.length > 1 ? void 0 : defaultHint;
    const path = hint ? relativeTargetPath(hint) : void 0;
    const witnessed = occurrenceMode ? path !== void 0 && (path === "" || bindings.length === 1) && ref.nodes.some((n) => n.path === path) && Boolean(comparison?.referencePaths && Object.values(comparison.referencePaths).includes(path)) : path !== void 0 && siblings.some((v) => evidence.structures[v.structureId]?.some((n) => n.path === path));
    const isolated = path !== void 0 && comparison?.boundaries.some((b) => withinBoundary(path, b.referencePath) || withinBoundary(path, b.actualPath));
    targets[target.semanticRole] = !witnessed || isolated || target.resolution === "ambiguous" || target.resolution === "unknown" ? { state: "unknown" } : { state: (occurrenceMode ? ref.nodes : shape).some((n) => n.path === path) ? "present" : "absent", path };
  }
  const aliases = contract.runtimePolicy?.rootTargetAliasesVersion === 1 ? declaredRootAliasRoles(contract.facts.targets) : /* @__PURE__ */ new Set();
  for (const target of Object.values(targets)) {
    const collisions = Object.entries(targets).filter(([, t]) => t.path === target.path);
    if (target.path !== void 0 && collisions.length > 1 && !(target.path === "" && collisions.every(([role]) => aliases.has(role)))) target.state = "unknown";
  }
  return {
    status: comparison?.boundaries.length || occurrenceMode && !comparison?.complete ? "partial" : "verified",
    reason: occurrenceMode && !comparison?.complete ? "occurrence-correspondence-incomplete" : comparison?.boundaries.length ? "verified-outside-instance-boundaries" : "catalog-and-live-reference-agree",
    targets,
    ...scoped ? { boundaries: comparison.boundaries } : {}
  };
}
function materializeVariantFacts(snapshot, contract) {
  snapshot.nodes.forEach((node) => {
    delete node.rootTargetAliasesV1;
  });
  const availability = variantAvailability(snapshot, contract);
  const scoped = ["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "");
  if (scoped) {
    delete snapshot.instanceBoundaries;
    isolateInstanceBoundaries(snapshot, availability.boundaries || []);
  }
  const ref = snapshot.variantReference;
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  if (contract.runtimePolicy.rootTargetAliasesVersion === 1 && availability.status !== "unknown" && root2 && ref) {
    const identity = record4(record4(root2.component).identity), expected = ref.nodeProperties[""]?.identity;
    const missingIdentity = (root2.unknownFacts || []).some((p) => p === "component" || p === "component.identity" || p.startsWith("component.identity."));
    if (expected && !missingIdentity && typeof identity.mainComponentId === "string" && identity.mainComponentId.length > 0 && identity.componentKey === expected.componentKey && identity.mainComponentId === expected.mainComponentId && (identity.componentSetKey || "") === (expected.componentSetKey || "")) {
      const roles = [...declaredRootAliasRoles(contract.facts.targets)].filter((role) => availability.targets[role]?.state === "present" && availability.targets[role].path === "");
      for (const node of snapshot.nodes) node.rootTargetAliasesV1 = Object.fromEntries(roles.map((role) => [role, node === root2]));
    }
  }
  const rootPath = record4(root2?.semantic).path;
  const byPath2 = /* @__PURE__ */ new Map();
  const structuralPaths = scoped ? snapshotPaths(snapshot) : void 0;
  const correspondence = snapshot.source?.instanceIdentityVersion === 1 && ref ? compareInstanceBoundaries(snapshot, ref) : void 0;
  for (const node of snapshot.nodes) {
    const path = structuralPaths?.get(String(node.id)) ?? (node === root2 ? "" : relativeTargetPath(String(record4(node.semantic).path || "")));
    if (node !== root2 && !record4(node.semantic).path?.startsWith(`${rootPath} / `)) continue;
    const referencePath = correspondingPath(correspondence, path);
    if (referencePath !== void 0) byPath2.set(referencePath, [...byPath2.get(referencePath) || [], node]);
  }
  const targetFacts = {};
  const properties = {};
  const propertyAvailable = (name, data) => {
    const resolved = resolveComponentProperty(name, data);
    if (!("name" in resolved)) return void 0;
    name = resolved.name;
    const type = data.propertyTypes[name];
    if (type === "VARIANT") return true;
    if (["BOOLEAN", "TEXT", "INSTANCE_SWAP"].includes(String(type))) return data.propertyReferences.includes(name);
    if (!Object.prototype.hasOwnProperty.call(data.properties, name) && data.definedProperties?.includes(name)) return false;
    return void 0;
  };
  for (const [role, target] of Object.entries(availability.targets)) {
    if (target.state === "unknown" || target.path === void 0) continue;
    const actual = byPath2.get(target.path) || [];
    if (actual.length === 1) {
      record4(actual[0].semantic).role = role;
      targetFacts[role] = { present: true, referenceState: target.state };
    } else if (actual.length === 0 && target.state === "absent") targetFacts[role] = { present: false, referenceState: "absent" };
  }
  if (availability.status !== "unknown" && ref) {
    const reps = contract.facts.representations.filter((r) => r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
    for (const property of contract.facts.semanticApi) {
      const surfaceBindings = property.bindings.filter((b) => b.representationId === reps[0]?.id && b.path === "representation.surface" && b.transform === "identity");
      if (reps.length === 1 && surfaceBindings.length === 1 && record4(record4(root2?.semanticBindingEvidence)[property.id]).reason === "resolved") {
        properties[property.id] = true;
      }
      const bindings = property.bindings.filter((b) => b.representationId === reps[0]?.id && b.path.startsWith("component.properties."));
      if (bindings.length !== 1) continue;
      const name = bindings[0].path.slice("component.properties.".length);
      const supported = propertyAvailable(name, ref);
      if (supported !== void 0) properties[property.id] = supported;
    }
  }
  for (const node of snapshot.nodes) {
    const componentProperties = {};
    const path = structuralPaths?.get(String(node.id)) ?? (node === root2 ? "" : relativeTargetPath(String(record4(node.semantic).path || "")));
    const isolated = availability.boundaries?.some((b) => withinBoundary(path, b.actualPath));
    const referencePath = correspondingPath(correspondence, path);
    const reference = availability.status !== "unknown" && !isolated && referencePath !== void 0 ? ref?.nodeProperties?.[referencePath] : void 0;
    if (reference) {
      const names = /* @__PURE__ */ new Set([...Object.keys(reference.properties), ...contract.capabilities.facts.filter((f) => f.startsWith("component.properties.")).map((f) => f.slice("component.properties.".length))]);
      for (const name of names) {
        const supported = propertyAvailable(name, reference);
        if (supported !== void 0) componentProperties[propertyAvailabilityKey(name)] = supported;
      }
    }
    node.variantAvailability = { ...availability, targets: targetFacts, properties, componentProperties, isRoot: node === root2 };
    const unknown12 = new Set((node.unknownFacts || []).filter((p) => !p.startsWith("variantAvailability.")));
    for (const target of contract.facts.targets) {
      if (targetFacts[target.semanticRole]?.present === void 0) unknown12.add(`variantAvailability.targets.${target.semanticRole}.present`);
    }
    for (const property of contract.facts.semanticApi) {
      if (properties[property.id] === void 0) unknown12.add(`variantAvailability.properties.${property.id}`);
    }
    for (const fact2 of contract.capabilities.facts.filter((f) => f.startsWith("variantAvailability.componentProperties."))) {
      if (componentProperties[fact2.slice("variantAvailability.componentProperties.".length)] === void 0) unknown12.add(fact2);
    }
    node.unknownFacts = [...unknown12];
  }
}
function materializeVerifiedVariantTargets(snapshot, contract) {
  if (contract.runtimePolicy.semanticTargetVisibilityVersion !== 1 || !["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "") || snapshot.instanceContentReferences?.schemaVersion !== "apollo.instance-content-references.v4") return;
  const ref = snapshot.variantReference, paths = snapshotPaths(snapshot);
  if (!ref || !paths) return;
  const comparison = compareInstanceBoundaries(snapshot, ref);
  if (!comparison.complete || !comparison.boundaries.some((b) => b.reason === "component-variant-changed")) return;
  const availability = variantAvailability(snapshot, contract);
  if (availability.status !== "partial") return;
  const reps = contract.facts.representations.filter((r) => r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
  if (reps.length !== 1) return;
  const candidates = [];
  for (const target of contract.facts.targets) {
    if (target.resolution !== "resolved") continue;
    const hints = target.representationHints?.filter((h) => h.representationId === reps[0].id) || [];
    if (hints.length > 1) continue;
    const variantHints = contract.runtimePolicy.assetIdentityLockVersion === 1 ? target.variantHints?.filter((h) => h.representationId === reps[0].id && h.componentKey === ref.componentKey) || [] : [];
    if (variantHints.length > 1) continue;
    const hint = variantHints[0]?.pathHint || hints[0]?.pathHint || target.pathHint;
    if (!hint) continue;
    const path = relativeTargetPath(hint);
    const boundaries = comparison.boundaries.filter((b) => b.referencePath === path && b.reason === "component-variant-changed");
    if (boundaries.length !== 1) continue;
    const boundary = boundaries[0];
    const results = snapshot.instanceContentResults?.filter((r) => r.boundaryNodeId === boundary.nodeId) || [];
    if (results.length !== 1 || !results[0].lineageProven || !(results[0].status === "matched" || contract.runtimePolicy.assetIdentityLockVersion === 1 && results[0].status === "partial") || !results[0].matchedNodeIds.includes(boundary.nodeId)) continue;
    const nodes = snapshot.nodes.filter((n) => n.id === boundary.nodeId && paths.get(String(n.id)) === boundary.actualPath);
    if (nodes.length !== 1 || nodes[0].type !== "INSTANCE") continue;
    const node = nodes[0], provenance = record4(node.baselineProvenance);
    if (provenance.status !== "matched" || provenance.kind !== "independent-host-variant" || provenance.boundaryNodeId !== boundary.nodeId || provenance.componentKey !== boundary.actualComponentKey) continue;
    candidates.push({ role: target.semanticRole, node });
  }
  for (const { role, node } of candidates) {
    if (contract.facts.targets.filter((t) => t.semanticRole === role).length !== 1 || candidates.filter((c) => c.node.id === node.id).length !== 1 || snapshot.nodes.some((n) => n !== node && record4(n.semantic).role === role)) continue;
    record4(node.semantic).role = role;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "semantic.role");
    for (const entry of snapshot.nodes) {
      const facts = record4(entry.variantAvailability);
      facts.targets = { ...record4(facts.targets), [role]: { present: true, referenceState: "present", evidence: "independent-host-variant-root" } };
      entry.variantAvailability = facts;
      entry.unknownFacts = (entry.unknownFacts || []).filter((p) => p !== `variantAvailability.targets.${role}.present`);
    }
  }
}

// src/declared-target-identity.ts
var DECLARED_TARGET_IDENTITY_SCHEMA = "apollo.declared-target-identities.v1";
var record5 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var text = (v) => typeof v === "string" && v.length > 0 && v === v.trim();
var closed = (v, required, optional = []) => {
  const r = record5(v);
  return v === r && required.every((k) => Object.prototype.hasOwnProperty.call(r, k)) && Object.keys(r).every((k) => required.includes(k) || optional.includes(k));
};
var unknown = (n, fact2) => (n.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + "."));
var types = /* @__PURE__ */ new Set(["INSTANCE", "COMPONENT", "FRAME", "GROUP", "TEXT", "RECTANGLE", "ELLIPSE", "VECTOR", "BOOLEAN_OPERATION", "LINE", "POLYGON", "STAR", "SLOT", "SECTION"]);
function portableDeclaredTargetReferenceHash(reference) {
  const portable = JSON.parse(JSON.stringify(reference));
  for (const value of Object.values(record5(portable.nodeProperties))) {
    const properties = record5(value);
    if (properties.identity) delete properties.identity.mainComponentId;
    if (properties.sourceIdentity) delete properties.sourceIdentity.ownerMainComponentId;
  }
  return stableHash(portable);
}
function configurationDeclaredTargetReferenceHash(reference) {
  const portable = JSON.parse(JSON.stringify(reference));
  for (const value of Object.values(record5(portable.nodeProperties))) {
    const properties = record5(value);
    if (properties.identity) delete properties.identity.mainComponentId;
    if (properties.sourceIdentity) delete properties.sourceIdentity.ownerMainComponentId;
  }
  const root2 = record5(record5(portable.nodeProperties)[""]);
  const configurationProperties = [];
  for (const name of Array.isArray(root2.definedProperties) ? root2.definedProperties : []) {
    const type = record5(root2.propertyTypes)[name], value = record5(root2.properties)[name];
    if (record5(portable.propertyTypes)[name] !== type || record5(portable.properties)[name] !== value || !(type === "TEXT" && typeof value === "string" || type === "BOOLEAN" && typeof value === "boolean")) continue;
    delete root2.properties[name];
    delete portable.properties[name];
    configurationProperties.push({ name, type });
  }
  return stableHash({ schemaVersion: "apollo.declared-target-configuration-reference.v1", configurationProperties, reference: portable });
}
function publicSwapDeclaredTargetReferenceHash(reference, shape) {
  return stableHash({
    schemaVersion: "apollo.declared-target-configuration-reference.v2",
    referenceHash: configurationDeclaredTargetReferenceHash(projectPublicSwapReference(reference, shape))
  });
}
function contractConfigurationHash(reference, contract) {
  if (contract.runtimePolicy.declaredTargetConfigurationVersion === 2) return publicSwapDeclaredTargetReferenceHash(reference, { targets: contract.facts.targets, policies: contract.customizationPolicy, representations: contract.facts.representations });
  if (contract.runtimePolicy.declaredTargetConfigurationVersion === 1) return configurationDeclaredTargetReferenceHash(reference);
}
function configuredReferencePath(reference, binding, contract) {
  if (contract.runtimePolicy.declaredTargetConfigurationVersion === 2) {
    const slots = publicSwapSlots(reference, { targets: contract.facts.targets, policies: contract.customizationPolicy, representations: contract.facts.representations });
    const slot = slots.find((s) => s.bindingPath === binding.referencePath);
    if (slot) return slot.referencePath;
  }
  return binding.referencePath;
}
function declaredTargetIdentityErrors(shape) {
  const bindings = shape.targets.flatMap((t) => t.identityBindingsV1 === void 0 ? [] : [t.identityBindingsV1]);
  if (shape.version === void 0 && shape.configurationVersion === void 0 && !bindings.length) return [];
  const errors = [];
  if (shape.configurationVersion !== void 0 && (shape.configurationVersion !== 1 && shape.configurationVersion !== 2 || shape.version !== 3)) errors.push("declared target configuration requires version 1 or 2 and identity policy v3");
  if (typeof shape.version !== "number" || ![1, 2, 3].includes(shape.version)) errors.push("declared target bindings require explicit supported policy version 1, 2 or 3");
  if (!bindings.length) errors.push("declared target policy requires explicit bindings");
  const ids = /* @__PURE__ */ new Set(), roles = /* @__PURE__ */ new Set();
  for (const target of shape.targets) {
    if (!text(target.id) || !text(target.semanticRole) || ids.has(target.id) || roles.has(target.semanticRole)) errors.push("declared target IDs and roles must be unique");
    ids.add(target.id);
    roles.add(target.semanticRole);
    if (target.identityBindingsV1 === void 0) continue;
    if (!Array.isArray(target.identityBindingsV1) || !target.identityBindingsV1.length) {
      errors.push("target bindings must be a nonempty array");
      continue;
    }
    const keys = /* @__PURE__ */ new Set();
    for (const b of target.identityBindingsV1) {
      if (!closed(b, ["representationId", "componentKey", "componentSetKey", "referenceHash", "referencePath", "nodeType"], [1, 2].includes(Number(shape.configurationVersion)) ? ["nativeSource", "portableReferenceHash", "configurationReferenceHash"] : shape.version === 2 || shape.version === 3 ? ["nativeSource", "portableReferenceHash"] : ["nativeSource"]) || !text(b.representationId) || !text(b.componentKey) || typeof b.componentSetKey !== "string" || !/^[a-f0-9]{64}$/.test(b.referenceHash) || b.portableReferenceHash !== void 0 && !/^[a-f0-9]{64}$/.test(b.portableReferenceHash) || typeof b.referencePath !== "string" || b.referencePath !== b.referencePath.trim() || !types.has(b.nodeType) || b.referencePath.split(" / ").some((p) => /^@(local|catalog):/.test(p)) || !shape.representations.some((r) => r.kind === "figma" && r.id === b.representationId && r.status !== "deprecated")) {
        errors.push("malformed typed declared target binding");
        continue;
      }
      if ([1, 2].includes(Number(shape.configurationVersion)) && (!/^[a-f0-9]{64}$/.test(b.configurationReferenceHash || "") || !b.portableReferenceHash)) errors.push("configuration binding requires exact portable and configuration SHA256 pins");
      const key = JSON.stringify([b.representationId, b.componentKey, b.componentSetKey]);
      if (keys.has(key)) errors.push("duplicate selected-variant target binding");
      keys.add(key);
      if (b.referencePath === "") {
        if (!isDeclaredRootTarget(target) || !["INSTANCE", "COMPONENT"].includes(b.nodeType) || b.nativeSource !== void 0) errors.push("root binding requires an explicit root target and native root type");
      } else if (!closed(b.nativeSource, ["sourceNodeId", "ownerComponentKey", "ownerMainComponentId"]) || !Object.values(b.nativeSource).every(text)) errors.push("descendant binding requires exact native source identity");
    }
  }
  return errors;
}
function assertDeclaredTargetContract(contract) {
  const errors = declaredTargetIdentityErrors({
    version: contract.runtimePolicy.declaredTargetIdentityVersion,
    configurationVersion: contract.runtimePolicy.declaredTargetConfigurationVersion,
    targets: contract.facts.targets,
    representations: contract.facts.representations
  });
  if (contract.runtimePolicy.declaredTargetIdentityVersion !== void 0 && !contract.facts.variantEvidence) errors.push("independent variant anatomy is required");
  if ([1, 2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0)) {
    for (const target of contract.facts.targets) if (!contract.capabilities.facts.includes(`declaredTargetMembershipV1.${declaredTargetMembershipKey(target.id)}`)) errors.push("declared membership capability missing");
    const exporter = contract.runtimePolicy.declaredTargetConfigurationVersion === 2 ? "component-contract-editor@0.2.103" : contract.runtimePolicy.declaredTargetConfigurationVersion === 1 ? "component-contract-editor@0.2.99" : contract.runtimePolicy.declaredTargetIdentityVersion === 3 ? "component-contract-editor@0.2.95" : contract.runtimePolicy.textContentFactsVersion === 1 || contract.runtimePolicy.nativeTargetPropertyFactsVersion === 1 ? "component-contract-editor@0.2.94" : contract.runtimePolicy.declaredTargetIdentityVersion === 2 ? "component-contract-editor@0.2.93" : "component-contract-editor@0.2.92";
    if (contract.package.sourceExportVersion !== exporter) errors.push("declared target exporter compatibility stamp missing");
    if (contract.rules.some((rule) => {
      const inspect = (value) => Array.isArray(value) ? value.some(inspect) : value && typeof value === "object" ? value.actual?.fact === "semantic.role" && value.expected?.literal !== void 0 || Object.values(value).some(inspect) : false;
      return inspect(rule);
    })) errors.push("unbound diagnostic role selector in declared target IR");
  }
  if (contract.runtimePolicy.declaredTargetIdentityVersion === void 0 && contract.capabilities.facts.some((f) => f.startsWith("declaredTargetMembershipV1."))) errors.push("membership capability requires its policy");
  if (errors.length) throw Object.assign(new Error("DECLARED_TARGET_IDENTITY_UNSUPPORTED: " + errors.join("; ")), { code: "DECLARED_TARGET_IDENTITY_UNSUPPORTED" });
}
function rootedTopology(snapshot) {
  if (snapshot.selection.length !== 1 || snapshot.source?.truncated !== false || snapshot.source.captureTopology?.complete !== true) return;
  const byId = /* @__PURE__ */ new Map();
  for (const n of snapshot.nodes) {
    if (!text(n.id) || byId.has(String(n.id)) || typeof n.type !== "string" || !types.has(n.type) || unknown(n, "type") || !Array.isArray(n.childIds) || new Set(n.childIds).size !== n.childIds.length) return;
    byId.set(String(n.id), n);
  }
  const root2 = byId.get(snapshot.selection[0]);
  if (!root2 || root2.parentId !== null) return;
  for (const n of byId.values()) {
    if (unknown(n, "parentId") || unknown(n, "childIds")) return;
    if (n !== root2 && (!byId.has(String(n.parentId)) || !byId.get(String(n.parentId)).childIds.includes(n.id))) return;
    if (n.childIds.some((id) => !byId.has(id) || byId.get(id).parentId !== n.id)) return;
    const visited = /* @__PURE__ */ new Set();
    let current = n;
    while (current !== root2) {
      if (!current || visited.has(String(current.id))) return;
      visited.add(String(current.id));
      current = byId.get(String(current.parentId));
    }
  }
  return { root: root2, byId };
}
function effectiveVisibility(node, topology) {
  let n = node, hidden = false, uncertain2 = false;
  while (n) {
    if (unknown(n, "visible") || typeof n.visible !== "boolean") uncertain2 = true;
    else if (n.visible === false) hidden = true;
    if (n === topology.root) return hidden ? false : uncertain2 ? void 0 : true;
    n = topology.byId.get(String(n.parentId));
  }
  return;
}
function sourceMatches(node, path, binding, snapshot, topology, portable) {
  const source = record5(record5(node.component).sourceIdentity), expected = binding.nativeSource;
  const reference = snapshot.variantReference;
  if (!expected || source.version !== 1 || snapshot.source?.instanceSourceIdentityVersion !== 1 || snapshot.source.occurrenceAddressVersion !== 1 || reference.occurrenceAddressVersion !== 1 || Object.entries(expected).some(([key, value]) => (!portable || key !== "ownerMainComponentId") && source[key] !== value || unknown(node, `component.sourceIdentity.${key}`)) || unknown(node, "component.sourceIdentity.version")) return false;
  const independentlyCaptured = reference.nodeProperties[path]?.sourceIdentity;
  if (!independentlyCaptured || independentlyCaptured.version !== 1 || Object.entries(expected).some(([key, value]) => (!portable || key !== "ownerMainComponentId") && independentlyCaptured[key] !== value)) return false;
  let owner = topology.byId.get(String(node.parentId));
  while (owner && owner !== topology.root && owner.type !== "INSTANCE" && owner.type !== "COMPONENT") {
    if (owner.type === "SLOT") return false;
    owner = topology.byId.get(String(owner.parentId));
  }
  const identity = record5(record5(owner?.component).identity);
  if (!owner || unknown(owner, "component.identity") || unknown(owner, "component.identity.componentKey") || unknown(owner, "component.identity.mainComponentId") || identity.componentKey !== expected.ownerComponentKey || !text(identity.mainComponentId) || identity.mainComponentId !== source.ownerMainComponentId || !portable && identity.mainComponentId !== expected.ownerMainComponentId) return false;
  let parent3 = path.split(" / ").slice(0, -1).join(" / ");
  while (parent3 && reference.nodes.find((n) => n.path === parent3)?.type !== "INSTANCE") parent3 = parent3.split(" / ").slice(0, -1).join(" / ");
  const refOwner = reference.nodeProperties[parent3]?.identity;
  if (refOwner?.componentKey !== expected.ownerComponentKey || refOwner.mainComponentId !== independentlyCaptured.ownerMainComponentId || refOwner.mainComponentId !== identity.mainComponentId || !portable && refOwner.mainComponentId !== expected.ownerMainComponentId) return false;
  if (owner === topology.root) return parent3 === "";
  const ownerSource = reference.nodeProperties[parent3]?.sourceIdentity;
  if (!ownerSource || ownerSource.version !== 1 || !text(ownerSource.sourceNodeId) || !text(ownerSource.ownerComponentKey) || !text(ownerSource.ownerMainComponentId)) return false;
  return sourceMatches(owner, parent3, { ...binding, nativeSource: {
    sourceNodeId: ownerSource.sourceNodeId,
    ownerComponentKey: ownerSource.ownerComponentKey,
    ownerMainComponentId: ownerSource.ownerMainComponentId
  } }, snapshot, topology, portable);
}
function materializeNativeTargetProperties(snapshot, contract) {
  if (contract.runtimePolicy.nativeTargetPropertyFactsVersion !== 1) return;
  for (const node of snapshot.nodes) delete node.nativeTargetPropertiesV1;
  const topology = rootedTopology(snapshot), ref = snapshot.variantReference, paths = snapshotPaths(snapshot);
  if (!topology || !paths || !ref?.complete) return;
  const root2 = topology.root, identity = record5(record5(root2.component).identity);
  const reps = contract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
  if (reps.length !== 1 || unknown(root2, "component.identity") || identity.componentKey !== ref.componentKey || identity.componentSetKey !== ref.componentSetKey || identity.mainComponentId !== ref.nodeProperties?.[""]?.identity?.mainComponentId || snapshot.source?.componentKey !== ref.componentKey || snapshot.source?.componentSetKey !== ref.componentSetKey) return;
  const comparison = compareInstanceBoundaries(snapshot, ref), facts = {}, proven = /* @__PURE__ */ new Map();
  if (!comparison.complete) return;
  for (const target of contract.facts.targets) {
    if (target.resolution !== "resolved") continue;
    const bindings = target.identityBindingsV1?.filter((b2) => b2.representationId === reps[0].id && b2.componentKey === ref.componentKey && b2.componentSetKey === ref.componentSetKey) || [];
    if (bindings.length !== 1) continue;
    const b = bindings[0], portable = [2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0) && b.portableReferenceHash !== void 0;
    const configurationHash = contractConfigurationHash(ref, contract), referencePath = configuredReferencePath(ref, b, contract);
    if (configurationHash ? b.configurationReferenceHash !== configurationHash : portable ? b.portableReferenceHash !== portableDeclaredTargetReferenceHash(ref) : b.referenceHash !== stableHash(ref)) continue;
    const candidates = snapshot.nodes.filter((n) => referencePath === "" ? n === root2 : sourceMatches(n, referencePath, b, snapshot, topology, portable));
    if (candidates.length !== 1 || candidates[0].type !== b.nodeType) continue;
    const node = candidates[0], path = paths.get(String(node.id));
    if (path === void 0 || comparison.referencePaths?.[path] !== referencePath) continue;
    const key = declaredTargetMembershipKey(target.id), component = record5(node.component), props = {};
    const original = ref.nodeProperties[referencePath];
    for (const [name, value] of Object.entries(record5(component.properties))) {
      const type = record5(component.propertyTypes)[name];
      if (original?.propertyTypes[name] === type && !unknown(node, `component.properties.${name}`) && !unknown(node, `component.propertyTypes.${name}`) && (type === "VARIANT" && typeof value === "string" || type === "BOOLEAN" && typeof value === "boolean")) props[name] = value;
    }
    facts[key] = { properties: props };
    if (!unknown(node, "component.identity.componentSetKey")) facts[key].componentSetKey = record5(component.identity).componentSetKey;
    proven.set(key, path);
  }
  for (const fact2 of contract.capabilities.facts.filter((f) => f.startsWith("nativeTargetPropertiesV1.swapCountExcept_"))) {
    const key = fact2.slice("nativeTargetPropertiesV1.swapCountExcept_".length), except = proven.get(key);
    if (except === void 0) continue;
    let count = 0, complete = true;
    const seen = /* @__PURE__ */ new Set();
    const visit = (reference) => {
      const cmp = compareInstanceBoundaries(snapshot, reference);
      if (!cmp.complete) {
        complete = false;
        return;
      }
      for (const boundary of cmp.boundaries) {
        if (withinBoundary(boundary.actualPath, except) || seen.has(boundary.nodeId)) continue;
        seen.add(boundary.nodeId);
        if (boundary.reason === "component-variant-changed") {
          const result = snapshot.instanceContentResults?.find((r) => r.boundaryNodeId === boundary.nodeId);
          const attempts = snapshot.instanceContentReferences?.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId) || [];
          if (!result?.lineageProven || attempts.length !== 1 || attempts[0].failure || !attempts[0].reference) {
            complete = false;
            continue;
          }
          const host = attempts[0].reference;
          visit(captureVariantReference(host, host.source?.componentKey || "", host.source?.componentSetKey || ""));
        } else if (boundary.reason === "instance-identity-unavailable") complete = false;
        else count++;
      }
    };
    visit(ref);
    if (complete || count > 0) facts["swapCountExcept_" + key] = count;
  }
  root2.nativeTargetPropertiesV1 = facts;
}
function materializeDeclaredTargetIdentities(snapshot, contract) {
  if (![1, 2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0)) return;
  const topology = rootedTopology(snapshot), ref = snapshot.variantReference;
  const ledger = { schemaVersion: DECLARED_TARGET_IDENTITY_SCHEMA, manualSourceHash: contract.package.manualSourceHash, targets: [] };
  const reps = ref ? contract.facts.representations.filter((r) => r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey)) : [];
  const identity = record5(record5(topology?.root.component).identity);
  const identityKnown = !!(topology && ref?.complete && !unknown(topology.root, "component.identity") && snapshot.source?.componentKey === ref.componentKey && (snapshot.source.componentSetKey || "") === ref.componentSetKey && identity.componentKey === ref.componentKey && (identity.componentSetKey || "") === ref.componentSetKey && identity.mainComponentId === ref.nodeProperties?.[""]?.identity?.mainComponentId && reps.length === 1);
  const paths = topology && snapshotPaths(snapshot), comparison = identityKnown ? compareInstanceBoundaries(snapshot, ref) : void 0;
  const availability = identityKnown ? variantAvailability(snapshot, contract) : void 0;
  const refHash = ref ? stableHash(ref) : void 0;
  ledger.referenceHash = refHash;
  const portableHash = ref && [2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0) ? portableDeclaredTargetReferenceHash(ref) : void 0;
  if (portableHash) ledger.portableReferenceHash = portableHash;
  const configurationHash = ref ? contractConfigurationHash(ref, contract) : void 0;
  if (configurationHash) ledger.configurationReferenceHash = configurationHash;
  for (const target of contract.facts.targets) {
    const fact2 = { targetId: target.id, semanticRole: target.semanticRole, status: "unknown", reason: "source-or-reference-incomplete" };
    ledger.targets.push(fact2);
    if (!identityKnown || !paths) continue;
    if (target.resolution !== "resolved") {
      fact2.reason = "authoring-target-unresolved";
      continue;
    }
    const bindings = target.identityBindingsV1?.filter((b2) => b2.representationId === reps[0].id && b2.componentKey === ref.componentKey && b2.componentSetKey === ref.componentSetKey) || [];
    if (bindings.length !== 1) {
      fact2.status = bindings.length > 1 ? "ambiguous" : "unknown";
      fact2.reason = "selected-binding-unavailable";
      continue;
    }
    const b = bindings[0], referencePath = configuredReferencePath(ref, bindings[0], contract);
    const portable = [2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0) && b.portableReferenceHash !== void 0;
    if (configurationHash ? b.configurationReferenceHash !== configurationHash : portable ? b.portableReferenceHash !== portableHash : b.referenceHash !== refHash) {
      fact2.reason = "reference-pin-stale";
      continue;
    }
    const referenceNodes = ref.nodes.filter((n) => n.path === referencePath && n.type === (referencePath === "" ? "ROOT" : b.nodeType));
    if (referenceNodes.length !== 1 || contract.runtimePolicy.declaredTargetIdentityVersion !== 3 && comparison?.boundaries.some((boundary) => withinBoundary(referencePath, boundary.referencePath))) {
      fact2.reason = "independent-correspondence-unavailable";
      continue;
    }
    const candidates = snapshot.nodes.filter((n) => referencePath === "" ? n === topology.root && n.type === b.nodeType : sourceMatches(n, referencePath, b, snapshot, topology, portable));
    if (candidates.length !== 1) {
      fact2.status = candidates.length > 1 ? "ambiguous" : "unknown";
      fact2.reason = "native-cardinality-unresolved";
      continue;
    }
    if (!comparison?.complete || availability?.status === "unknown") {
      fact2.reason = "independent-correspondence-unavailable";
      continue;
    }
    const node = candidates[0], actualPath = paths.get(String(node.id));
    const boundaries = comparison.boundaries.filter((boundary) => withinBoundary(referencePath, boundary.referencePath) || actualPath !== void 0 && withinBoundary(actualPath, boundary.actualPath));
    const configured = contract.runtimePolicy.declaredTargetIdentityVersion === 3 && boundaries.length === 1 && verifiedConfiguredTarget(snapshot, node, referencePath, actualPath, boundaries[0]);
    if (boundaries.length && !configured) {
      fact2.reason = "independent-correspondence-unavailable";
      continue;
    }
    if (node.type !== b.nodeType || actualPath === void 0 || comparison.referencePaths?.[actualPath] !== referencePath) {
      fact2.reason = "typed-correspondence-unavailable";
      continue;
    }
    Object.assign(fact2, { status: "resolved", reason: "exact-independent-native-identity", nodeId: String(node.id), nodeType: node.type, present: true, referencePath });
    const visible = effectiveVisibility(node, topology);
    if (visible !== void 0) fact2.effectiveVisible = visible;
  }
  for (const fact2 of ledger.targets) if (fact2.nodeId) {
    const claims = ledger.targets.filter((t) => t.nodeId === fact2.nodeId);
    const rootAliases = claims.every((t) => isDeclaredRootTarget(contract.facts.targets.find((x) => x.id === t.targetId))) && contract.runtimePolicy.rootTargetAliasesVersion === 1 && fact2.nodeId === topology?.root.id;
    if (claims.length > 1 && !rootAliases) {
      fact2.status = "ambiguous";
      fact2.reason = "declared-target-collision";
      delete fact2.present;
      delete fact2.effectiveVisible;
    }
  }
  snapshot.declaredTargetIdentitiesV1 = ledger;
  for (const node of snapshot.nodes) {
    const capturedRole = record5(node.semantic).role;
    node.targetDiagnosticsV1 = { capturedRole: Object.prototype.hasOwnProperty.call(record5(node.targetDiagnosticsV1), "capturedRole") ? record5(node.targetDiagnosticsV1).capturedRole : capturedRole };
    node.semantic = Object.assign({}, record5(node.semantic), { role: "" });
    const membership = {}, relations = {}, targets = {}, availabilityFacts = {};
    const missing = new Set((node.unknownFacts || []).filter((p) => !p.startsWith("declaredTargetMembershipV1.") && !p.startsWith("semanticTargets.") && !p.startsWith("variantAvailability.targets.") && p !== "visibility.effective" && p !== "semantic.role"));
    for (const fact2 of ledger.targets) {
      const key = declaredTargetMembershipKey(fact2.targetId);
      if (fact2.status === "resolved") {
        membership[key] = fact2.nodeId === node.id;
        targets[fact2.semanticRole] = { resolved: true, present: true };
        availabilityFacts[fact2.semanticRole] = { present: true };
        relations[fact2.semanticRole] = fact2.nodeId;
        if (fact2.effectiveVisible !== void 0) targets[fact2.semanticRole].visibilityKnown = true;
        else missing.add(`semanticTargets.${fact2.semanticRole}.visibilityKnown`);
        if (fact2.nodeId === node.id && !record5(node.semantic).role) record5(node.semantic).role = fact2.semanticRole;
      } else {
        missing.add(`declaredTargetMembershipV1.${key}`);
        missing.add(`semanticTargets.${fact2.semanticRole}`);
        missing.add(`variantAvailability.targets.${fact2.semanticRole}.present`);
      }
    }
    const visible = topology ? effectiveVisibility(node, topology) : void 0;
    node.visibility = visible === void 0 ? {} : { effective: visible };
    if (visible === void 0) missing.add("visibility.effective");
    node.declaredTargetMembershipV1 = membership;
    node.relations = relations;
    node.semanticTargets = targets;
    node.variantAvailability = Object.assign({}, record5(node.variantAvailability), { targets: availabilityFacts });
    node.unknownFacts = [...missing];
  }
}
function verifiedConfiguredTarget(snapshot, node, referencePath, actualPath, boundary) {
  if (snapshot.instanceContentReferences?.schemaVersion !== "apollo.instance-content-references.v4" || boundary.reason !== "component-variant-changed" || boundary.nodeId !== node.id || boundary.referencePath !== referencePath || boundary.actualPath !== actualPath || node.type !== "INSTANCE") return false;
  const results = snapshot.instanceContentResults?.filter((r) => r.boundaryNodeId === node.id) || [];
  const identity = record5(record5(node.component).identity), provenance = record5(node.baselineProvenance);
  return results.length === 1 && results[0].lineageProven === true && results[0].matchedNodeIds.includes(String(node.id)) && ["matched", "partial"].includes(results[0].status) && provenance.status === "matched" && provenance.kind === "independent-host-variant" && provenance.boundaryNodeId === node.id && provenance.componentKey === boundary.actualComponentKey && provenance.componentSetKey === boundary.componentSetKey && !unknown(node, "component.identity") && !unknown(node, "component.identity.componentKey") && !unknown(node, "component.identity.componentSetKey") && identity.componentKey === boundary.actualComponentKey && identity.componentSetKey === boundary.componentSetKey;
}

// src/configured-native-property.ts
var CONFIGURED_NATIVE_PROPERTY_POLICY = "configured-native@1";
var record6 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
var owns = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
var nameFor = (fact2) => typeof fact2 === "string" && /^component\.properties\.[^.]+$/.test(fact2) ? fact2.slice("component.properties.".length) : void 0;
var uncertain = (node, fact2) => {
  const paths = node.unknownFacts === void 0 ? [] : node.unknownFacts;
  return !Array.isArray(paths) || paths.some((p) => typeof p !== "string" || p === fact2 || fact2.startsWith(p + ".") || p.startsWith(fact2 + "."));
};
function materializeConfiguredNativeProperties(source, prepared, contract) {
  for (const node of prepared.nodes) {
    delete node.configuredNativePropertiesV1;
    if (contract.runtimePolicy.configuredNativePropertyConformanceVersion === 1 && Array.isArray(node.unknownFacts))
      node.unknownFacts = node.unknownFacts.filter((p) => typeof p !== "string" || !p.startsWith("configuredNativePropertiesV1"));
  }
  if (contract.runtimePolicy.configuredNativePropertyConformanceVersion !== 1) return;
  if (source.selection.length !== 1 || new Set(source.nodes.map((n) => n.id)).size !== source.nodes.length) return;
  const roots = source.nodes.filter((n) => n.id === source.selection[0]);
  if (roots.length !== 1) return;
  const root2 = roots[0], output = prepared.nodes.find((n) => n.id === root2.id), ref = source.variantReference;
  const identity = record6(record6(root2.component).identity), expected = ref?.nodeProperties?.[""]?.identity;
  if (!output || root2.type !== "INSTANCE" || root2.visible !== true || source.source?.truncated !== false || source.source.instanceIdentityVersion !== 1 || source.source.captureTopology?.complete !== true || !ref?.complete || !expected || typeof identity.mainComponentId !== "string" || !identity.mainComponentId || expected.componentKey !== ref.componentKey || (expected.componentSetKey || "") !== ref.componentSetKey || identity.componentKey !== expected.componentKey || identity.mainComponentId !== expected.mainComponentId || (identity.componentSetKey || "") !== (expected.componentSetKey || "") || uncertain(root2, "component.identity") || uncertain(root2, "visible")) return;
  const availability = variantAvailability(source, contract);
  if (availability.status === "unknown") return;
  const targetIds = contract.customizationPolicy.filter((p) => p.propertyConformance === CONFIGURED_NATIVE_PROPERTY_POLICY).map((p) => p.targetId);
  if (!targetIds.length || targetIds.some((id) => {
    const targets = contract.facts.targets.filter((t) => t.id === id), target = targets[0];
    const proof = target && availability.targets[target.semanticRole];
    return targets.length !== 1 || target.resolution !== "resolved" || !isDeclaredRootTarget(target) || proof?.state !== "present" || proof.path !== "";
  })) return;
  const booleanValues = {}, variantValues = {};
  const component = record6(root2.component), reference = ref.nodeProperties[""];
  const referenceProperties = record6(reference.properties), referenceTypes = record6(reference.propertyTypes);
  for (const [name, value] of Object.entries(record6(component.properties))) {
    const fact2 = "component.properties." + name, type = record6(component.propertyTypes)[name];
    if (!nameFor(fact2) || uncertain(root2, fact2) || uncertain(root2, "component.propertyTypes." + name) || !owns(referenceProperties, name) || referenceTypes[name] !== type) continue;
    const expectedValue = referenceProperties[name];
    if (type === "BOOLEAN" && typeof value === "boolean" && typeof expectedValue === "boolean")
      booleanValues[propertyAvailabilityKey(name)] = value;
    if (type === "VARIANT" && typeof value === "string" && value.trim() && typeof expectedValue === "string" && expectedValue.trim())
      variantValues[propertyAvailabilityKey(name)] = value;
  }
  output.configuredNativePropertiesV1 = { booleanValues, variantValues };
}
function assertConfiguredPropertyContract(contract) {
  const version = contract.runtimePolicy.configuredNativePropertyConformanceVersion;
  const markers = contract.rules.map((r) => r.presentation?.propertyConformance).filter((v) => v !== void 0);
  if (version !== void 0 && version !== 1 || markers.some((m) => m !== CONFIGURED_NATIVE_PROPERTY_POLICY) || markers.length && version !== 1) throw new Error("CONFIGURED_NATIVE_PROPERTY_RUNTIME_UNSUPPORTED");
}
function configuredCaptureUnknowns(result, contract) {
  if (contract.runtimePolicy.configuredNativePropertyConformanceVersion !== 1) return;
  const rules = new Set(contract.rules.filter((r) => r.presentation?.propertyConformance === CONFIGURED_NATIVE_PROPERTY_POLICY).map((r) => r.ruleId));
  for (const evaluation of result.evaluations) {
    if (rules.has(evaluation.ruleId) && evaluation.trace?.reason === "selector matched no visible nodes") {
      evaluation.classification = "human-review";
      evaluation.applicability = "unknown";
      evaluation.trace = { ...evaluation.trace, reason: "configured native root visibility/capture is unresolved", truth: "unknown" };
    }
  }
  const missing = [...rules].filter((id) => !result.evaluations.some((e) => e.ruleId === id));
  if (missing.length) result.configuredNativePropertyDiagnostics = missing.map((ruleId) => ({ ruleId, truth: "unknown", reason: "configured native root capture is absent" }));
  const byClassification = {};
  for (const e of result.evaluations) byClassification[e.classification] = (byClassification[e.classification] || 0) + 1;
  result.coverage = { ...result.coverage, byClassification };
}

// src/representation-evidence.ts
var hash = /^[a-f0-9]{64}$/;
var record7 = (v) => Boolean(v) && typeof v === "object" && !Array.isArray(v);
var closed2 = (v, keys) => record7(v) && Object.keys(v).every((k) => keys.includes(k)) && keys.every((k) => Object.prototype.hasOwnProperty.call(v, k));
var text2 = (v) => typeof v === "string" && Boolean(v.trim());
var strings = (v) => Array.isArray(v) && v.every(text2) && new Set(v).size === v.length;
var safeEvidencePath = (v) => text2(v) && !v.startsWith("/") && !v.includes("\\") && !v.split("/").some((p) => !p || p === "." || p === "..") && !/[:\x00-\x1f]/.test(v);
var refs = (v) => Array.isArray(v) && v.length <= 64 && v.every((r) => closed2(r, ["path", "sha256"]) && safeEvidencePath(r.path) && hash.test(r.sha256)) && new Set(v.map((r) => r.path)).size === v.length;
function contractRepresentationShape(c) {
  return { representations: c.facts.representations, semanticApi: c.facts.semanticApi, targets: c.facts.targets, dependencies: c.componentDependencies || [], profiles: c.facts.generation.profiles, slots: c.customizationPolicy.filter((r) => r.status !== "deprecated" && r.permission !== "forbidden").flatMap((r) => r.controlPaths) };
}
function representationEvidenceErrors(s) {
  const errors = [];
  const add = (path, message) => errors.push(path + ": " + message);
  for (const [i, r] of s.representations.entries()) if (r.codeEvidence !== void 0) {
    const p = "representations/" + i + "/codeEvidence", e = r.codeEvidence;
    if (r.kind !== "code" || !closed2(e, ["version", "sourcePin", "availability", "parity", "acceptance", "publication"]) || e.version !== 1) {
      add(p, "unsupported evidence version/shape or representation kind");
      continue;
    }
    if (!record7(e.sourcePin) || !record7(e.availability) || !record7(e.parity) || !record7(e.acceptance) || !record7(e.publication)) {
      add(p, "invalid evidence sections");
      continue;
    }
    const pin = e.sourcePin;
    if (!closed2(pin, ["packageName", "packageVersion", "commit", "registryDigest", "mappingId"]) || !text2(pin.packageName) || !text2(pin.packageVersion) || !/^[a-f0-9]{40}$/.test(pin.commit) || !hash.test(pin.registryDigest) || !text2(pin.mappingId)) add(p, "exact code source pin required");
    if (pin.packageName !== r.locator.packageName || pin.packageVersion !== r.locator.packageVersion || pin.commit !== r.locator.sourceCommit || pin.registryDigest !== r.locator.registryDigest || pin.mappingId !== r.locator.mappingId) add(p, "source pin differs from representation locator");
    if (!closed2(e.availability, ["status", "evidenceRefs"]) || !["confirmed-source-api", "unresolved"].includes(e.availability.status) || !refs(e.availability.evidenceRefs) || e.availability.status === "confirmed-source-api" && !e.availability.evidenceRefs.length) add(p, "availability requires exact evidence refs");
    if (!closed2(e.parity, ["status", "profileIds", "unresolvedGapIds"]) || !["not-confirmed", "accepted-for-profile"].includes(e.parity.status) || !strings(e.parity.profileIds) || !strings(e.parity.unresolvedGapIds)) add(p, "invalid parity claim");
    else if (e.parity.status === "accepted-for-profile" && (!e.parity.profileIds.length || e.parity.unresolvedGapIds.length || e.parity.profileIds.some((id) => s.profiles.filter((p2) => p2.id === id && p2.representationId === r.id && p2.platform === r.platform).length !== 1))) add(p, "accepted parity requires declared profiles and no unresolved gaps");
    if (!closed2(e.acceptance, ["status", "receiptRefs"]) || !["not-run", "accepted"].includes(e.acceptance.status) || !refs(e.acceptance.receiptRefs) || e.acceptance.status === "accepted" && (!e.acceptance.receiptRefs.length || e.parity.status !== "accepted-for-profile")) add(p, "acceptance requires profile parity and receipt refs");
    if (!closed2(e.publication, ["status"]) || !["not-confirmed", "published"].includes(e.publication.status) || e.publication.status === "published" && e.acceptance.status !== "accepted") add(p, "publication requires accepted evidence");
  }
  const addresses = /* @__PURE__ */ new Set();
  for (const [i, api] of s.semanticApi.entries()) for (const [j, b] of api.bindings.entries()) {
    const p = "semanticApi/" + i + "/bindings/" + j, rep = s.representations.find((r) => r.id === b.representationId);
    if ([b.codeTransform, b.ownedOccurrence, b.nativeSlotBinding].every((v) => v === void 0)) continue;
    const address = [b.representationId, b.ownedOccurrence ? b.targetId : b.nativeSlotBinding ? "native-slot" : "root", b.path].join("|");
    if (addresses.has(address)) add(p, "duplicate typed code address");
    addresses.add(address);
    if (rep?.kind !== "code" || rep.codeEvidence?.version !== 1 || [b.codeTransform, b.ownedOccurrence, b.nativeSlotBinding].filter((v) => v !== void 0).length !== 1 || b.transform !== void 0) add(p, "exactly one typed code binding is required; free transform is not allowed");
    if (b.codeTransform !== void 0) {
      const t = b.codeTransform;
      if (!record7(t)) {
        add(p, "invalid code transform");
        continue;
      }
      if (t.version !== 1 || (t.id === "identity" ? !closed2(t, ["version", "id"]) : t.id !== "enum-map" || !closed2(t, ["version", "id", "entries"]) || !Array.isArray(t.entries) || !t.entries.length || !api.domain?.length || t.entries.length !== api.domain.length || t.entries.some((e) => !closed2(e, ["from", "to"]) || !api.domain?.some((v) => stableHash(v) === stableHash(e.from)) || !["string", "number", "boolean"].includes(typeof e.to) || typeof e.to === "number" && !Number.isFinite(e.to)) || new Set(t.entries?.map((e) => stableHash(e.from))).size !== t.entries?.length)) add(p, "unknown transform or incomplete enum map");
      if (!["boolean", "string", "number", "enum"].includes(api.valueType) || !/^props\.[A-Za-z][A-Za-z0-9]*$/.test(b.path) || ["props.key", "props.ref", "props.children", "props.elements"].includes(b.path) || b.targetId !== void 0) add(p, "scalar transform requires an explicit public scalar prop");
    }
    if (b.ownedOccurrence !== void 0) {
      const o = b.ownedOccurrence;
      if (!closed2(o, ["version", "dependencyId", "dependencyBindingId", "sourceRepresentationId", "collectionResolver", "sourceProperty", "transformId"]) || o.version !== 1) {
        add(p, "unknown owned-occurrence binding");
        continue;
      }
      const resolver = o.collectionResolver, source = o.sourceProperty;
      if (!record7(resolver) || !record7(source)) {
        add(p, "invalid owned capture resolver");
        continue;
      }
      if (!closed2(resolver, ["version", "source", "ownerTargetId", "visibility", "ordering"]) || resolver.version !== 1 || resolver.source !== "trusted-native-capture" || resolver.visibility !== "captured-effective" || resolver.ordering !== "captured-source-order") add(p, "closed trusted collection resolver required");
      if (!closed2(source, ["property", "propertyType"]) || !text2(source.property)) add(p, "typed source property required");
      const target = s.targets.filter((t) => t.id === b.targetId), owner = s.targets.filter((t) => t.id === resolver.ownerTargetId), figma = s.representations.find((r) => r.id === o.sourceRepresentationId);
      const dependencies = s.dependencies.filter((d) => d.id === o.dependencyId), direct = dependencies[0]?.bindings.filter((d) => d.id === o.dependencyBindingId);
      if (target.length !== 1 || target[0].resolution !== "resolved" || owner.length !== 1 || owner[0].resolution !== "resolved" || figma?.kind !== "figma" || figma.platform !== rep?.platform || dependencies.length !== 1 || direct?.length !== 1 || direct[0].kind !== "direct-child" || direct[0].targetRole !== target[0].semanticRole || direct[0].ownerTargetRole !== owner[0].semanticRole || !direct[0].representationIds.includes(o.sourceRepresentationId) || !target[0].variantHints?.some((h) => h.representationId === figma.id && h.pathHint.includes("@source:"))) add(p, "owned target requires exact declared direct dependency and source addresses");
      const forms = {
        "owned-button-label.v1": ["props.elements[].children", "TEXT", "content", "string"],
        "owned-button-disabled.v1": ["props.elements[].disabled", "VARIANT", "state", "enum"],
        "owned-button-primary-first.v1": ["props.primaryFirst", "VARIANT", "appearance", "enum"]
      };
      const f = forms[o.transformId];
      if (!f || b.path !== f[0] || source.propertyType !== f[1] || api.kind !== f[2] || api.valueType !== f[3]) add(p, "unsupported owned field transformation");
      if (o.transformId === "owned-button-disabled.v1" && stableHash(api.domain) !== stableHash(["False", "True"])) add(p, "disabled conversion requires exact False/True domain");
      if (o.transformId === "owned-button-primary-first.v1" && stableHash(api.domain) !== stableHash(["Primary", "Secondary"])) add(p, "view conversion requires exact Primary/Secondary domain");
    }
    if (b.nativeSlotBinding !== void 0) {
      const n = b.nativeSlotBinding;
      if (!closed2(n, ["version", "figmaRepresentationId", "targetId", "propertyIdentity", "propertyType", "codeRepresentationId", "codePath", "contentPolicy", "proof"]) || n.version !== 1 || n.propertyType !== "SLOT" || n.codePath !== "props.children" || n.contentPolicy !== "preserve-ordered-content" || n.proof !== "trusted-native-capture") {
        add(p, "unknown native SLOT association");
        continue;
      }
      const figma = s.representations.find((r) => r.id === n.figmaRepresentationId), targets = s.targets.filter((t) => t.id === n.targetId);
      if (b.path !== n.codePath || b.representationId !== n.codeRepresentationId || b.targetId !== void 0 && b.targetId !== n.targetId || api.kind !== "slot" || api.valueType !== "content" || figma?.kind !== "figma" || figma.platform !== rep?.platform || targets.length !== 1 || targets[0].resolution !== "resolved" || !text2(n.propertyIdentity) || !api.bindings.some((f) => f.representationId === figma.id && f.path === "component.properties." + n.propertyIdentity) || !s.slots.some((c) => c.kind === "slot-api" && c.target === n.targetId && c.property === n.propertyIdentity && c.contentOwnership === "external")) add(p, "SLOT association requires an existing exact Figma port/target and ordered children API");
    }
  }
  return errors;
}
function representationFeatureFlags(s) {
  return { evidence: s.representations.some((r) => r.codeEvidence !== void 0), bindings: s.semanticApi.some((p) => p.bindings.some((b) => b.codeTransform !== void 0 || b.ownedOccurrence !== void 0 || b.nativeSlotBinding !== void 0)) };
}

// src/runtime.ts
var import_predicate = __toESM(require_predicate());

// src/semantic-facts.ts
function supportedSemanticBinding(binding) {
  if (binding.targetId !== void 0) return false;
  if (binding.path === "representation.surface") return binding.transform === "identity";
  return binding.path.startsWith("component.properties.") && ["identity", "number-to-string", "boolean-string", "pascal-case"].includes(binding.transform || "identity");
}
function decode(value, property, transform = "identity") {
  if (transform === "number-to-string") {
    if (!["number", "enum"].includes(property.valueType) || typeof value !== "string" || !/^-?\d+(\.\d+)?$/.test(value)) return void 0;
    const number = Number(value);
    return Number.isFinite(number) ? number : void 0;
  }
  if (transform === "boolean-string") {
    if (property.valueType !== "boolean") return void 0;
    return value === "True" || value === "true" ? true : value === "False" || value === "false" ? false : void 0;
  }
  if (transform === "pascal-case") {
    const matches2 = (property.domain || []).filter((entry) => typeof entry === "string" && entry.charAt(0).toUpperCase() + entry.slice(1) === value);
    return matches2.length === 1 ? matches2[0] : void 0;
  }
  if (property.valueType === "boolean") return typeof value === "boolean" ? value : void 0;
  if (property.valueType === "number") return typeof value === "number" && Number.isFinite(value) ? value : void 0;
  if (["enum", "string", "content"].includes(property.valueType)) return typeof value === "string" || typeof value === "number" ? value : void 0;
  return void 0;
}
function materializeSemanticFacts(snapshot, contract) {
  if (!contract.facts.semanticApi.length) return;
  const keys = [snapshot.source?.componentKey, snapshot.source?.componentSetKey].filter(Boolean);
  const representations = contract.facts.representations.filter((rep) => rep.kind === "figma" && rep.platform === snapshot.context.platform && rep.status !== "deprecated" && keys.some((key) => key === rep.locator.componentKey || key === rep.locator.componentSetKey));
  for (const node of snapshot.nodes.filter((entry) => snapshot.selection.includes(String(entry.id)))) {
    const values = /* @__PURE__ */ Object.create(null);
    const evidence = /* @__PURE__ */ Object.create(null);
    const unknown12 = new Set(Array.isArray(node.unknownFacts) ? node.unknownFacts : []);
    const component = node.component;
    for (const property of contract.facts.semanticApi) {
      const fact2 = `semanticApi.${property.id}`;
      let reason = "representation-unresolved";
      if (representations.length === 1) {
        const bindings = property.bindings.filter((binding) => binding.representationId === representations[0].id);
        reason = bindings.length === 1 ? "unsupported-binding" : "binding-missing-or-ambiguous";
        if (bindings.length === 1 && supportedSemanticBinding(bindings[0])) {
          const binding = bindings[0];
          const surface = binding.path === "representation.surface";
          const allowedTypes = ["boolean-string", "number-to-string", "pascal-case"].includes(binding.transform || "") ? ["VARIANT"] : property.valueType === "boolean" ? ["BOOLEAN"] : ["TEXT", "VARIANT", "INSTANCE_SWAP"];
          const reference = snapshot.variantReference;
          const propertyData = { ...component, definedProperties: [
            ...component?.definedProperties || [],
            ...reference?.definedProperties || [],
            ...Object.keys(reference?.properties || {}),
            ...Object.keys(reference?.propertyTypes || {})
          ] };
          const resolved = !surface ? resolveComponentProperty(binding.path.slice("component.properties.".length), propertyData, allowedTypes) : void 0;
          const name = resolved && "name" in resolved ? resolved.name : void 0;
          const identity = component?.identity;
          const identityProven = Boolean(snapshot.source?.componentSetKey && identity?.componentSetKey === snapshot.source.componentSetKey && snapshot.source?.componentKey && identity?.componentKey === snapshot.source.componentKey && [representations[0].locator.componentKey, representations[0].locator.componentSetKey].includes(snapshot.source.componentSetKey));
          const raw = surface ? identityProven ? representations[0].surface : void 0 : name !== void 0 ? component?.properties?.[name] : void 0;
          const inputs = surface ? ["component.identity.componentKey", "component.identity.componentSetKey", binding.path] : [binding.path, ...name !== void 0 ? [`component.properties.${name}`, `component.propertyTypes.${name}`] : []];
          const sourceUnknown = Array.from(unknown12).some((path) => inputs.some((input) => input === path || input.startsWith(`${path}.`)));
          const value = sourceUnknown ? void 0 : decode(raw, property, binding.transform);
          const valid = value !== void 0 && (!surface || !property.domain || property.domain.includes(value));
          reason = valid ? "resolved" : "source-missing-unknown-or-incompatible";
          if (valid) {
            values[property.id] = value;
            unknown12.delete(fact2);
          }
          evidence[property.id] = {
            reason,
            representationId: representations[0].id,
            path: binding.path,
            transform: binding.transform || "identity",
            ...resolved && "name" in resolved && resolved.match === "alias" ? { resolvedPath: `component.properties.${resolved.name}`, match: "unique-property-alias" } : {},
            ...resolved && "reason" in resolved && resolved.reason === "property-ambiguous" ? { propertyResolution: resolved.reason } : {}
          };
        }
      }
      if (!Object.prototype.hasOwnProperty.call(evidence, property.id)) evidence[property.id] = { reason };
      if (!Object.prototype.hasOwnProperty.call(values, property.id)) unknown12.add(fact2);
    }
    node.semanticApi = values;
    node.semanticBindingEvidence = evidence;
    node.unknownFacts = Array.from(unknown12);
  }
}

// src/validation-inputs.ts
function validationInputs(source) {
  return [
    ...(source?.semanticApi || []).filter((p) => p.validationInput),
    ...(Array.isArray(source?.validationContext) ? source.validationContext : []).filter((p) => p && typeof p === "object").map((p) => ({
      id: p.id,
      valueType: p.valueType,
      domain: p.domain,
      kind: "layout",
      bindings: [],
      validationInput: { version: p.valueType === "enum" ? 2 : 1, label: `\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442: ${p.label}`, description: p.description }
    }))
  ];
}

// src/validation-intent.ts
var subjectOf = (snapshot) => ({
  rootNodeId: snapshot.source?.rootNodeId || "",
  pageId: snapshot.source?.pageId || "",
  componentKey: snapshot.source?.componentKey || "",
  componentSetKey: snapshot.source?.componentSetKey || ""
});
function materializeValidationIntent(snapshot, contract) {
  if (![1, 2].includes(contract.runtimePolicy.validationIntentVersion || 0)) return;
  const properties = validationInputs(contract.facts).filter((p) => p.validationInput?.version === 1 || contract.runtimePolicy.validationIntentVersion === 2 && p.validationInput?.version === 2);
  const roots = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  const root2 = roots.length === 1 ? roots[0] : void 0;
  const subject = subjectOf(snapshot), input = snapshot.validationIntent;
  const identity = root2?.component?.identity;
  const reps = contract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && r.platform === snapshot.context.platform && [r.locator.componentKey, r.locator.componentSetKey].includes(subject.componentSetKey));
  const validIdentity = Boolean(root2 && Object.values(subject).every(Boolean) && reps.length === 1 && !snapshot.source?.truncated && !(Array.isArray(root2.unknownFacts) ? root2.unknownFacts : []).some((f) => ["component", "component.identity", "component.identity.componentKey", "component.identity.componentSetKey"].includes(f)) && identity?.componentKey === subject.componentKey && identity?.componentSetKey === subject.componentSetKey);
  const reason = !input ? "expected-input-missing" : input.schemaVersion !== "apollo.validation-intent.v1" || input.origin !== "explicit-scenario-input" ? "expected-input-origin-invalid" : input.manualSourceHash !== contract.package.manualSourceHash ? "expected-input-contract-changed" : !validIdentity || !input.subject || Object.entries(subject).some(([key, value]) => input.subject[key] !== value) ? "expected-input-subject-mismatch" : "resolved";
  for (const node of snapshot.nodes) {
    delete node.expectedInput;
    delete node.expectedInputEvidence;
    if (node !== root2) continue;
    const values = {}, evidence = {};
    const unknown12 = new Set(Array.isArray(node.unknownFacts) ? node.unknownFacts : []);
    for (const property of properties) {
      const fact2 = `expectedInput.${property.id}`, value = input?.values?.[property.id];
      const valid = reason === "resolved" && (property.valueType === "boolean" && typeof value === "boolean" || property.validationInput?.version === 2 && property.valueType === "enum" && typeof value === "string") && (!property.domain || property.domain.includes(value));
      if (valid) {
        values[property.id] = value;
        unknown12.delete(fact2);
      } else unknown12.add(fact2);
      evidence[property.id] = {
        reason: valid ? "resolved" : reason === "resolved" ? "expected-input-missing-or-invalid" : reason,
        origin: input?.origin || null,
        manualSourceHash: input?.manualSourceHash || null
      };
    }
    node.expectedInput = values;
    node.expectedInputEvidence = evidence;
    node.unknownFacts = [...unknown12];
  }
}

// src/validation-mode.ts
function validationMode(snapshot) {
  if (!snapshot) return "unknown";
  const request = snapshot.validationRequest;
  if (request === void 0) return "component-audit";
  return request?.version === 1 && ["component-audit", "specification"].includes(request.mode) ? request.mode : "unknown";
}
function materializeValidationMode(snapshot, contract) {
  if (contract.runtimePolicy.validationModeVersion !== 1) return;
  const mode = validationMode(snapshot);
  for (const node of snapshot.nodes) {
    node.validationScopeV1 = mode === "unknown" ? {} : { mode, isRoot: snapshot.selection.includes(String(node.id)) };
    const unknown12 = new Set(Array.isArray(node.unknownFacts) ? node.unknownFacts : []);
    for (const fact2 of [...unknown12]) if (fact2 === "validationScopeV1" || fact2.startsWith("validationScopeV1.")) unknown12.delete(fact2);
    if (mode === "unknown") unknown12.add("validationScopeV1");
    node.unknownFacts = [...unknown12];
  }
}

// src/component-facts.ts
function unknown2(node, path) {
  return (node.unknownFacts || []).some((entry) => path === entry || path.startsWith(`${entry}.`));
}
function materializeComponentFacts(snapshot, contract) {
  const roots = snapshot.nodes.filter((node) => snapshot.selection.includes(String(node.id)));
  const root2 = roots.length === 1 ? roots[0] : void 0;
  if ([1, 2, 3].includes(contract.runtimePolicy.declaredTargetIdentityVersion || 0)) {
    const host2 = root2 ? { component: root2.component || {}, semanticApi: root2.semanticApi || {} } : {};
    const hostUnknown2 = root2 ? (root2.unknownFacts || []).filter((path) => /^(component|semanticApi)(\.|$)/.test(path)).map((path) => `host.${path}`) : ["host"];
    for (const node of snapshot.nodes) {
      node.host = JSON.parse(JSON.stringify(host2));
      node.unknownFacts = [...new Set((node.unknownFacts || []).filter((path) => path !== "host" && !path.startsWith("host.")).concat(hostUnknown2))];
    }
    return;
  }
  const index = new Map(snapshot.nodes.map((node) => [String(node.id), node]));
  const visibility = (node) => {
    const visited = /* @__PURE__ */ new Set();
    let current = node;
    let uncertain2 = false;
    let hidden = false;
    while (current) {
      const id = String(current.id);
      if (visited.has(id)) return void 0;
      visited.add(id);
      if (unknown2(current, "visible") || typeof current.visible !== "boolean") uncertain2 = true;
      else if (current.visible === false) hidden = true;
      if (current === root2) return hidden ? false : uncertain2 ? void 0 : true;
      current = index.get(String(current.parentId));
    }
    return void 0;
  };
  const host = root2 ? { component: root2.component || {}, semanticApi: root2.semanticApi || {} } : {};
  const hostUnknown = root2 ? (root2.unknownFacts || []).filter((path) => /^(component|semanticApi)(\.|$)/.test(path)).map((path) => `host.${path}`) : ["host"];
  const targets = {};
  const targetsUnknown = [];
  if (["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) {
    const roles = /* @__PURE__ */ new Map();
    for (const node of snapshot.nodes) {
      const role = node.semantic?.role;
      if (role) roles.set(role, [...roles.get(role) || [], String(node.id)]);
    }
    const relations = Object.fromEntries([...roles].filter(([, ids]) => ids.length === 1).map(([role, ids]) => [role, ids[0]]));
    if (root2 && contract.runtimePolicy.rootTargetAliasesVersion === 1) {
      for (const [role, proven] of Object.entries(root2.rootTargetAliasesV1 || {})) if (proven === true) relations[role] = String(root2.id);
    }
    snapshot.nodes.forEach((node) => {
      node.relations = { ...relations };
    });
  }
  for (const target of contract.facts.targets) {
    const candidates = snapshot.nodes.filter((node) => matchesTargetRole(node, target.semanticRole, contract));
    const verified = root2?.variantAvailability?.targets?.[target.semanticRole];
    if (verified?.present === false && candidates.length === 0) {
      targets[target.semanticRole] = { resolved: true, visibilityKnown: true, present: false };
    } else if (root2 && !snapshot.source?.truncated && (target.resolution === "resolved" || verified?.present === true) && candidates.length === 1 && !unknown2(candidates[0], "semantic.role")) {
      targets[target.semanticRole] = { resolved: true, ...verified ? { present: true } : {} };
      if (visibility(candidates[0]) !== void 0) targets[target.semanticRole].visibilityKnown = true;
      else targetsUnknown.push(`semanticTargets.${target.semanticRole}.visibilityKnown`);
    } else targetsUnknown.push(`semanticTargets.${target.semanticRole}`);
  }
  for (const node of snapshot.nodes) {
    const paths = new Set((node.unknownFacts || []).filter((path) => path !== "host" && !path.startsWith("host.") && path !== "visibility.effective" && !path.startsWith("semanticTargets.")));
    const effective = visibility(node);
    node.visibility = effective === void 0 ? {} : { effective };
    if (effective === void 0) paths.add("visibility.effective");
    node.host = JSON.parse(JSON.stringify(host));
    node.semanticTargets = targets;
    hostUnknown.forEach((path) => paths.add(path));
    targetsUnknown.forEach((path) => paths.add(path));
    node.unknownFacts = [...paths];
  }
}

// src/instance-validation.ts
var EFFECTIVE_FACT_KEYS = [
  "layout",
  "appearance",
  "variable",
  "component",
  "text",
  "visible"
];
function record8(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function semanticRole(node) {
  const semantic = record8(node.semantic);
  return typeof semantic.role === "string" ? semantic.role : "";
}
function intrinsicBounds(value) {
  const bounds = record8(value), result = {};
  for (const key of ["width", "height"]) {
    const size = bounds[key];
    if (typeof size === "number" && Number.isFinite(size) && size >= 0) result[key] = size;
  }
  return result;
}
function effectiveFacts(node, includeDimensions = false) {
  const result = {};
  EFFECTIVE_FACT_KEYS.forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(node, key)) result[key] = node[key];
  });
  if (includeDimensions) {
    const bounds = intrinsicBounds(node.bounds);
    if (Object.keys(bounds).length) result.bounds = bounds;
    if (node.propertyActivityV1) result.propertyActivityV1 = node.propertyActivityV1;
  }
  return result;
}
function cloneSnapshot(snapshot) {
  return JSON.parse(JSON.stringify(snapshot));
}
function materializeEffectiveBaseline(actual, reference, strictInstanceBoundaries = true) {
  const result = cloneSnapshot(actual);
  if (strictInstanceBoundaries) {
    const actualPaths = snapshotPaths(actual), referencePaths = snapshotPaths(reference);
    const ref = captureVariantReference(reference, reference.source?.componentKey || "", reference.source?.componentSetKey || "");
    const comparison = compareInstanceBoundaries(actual, ref);
    const byPath2 = new Map(reference.nodes.map((node) => [referencePaths?.get(String(node.id)), node]));
    const unmatchedNodeIds2 = [];
    let matchedNodes2 = 0;
    result.nodes = result.nodes.map((node) => {
      const path = actualPaths?.get(String(node.id));
      const isolated = path !== void 0 && comparison.boundaries.find((b) => withinBoundary(path, b.actualPath));
      const referencePath = path !== void 0 ? correspondingPath(comparison, path) : void 0;
      const expected = referencePath !== void 0 && comparison.complete && !isolated ? byPath2.get(referencePath) : void 0;
      if (!expected || expected.type !== node.type) {
        unmatchedNodeIds2.push(String(node.id));
        return { ...node, baseline: { effective: {} }, baselineProvenance: { status: "unresolved", reason: isolated ? isolated.reason : "structural-identity-unresolved" } };
      }
      matchedNodes2++;
      return { ...node, baseline: { effective: effectiveFacts(expected, true) }, baselineProvenance: { status: "matched", referencePath } };
    });
    return { snapshot: result, matchedNodes: matchedNodes2, unmatchedNodeIds: unmatchedNodeIds2 };
  }
  const referenceByRole = /* @__PURE__ */ new Map();
  reference.nodes.forEach((candidate) => {
    const node = record8(candidate);
    const role = semanticRole(node);
    if (role && !referenceByRole.has(role)) referenceByRole.set(role, node);
  });
  let matchedNodes = 0;
  const unmatchedNodeIds = [];
  result.nodes = result.nodes.map((candidate, index) => {
    const node = record8(candidate);
    const role = semanticRole(node);
    const referenceNode = referenceByRole.get(role) || (index === 0 ? record8(reference.nodes[0]) : void 0);
    if (!referenceNode || referenceNode.type !== node.type) {
      unmatchedNodeIds.push(String(node.id || `node:${index}`));
      return { ...node, baseline: { effective: {} } };
    }
    matchedNodes += 1;
    return {
      ...node,
      baseline: { effective: effectiveFacts(referenceNode, true) }
    };
  });
  return { snapshot: result, matchedNodes, unmatchedNodeIds };
}

// src/component-dependencies.ts
var record9 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var COMPONENT_DEPENDENCY_DEPTH_LIMIT = 4;
function dependencyPinIssue(pin, contract) {
  if (!contract) return "dependency-contract-missing";
  if (contract.documentType !== "component-contract" || contract.schemaVersion !== "apollo.component-contract.v2.1-experimental") return "dependency-schema-unsupported";
  if (contract.package?.componentId !== pin.componentId) return "dependency-component-mismatch";
  if (!Array.isArray(contract.rules) || !Array.isArray(contract.facts?.representations) || !Array.isArray(contract.nonExecutableRules) || !Array.isArray(contract.customizationPolicy)) return "dependency-contract-malformed";
  const revisions = [...new Set(contract.rules.map((r) => r.revision))];
  const revision = contract.package.manualRevision ?? (revisions.length === 1 ? revisions[0] : void 0);
  if (revision !== pin.revision || contract.package.manualSourceHash !== pin.manualSourceHash || stableHash(contract) !== pin.compiledHash) return "dependency-pin-mismatch";
  if (contract.runtimePolicy?.engine !== "apollo-predicate-engine" || contract.runtimePolicy?.unknownPolicy !== "fail-closed") return "dependency-runtime-unsupported";
  for (const field of ["occurrenceAddressVersion", "directChildDependenciesVersion", "memberCollectionsVersion", "dependencySubjectConditionsVersion", "rootTargetAliasesVersion", "assetIdentityLockVersion", "instanceMainComponentAliasesVersion", "representationEvidenceVersion", "crossRepresentationBindingsVersion"])
    if (contract.runtimePolicy[field] !== void 0 && contract.runtimePolicy[field] !== 1) return "dependency-runtime-unsupported";
  const shape = contractRepresentationShape(contract), flags = representationFeatureFlags(shape);
  if (representationEvidenceErrors(shape).length || flags.evidence !== (contract.runtimePolicy.representationEvidenceVersion === 1) || flags.bindings !== (contract.runtimePolicy.crossRepresentationBindingsVersion === 1)) return "dependency-representation-unsupported";
  return void 0;
}
function resolveFixedNestedBinding(snapshot, d, b, strictCompositionEvidence = false, hostContract) {
  if (b.kind === "direct-child") return resolveDirectChildBinding(snapshot, d, b, hostContract);
  const unknown12 = (reason) => ({ status: "unknown", reason });
  const root2 = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  const paths = snapshotPaths(snapshot), ref = snapshot.variantReference;
  const comparison = ref && compareInstanceBoundaries(snapshot, ref);
  if (root2.length !== 1 || !paths || snapshot.source?.truncated || !ref?.complete || !comparison?.complete) return unknown12("dependency-topology-unavailable");
  const availability = record9(record9(root2[0].variantAvailability).targets)[b.targetRole];
  if (availability?.present === false) return { status: "inactive", reason: "target-absent-in-variant" };
  const targets = snapshot.nodes.filter((n) => record9(n.semantic).role === b.targetRole);
  if (availability?.present !== true || targets.length !== 1) return unknown12("dependency-target-unresolved");
  if (record9(targets[0].visibility).effective === false) return { status: "inactive", reason: "target-hidden" };
  if (record9(targets[0].visibility).effective !== true) return unknown12("dependency-visibility-unavailable");
  const ownerPath = [correspondingPath(comparison, paths.get(String(targets[0].id))), b.relativePath].filter(Boolean).join(" / ");
  const owners = snapshot.nodes.filter((n) => correspondingPath(comparison, paths.get(String(n.id))) === ownerPath && n.type === "INSTANCE");
  if (owners.length !== 1) return unknown12("dependency-owner-unresolved");
  const owner = owners[0], component = record9(owner.component), identity = record9(component.identity);
  if (strictCompositionEvidence && (owner.unknownFacts || []).some((p) => ["component.identity", "component.properties." + b.activeVariant.property, "component.propertyTypes." + b.activeVariant.property].some((input) => input === p || input.startsWith(p + ".") || input === "component.identity" && p.startsWith(input + ".")))) return unknown12("dependency-owner-evidence-unknown");
  if (!b.ownerComponentSetKeys.includes(identity.componentSetKey)) return unknown12("dependency-owner-identity-mismatch");
  let selectedReference = ref;
  const boundary = comparison.boundaries.find((x) => withinBoundary(paths.get(String(owner.id)), x.actualPath));
  if (boundary) {
    const result = snapshot.instanceContentResults?.find((r) => r.boundaryNodeId === boundary.nodeId && r.lineageProven);
    const attempts = snapshot.instanceContentReferences?.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId) || [];
    if (boundary.nodeId !== owner.id || boundary.reason !== "component-variant-changed" || !result || attempts.length !== 1 || attempts[0].failure || !attempts[0].reference) return unknown12("dependency-owner-lineage-unproven");
    const s = attempts[0].reference;
    selectedReference = captureVariantReference(s, s.source?.componentKey || "", s.source?.componentSetKey || "");
  }
  const originalOwner = selectedReference.nodeProperties[ownerPath];
  const prop = b.activeVariant.property, value = component.properties?.[prop];
  if (!originalOwner || originalOwner.identity?.componentKey !== identity.componentKey || originalOwner.identity?.componentSetKey !== identity.componentSetKey || component.propertyTypes?.[prop] !== "VARIANT" || originalOwner.propertyTypes[prop] !== "VARIANT" || originalOwner.properties[prop] !== value || (owner.unknownFacts || []).some((p) => `component.properties.${prop}` === p || `component.properties.${prop}`.startsWith(p + "."))) return unknown12("dependency-owner-variant-unproven");
  if (!b.activeVariant.values.includes(value)) return { status: "inactive", reason: "owner-variant-inactive" };
  const childPath = [ownerPath, b.childPath].filter(Boolean).join(" / "), original = selectedReference.nodeProperties[childPath];
  const childContract = d.contract;
  const childKeys = childContract?.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated").flatMap((r) => [r.locator.componentKey, r.locator.componentSetKey]).filter((key) => typeof key === "string" && Boolean(key)) || [];
  if (!original?.identity || !childKeys.includes(original.identity.componentSetKey || original.identity.componentKey)) return { ...unknown12("dependency-child-lineage-unproven"), ownerActive: true };
  const selectedComparison = snapshot.source?.instanceIdentityVersion === 1 ? compareInstanceBoundaries(snapshot, selectedReference, true) : void 0;
  if (selectedComparison && !selectedComparison.complete) return { ...unknown12("dependency-child-lineage-unproven"), ownerActive: true };
  const children = snapshot.nodes.filter((n) => correspondingPath(selectedComparison, paths.get(String(n.id))) === childPath);
  if (children.length !== 1 || children[0].type !== "INSTANCE") return { ...unknown12("dependency-child-missing-or-ambiguous"), ownerActive: true };
  const node = children[0], childIdentity = record9(record9(node.component).identity);
  return { status: "active", reason: "fixed-child-proven", node, nodeId: String(node.id), identityValid: childKeys.includes(childIdentity.componentSetKey || childIdentity.componentKey), ownerActive: true };
}
function resolveDirectChildBinding(snapshot, d, b, hostContract) {
  const unavailable = (reason) => ({ status: "unknown", reason });
  if (hostContract?.runtimePolicy.directChildDependenciesVersion !== 1) return unavailable("direct-dependency-version-unavailable");
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id))), ref = snapshot.variantReference, paths = snapshotPaths(snapshot);
  if (!root2 || !ref?.complete || !paths || snapshot.source?.occurrenceAddressVersion !== 1 || ref.occurrenceAddressVersion !== 1 || !["verified", "partial"].includes(record9(root2.variantAvailability).status)) return unavailable("dependency-topology-unavailable");
  const reps = hostContract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
  if (reps.length !== 1) return unavailable("dependency-representation-unresolved");
  if (!b.representationIds.includes(reps[0].id)) return { status: "inactive", reason: "binding-outside-representation" };
  const targets = hostContract.facts.targets.filter((t) => t.semanticRole === b.targetRole && t.resolution === "resolved");
  const owners = hostContract.facts.targets.filter((t) => t.semanticRole === b.ownerTargetRole && t.resolution === "resolved");
  if (targets.length !== 1 || owners.length !== 1) return unavailable("dependency-target-unresolved");
  const memberPath = selectedTargetPathHint(targets[0], reps[0].id, ref.componentKey, true)?.split(" / ").slice(1).join(" / ");
  const ownerPath = selectedTargetPathHint(owners[0], reps[0].id, ref.componentKey, true)?.split(" / ").slice(1).join(" / ");
  if (memberPath === void 0 || !memberPath || ownerPath === void 0 || memberPath.split(" / ").slice(0, -1).join(" / ") !== ownerPath)
    return unavailable("dependency-direct-binding-unresolved");
  const comparison = compareInstanceBoundaries(snapshot, ref, true);
  const actualOwners = snapshot.nodes.filter((n) => n.type === "INSTANCE" && correspondingPath(comparison, paths.get(String(n.id))) === ownerPath);
  const members = snapshot.nodes.filter((n) => n.type === "INSTANCE" && correspondingPath(comparison, paths.get(String(n.id))) === memberPath);
  if (actualOwners.length !== 1 || members.length !== 1 || members[0].parentId !== actualOwners[0].id) return unavailable("dependency-direct-lineage-unproven");
  const owner = actualOwners[0], node = members[0], identity = record9(record9(node.component).identity), ownerIdentity = record9(record9(owner.component).identity);
  if ((owner.unknownFacts || []).some((p) => p === "component" || p === "component.identity" || p.startsWith("component.identity."))) return unavailable("dependency-owner-evidence-unknown");
  const original = ref.nodeProperties[memberPath], expectedOwner = ref.nodeProperties[ownerPath]?.identity;
  const source = record9(record9(node.component).sourceIdentity), expectedSource = original?.sourceIdentity;
  if (!expectedOwner || expectedOwner.componentKey !== ownerIdentity.componentKey || expectedOwner.mainComponentId !== ownerIdentity.mainComponentId || !b.ownerComponentKeys.some((k) => k === ownerIdentity.componentKey || k === ownerIdentity.componentSetKey) || !expectedSource || source.version !== 1 || source.sourceNodeId !== expectedSource.sourceNodeId || source.ownerComponentKey !== ownerIdentity.componentKey || source.ownerMainComponentId !== ownerIdentity.mainComponentId || (node.unknownFacts || []).some((p) => p === "component" || p === "component.sourceIdentity" || p.startsWith("component.sourceIdentity.")))
    return unavailable("dependency-direct-lineage-unproven");
  const selected = d.contract?.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && matchesCaptureRepresentation(r, identity.componentKey || "", identity.componentSetKey || "")) || [];
  const sameFamily = Boolean(identity.componentKey && original.identity?.componentKey && (identity.componentSetKey ? identity.componentSetKey === original.identity.componentSetKey : !original.identity.componentSetKey && identity.componentKey === original.identity.componentKey));
  const identityKnown = !(node.unknownFacts || []).some((p) => p === "component" || p === "component.identity" || p.startsWith("component.identity."));
  if (!sameFamily || !identityKnown || selected.length !== 1 || !["universal", snapshot.context.platform].includes(selected[0].platform))
    return { status: "active", reason: "dependency-child-identity-mismatch", node, nodeId: String(node.id), identityValid: false, ownerActive: true };
  const visibility = record9(node.visibility).effective;
  if ((node.unknownFacts || []).some((p) => ["visible", "visibility", "visibility.effective"].includes(p)) || typeof visibility !== "boolean") return unavailable("dependency-visibility-unavailable");
  if (visibility === false) return { status: "inactive", reason: "target-hidden", node, nodeId: String(node.id), identityValid: true };
  return { status: "active", reason: "direct-child-proven", node, nodeId: String(node.id), identityValid: true, ownerActive: true };
}
function dependencyActualFacts(node) {
  const facts = effectiveFacts(node, true), variable = record9(facts.variable);
  if (variable.modeCatalog !== void 0) {
    const catalog = record9(variable.modeCatalog), relevant = {};
    for (const key of Object.keys(record9(variable.modes))) {
      if (!Object.prototype.hasOwnProperty.call(catalog, key)) return;
      relevant[key] = catalog[key];
    }
    facts.variable = { ...variable };
    if (Object.keys(relevant).length) record9(facts.variable).modeCatalog = relevant;
    else delete record9(facts.variable).modeCatalog;
  } else if (Object.keys(record9(variable.modes)).length) return;
  return facts;
}
function validatedDependencyCapture(snapshot, nodeId, childContract) {
  const captures = snapshot.componentDependencyCaptures?.filter((c) => c.nodeId === nodeId) || [];
  if (captures.length !== 1 || !captures[0].snapshot || !captures[0].nodeMap || captures[0].failure) return { reason: captures[0]?.failure || "dependency-reference-not-captured" };
  const capture = captures[0], child = JSON.parse(JSON.stringify(capture.snapshot)), nodeMap = capture.nodeMap;
  if (child.source?.truncated || !child.variantReference?.complete || child.selection.length !== 1 || nodeMap[child.selection[0]] !== nodeId || !snapshot.nodes.find((n) => n.id === nodeId)?.resolvedModes || stableHash(child.context.modes) !== stableHash(snapshot.nodes.find((n) => n.id === nodeId).resolvedModes)) return { reason: "dependency-capture-incomplete" };
  const paths = snapshotPaths(snapshot), prefix = paths?.get(nodeId);
  if (prefix === void 0) return { reason: "dependency-capture-topology-mismatch" };
  const expected = snapshot.nodes.filter((n) => withinBoundary(paths.get(String(n.id)) || "", prefix));
  const mapped = Object.values(nodeMap);
  if (expected.length !== child.nodes.length || mapped.length !== child.nodes.length || new Set(mapped).size !== mapped.length || expected.some((n) => !mapped.includes(String(n.id)))) return { reason: "dependency-capture-topology-mismatch" };
  for (const n of child.nodes) {
    const host = snapshot.nodes.find((h) => h.id === nodeMap[String(n.id)]);
    const actual = dependencyActualFacts(n), expected2 = host && dependencyActualFacts(host);
    if (!actual || !expected2) return { reason: "dependency-capture-actual-mismatch" };
    if (expected2 && String(n.id) === child.selection[0] && snapshot.source?.occurrenceAddressVersion === 1 && child.source?.occurrenceAddressVersion === 1) {
      actual.component = { ...record9(actual.component) };
      expected2.component = { ...record9(expected2.component) };
      delete record9(actual.component).sourceIdentity;
      delete record9(expected2.component).sourceIdentity;
    }
    if (!host || n.type !== host.type || stableHash(actual) !== stableHash(expected2) || String(n.id) !== child.selection[0] && nodeMap[String(n.parentId)] !== host.parentId) return { reason: "dependency-capture-actual-mismatch" };
  }
  const root2 = child.nodes.find((n) => child.selection.includes(String(n.id)));
  const identity = record9(record9(root2.component).identity);
  if (!identity.componentKey || identity.componentKey !== child.source?.componentKey || (identity.componentSetKey || "") !== (child.source?.componentSetKey || "")) return { reason: "dependency-capture-identity-mismatch" };
  const key = identity.componentSetKey || identity.componentKey;
  const reps = childContract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && [r.locator.componentKey, r.locator.componentSetKey].filter(Boolean).includes(key));
  if (reps.length !== 1) return { reason: "dependency-representation-unresolved" };
  child.context = { ...snapshot.context, platform: reps[0].platform, modes: child.context.modes };
  const inverse = new Map(Object.entries(nodeMap).map(([local, host]) => [host, local]));
  child.componentDependencyCaptures = (snapshot.componentDependencyCaptures || []).filter((c) => c.nodeId !== nodeId && inverse.has(c.nodeId)).map((c) => ({
    ...c,
    nodeId: inverse.get(c.nodeId),
    nodeMap: c.nodeMap ? Object.fromEntries(Object.entries(c.nodeMap).map(([local, host]) => [local, inverse.get(host)])) : void 0
  }));
  return { snapshot: child, nodeMap };
}

// src/member-collections.ts
var record10 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var parent2 = (path) => path.split(" / ").slice(0, -1).join(" / ");
var unknown3 = (node, fact2) => (node.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + ".") || p.startsWith(fact2 + "."));
var valueType = (type, value) => type === "BOOLEAN" ? typeof value === "boolean" : typeof value === "string";
function completeGraph(snapshot) {
  if (snapshot.selection.length !== 1 || snapshot.source?.truncated !== false || snapshot.source?.captureTopology?.complete === false) return;
  const nodes = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  if (nodes.size !== snapshot.nodes.length || nodes.get(snapshot.selection[0])?.parentId !== null) return;
  const seen = /* @__PURE__ */ new Set();
  const visit = (id) => {
    const n = nodes.get(id);
    if (!n || seen.has(id) || !Array.isArray(n.childIds) || new Set(n.childIds).size !== n.childIds.length) return false;
    seen.add(id);
    return n.childIds.every((child) => nodes.get(child)?.parentId === id && visit(child));
  };
  return visit(snapshot.selection[0]) && seen.size === nodes.size ? nodes : void 0;
}
function referenceMatchesCatalog(snapshot, contract) {
  const ref = snapshot.variantReference, e = contract.facts.variantEvidence;
  if (!ref?.complete || ref.occurrenceAddressVersion !== 1 || !e || ref.componentKey !== snapshot.source?.componentKey || ref.componentSetKey !== (snapshot.source?.componentSetKey || "")) return false;
  const variants = e.variants.filter((v2) => v2.componentKey === ref.componentKey && (v2.componentSetKey === ref.componentSetKey || !ref.componentSetKey && v2.componentSetKey === v2.componentKey));
  if (variants.length !== 1) return false;
  const v = variants[0], shape = e.structures[v.structureId];
  const names = e.occurrences?.filter((o) => o.componentKey === v.componentKey && o.componentSetKey === v.componentSetKey);
  const expected = shape && (e.occurrenceAddressVersion === 1 ? names?.length === 1 && diagnosticStructure(shape, names[0].namesByPath) : diagnosticStructure(shape, Object.fromEntries(shape.map((n) => [n.path, n.path.split(" / ").slice(-1)[0]]))));
  const observed = diagnosticStructure(ref.nodes, Object.fromEntries(Object.entries(ref.nodeProperties).map(([p, n]) => [p, n.diagnosticName])));
  if (!expected || !observed || stableHash(expected) !== stableHash(observed)) return false;
  const root2 = snapshot.nodes.find((n) => n.id === snapshot.selection[0]);
  return Object.entries(v.properties).every(([p, value]) => p === "raw" && !ref.componentSetKey && !ref.propertyTypes[p] || ref.properties[p] === value && record10(record10(root2?.component).properties)[p] === value);
}
function resolveCollection(snapshot, contract, c, representationId) {
  const result = { missing: [] }, ref = snapshot.variantReference, graph = completeGraph(snapshot);
  if (!graph || snapshot.source?.occurrenceAddressVersion !== 1 || snapshot.source.instanceSourceIdentityVersion !== 1 || !referenceMatchesCatalog(snapshot, contract)) {
    result.missing.push("collection-topology-or-reference-unavailable");
    return result;
  }
  const pathFor = (role) => {
    const targets = contract.facts.targets.filter((t) => t.semanticRole === role && t.resolution === "resolved");
    return targets.length === 1 ? selectedTargetPathHint(targets[0], representationId, ref.componentKey, true)?.split(" / ").slice(1).join(" / ") : void 0;
  };
  const ownerPath = pathFor(c.ownerTargetRole), memberPaths = c.memberTargetRoles.map(pathFor);
  if (ownerPath === void 0 || memberPaths.some((p) => !p || parent2(p) !== ownerPath) || new Set(memberPaths).size !== memberPaths.length) {
    result.missing.push("collection-bindings-unresolved");
    return result;
  }
  const root2 = graph.get(snapshot.selection[0]), rootIdentity = record10(record10(root2.component).identity), expectedRoot = ref.nodeProperties[""]?.identity;
  if (!expectedRoot || unknown3(root2, "component.identity") || rootIdentity.componentKey !== expectedRoot.componentKey || rootIdentity.mainComponentId !== expectedRoot.mainComponentId || (rootIdentity.componentSetKey || "") !== (expectedRoot.componentSetKey || "")) {
    result.missing.push("collection-owner-identity-unproven");
    return result;
  }
  const actualFor = (path, seen = /* @__PURE__ */ new Set()) => {
    if (path === "") return root2;
    if (seen.has(path)) return;
    seen.add(path);
    const expected = ref.nodeProperties[path], expectedParent = actualFor(parent2(path), seen);
    const source = expected?.sourceIdentity;
    if (!expectedParent || !source) return;
    const identity = record10(record10(expectedParent.component).identity);
    const candidates = [...graph.values()].filter((n) => n.parentId === expectedParent.id && (() => {
      const s = record10(record10(n.component).sourceIdentity);
      return !unknown3(n, "component.sourceIdentity") && s.version === 1 && s.sourceNodeId === source.sourceNodeId && s.ownerComponentKey === identity.componentKey && s.ownerMainComponentId === identity.mainComponentId;
    })());
    return candidates.length === 1 ? candidates[0] : void 0;
  };
  const owner = actualFor(ownerPath), expectedOwner = ref.nodeProperties[ownerPath]?.identity;
  const ownerIdentity = record10(record10(owner?.component).identity);
  if (!owner || owner.type !== "INSTANCE" || !expectedOwner || unknown3(owner, "component.identity") || ownerIdentity.componentKey !== expectedOwner.componentKey || ownerIdentity.mainComponentId !== expectedOwner.mainComponentId) {
    result.missing.push("collection-owner-identity-unproven");
    return result;
  }
  result.owner = owner;
  const originalChildren = ref.nodes.filter((n) => n.path && parent2(n.path) === ownerPath);
  if (originalChildren.length !== memberPaths.length || originalChildren.some((n) => n.type !== "INSTANCE" || !memberPaths.includes(n.path))) {
    result.missing.push("collection-members-do-not-cover-reference");
    return result;
  }
  const children = owner.childIds.map((id) => graph.get(id));
  result.actualCount = children.length;
  const issues = [], members = [];
  if (children.length > originalChildren.length) issues.push({ reason: "added-children", ownerNodeId: owner.id, expected: originalChildren.length, actual: children.length });
  if (children.length < originalChildren.length) issues.push({ reason: "missing-children", ownerNodeId: owner.id, expected: originalChildren.length, actual: children.length });
  const expectedBySource = /* @__PURE__ */ new Map();
  for (let i = 0; i < memberPaths.length; i++) {
    const p = memberPaths[i], s = ref.nodeProperties[p]?.sourceIdentity;
    if (!s || s.version !== 1 || s.ownerComponentKey !== ownerIdentity.componentKey || s.ownerMainComponentId !== ownerIdentity.mainComponentId || expectedBySource.has(s.sourceNodeId)) {
      result.missing.push("collection-reference-lineage-unavailable");
      return result;
    }
    expectedBySource.set(s.sourceNodeId, { path: p, role: c.memberTargetRoles[i] });
  }
  const claimed = /* @__PURE__ */ new Set();
  for (const node of children) {
    if (node.type !== "INSTANCE") {
      issues.push({ reason: "foreign-child-type", nodeId: node.id, type: node.type });
      continue;
    }
    const s = record10(record10(node.component).sourceIdentity), identity = record10(record10(node.component).identity);
    if (unknown3(node, "component.sourceIdentity") || s.version !== 1 || typeof s.sourceNodeId !== "string" || s.ownerComponentKey !== ownerIdentity.componentKey || s.ownerMainComponentId !== ownerIdentity.mainComponentId) {
      result.missing.push("collection-member-lineage-unavailable:" + node.id);
      continue;
    }
    const original = expectedBySource.get(s.sourceNodeId);
    if (!original) {
      issues.push({ reason: "foreign-occurrence", nodeId: node.id, sourceNodeId: s.sourceNodeId });
      continue;
    }
    if (claimed.has(s.sourceNodeId)) {
      issues.push({ reason: "duplicate-occurrence", nodeId: node.id, memberRole: original.role, sourceNodeId: s.sourceNodeId });
      continue;
    }
    claimed.add(s.sourceNodeId);
    const expected = ref.nodeProperties[original.path]?.identity;
    if (unknown3(node, "component.identity") || !identity.componentKey || !expected?.componentKey) {
      result.missing.push("collection-member-identity-unavailable:" + node.id);
      continue;
    }
    if (expected.componentSetKey ? identity.componentSetKey !== expected.componentSetKey : identity.componentSetKey || identity.componentKey !== expected.componentKey) {
      issues.push({ reason: "member-family-replaced", nodeId: node.id, memberRole: original.role, expected: expected.componentSetKey || expected.componentKey, actual: identity.componentSetKey || identity.componentKey });
      continue;
    }
    members.push({ role: original.role, node, sourceNodeId: s.sourceNodeId });
  }
  result.members = members;
  result.issues = issues;
  return result;
}
function typedCollectionValue(node, p) {
  const component = record10(node.component), fact2 = "component.properties." + p.property;
  if (unknown3(node, fact2) || unknown3(node, "component.propertyTypes." + p.property) || component.propertyTypes?.[p.property] !== p.propertyType) return void 0;
  const value = component.properties?.[p.property];
  return valueType(p.propertyType, value) ? value : void 0;
}
var collectionPropertyMatches = (node, filter) => {
  const value = typedCollectionValue(node, filter);
  return value === void 0 ? void 0 : filter.values.some((v) => stableHash(v) === stableHash(value));
};
var typedValue = typedCollectionValue;
var matches = collectionPropertyMatches;
function memberCollectionSummary(fact2) {
  const labels = { "added-children": "\u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u043E\u0447\u0435\u0440\u043D\u0438\u0435 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B", "missing-children": "\u0443\u0434\u0430\u043B\u0435\u043D\u044B \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B", "foreign-child-type": "\u043F\u043E\u0441\u0442\u043E\u0440\u043E\u043D\u043D\u0438\u0439 \u0442\u0438\u043F \u0434\u043E\u0447\u0435\u0440\u043D\u0435\u0433\u043E \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430", "foreign-occurrence": "\u043F\u043E\u0441\u0442\u043E\u0440\u043E\u043D\u043D\u044F\u044F occurrence", "duplicate-occurrence": "\u0434\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 occurrence", "member-family-replaced": "\u0441\u0435\u043C\u0435\u0439\u0441\u0442\u0432\u043E member \u043F\u043E\u0434\u043C\u0435\u043D\u0435\u043D\u043E" };
  const reasons = (fact2.violations || []).map((v) => {
    const role = v.memberRole || v.nodeId || "Owner";
    if (v.reason === "count-outside-domain") return `\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E ${v.actual}; \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E ${v.min ?? 0}\u2013${v.max ?? "\u221E"}`;
    if (v.reason === "member-position") return `${role}: \u043F\u043E\u0437\u0438\u0446\u0438\u044F ${v.actualIndex + 1}, \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F ${v.position === "first" ? "\u043F\u0435\u0440\u0432\u0430\u044F" : "\u043F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F"}`;
    if (v.reason === "member-property-domain") return `${role}: ${v.property}=${JSON.stringify(v.actual)}, \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E ${v.expected.map((x) => JSON.stringify(x)).join(", ")}`;
    if (v.reason === "member-host-mapping") return `${role}: ${v.property}=${JSON.stringify(v.actual)}, \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F ${v.hostProperty} \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430=${JSON.stringify(v.expected)}`;
    if (v.reason === "required-host-property") return `\u0412\u043B\u0430\u0434\u0435\u043B\u0435\u0446: ${v.property}=${JSON.stringify(v.actual)}, \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F ${v.expected.map((x) => JSON.stringify(x)).join(", ")}`;
    return `${role}: ${labels[v.reason] || v.reason}${v.actual !== void 0 ? `; \u0441\u0435\u0439\u0447\u0430\u0441 ${v.actual}, \u0438\u0441\u0445\u043E\u0434\u043D\u043E ${v.expected}` : ""}`;
  });
  if (fact2.missing?.length) reasons.push("\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u0445: " + fact2.missing.join("; "));
  return reasons.length ? reasons.join(". ") : fact2.active === false ? "\u0423\u0441\u043B\u043E\u0432\u0438\u0435 \u043A\u043E\u043B\u043B\u0435\u043A\u0446\u0438\u0438 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E; \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F" : `\u0421\u043E\u0441\u0442\u0430\u0432 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D${fact2.count !== void 0 ? `; \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 ${fact2.count}, \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043E ${fact2.selectedCount ?? fact2.count}` : fact2.actualCount !== void 0 ? `; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u043E\u0432 ${fact2.actualCount}` : ""}`;
}
function materializeMemberCollections(snapshot, contract) {
  if (contract.runtimePolicy.memberCollectionsVersion !== 1 || !contract.facts.memberCollections?.length) return;
  const all = {}, ref = snapshot.variantReference;
  for (const entry of contract.facts.memberCollections) {
    const c = entry.collection, fact2 = { assertionKind: entry.collection.assertion.kind, missing: [], evidence: [] };
    all[entry.id] = fact2;
    const reps = ref && contract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && ["universal", snapshot.context.platform].includes(r.platform) && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
    if (!reps || reps.length !== 1) {
      fact2.missing.push("collection-representation-unresolved");
      continue;
    }
    if (!c.representationIds.includes(reps[0].id)) {
      fact2.active = false;
      continue;
    }
    const resolution = resolveCollection(snapshot, contract, c, reps[0].id);
    fact2.missing.push(...resolution.missing);
    fact2.evidence = resolution.issues || [];
    if (resolution.actualCount !== void 0) fact2.actualCount = resolution.actualCount;
    if (!resolution.owner || !resolution.members || !resolution.issues) continue;
    const owner = resolution.owner;
    fact2.ownerNodeId = owner.id;
    if (c.assertion.kind === "membership") {
      fact2.active = true;
      if (resolution.issues.length || !resolution.missing.length) fact2.violations = resolution.issues;
      continue;
    }
    const independentPropertyCheck = ["propertyDomain", "propertyMapping"].includes(c.assertion.kind) && !c.filter && !c.whenHost && !c.whenMember;
    if (resolution.missing.length || resolution.issues.length) {
      fact2.missing.push("collection-membership-unproven");
      if (!independentPropertyCheck) continue;
    }
    let members = resolution.members;
    if (c.visibleOnly) {
      if (members.some((m) => unknown3(m.node, "visible") || unknown3(m.node, "visibility.effective") || typeof record10(m.node.visibility).effective !== "boolean")) {
        fact2.missing.push("collection-visibility-unavailable");
        if (!independentPropertyCheck) continue;
      }
      members = members.filter((m) => !unknown3(m.node, "visible") && !unknown3(m.node, "visibility.effective") && record10(m.node.visibility).effective === true);
    }
    fact2.memberNodeIds = members.map((m) => m.node.id);
    if (fact2.missing.length) fact2.knownCount = members.length;
    else fact2.count = members.length;
    if (c.whenHost) {
      const active = matches(owner, c.whenHost);
      fact2.hostConditionValue = typedValue(owner, c.whenHost);
      if (active === void 0) {
        fact2.missing.push("collection-host-condition-unavailable");
        continue;
      }
      if (!active) {
        fact2.active = false;
        continue;
      }
    }
    if (c.whenMember) {
      const results = members.map((m) => matches(m.node, c.whenMember));
      if (!results.includes(true)) {
        if (results.includes(void 0)) fact2.missing.push("collection-member-condition-unavailable");
        else fact2.active = false;
        continue;
      }
    }
    let selected = members;
    if (c.filter) {
      const results = members.map((m) => matches(m.node, c.filter));
      if (results.includes(void 0)) {
        fact2.missing.push("collection-filter-property-unavailable");
        continue;
      }
      selected = members.filter((_, i) => results[i]);
    }
    fact2.selectedNodeIds = selected.map((m) => m.node.id);
    if (fact2.missing.length) fact2.knownSelectedCount = selected.length;
    else fact2.selectedCount = selected.length;
    const a = c.assertion, violations = [];
    if (a.kind === "hostRequirement" && !selected.length) {
      fact2.active = false;
      continue;
    }
    fact2.active = true;
    if (a.kind === "count") {
      if (a.min !== void 0 && selected.length < a.min || a.max !== void 0 && selected.length > a.max) violations.push({ reason: "count-outside-domain", actual: selected.length, min: a.min, max: a.max });
    } else if (a.kind === "position") {
      if (unknown3(owner, "childIds") || unknown3(owner, "children.order")) {
        fact2.missing.push("collection-order-unavailable");
        continue;
      }
      const edge = members[a.position === "first" ? 0 : members.length - 1];
      fact2.edgeNodeId = edge?.node.id;
      selected.filter((m) => m !== edge).forEach((m) => violations.push({ reason: "member-position", nodeId: m.node.id, memberRole: m.role, position: a.position, actualIndex: members.indexOf(m), edgeNodeId: edge?.node.id }));
    } else if (a.kind === "propertyDomain") {
      const values = selected.map((m) => typedValue(m.node, a));
      fact2.memberValues = values;
      if (values.includes(void 0)) fact2.missing.push("collection-member-property-unavailable");
      selected.forEach((m, i) => {
        if (values[i] !== void 0 && !a.values.some((v) => stableHash(v) === stableHash(values[i]))) violations.push({ reason: "member-property-domain", nodeId: m.node.id, memberRole: m.role, property: a.property, actual: values[i], expected: a.values });
      });
    } else if (a.kind === "propertyMapping") {
      const host = typedValue(owner, { property: a.hostProperty, propertyType: a.hostPropertyType }), values = selected.map((m) => typedValue(m.node, a));
      fact2.hostValue = host;
      fact2.memberValues = values;
      if (host === void 0) {
        fact2.missing.push("collection-mapping-property-unavailable");
        continue;
      }
      if (values.includes(void 0)) fact2.missing.push("collection-mapping-property-unavailable");
      const normalized = values.map((v) => a.transform === "string-to-boolean" ? typeof v === "string" && /^(true|false)$/i.test(v) ? v.toLowerCase() === "true" : void 0 : v);
      if (normalized.some((v, i) => v === void 0 && values[i] !== void 0)) fact2.missing.push("collection-transform-value-unavailable");
      selected.forEach((m, i) => {
        if (normalized[i] !== void 0 && stableHash(normalized[i]) !== stableHash(host)) violations.push({ reason: "member-host-mapping", nodeId: m.node.id, memberRole: m.role, property: a.property, actual: values[i], hostProperty: a.hostProperty, expected: host });
      });
    } else if (a.kind === "hostRequirement") {
      const value = typedValue(owner, a);
      fact2.hostValue = value;
      if (value === void 0) {
        fact2.missing.push("collection-host-property-unavailable");
        continue;
      }
      if (!a.values.some((v) => stableHash(v) === stableHash(value))) violations.push({ reason: "required-host-property", nodeId: owner.id, memberNodeIds: fact2.selectedNodeIds, property: a.property, actual: value, expected: a.values });
    }
    if (violations.length || !fact2.missing.length) fact2.violations = violations;
  }
  for (const node of snapshot.nodes) {
    node.memberCollectionsV1 = all;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "memberCollectionsV1" && !p.startsWith("memberCollectionsV1."));
  }
}

// src/dependency-facts.ts
var record11 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var propertyName = (name) => name.replace(/#[^#]+$/, "");
function identityLockFacts(snapshot, binding, owner, paths, originalReference) {
  const gap = (reason) => ({ reason });
  const knownId = (value) => typeof value === "string" && value.length > 0;
  const unknown12 = (node, fact2) => (node.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + "."));
  const ownerPath = paths.get(String(owner.id));
  const comparison = compareInstanceBoundaries(snapshot, originalReference);
  const boundaries = (snapshot.instanceBoundaries || comparison.boundaries).filter((b) => withinBoundary(ownerPath, b.actualPath)).sort((a, b) => a.actualPath.split(" / ").length - b.actualPath.split(" / ").length);
  let reference = originalReference;
  for (const boundary of boundaries) {
    if (boundary.reason !== "component-variant-changed") return gap("wrapper-lineage-changed");
    const result = snapshot.instanceContentResults?.find((r) => r.boundaryNodeId === boundary.nodeId);
    const attempts = snapshot.instanceContentReferences?.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId) || [];
    if (snapshot.instanceContentReferences?.schemaVersion !== "apollo.instance-content-references.v4" || !result?.lineageProven || attempts.length !== 1 || attempts[0].failure || !attempts[0].reference) return gap("wrapper-lineage-unproven");
    const host = attempts[0].reference;
    reference = captureVariantReference(host, host.source?.componentKey || "", host.source?.componentSetKey || "");
  }
  const portComparison = compareInstanceBoundaries(snapshot, reference, true);
  const referenceOwnerPath = correspondingPath(portComparison, ownerPath);
  if (!portComparison.complete || referenceOwnerPath === void 0) return gap("original-port-unproven");
  const expectedOwner = reference.nodeProperties[referenceOwnerPath], component = record11(owner.component), identity = record11(component.identity);
  if (unknown12(owner, "component.identity.componentKey") || unknown12(owner, "component.identity.componentSetKey") || !knownId(identity.componentKey) || identity.componentKey !== expectedOwner?.identity?.componentKey || (identity.componentSetKey || "") !== (expectedOwner?.identity?.componentSetKey || "")) return gap("wrapper-identity-unproven");
  const nearestActualOwner = (node) => {
    const seen = /* @__PURE__ */ new Set();
    let parentId = node.parentId;
    while (parentId && !seen.has(String(parentId))) {
      seen.add(String(parentId));
      const parent3 = snapshot.nodes.find((n) => n.id === parentId);
      if (!parent3) return void 0;
      if (parent3.type === "INSTANCE") return parent3;
      parentId = parent3.parentId;
    }
    return void 0;
  };
  const nearestReferenceOwner = (path) => {
    let parent3 = path.split(" / ").slice(0, -1).join(" / ");
    while (parent3) {
      if (reference.nodes.some((n) => n.path === parent3 && n.type === "INSTANCE")) return parent3;
      parent3 = parent3.split(" / ").slice(0, -1).join(" / ");
    }
    return "";
  };
  const actual = snapshot.nodes.filter((n) => n.type === "INSTANCE" && nearestActualOwner(n) === owner && typeof record11(record11(n.component).propertyReferenceBindings).mainComponent === "string" && binding.portNames.includes(propertyName(record11(record11(n.component).propertyReferenceBindings).mainComponent)));
  const expected = reference.nodes.filter((n) => n.type === "INSTANCE" && nearestReferenceOwner(n.path) === referenceOwnerPath && typeof reference.nodeProperties[n.path]?.propertyReferenceBindings?.mainComponent === "string" && binding.portNames.includes(propertyName(reference.nodeProperties[n.path].propertyReferenceBindings.mainComponent)));
  if (actual.length !== 1 || expected.length !== 1) return gap("swap-consumer-unresolved");
  const asset = record11(actual[0].component), assetIdentity = record11(asset.identity), expectedAsset = reference.nodeProperties[expected[0].path];
  if (!expectedAsset.identity) return gap("original-port-unproven");
  const port = record11(asset.propertyReferenceBindings).mainComponent;
  if (["component.identity.componentKey", "component.identity.mainComponentId", "component.propertyReferenceBindings.mainComponent"].some((f) => unknown12(actual[0], f)) || ["component.properties." + port, "component.propertyTypes." + port].some((f) => unknown12(owner, f)) || record11(component.propertyTypes)[port] !== "INSTANCE_SWAP" || expectedOwner.propertyTypes[port] !== "INSTANCE_SWAP" || expectedAsset.propertyReferenceBindings?.mainComponent !== port || !knownId(assetIdentity.mainComponentId) || record11(component.properties)[port] !== assetIdentity.mainComponentId || !knownId(assetIdentity.componentKey) || !knownId(expectedAsset.identity?.componentKey) || !knownId(expectedAsset.identity?.mainComponentId) || expectedOwner.properties[port] !== expectedAsset.identity.mainComponentId) return gap("original-port-unproven");
  if (assetIdentity.componentKey === expectedAsset.identity.componentKey && (unknown12(actual[0], "component.identity.componentSetKey") || (assetIdentity.componentSetKey || "") !== (expectedAsset.identity.componentSetKey || ""))) return gap("asset-identity-conflict");
  if (record11(actual[0].visibility).effective === false) return { applicable: false, reason: "icon-hidden" };
  if (record11(actual[0].visibility).effective !== true) return gap("icon-visibility-unavailable");
  return {
    applicable: true,
    changed: assetIdentity.componentKey !== expectedAsset.identity.componentKey,
    componentKey: assetIdentity.componentKey,
    referenceComponentKey: expectedAsset.identity.componentKey
  };
}
function materializeDependencyFacts(snapshot, contract) {
  const bindings = contract.facts.dependencyBindings || [];
  const root2 = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  const paths = snapshotPaths(snapshot);
  const reference = snapshot.variantReference;
  const comparison = reference ? compareInstanceBoundaries(snapshot, reference) : void 0;
  const membership = /* @__PURE__ */ new Map();
  for (const catalog of contract.facts.variantEvidence?.assetCatalogs || []) for (const m of catalog.members) {
    membership.set(m.componentKey, [...membership.get(m.componentKey) || [], { catalog: catalog.catalog, library: catalog.library, componentSetKey: m.componentSetKey }]);
  }
  const facts = {};
  for (const b of bindings) {
    const f = {};
    facts[b.id] = f;
    const lockRequired = contract.rules.some((r) => record11(record11(r.assert).actual).fact === `dependencies.${b.id}.changed`);
    if ((b.identityLock || lockRequired) && (b.identityLock !== true || contract.runtimePolicy.assetIdentityLockVersion !== 1)) {
      f.reason = "asset-identity-lock-version-unavailable";
      continue;
    }
    if (b.subjectCondition) {
      if (contract.runtimePolicy.dependencySubjectConditionsVersion !== 1) {
        f.reason = "dependency-subject-condition-version-unavailable";
        continue;
      }
      const targets2 = snapshot.nodes.filter((n) => record11(n.semantic).role === b.targetRole);
      const available = record11(record11(root2[0]?.variantAvailability).targets)[b.targetRole];
      if (targets2.length !== 1 || available?.present !== true) {
        f.reason = "dependency-subject-unproven";
        continue;
      }
      const matched = collectionPropertyMatches(targets2[0], b.subjectCondition);
      f.subjectValue = typedCollectionValue(targets2[0], b.subjectCondition);
      if (matched === void 0) {
        f.reason = "dependency-subject-property-unavailable";
        continue;
      }
      f.subjectMatches = matched;
      if (!matched) {
        f.applicable = false;
        f.reason = "dependency-subject-condition-inactive";
        continue;
      }
    }
    if (b.contractDependencyId) {
      const dependency = contract.componentDependencies?.find((d) => d.id === b.contractDependencyId);
      const binding = dependency?.bindings.find((d) => d.targetRole === b.targetRole && d.relativePath === b.relativePath);
      if (!dependency || !binding || dependency.issue) {
        f.reason = dependency?.issue || "dependency-binding-missing";
        continue;
      }
      const result = resolveFixedNestedBinding(snapshot, dependency, binding, false, contract);
      f.reason = result.reason;
      if (result.status === "inactive") f.applicable = false;
      if (result.status !== "active" || !result.node) continue;
      if (!result.identityValid) {
        f.reason = "dependency-child-identity-mismatch";
        continue;
      }
      f.applicable = true;
      const node = result.node, component2 = record11(node.component), identity2 = record11(component2.identity);
      if (identity2.componentKey) f.componentKey = identity2.componentKey;
      if (identity2.componentSetKey) f.componentSetKey = identity2.componentSetKey;
      if (b.variantProperty) {
        const value = component2.properties?.[b.variantProperty];
        const unavailable = (node.unknownFacts || []).some((p) => [`component.properties.${b.variantProperty}`, `component.propertyTypes.${b.variantProperty}`].some((input) => input === p || input.startsWith(p + ".")));
        if (!unavailable && component2.propertyTypes?.[b.variantProperty] === "VARIANT" && typeof value === "string" && value.trim()) f.variantProperty = value;
        else f.reason = "dependency-variant-property-unavailable";
      }
      for (const dim of ["width", "height"]) if (typeof record11(node.bounds)[dim] === "number" && Number.isFinite(record11(node.bounds)[dim])) f[dim] = record11(node.bounds)[dim];
      continue;
    }
    if (root2.length !== 1 || !paths || snapshot.source?.truncated || !comparison?.complete) {
      f.reason = "reference-or-topology-unavailable";
      continue;
    }
    const availability = record11(record11(root2[0].variantAvailability).targets)[b.targetRole];
    if (availability?.present === false) {
      f.applicable = false;
      f.reason = "target-absent-in-variant";
      continue;
    }
    const targets = snapshot.nodes.filter((n) => record11(n.semantic).role === b.targetRole);
    if (targets.length !== 1 || availability?.present !== true) {
      f.reason = "target-unresolved";
      continue;
    }
    const target = targets[0];
    if (record11(target.visibility).effective === false) {
      f.applicable = false;
      f.reason = "target-hidden";
      continue;
    }
    if (record11(target.visibility).effective !== true) {
      f.reason = "visibility-unavailable";
      continue;
    }
    const targetPath = b.identityLock ? paths.get(String(target.id)) : correspondingPath(comparison, paths.get(String(target.id)));
    const path = [targetPath, b.relativePath].filter(Boolean).join(" / ");
    const matches2 = snapshot.nodes.filter((n) => (b.identityLock ? paths.get(String(n.id)) : correspondingPath(comparison, paths.get(String(n.id)))) === path);
    if (matches2.length !== 1 || matches2[0].type !== "INSTANCE") {
      f.reason = "nested-instance-unresolved";
      continue;
    }
    const owner = matches2[0], component = record11(owner.component), identity = record11(component.identity);
    if (b.identityLock) {
      Object.assign(f, identityLockFacts(snapshot, b, owner, paths, reference));
      continue;
    }
    if (!b.portNames.length) {
      f.applicable = true;
      if (typeof identity.componentKey === "string" && identity.componentKey && typeof identity.componentSetKey === "string" && identity.componentSetKey) {
        f.componentSetKey = identity.componentSetKey;
        f.componentKey = identity.componentKey;
      } else f.reason = "component-identity-unavailable";
      continue;
    }
    let portReference = reference;
    const wrapperBoundary = comparison.boundaries.find((boundary2) => withinBoundary(paths.get(String(owner.id)), boundary2.actualPath));
    if (wrapperBoundary) {
      const resolved = snapshot.instanceContentResults?.find((r) => r.boundaryNodeId === wrapperBoundary.nodeId && (r.status === "matched" || snapshot.instanceContentReferences?.schemaVersion === "apollo.instance-content-references.v4" && r.lineageProven));
      const attempts = snapshot.instanceContentReferences?.attempts.filter((a) => a.boundaryNodeId === wrapperBoundary.nodeId) || [];
      const host = attempts.length === 1 && !attempts[0].failure ? attempts[0].reference : void 0;
      if (wrapperBoundary.reason !== "component-variant-changed" || wrapperBoundary.nodeId !== owner.id || !resolved || !host) {
        f.reason = "wrapper-lineage-changed";
        continue;
      }
      portReference = captureVariantReference(host, host.source?.componentKey || "", host.source?.componentSetKey || "");
    }
    let properties = Object.entries(record11(component.propertyTypes)).filter(([p, t]) => t === "INSTANCE_SWAP" && b.portNames.includes(propertyName(p))).map(([p]) => p);
    const ownerFor = (node) => {
      const seen = /* @__PURE__ */ new Set();
      let current = node;
      while (current.parentId && !seen.has(String(current.parentId))) {
        seen.add(String(current.parentId));
        const parent3 = snapshot.nodes.find((n) => n.id === current.parentId);
        if (!parent3) return void 0;
        if (parent3.type === "INSTANCE") return parent3;
        current = parent3;
      }
      return void 0;
    };
    if (["apollo.instance-content-references.v3", "apollo.instance-content-references.v4"].includes(snapshot.instanceContentReferences?.schemaVersion || "")) {
      const binding = (n) => record11(record11(n.component).propertyReferenceBindings).mainComponent;
      const actualConsumers = snapshot.nodes.filter((n) => n.type === "INSTANCE" && ownerFor(n) === owner && typeof binding(n) === "string" && b.portNames.includes(propertyName(binding(n))));
      const referenceOwner = (p) => {
        let parent3 = p.split(" / ").slice(0, -1).join(" / ");
        while (parent3) {
          if (portReference.nodes.some((n) => n.path === parent3 && n.type === "INSTANCE")) return parent3;
          parent3 = parent3.split(" / ").slice(0, -1).join(" / ");
        }
        return "";
      };
      const referenceConsumers = portReference.nodes.filter((n) => n.type === "INSTANCE" && referenceOwner(n.path) === path && typeof portReference.nodeProperties[n.path]?.propertyReferenceBindings?.mainComponent === "string" && b.portNames.includes(propertyName(portReference.nodeProperties[n.path].propertyReferenceBindings.mainComponent)));
      if (!actualConsumers.length && !referenceConsumers.length) {
        f.applicable = false;
        f.reason = "no-icon-port-in-variant";
        continue;
      }
      if (actualConsumers.length !== 1 || referenceConsumers.length !== 1) {
        f.reason = "swap-consumer-unresolved";
        continue;
      }
      const property2 = binding(actualConsumers[0]);
      const original2 = portReference.nodeProperties[referenceConsumers[0].path], originalOwner = portReference.nodeProperties[path];
      if (!properties.includes(property2) || original2.propertyReferenceBindings?.mainComponent !== property2 || originalOwner?.propertyTypes[property2] !== "INSTANCE_SWAP" || !original2.identity?.mainComponentId || originalOwner.properties[property2] !== original2.identity.mainComponentId) {
        f.reason = "original-port-unproven";
        continue;
      }
      properties = [property2];
    }
    if (!properties.length) {
      const original2 = portReference.nodeProperties[path];
      const referenceHasPort = Object.entries(original2?.propertyTypes || {}).some(([p, t]) => t === "INSTANCE_SWAP" && b.portNames.includes(propertyName(p)));
      if (!original2 || referenceHasPort) f.reason = "swap-port-evidence-unavailable";
      else {
        f.applicable = false;
        f.reason = "no-icon-port-in-variant";
      }
      continue;
    }
    if (properties.length !== 1) {
      f.reason = "ambiguous-swap-port";
      continue;
    }
    const property = properties[0];
    const consumers = snapshot.nodes.filter((n) => n.type === "INSTANCE" && ownerFor(n) === owner && record11(record11(n.component).propertyReferenceBindings).mainComponent === property);
    if (consumers.length !== 1) {
      f.reason = "swap-consumer-unresolved";
      continue;
    }
    const icon = consumers[0], iconIdentity = record11(record11(icon.component).identity);
    if (!iconIdentity.mainComponentId || record11(component.properties)[property] !== iconIdentity.mainComponentId || !iconIdentity.componentKey) {
      f.reason = "swap-binding-unproven";
      continue;
    }
    if (record11(icon.visibility).effective === false) {
      f.applicable = false;
      f.reason = "icon-hidden";
      continue;
    }
    if (record11(icon.visibility).effective !== true) {
      f.reason = "icon-visibility-unavailable";
      continue;
    }
    const boundary = (snapshot.instanceBoundaries || comparison.boundaries).find((b2) => b2.nodeId === String(icon.id));
    const portComparison = snapshot.source?.instanceIdentityVersion === 1 ? compareInstanceBoundaries(snapshot, portReference, true) : void 0;
    const iconPath = correspondingPath(portComparison, paths.get(String(icon.id)));
    const original = boundary ? portReference.nodeProperties[boundary.referencePath] : iconPath !== void 0 ? portReference.nodeProperties[iconPath] : void 0;
    if (original?.propertyReferenceBindings?.mainComponent !== property || !original.identity?.componentKey) {
      f.reason = "original-port-unproven";
      continue;
    }
    f.applicable = true;
    f.changed = iconIdentity.componentKey !== original.identity.componentKey;
    f.componentKey = iconIdentity.componentKey;
    f.referenceComponentKey = original.identity.componentKey;
    if (b.variantProperty) {
      const asset = record11(icon.component), value = record11(asset.properties)[b.variantProperty];
      const unavailable = (icon.unknownFacts || []).some((p) => [`component.properties.${b.variantProperty}`, `component.propertyTypes.${b.variantProperty}`].some((f2) => f2 === p || f2.startsWith(`${p}.`)));
      if (!unavailable && record11(asset.propertyTypes)[b.variantProperty] === "VARIANT" && typeof value === "string" && value.trim()) f.variantProperty = value;
      else f.reason = "asset-variant-property-unavailable";
    }
    if (b.metrics) {
      f.portName = propertyName(property);
      for (const dimension of ["width", "height"]) {
        const value = record11(icon.bounds)[dimension];
        if (typeof value === "number" && Number.isFinite(value) && value > 0) f[dimension] = value;
      }
    }
    const entries = membership.get(iconIdentity.componentKey) || [];
    const catalogs = [...new Set(entries.map((m) => m.catalog))];
    if (catalogs.length === 1 && new Set(entries.map((m) => m.library)).size === 1 && entries.every((m) => m.componentSetKey === iconIdentity.componentSetKey)) f.catalog = catalogs[0];
    else f.reason = entries.length ? "catalog-identity-conflict" : "catalog-key-unknown";
  }
  for (const node of snapshot.nodes) {
    node.dependencies = facts;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "dependencies" && !p.startsWith("dependencies."));
  }
}

// src/host-context-variable-modes.ts
var record12 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var object = (v) => Boolean(v && typeof v === "object" && !Array.isArray(v));
var unknown4 = (n, fact2) => (n.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + ".") || p.startsWith(fact2 + "."));
function tokenIds(values) {
  const ids = /* @__PURE__ */ new Set();
  let complete = true;
  const add = (id) => {
    if (typeof id === "string" && id.trim()) ids.add(id);
    else complete = false;
  };
  const visit = (v) => {
    if (Array.isArray(v)) {
      v.forEach(visit);
      return;
    }
    if (!v || typeof v !== "object") return;
    for (const [key, value] of Object.entries(v)) {
      if (key === "tokenId" && value !== null) add(value);
      else if (key === "tokenIds") {
        if (Array.isArray(value)) value.forEach(add);
        else complete = false;
      } else if (key === "id" && record12(v).type === "VARIABLE_ALIAS") add(value);
      else visit(value);
    }
    if (record12(v).type === "VARIABLE_ALIAS" && !Object.prototype.hasOwnProperty.call(v, "id")) complete = false;
  };
  values.forEach(visit);
  return { ids: Array.from(ids).sort(), complete };
}
function hostContextFacts(node) {
  const usage = record12(node.hostVariableUsageV1), variable = record12(node.variable);
  if (usage.version !== 1 || usage.complete !== true || !object(usage.bindings) || !object(variable.bindings) || !object(variable.modes) || !object(variable.modeCatalog) || unknown4(node, "hostVariableUsageV1") || unknown4(node, "variable.bindings")) return;
  const tokens = tokenIds([variable.bindings, node.appearance, node.textFillEvidenceV1]);
  if (!tokens.complete || tokens.ids.some((id) => !Object.prototype.hasOwnProperty.call(usage.bindings, id))) return;
  const checked = /* @__PURE__ */ new Set(), visiting = /* @__PURE__ */ new Set();
  const validChain = (id, depth) => {
    if (visiting.has(id) || depth > 16) return false;
    if (checked.has(id)) return true;
    const refs2 = record12(usage.bindings[id]).referencedVariableIds;
    if (!Array.isArray(refs2)) return false;
    visiting.add(id);
    if (refs2.some((alias) => typeof alias !== "string" || !Object.prototype.hasOwnProperty.call(usage.bindings, alias) || !validChain(alias, depth + 1))) return false;
    visiting.delete(id);
    checked.add(id);
    return true;
  };
  if (Object.keys(usage.bindings).length > 128 || Object.keys(usage.bindings).some((id) => !validChain(id, 0))) return;
  const modes = {}, catalog = {};
  const ids = /* @__PURE__ */ new Map();
  for (const binding of Object.values(usage.bindings)) {
    const collection = record12(binding), key = collection.collectionKey, id = collection.collectionId;
    if (typeof key !== "string" || !/^[a-f0-9]{40}$/i.test(key) || typeof id !== "string" || !id || ids.has(key) && ids.get(key) !== id) return;
    if (!Array.isArray(collection.referencedVariableIds) || collection.referencedVariableIds.some((alias) => typeof alias !== "string" || !Object.prototype.hasOwnProperty.call(usage.bindings, alias))) return;
    ids.set(key, id);
    const mode = variable.modes[key], entry = record12(variable.modeCatalog[key]);
    if (unknown4(node, `variable.modes.${key}`) || unknown4(node, `variable.modeCatalog.${key}`) || typeof mode !== "string" || record12(node.resolvedModes)[id] !== mode || entry.collectionId !== id || !Array.isArray(entry.modes) || entry.modes.filter((m) => m?.modeId === mode).length !== 1) return;
    modes[key] = mode;
    catalog[key] = entry;
  }
  const facts = JSON.parse(JSON.stringify(effectiveFacts(node)));
  facts.variable = Object.assign({}, variable, { modes, modeCatalog: catalog });
  facts.hostVariableUsageV1 = usage;
  return facts;
}

// src/nested-instance-content-reference.ts
var INSTANCE_CONTENT_REFERENCE_LIMIT = 8;
var record13 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var clone = (v) => JSON.parse(JSON.stringify(v));
var referenceFor = (s) => captureVariantReference(s, s.source?.componentKey || "", s.source?.componentSetKey || "");
var nodesByPath = (s) => {
  const paths = snapshotPaths(s);
  return paths && new Map(s.nodes.map((n) => [paths.get(String(n.id)), n]));
};
function materializeNestedInstanceContentReferences(snapshot) {
  const evidence = snapshot.instanceContentReferences;
  const actual = nodesByPath(snapshot), original = snapshot.variantReference;
  const results = [];
  snapshot.instanceContentResults = results;
  const comparison = original && compareInstanceBoundaries(snapshot, original, true);
  const roots = comparison?.complete ? comparison.boundaries : [];
  snapshot.instanceBoundaries = [...roots];
  const base = evidence.base;
  const baseRef = base && captureVariantReference(base, base.source?.componentKey || "", base.source?.componentSetKey || "", original?.definedProperties);
  const baseValid = actual && original?.complete && baseRef?.complete && base.source?.rootNodeId && base.source.rootNodeId !== snapshot.source?.rootNodeId && stableHash(baseRef) === stableHash(original) && base.context.platform === snapshot.context.platform && stableHash(base.context.modes) === stableHash(snapshot.context.modes);
  let visited = 0;
  const visit = (boundary, context, parentId) => {
    const result = { boundaryNodeId: boundary.nodeId, status: "unresolved", reason: "reference-not-captured", matchedNodeIds: [] };
    results.push(result);
    if (actual) {
      for (const [path, node] of actual) if (withinBoundary(path, boundary.actualPath)) {
        node.baseline = { effective: {} };
        node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
        if (node.semantic) delete record13(node.semantic).role;
      }
    }
    const fail = (reason) => {
      result.reason = reason;
      return result;
    };
    if (++visited > INSTANCE_CONTENT_REFERENCE_LIMIT) return fail("reference-capture-limit");
    if (!baseValid) return fail("original-host-evidence-invalid");
    if (evidence.hostContextVariableModesVersion !== void 0 && evidence.hostContextVariableModesVersion !== 1) return fail("host-context-mode-version-unsupported");
    const variant = boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
    if (!boundary.actualComponentKey || !variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) return fail("explicit-swap-port-required");
    const attempts = evidence.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId);
    if (attempts.length !== 1) return fail(attempts.length ? "ambiguous-reference" : "reference-not-captured");
    const attempt = attempts[0], reference = attempt.reference;
    if (attempt.parentBoundaryNodeId !== parentId) return fail("reference-parent-mismatch");
    if (attempt.failure || !reference) return fail(attempt.failure || "reference-not-captured");
    if (variant && attempt.strategy !== "pristine-host-variant-properties") return fail("variant-capture-strategy-unproven");
    const expected = nodesByPath(reference), contextNodes = nodesByPath(context);
    const refId = reference.source?.rootNodeId;
    if (!expected || !contextNodes || !refId || refId === snapshot.source?.rootNodeId || refId === base.source?.rootNodeId || refId === context.source?.rootNodeId || reference.context.platform !== snapshot.context.platform || stableHash(reference.context.modes) !== stableHash(snapshot.context.modes)) return fail("replacement-reference-incomplete");
    const change = compareInstanceBoundaries(reference, referenceFor(context), true), refBoundary = change.boundaries[0];
    if (!change.complete || change.boundaries.length !== 1 || refBoundary.reason !== boundary.reason || refBoundary.referencePath !== boundary.referencePath || refBoundary.ownerPath !== boundary.ownerPath || refBoundary.property !== boundary.property || refBoundary.actualComponentKey !== boundary.actualComponentKey || refBoundary.componentSetKey !== boundary.componentSetKey) return fail("replacement-identity-or-port-mismatch");
    for (const [path, node] of contextNodes) {
      if (withinBoundary(path, boundary.referencePath)) continue;
      const other = expected.get(path);
      if (!other) return fail("host-context-changed");
      const before = evidence.hostContextVariableModesVersion === 1 ? hostContextFacts(node) : clone(effectiveFacts(node));
      const after = evidence.hostContextVariableModesVersion === 1 ? hostContextFacts(other) : clone(effectiveFacts(other));
      if (!before || !after) return fail("host-context-variable-evidence-incomplete");
      if (!variant && path === boundary.ownerPath && boundary.property) {
        delete record13(record13(before.component).properties)[boundary.property];
        delete record13(record13(after.component).properties)[boundary.property];
      }
      if (stableHash(before) !== stableHash(after)) return fail("host-context-changed");
    }
    const remainder = compareInstanceBoundaries(snapshot, referenceFor(reference), true);
    if (!remainder.complete) return fail("replacement-structure-needs-remap");
    const children = remainder.boundaries.filter((b) => withinBoundary(b.actualPath, boundary.actualPath));
    if (children.some((b) => b.actualPath === boundary.actualPath)) return fail("replacement-nested-identity-unresolved");
    const pairs = [];
    for (const [path, node] of actual) {
      if (!withinBoundary(path, boundary.actualPath) || children.some((b) => withinBoundary(path, b.actualPath))) continue;
      const relative = path.slice(boundary.actualPath.length);
      const referencePath = remainder.referencePaths ? correspondingPath(remainder, path) : refBoundary.actualPath + relative;
      const other = referencePath !== void 0 ? expected.get(referencePath) : void 0;
      if (!other || other.type !== node.type) return fail("replacement-structure-needs-remap");
      if (node.type === "INSTANCE") {
        const a = record13(record13(node.component).identity), b = record13(record13(other.component).identity);
        if (!a.componentKey || a.componentKey !== b.componentKey || (a.componentSetKey || "") !== (b.componentSetKey || "")) return fail("replacement-nested-identity-unresolved");
      }
      pairs.push([path, node, other]);
    }
    if (variant) {
      const props = (n) => {
        const c = record13(n?.component);
        return Object.fromEntries(Object.entries(record13(c.propertyTypes)).filter(([, t]) => t === "VARIANT").map(([p]) => [p, record13(c.properties)[p]]));
      };
      const expectedProperties = props(expected.get(refBoundary.actualPath));
      if (!Object.keys(expectedProperties).length || stableHash(props(actual.get(boundary.actualPath))) !== stableHash(expectedProperties)) return fail("variant-properties-mismatch");
    }
    result.lineageProven = true;
    for (const [path, node, other] of pairs) {
      node.baseline = { effective: clone(effectiveFacts(
        other,
        snapshot.source?.geometryCaptureVersion === 1 && reference.source?.geometryCaptureVersion === 1
      )) };
      if (variant && path === boundary.actualPath) {
        const originalComponent = record13(contextNodes.get(boundary.referencePath)?.component), current = record13(node.component);
        const baseline = record13(record13(record13(node.baseline).effective).component), available = record13(record13(node.variantAvailability).componentProperties);
        for (const [name, type] of Object.entries(record13(current.propertyTypes))) {
          if (type !== "VARIANT" || record13(originalComponent.propertyTypes)[name] !== "VARIANT" || !Object.prototype.hasOwnProperty.call(record13(originalComponent.properties), name)) continue;
          record13(baseline.properties)[name] = originalComponent.properties[name];
          available[propertyAvailabilityKey(name)] = true;
          node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== `variantAvailability.componentProperties.${propertyAvailabilityKey(name)}`);
        }
        if (node.variantAvailability) record13(node.variantAvailability).componentProperties = available;
      }
      node.baselineProvenance = {
        status: "matched",
        kind: variant ? "independent-host-variant" : "independent-host-swap",
        boundaryNodeId: boundary.nodeId,
        componentKey: boundary.actualComponentKey,
        ownerPath: boundary.ownerPath,
        property: boundary.property,
        ...variant ? { componentSetKey: boundary.componentSetKey } : {},
        referencePath: remainder.referencePaths ? correspondingPath(remainder, path) : refBoundary.actualPath + path.slice(boundary.actualPath.length)
      };
      result.matchedNodeIds.push(String(node.id));
    }
    let complete = true;
    for (const child of children) {
      snapshot.instanceBoundaries.push(child);
      const childResult = visit(child, reference, boundary.nodeId);
      complete = complete && childResult.status === "matched";
      result.matchedNodeIds.push(...childResult.matchedNodeIds);
    }
    result.status = complete ? "matched" : "partial";
    result.reason = complete ? variant ? "independent-host-variant-reference" : "independent-host-swap-reference" : "nested-content-reference-unresolved";
    return result;
  };
  for (const boundary of roots) visit(boundary, base);
}

// src/instance-content-reference.ts
var record14 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var clone2 = (v) => JSON.parse(JSON.stringify(v));
function planInstanceContentReferences(snapshot) {
  if (!snapshot.variantReference) return [];
  const comparison = compareInstanceBoundaries(snapshot, snapshot.variantReference);
  return comparison.complete ? comparison.boundaries : [];
}
function byPath(snapshot) {
  const paths = snapshotPaths(snapshot);
  return paths && new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
}
function subtree(nodes, root2) {
  return new Map([...nodes].filter(([p]) => withinBoundary(p, root2)).map(([p, n]) => [p === root2 ? "" : p.slice(root2.length + 3), n]));
}
function materializeInstanceContentReferences(snapshot) {
  const evidence = snapshot.instanceContentReferences;
  if (!evidence) return;
  if (evidence.schemaVersion === "apollo.instance-content-references.v4") {
    materializeNestedInstanceContentReferences(snapshot);
    return;
  }
  const boundaries = planInstanceContentReferences(snapshot);
  const results = [];
  snapshot.instanceContentResults = results;
  const original = snapshot.variantReference;
  const actualNodes = byPath(snapshot);
  const base = evidence.base;
  const baseNodes = base && byPath(base);
  const baseReference = base && captureVariantReference(
    base,
    base.source?.componentKey || "",
    base.source?.componentSetKey || "",
    original?.definedProperties
  );
  const nestedVariants = ["apollo.instance-content-references.v2", "apollo.instance-content-references.v3"].includes(evidence.schemaVersion);
  const baseValid = (evidence.schemaVersion === "apollo.instance-content-references.v1" || nestedVariants) && actualNodes && baseNodes && original?.complete && baseReference?.complete && base.source?.rootNodeId && base.source.rootNodeId !== snapshot.source?.rootNodeId && stableHash(baseReference) === stableHash(original) && stableHash(base.context.modes) === stableHash(snapshot.context.modes) && base.context.platform === snapshot.context.platform;
  for (const boundary of boundaries) {
    const result = { boundaryNodeId: boundary.nodeId, status: "unresolved", reason: "reference-not-captured", matchedNodeIds: [] };
    results.push(result);
    if (actualNodes) for (const node of subtree(actualNodes, boundary.actualPath).values()) {
      node.baseline = { effective: {} };
      node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
      if (node.semantic && typeof node.semantic === "object") delete record14(node.semantic).role;
    }
    if (!baseValid) {
      result.reason = "original-host-evidence-invalid";
      continue;
    }
    const variant = nestedVariants && boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
    if (!boundary.actualComponentKey || !variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) {
      result.reason = "explicit-swap-port-required";
      continue;
    }
    const attempts = evidence.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId);
    if (attempts.length !== 1) {
      result.reason = attempts.length ? "ambiguous-reference" : "reference-not-captured";
      continue;
    }
    const attempt = attempts[0], reference = attempt.reference;
    if (attempt.failure || !reference) {
      result.reason = attempt.failure || "reference-not-captured";
      continue;
    }
    if (variant && evidence.schemaVersion === "apollo.instance-content-references.v3" && attempt.strategy !== "pristine-host-variant-properties") {
      result.reason = "variant-capture-strategy-unproven";
      continue;
    }
    const refNodes = byPath(reference);
    const independent = reference.source?.rootNodeId && reference.source.rootNodeId !== snapshot.source?.rootNodeId && reference.source.rootNodeId !== base.source?.rootNodeId;
    if (!independent || !refNodes || stableHash(reference.context.modes) !== stableHash(snapshot.context.modes) || reference.context.platform !== snapshot.context.platform) {
      result.reason = "replacement-reference-incomplete";
      continue;
    }
    const comparison = compareInstanceBoundaries(reference, original, nestedVariants);
    const refBoundary = comparison.boundaries[0];
    if (!comparison.complete || comparison.boundaries.length !== 1 || refBoundary.reason !== boundary.reason || refBoundary.referencePath !== boundary.referencePath || refBoundary.ownerPath !== boundary.ownerPath || refBoundary.property !== boundary.property || refBoundary.actualComponentKey !== boundary.actualComponentKey || refBoundary.componentSetKey !== boundary.componentSetKey) {
      result.reason = "replacement-identity-or-port-mismatch";
      continue;
    }
    let hostIntact = true;
    for (const [path, node] of baseNodes) {
      if (withinBoundary(path, boundary.referencePath)) continue;
      const other = refNodes.get(path);
      if (!other) {
        hostIntact = false;
        break;
      }
      const expected2 = clone2(effectiveFacts(node)), observed = clone2(effectiveFacts(other));
      if (!variant && path === boundary.ownerPath && boundary.property) {
        delete record14(record14(expected2.component).properties)[boundary.property];
        delete record14(record14(observed.component).properties)[boundary.property];
      }
      if (stableHash(expected2) !== stableHash(observed)) {
        hostIntact = false;
        break;
      }
    }
    if (!hostIntact) {
      result.reason = "host-context-changed";
      continue;
    }
    const actual = subtree(actualNodes, boundary.actualPath), expected = subtree(refNodes, refBoundary.actualPath);
    const shape = (nodes) => [...nodes].map(([p, n]) => [p, n.type]).sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    if (stableHash(shape(actual)) !== stableHash(shape(expected))) {
      result.reason = "replacement-structure-needs-remap";
      continue;
    }
    const identityKnown = [...actual].every(([path, node]) => {
      if (node.type !== "INSTANCE") return true;
      const a = record14(record14(node.component).identity), b = record14(record14(expected.get(path)?.component).identity);
      return Boolean(a.componentKey && b.componentKey && a.componentKey === b.componentKey && (a.componentSetKey || "") === (b.componentSetKey || ""));
    });
    if (!identityKnown) {
      result.reason = "replacement-nested-identity-unresolved";
      continue;
    }
    if (variant) {
      const variantProperties = (node) => {
        const component = record14(node?.component);
        return Object.fromEntries(Object.entries(record14(component.propertyTypes)).filter(([, type]) => type === "VARIANT").map(([name]) => [name, record14(component.properties)[name]]));
      };
      const expectedProperties = variantProperties(expected.get(""));
      if (!Object.keys(expectedProperties).length || stableHash(variantProperties(actual.get(""))) !== stableHash(expectedProperties)) {
        result.reason = "variant-properties-mismatch";
        continue;
      }
    }
    for (const [path, node] of actual) {
      node.baseline = { effective: clone2(effectiveFacts(
        expected.get(path),
        snapshot.source?.geometryCaptureVersion === 1 && reference.source?.geometryCaptureVersion === 1
      )) };
      if (variant && path === "") {
        const originalComponent = record14(baseNodes.get(boundary.referencePath)?.component);
        const current = record14(node.component), baseline = record14(record14(record14(node.baseline).effective).component);
        const available = record14(record14(node.variantAvailability).componentProperties);
        for (const [name, type] of Object.entries(record14(current.propertyTypes))) {
          if (type !== "VARIANT" || record14(originalComponent.propertyTypes)[name] !== "VARIANT" || !Object.prototype.hasOwnProperty.call(record14(originalComponent.properties), name)) continue;
          record14(baseline.properties)[name] = originalComponent.properties[name];
          available[propertyAvailabilityKey(name)] = true;
          node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== `variantAvailability.componentProperties.${propertyAvailabilityKey(name)}`);
        }
        if (node.variantAvailability) record14(node.variantAvailability).componentProperties = available;
      }
      node.baselineProvenance = {
        status: "matched",
        kind: variant ? "independent-host-variant" : "independent-host-swap",
        boundaryNodeId: boundary.nodeId,
        componentKey: boundary.actualComponentKey,
        ownerPath: boundary.ownerPath,
        property: boundary.property,
        ...variant ? { componentSetKey: boundary.componentSetKey } : {},
        referencePath: [refBoundary.actualPath, path].filter(Boolean).join(" / ")
      };
      result.matchedNodeIds.push(String(node.id));
    }
    result.status = "matched";
    result.reason = variant ? "independent-host-variant-reference" : "independent-host-swap-reference";
  }
}

// src/target-resolution.ts
var TARGET_RESOLUTION_SCHEMA = "apollo.target-resolution.v1";
var record15 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
function resolveSnapshotTargets(snapshot, contract) {
  const paths = snapshotPaths(snapshot);
  const byId = new Map(snapshot.nodes.map((node) => [String(node.id), node]));
  const keys = [snapshot.source?.componentKey, snapshot.source?.componentSetKey].filter(Boolean);
  const representations = contract.facts.representations.filter((rep) => rep.kind === "figma" && rep.status !== "deprecated" && rep.platform === snapshot.context.platform && keys.some((key) => key === rep.locator.componentKey || key === rep.locator.componentSetKey));
  const targets = contract.facts.targets.map((target) => {
    const result = {
      targetId: target.id,
      semanticRole: target.semanticRole,
      resolution: "unknown",
      reason: "topology-incomplete-or-ambiguous"
    };
    if (!paths) return result;
    if (representations.length !== 1) return { ...result, reason: "representation-unresolved" };
    if (target.resolution !== "resolved") return { ...result, reason: "authoring-target-unresolved" };
    const hints = target.representationHints?.filter((h) => h.representationId === representations[0].id) || [];
    if (hints.length > 1) return { ...result, resolution: "ambiguous", reason: "representation-hints-ambiguous" };
    const hint = hints[0];
    if (!hint && ![representations[0].locator.componentKey, representations[0].locator.componentSetKey].includes(contract.facts.component.componentKey)) {
      return { ...result, reason: "representation-hint-missing" };
    }
    const pathHint = hint?.pathHint || target.pathHint;
    if (!pathHint) return { ...result, reason: "path-hint-missing" };
    const path = pathHint.split(" / ").slice(1).join(" / ");
    const candidates = snapshot.nodes.filter((node2) => paths.get(String(node2.id)) === path);
    if (candidates.length !== 1) return { ...result, reason: "path-needs-remap" };
    const node = candidates[0];
    const fingerprint = hint?.structuralFingerprint || target.structuralFingerprint;
    if (path !== "" && !fingerprint) return { ...result, reason: "structural-anchor-missing" };
    if (fingerprint) {
      const types2 = path === "" ? ["INSTANCE", "COMPONENT", "COMPONENT_SET"] : [String(node.type)];
      if (!types2.some((type) => stableHash({ type, path: pathHint, order: node.order }).slice(0, 16) === fingerprint)) {
        return { ...result, reason: "structural-anchor-changed" };
      }
    }
    const declaredLineage = hint?.pathHint ? void 0 : target.lineage;
    const hintLineage = pathHint.split("/").slice(0, -1).map((part) => slug(part.trim()));
    if (declaredLineage && stableHash(declaredLineage) !== stableHash(hintLineage)) return { ...result, reason: "lineage-hint-conflict" };
    let current = node;
    const actualSegments = [];
    while (current && current.parentId !== null) {
      if (current.type === "INSTANCE") return { ...result, reason: "nested-lineage-unproven" };
      actualSegments.unshift(String(current.name));
      current = byId.get(String(current.parentId));
    }
    if (stableHash(actualSegments) !== stableHash(pathHint.split(" / ").slice(1))) return { ...result, reason: "lineage-hint-conflict" };
    return { ...result, resolution: "resolved", reason: "exact-structural-anchor", nodeId: String(node.id) };
  });
  for (const target of targets) {
    if (targets.filter((other) => other.semanticRole === target.semanticRole).length > 1 || target.nodeId && targets.filter((other) => other.nodeId === target.nodeId).length > 1) {
      target.resolution = "ambiguous";
      target.reason = "target-collision";
    }
  }
  return { schemaVersion: TARGET_RESOLUTION_SCHEMA, manualSourceHash: contract.package.manualSourceHash, targets };
}
function materializeTargetResolution(snapshot, contract) {
  const evidence = resolveSnapshotTargets(snapshot, contract);
  snapshot.targetResolution = evidence;
  const bindings = new Map(evidence.targets.filter((t) => t.resolution === "resolved").map((t) => [t.nodeId, t.semanticRole]));
  const relations = Object.fromEntries([...bindings].map(([id, role]) => [role, id]));
  for (const node of snapshot.nodes) {
    const role = bindings.get(String(node.id));
    node.semantic = { ...record15(node.semantic), role: role || "" };
    node.relations = { ...relations };
    node.unknownFacts = (node.unknownFacts || []).filter((path) => path !== "semantic.role");
  }
}

// src/gradient-paint-facts.ts
var TYPES = /* @__PURE__ */ new Set(["GRADIENT_LINEAR", "GRADIENT_RADIAL", "GRADIENT_ANGULAR", "GRADIENT_DIAMOND"]);
var record16 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var unit = (v) => finite(v) && v >= 0 && v <= 1;
var transformValid = (v) => Array.isArray(v) && v.length === 2 && v.every((row) => Array.isArray(row) && row.length === 3 && row.every(finite));
var colorValid = (v) => ["r", "g", "b", "a"].every((key) => unit(record16(v)[key]));
function gradientPaintIssues(value) {
  if (!Array.isArray(value)) return [];
  const issues = [];
  value.forEach((raw, index) => {
    const paint = record16(raw);
    if (!TYPES.has(String(paint.type))) return;
    const prefix = `[${index}]`;
    if (!transformValid(paint.gradientTransform)) issues.push(`${prefix}.gradientTransform`);
    if (!Array.isArray(paint.gradientStops) || !paint.gradientStops.length) issues.push(`${prefix}.gradientStops`);
    else paint.gradientStops.forEach((rawStop, stopIndex) => {
      const stop = record16(rawStop), path = `${prefix}.gradientStops[${stopIndex}]`;
      if (!unit(stop.position)) issues.push(`${path}.position`);
      if (!colorValid(stop.color)) issues.push(`${path}.color`);
      if (!(stop.tokenId === null || typeof stop.tokenId === "string" && Boolean(stop.tokenId.trim()))) issues.push(`${path}.tokenId`);
    });
  });
  return issues;
}
function materializeGradientPaintEvidence(snapshot) {
  for (const node of snapshot.nodes) {
    const unknown12 = new Set(node.unknownFacts || []);
    const issues = [];
    const present = {};
    for (const [prefix, source] of [["", node], ["baseline.effective.", record16(record16(node.baseline).effective)]]) {
      const appearance = record16(source.appearance);
      for (const kind of ["fill", "stroke"]) {
        if (Object.prototype.hasOwnProperty.call(appearance, kind)) present[kind] = true;
        const missing = Object.prototype.hasOwnProperty.call(appearance, kind) && !Array.isArray(appearance[kind]) ? [""] : gradientPaintIssues(appearance[kind]);
        if (!missing.length) continue;
        const fact2 = `${prefix}appearance.${kind}`;
        unknown12.add(fact2);
        issues.push({ fact: fact2, missing: missing.map((path) => `${fact2}${path}`) });
      }
    }
    node.paintEvidenceV1 = present;
    node.unknownFacts = [...unknown12].sort();
    if (issues.length) {
      node.gradientPaintIssues = issues;
    } else delete node.gradientPaintIssues;
  }
}

// src/rule-scope-facts.ts
var record17 = (value) => value && typeof value === "object" ? value : {};
var unknown5 = (node, fact2) => (node.unknownFacts || []).some((path) => fact2 === path || fact2.startsWith(path + "."));
function materializeRuleScopeFacts(snapshot, contract) {
  const roots = snapshot.nodes.filter((node) => snapshot.selection.includes(String(node.id)));
  const root2 = roots.length === 1 ? roots[0] : void 0;
  const paths = snapshotPaths(snapshot);
  const childPaths = [];
  let ownershipUnknown = !paths;
  if (contract.customizationPolicy.some((rule) => rule.boundaryPolicy === "component-owned@1")) {
    if (contract.runtimePolicy.nativeSlotTargetsVersion === 1) {
      const nativeTargets = new Set(contract.customizationPolicy.filter((rule) => rule.status !== "deprecated" && ["allowed", "constrained"].includes(rule.permission)).flatMap((rule) => rule.controlPaths.filter((control) => control.kind === "slot-api" && control.contentOwnership === "external").map((control) => control.target)));
      for (const targetId of nativeTargets) {
        const target = contract.facts.targets.find((entry) => entry.id === targetId);
        const nodes = snapshot.nodes.filter((node) => record17(node.semantic).role === target?.semanticRole);
        if (nodes.length === 1 && nodes[0].type === "INSTANCE") continue;
        if (nodes.length !== 1 || nodes[0].type !== "SLOT" || record17(nodes[0].slotBoundaryV1).contentOwnership !== "external") {
          ownershipUnknown = true;
          continue;
        }
        const path = paths?.get(String(nodes[0].id));
        if (!path) {
          ownershipUnknown = true;
          continue;
        }
        for (const node of snapshot.nodes) {
          const descendant = paths?.get(String(node.id));
          if (descendant?.startsWith(path + " / ")) childPaths.push(descendant);
        }
      }
    }
    for (const dependency of contract.componentDependencies || []) {
      if (dependency.issue || dependencyPinIssue(dependency, dependency.contract)) {
        ownershipUnknown = true;
        continue;
      }
      for (const binding of dependency.bindings) {
        const resolved = resolveFixedNestedBinding(snapshot, dependency, binding);
        if (resolved.status === "inactive") continue;
        if (resolved.status !== "active" || !resolved.nodeId || !resolved.identityValid || !validatedDependencyCapture(snapshot, resolved.nodeId, dependency.contract).snapshot) {
          ownershipUnknown = true;
          continue;
        }
        const path = paths?.get(resolved.nodeId);
        if (path) childPaths.push(path);
        else ownershipUnknown = true;
      }
    }
  }
  const targets = {};
  for (const target of contract.facts.targets) {
    const candidates = snapshot.nodes.filter((node) => matchesTargetRole(node, target.semanticRole, contract) && !unknown5(node, "semantic.role"));
    const available = record17(record17(root2?.variantAvailability).targets)[target.semanticRole];
    const verified = record17(root2?.semanticTargets)[target.semanticRole];
    const fact2 = {};
    if (paths && verified?.resolved === true && target.resolution === "resolved" && contract.facts.targets.filter((other) => other.semanticRole === target.semanticRole).length === 1) {
      if (available?.present === false && candidates.length === 0) fact2.visible = false;
      else if (candidates.length === 1 && !unknown5(candidates[0], "visibility.effective") && typeof record17(candidates[0].visibility).effective === "boolean") fact2.visible = record17(candidates[0].visibility).effective;
    }
    targets[target.semanticRole] = fact2;
  }
  for (const node of snapshot.nodes) {
    const path = paths?.get(String(node.id));
    const local = path !== void 0 && childPaths.some((child) => withinBoundary(path, child)) ? false : ownershipUnknown ? void 0 : true;
    node.ruleScopeV1 = { isRoot: node === root2, ...local !== void 0 ? { local } : {}, targets };
    const missing = (node.unknownFacts || []).filter((path2) => path2 !== "ruleScopeV1" && !path2.startsWith("ruleScopeV1."));
    if (local === void 0) missing.push("ruleScopeV1.local");
    for (const [role, fact2] of Object.entries(targets)) if (fact2.visible === void 0) missing.push(`ruleScopeV1.targets.${role}.visible`);
    node.unknownFacts = missing;
  }
}

// src/dependency-composition.ts
function materializeDependencyComposition(snapshot, contract) {
  const ids = contract.facts.dependencyCompositionIds || [];
  if (!ids.length) return;
  const facts = {};
  for (const id of ids) {
    const dependency = contract.componentDependencies?.find((d) => d.id === id);
    const fact2 = { evidence: [] };
    facts[id] = fact2;
    if (!dependency || dependency.issue || !dependency.bindings.length) {
      fact2.evidence.push({ reason: dependency?.issue || "dependency-unavailable" });
      continue;
    }
    const results = dependency.bindings.map((binding) => ({ binding, result: resolveFixedNestedBinding(snapshot, dependency, binding, true, contract) }));
    if (results.some(({ result }) => result.ownerActive)) fact2.active = true;
    else if (results.every(({ result }) => result.status === "inactive")) fact2.active = false;
    const visible = [];
    let complete = true;
    for (const { binding, result } of results) {
      const node = result.node;
      const unknown12 = node?.unknownFacts || [];
      const identityUnknown = unknown12.some((p) => p === "component" || p === "component.identity" || p.startsWith("component.identity."));
      const visibilityUnknown = unknown12.some((p) => p === "visible" || p === "visibility" || p === "visibility.effective");
      const visibility = visibilityUnknown ? void 0 : node?.visibility?.effective;
      const identity = node?.component?.identity;
      const standalone = dependency.contract?.facts.representations.some((r) => r.kind === "figma" && r.status !== "deprecated" && !r.locator.componentSetKey && Boolean(identity?.componentKey) && r.locator.componentKey === identity.componentKey);
      fact2.evidence.push({
        bindingId: binding.id,
        status: result.status,
        reason: result.reason,
        ...result.nodeId ? { nodeId: result.nodeId } : {},
        ...result.identityValid !== void 0 && !identityUnknown ? { identityValid: result.identityValid } : {},
        ...typeof visibility === "boolean" ? { visible: visibility } : {}
      });
      if (result.status === "inactive") continue;
      if (result.status !== "active" || identityUnknown || !node?.component?.identity?.componentKey || !identity?.componentSetKey && !standalone || typeof visibility !== "boolean") {
        complete = false;
        continue;
      }
      if (result.identityValid && visibility) visible.push(result.nodeId);
    }
    if (complete && new Set(visible).size === visible.length) fact2.visibleInstances = visible;
  }
  for (const node of snapshot.nodes) {
    node.dependencyCompositionV1 = facts;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "dependencyCompositionV1" && !p.startsWith("dependencyCompositionV1."));
  }
}

// src/semantic-target-facts.ts
var record18 = (v) => v && typeof v === "object" ? v : {};
var unknown6 = (n, fact2) => (n.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + "."));
function materializeTargetSemanticFacts(snapshot, contract) {
  if (contract.runtimePolicy.semanticTargetVisibilityVersion !== 1) return;
  const roots = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  const root2 = roots.length === 1 ? roots[0] : void 0;
  if (!root2) return;
  const paths = snapshotPaths(snapshot);
  const identity = record18(record18(root2.component).identity);
  const sourceKey = snapshot.source?.componentKey ?? "";
  const sourceSetKey = snapshot.source?.componentSetKey ?? "";
  const reps = contract.facts.representations.filter((r) => r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, sourceKey, sourceSetKey));
  const identityKnown = sourceKey && identity.componentKey === sourceKey && (identity.componentSetKey ?? "") === sourceSetKey && !unknown6(root2, "component.identity.componentKey") && !unknown6(root2, "component.identity.componentSetKey");
  for (const property of contract.facts.semanticApi.filter((p) => p.bindings.some((b) => b.targetId && !b.ownedOccurrence && !b.nativeSlotBinding))) {
    const bindings = property.bindings.filter((b) => b.representationId === reps[0]?.id);
    const binding = bindings.length === 1 ? bindings[0] : void 0;
    const target = contract.facts.targets.filter((t) => t.id === binding?.targetId);
    const role = target[0]?.semanticRole;
    const candidates = snapshot.nodes.filter((n) => matchesTargetRole(n, role, contract) && !unknown6(n, "semantic.role"));
    const available = record18(record18(root2.variantAvailability).targets)[role];
    const resolved = snapshot.targetResolution?.targets.filter((t) => t.targetId === binding?.targetId);
    const anchor = available?.present === true || resolved?.length === 1 && resolved[0].resolution === "resolved" && candidates.length === 1 && resolved[0].nodeId === String(candidates[0].id);
    const absent = available?.present === false && candidates.length === 0;
    const targetKnown = Boolean(paths && identityKnown && reps.length === 1 && bindings.length === 1 && binding && (binding.path === "visibility.effective" || binding.path.startsWith("component.properties.")) && [void 0, "identity"].includes(binding.transform) && target.length === 1 && target[0].resolution === "resolved" && contract.facts.targets.filter((t) => t.semanticRole === role).length === 1 && (absent || anchor && candidates.length === 1));
    const fact2 = `semanticApi.${property.id}`;
    const sourceFact = `ruleScopeV1.targets.${role}.visible`;
    const isVisibility = binding?.path === "visibility.effective";
    const visible = targetKnown && !unknown6(root2, sourceFact) ? record18(record18(root2.ruleScopeV1).targets)[role]?.visible : void 0;
    let value = isVisibility ? visible : void 0;
    if (targetKnown && !isVisibility && !absent && candidates.length === 1) {
      const node = candidates[0], data = record18(node.component);
      const resolved2 = resolveComponentProperty(
        binding.path.slice("component.properties.".length),
        data,
        property.valueType === "boolean" ? ["BOOLEAN"] : property.kind === "variant" ? ["VARIANT"] : ["TEXT", "VARIANT"]
      );
      if ("name" in resolved2 && !unknown6(node, `component.properties.${resolved2.name}`) && !unknown6(node, `component.propertyTypes.${resolved2.name}`)) {
        const raw = record18(data.properties)[resolved2.name];
        if ((property.valueType === "boolean" ? typeof raw === "boolean" : typeof raw === "string") && (!property.domain || property.domain.includes(raw))) value = raw;
      }
    }
    const known2 = value !== void 0;
    const values = record18(root2.semanticApi);
    delete values[property.id];
    if (known2) values[property.id] = value;
    root2.semanticApi = values;
    root2.semanticBindingEvidence = { ...record18(root2.semanticBindingEvidence), [property.id]: {
      reason: known2 ? "resolved" : targetKnown ? isVisibility ? "target-visibility-unknown" : "target-property-unknown" : "target-unresolved",
      representationId: reps.length === 1 ? reps[0].id : void 0,
      targetId: binding?.targetId,
      path: binding?.path,
      readOnly: true,
      ...known2 ? isVisibility ? { effectiveVisible: visible, confirmedAbsent: absent } : { value } : {}
    } };
    for (const node of snapshot.nodes) {
      const missing = new Set((node.unknownFacts || []).filter((p) => p !== `variantAvailability.properties.${property.id}` && p !== `host.${fact2}` && (node !== root2 || p !== fact2)));
      const availability = record18(node.variantAvailability), properties = { ...record18(availability.properties) };
      delete properties[property.id];
      if (targetKnown) properties[property.id] = true;
      else missing.add(`variantAvailability.properties.${property.id}`);
      node.variantAvailability = { ...availability, properties };
      if (!known2) {
        missing.add(`host.${fact2}`);
        if (node === root2) missing.add(fact2);
      }
      node.host = { ...record18(node.host), semanticApi: JSON.parse(JSON.stringify(values)) };
      node.unknownFacts = [...missing];
    }
  }
}

// src/transition-facts.ts
function fact(node, path) {
  if ((node.unknownFacts || []).some((p) => p === path || path.startsWith(p + "."))) return void 0;
  return path.split(".").reduce((v, k) => v?.[k], node);
}
var root = (s) => s.selection.length === 1 ? s.nodes.find((n) => n.id === s.selection[0]) : void 0;
var same = (a, b) => a !== void 0 && b !== void 0 && stableHash(a) === stableHash(b);
function materializeTransitionFacts(snapshot, contract, prepareBefore) {
  if (contract.runtimePolicy.transitionFactsVersion !== 1) return;
  const after = root(snapshot), sourceBefore = snapshot.transitionBefore;
  const before = sourceBefore && !sourceBefore.transitionBefore && sourceBefore.nodes.length <= 500 ? prepareBefore(sourceBefore) : void 0;
  const prior = before && root(before), results = {};
  for (const binding of contract.facts.transitions || []) {
    const t = binding.transition, result = { reason: "before-not-captured" };
    results[binding.id] = result;
    const currentState = after && fact(after, `dependencyCompositionV1.${t.dependencyId}.active`);
    if (typeof currentState === "boolean" && currentState !== t.to) {
      Object.assign(result, { applicable: false, reason: "after-state-not-applicable" });
      continue;
    }
    if (typeof currentState !== "boolean") {
      result.reason = "after-state-unknown";
      continue;
    }
    result.applicable = true;
    if (!before || !prior || !after) continue;
    const a = snapshot.transitionCapture, b = before.transitionCapture;
    let reason = "";
    if (!a || !b || a.schemaVersion !== "apollo.transition-capture.v1" || b.schemaVersion !== a.schemaVersion || !a.complete || !b.complete) reason = a?.reason || b?.reason || "capture-context-incomplete";
    else if (!a.sessionId || a.sessionId !== b.sessionId || !Number.isInteger(a.sequence) || !Number.isInteger(b.sequence) || a.sequence <= b.sequence) reason = "capture-order-or-session-mismatch";
    else if (a.manualSourceHash !== contract.package.manualSourceHash || b.manualSourceHash !== a.manualSourceHash) reason = "manual-source-changed";
    else if (!snapshotPaths(snapshot) || !snapshotPaths(before)) reason = "topology-incomplete";
    else if (!snapshot.source?.rootNodeId || !same(snapshot.source.rootNodeId, before.source?.rootNodeId) || !same(snapshot.source.pageId, before.source?.pageId) || !same(snapshot.source.componentSetKey, before.source?.componentSetKey) || !same(snapshot.source.componentKey, before.source?.componentKey) || !same(snapshot.source.representationId, before.source?.representationId)) reason = "instance-or-variant-changed";
    else if (!same(snapshot.context, before.context) || snapshot.context.unknownFacts.length) reason = "scenario-context-changed";
    else if (!a.externalContext || !Object.keys(a.externalContext).length || !same(a.externalContext, b.externalContext)) reason = "external-context-changed";
    else if (fact(prior, `dependencyCompositionV1.${t.dependencyId}.active`) !== t.from) reason = "before-state-not-proven";
    else if (t.invariantFacts.some((path) => !same(fact(prior, path), fact(after, path)))) reason = "invariant-changed-or-unknown";
    else if ([before, snapshot].some((s) => {
      const n = root(s);
      return !same(fact(n, "component.identity.componentKey"), s.source?.componentKey) || !same(fact(n, "component.identity.componentSetKey"), s.source?.componentSetKey);
    })) reason = "root-identity-unproven";
    const old = fact(prior, binding.fact), now = fact(after, binding.fact);
    if (!reason && [old, now].some((v) => typeof v !== "number" || !Number.isFinite(v) || v <= 0)) reason = "dimension-unknown";
    if (reason) {
      result.reason = reason;
      continue;
    }
    Object.assign(result, { reason: "paired", before: old, after: now });
  }
  for (const n of snapshot.nodes) {
    n.transitionsV1 = results;
    n.unknownFacts = (n.unknownFacts || []).filter((p) => p !== "transitionsV1" && !p.startsWith("transitionsV1."));
  }
}

// src/paint-binding-facts.ts
var record19 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var token = (v) => typeof v === "string" && Boolean(v.trim());
function materializePaintBindings(snapshot) {
  for (const node of snapshot.nodes) {
    const prior = node.unknownFacts || [];
    const unknown12 = prior.filter((p) => p !== "paintBindingsV1" && !p.startsWith("paintBindingsV1."));
    const facts = {};
    if (record19(node.visibility).effective === false && !prior.some((p) => p === "visibility" || p === "visibility.effective")) {
      node.paintBindingsV1 = { fill: { required: true, tokenIds: [] }, stroke: { required: true, tokenIds: [] } };
      node.unknownFacts = unknown12;
      continue;
    }
    for (const kind of ["fill", "stroke"]) {
      const path = `appearance.${kind}`, paints = record19(node.appearance)[kind];
      let unavailable = !Array.isArray(paints) || prior.some((p) => p === path || path.startsWith(p + "."));
      const ids = [];
      let bound = true;
      if (Array.isArray(paints)) for (const raw of paints) {
        const paint = record19(raw);
        if (paint.visible === false || paint.opacity === 0) continue;
        if (paint.visible !== true || typeof paint.opacity !== "number" || !Number.isFinite(paint.opacity)) {
          unavailable = true;
          continue;
        }
        if (paint.type === "SOLID") {
          if (token(paint.tokenId)) ids.push(paint.tokenId);
          else if (paint.tokenId == null) bound = false;
          else unavailable = true;
        } else if (["GRADIENT_LINEAR", "GRADIENT_RADIAL", "GRADIENT_ANGULAR", "GRADIENT_DIAMOND"].includes(paint.type)) {
          if (!Array.isArray(paint.gradientStops) || !paint.gradientStops.length) {
            unavailable = true;
            continue;
          }
          for (const rawStop of paint.gradientStops) {
            const stop = record19(rawStop);
            if (record19(stop.color).a === 0) continue;
            if (token(stop.tokenId)) ids.push(stop.tokenId);
            else if (stop.tokenId === null) bound = false;
            else unavailable = true;
          }
        } else if (typeof paint.type === "string") bound = false;
        else unavailable = true;
      }
      if (!bound || !unavailable) facts[kind] = { required: bound, tokenIds: [...new Set(ids)].sort() };
      else unknown12.push(`paintBindingsV1.${kind}`);
    }
    node.paintBindingsV1 = facts;
    node.unknownFacts = unknown12;
  }
}

// src/native-slot-targets.ts
var record20 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
var unknown7 = (node, fact2) => (node.unknownFacts || []).some((path) => path === fact2 || fact2.startsWith(path + ".") || path.startsWith(fact2 + "."));
function materializeNativeSlotTargets(snapshot, contract, comparison, paths) {
  if (contract.runtimePolicy.nativeSlotTargetsVersion !== 1 || snapshot.source?.truncated || !comparison.complete || !snapshot.variantReference?.complete) return;
  const ref = snapshot.variantReference;
  const roots = snapshot.nodes.filter((node) => snapshot.selection.includes(String(node.id)));
  const reps = contract.facts.representations.filter((rep) => rep.status !== "deprecated" && rep.platform === snapshot.context.platform && matchesCaptureRepresentation(rep, ref.componentKey, ref.componentSetKey));
  if (roots.length !== 1 || reps.length !== 1) return;
  const pathFor = (target) => {
    return selectedTargetPathHint(target, reps[0].id, ref.componentKey, contract.facts.variantEvidence?.occurrenceAddressVersion === 1)?.split(" / ").slice(1).join(" / ");
  };
  for (const target of contract.facts.targets) {
    const controls = contract.customizationPolicy.filter((rule) => rule.targetId === target.id && rule.status !== "deprecated" && ["allowed", "constrained"].includes(rule.permission)).flatMap((rule) => rule.controlPaths.filter((control) => control.kind === "slot-api" && control.target === target.id && control.property));
    const anchors = [...new Set(controls.map((control) => control.property))];
    const ownerIds = [...new Set(controls.map((control) => control.ownerTargetId || ""))];
    const slotPath = pathFor(target);
    if (target.resolution !== "resolved" || anchors.length !== 1 || ownerIds.length !== 1 || !slotPath || contract.facts.targets.filter((other) => other.semanticRole === target.semanticRole).length !== 1) continue;
    const property = anchors[0];
    const owners = ownerIds[0] ? contract.facts.targets.filter((other) => other.id === ownerIds[0] && other.resolution === "resolved") : [];
    if (ownerIds[0] && owners.length !== 1) continue;
    const ownerPath = owners.length ? pathFor(owners[0]) : "";
    if (ownerPath === void 0 || slotPath.split(" / ").slice(0, -1).join(" / ") !== ownerPath) continue;
    const actualOwners = ownerIds[0] ? snapshot.nodes.filter((node2) => node2.type === "INSTANCE" && record20(node2.semantic).role === owners[0].semanticRole && comparison.referencePaths?.[paths.get(String(node2.id))] === ownerPath) : roots;
    if (actualOwners.length !== 1) continue;
    const owner = actualOwners[0], expectedOwner = ref.nodeProperties[ownerPath];
    const identity = record20(record20(owner.component).identity), expectedIdentity = expectedOwner?.identity;
    if (!expectedIdentity?.componentKey || identity.componentKey !== expectedIdentity.componentKey || (identity.componentSetKey || "") !== (expectedIdentity.componentSetKey || "") || unknown7(owner, "component.identity") || unknown7(owner, `component.propertyTypes.${property}`) || record20(record20(owner.component).propertyTypes)[property] !== "SLOT" || expectedOwner.propertyTypes[property] !== "SLOT") continue;
    const nativeActual = snapshot.nodes.filter((node2) => node2.type === "SLOT" && node2.parentId === owner.id && record20(record20(node2.component).propertyReferenceBindings).slotContentId === property);
    const nativeRef = ref.nodes.filter((node2) => node2.type === "SLOT" && node2.path.split(" / ").slice(0, -1).join(" / ") === ownerPath && ref.nodeProperties[node2.path]?.propertyReferenceBindings?.slotContentId === property);
    if (nativeActual.length !== 1 || nativeRef.length !== 1 || nativeRef[0].path !== slotPath) continue;
    const node = nativeActual[0], actualPath = paths.get(String(node.id));
    if (!actualPath || comparison.referencePaths?.[actualPath] !== slotPath || unknown7(node, "component.propertyReferenceBindings") || unknown7(node, "type") || unknown7(node, "parentId") || snapshot.nodes.some((other) => other !== node && record20(other.semantic).role === target.semanticRole)) continue;
    node.semantic = { ...record20(node.semantic), role: target.semanticRole };
    node.unknownFacts = (node.unknownFacts || []).filter((path) => path !== "semantic.role");
    for (const entry of snapshot.nodes) {
      const availability = record20(entry.variantAvailability);
      availability.targets = { ...record20(availability.targets), [target.semanticRole]: {
        present: true,
        referenceState: "present",
        evidence: "native-slot-content-reference"
      } };
      entry.variantAvailability = availability;
      entry.unknownFacts = (entry.unknownFacts || []).filter((path) => path !== `variantAvailability.targets.${target.semanticRole}.present`);
    }
    if (controls.some((control) => control.contentOwnership === "external")) {
      node.slotBoundaryV1 = {
        contentOwnership: "external",
        targetId: target.id,
        property,
        evidence: "native-slot-content-reference",
        ...ownerIds[0] ? { ownerTargetId: ownerIds[0] } : {}
      };
    }
  }
}

// src/slot-target-facts.ts
var record21 = (v) => v && typeof v === "object" ? v : {};
function materializeSlotTargets(snapshot, contract) {
  if (contract.runtimePolicy.slotTargetFactsVersion !== 1) return;
  for (const node of snapshot.nodes) delete node.slotBoundaryV1;
  const nestedTargets = new Set(contract.customizationPolicy.flatMap((r) => r.controlPaths.filter((p) => p.kind === "slot-api" && p.ownerTargetId).map((p) => p.target)));
  for (const target of contract.facts.targets.filter((t) => nestedTargets.has(t.id))) for (const node of snapshot.nodes) {
    if (record21(node.semantic).role === target.semanticRole) delete record21(node.semantic).role;
    delete record21(record21(node.variantAvailability).targets)[target.semanticRole];
    const key = `variantAvailability.targets.${target.semanticRole}.present`;
    node.unknownFacts = [.../* @__PURE__ */ new Set([...node.unknownFacts || [], key])];
  }
  if (snapshot.source?.propertyReferenceIdentityVersion !== 1) return;
  const ref = snapshot.variantReference, paths = snapshotPaths(snapshot);
  if (!ref || !paths) return;
  const comparison = compareInstanceBoundaries(snapshot, ref);
  if (!comparison.complete) return;
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  if (!root2 || !["verified", "partial"].includes(String(record21(root2.variantAvailability).status))) return;
  materializeNativeSlotTargets(snapshot, contract, comparison, paths);
  for (const target of contract.facts.targets) {
    const rules = contract.customizationPolicy.filter((r) => r.targetId === target.id && r.status !== "deprecated" && ["allowed", "constrained"].includes(r.permission));
    const properties = [...new Set(rules.flatMap((r) => r.controlPaths.filter((p) => p.kind === "slot-api" && p.target === target.id && p.property).map((p) => p.property)))];
    if (target.resolution !== "resolved" || properties.length !== 1) continue;
    const representations = contract.facts.representations.filter((r) => r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
    const property = properties[0], referencePath = (contract.runtimePolicy.occurrenceAddressVersion === 1 ? representations.length === 1 ? selectedTargetPathHint(target, representations[0].id, ref.componentKey, contract.facts.variantEvidence?.occurrenceAddressVersion === 1) : void 0 : target.pathHint)?.split(" / ").slice(1).join(" / ");
    const declarations = rules.flatMap((r) => r.controlPaths.filter((p) => p.kind === "slot-api" && p.target === target.id && p.property === property));
    if (declarations.some((p) => p.ownerTargetId !== void 0)) {
      const ownerIds = [...new Set(declarations.map((p) => p.ownerTargetId))];
      if (ownerIds.length !== 1 || !ownerIds[0]) continue;
      const owners = contract.facts.targets.filter((t) => t.id === ownerIds[0] && t.resolution === "resolved");
      const reps = contract.facts.representations.filter((r) => r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
      if (owners.length !== 1 || reps.length !== 1 || owners[0].id === target.id) continue;
      const pathFor = (t) => {
        return selectedTargetPathHint(t, reps[0].id, ref.componentKey, contract.facts.variantEvidence?.occurrenceAddressVersion === 1)?.split(" / ").slice(1).join(" / ");
      };
      const ownerPath = pathFor(owners[0]), slotPath = pathFor(target);
      if (ownerPath === void 0 || !slotPath || slotPath.split(" / ").slice(0, -1).join(" / ") !== ownerPath) continue;
      const nodes = snapshot.nodes.filter((n) => n.type === "INSTANCE" && record21(n.semantic).role === owners[0].semanticRole && comparison.referencePaths?.[paths.get(String(n.id))] === ownerPath);
      if (nodes.length !== 1) continue;
      const owner = nodes[0], expectedOwner = ref.nodeProperties[ownerPath], ownerComponent = record21(owner.component);
      const identity = record21(ownerComponent.identity), expectedIdentity = expectedOwner?.identity;
      const unknown12 = (n, p) => (n.unknownFacts || []).some((v) => v === p || p.startsWith(v + ".") || v.startsWith(p + "."));
      if (!expectedIdentity?.componentKey || identity.componentKey !== expectedIdentity.componentKey || (identity.componentSetKey || "") !== (expectedIdentity.componentSetKey || "") || unknown12(owner, "component.identity") || unknown12(owner, `component.propertyTypes.${property}`) || ownerComponent.propertyTypes?.[property] !== "BOOLEAN" || expectedOwner.propertyTypes[property] !== "BOOLEAN" || comparison.boundaries.some((b) => ownerPath === b.referencePath || ownerPath.startsWith(b.referencePath + " / "))) continue;
      const nativeRef = ref.nodes.filter((n) => n.type === "INSTANCE" && n.path.split(" / ").slice(0, -1).join(" / ") === ownerPath && ref.nodeProperties[n.path]?.propertyReferenceBindings?.visible === property);
      const nativeActual = snapshot.nodes.filter((n) => n.type === "INSTANCE" && n.parentId === owner.id && record21(record21(n.component).propertyReferenceBindings).visible === property);
      if (nativeRef.length !== 1 || nativeRef[0].path !== slotPath || nativeActual.length !== 1) continue;
      const node2 = nativeActual[0];
      if (unknown12(node2, "component.propertyReferenceBindings") || unknown12(node2, "parentId") || unknown12(node2, "type") || comparison.referencePaths?.[paths.get(String(node2.id))] !== slotPath || contract.facts.targets.filter((t) => t.semanticRole === target.semanticRole).length !== 1 || snapshot.nodes.some((n) => n !== node2 && record21(n.semantic).role === target.semanticRole)) continue;
      node2.semantic = { ...record21(node2.semantic), role: target.semanticRole };
      if (declarations.some((p) => p.contentOwnership === "external")) node2.slotBoundaryV1 = {
        contentOwnership: "external",
        targetId: target.id,
        property,
        evidence: "native-slot-reference",
        ownerTargetId: owners[0].id
      };
      node2.unknownFacts = (node2.unknownFacts || []).filter((p) => p !== "semantic.role");
      for (const entry of snapshot.nodes) {
        const availability = record21(entry.variantAvailability);
        availability.targets = { ...record21(availability.targets), [target.semanticRole]: { present: true, referenceState: "present", evidence: "native-nested-slot-reference" } };
        entry.variantAvailability = availability;
        entry.unknownFacts = (entry.unknownFacts || []).filter((p) => p !== `variantAvailability.targets.${target.semanticRole}.present`);
      }
      continue;
    }
    if (!referencePath || ref.nodeProperties[referencePath]?.propertyReferenceBindings?.visible !== property || ref.nodeProperties[""]?.propertyTypes[property] !== "BOOLEAN") continue;
    if (snapshot.nodes.filter((n) => n.type === "INSTANCE" && n.parentId === root2.id && record21(record21(n.component).propertyReferenceBindings).visible === property).length !== 1 || ref.nodes.filter((n) => n.type === "INSTANCE" && !n.path.includes(" / ") && ref.nodeProperties[n.path]?.propertyReferenceBindings?.visible === property).length !== 1) continue;
    const candidates = snapshot.nodes.filter((n) => n.type === "INSTANCE" && n.parentId === root2.id && record21(record21(n.component).propertyReferenceBindings).visible === property && comparison.referencePaths?.[paths.get(String(n.id))] === referencePath);
    if (candidates.length !== 1 || snapshot.nodes.some((n) => n !== candidates[0] && record21(n.semantic).role === target.semanticRole)) continue;
    const node = candidates[0];
    node.semantic = { ...record21(node.semantic), role: target.semanticRole };
    if (rules.some((r) => r.controlPaths.some((p) => p.kind === "slot-api" && p.target === target.id && p.property === property && p.contentOwnership === "external"))) {
      node.slotBoundaryV1 = { contentOwnership: "external", targetId: target.id, property, evidence: "native-slot-reference" };
    }
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "semantic.role");
    for (const entry of snapshot.nodes) {
      const availability = record21(entry.variantAvailability);
      availability.targets = { ...record21(availability.targets), [target.semanticRole]: { present: true, referenceState: "present", evidence: "native-slot-reference" } };
      entry.variantAvailability = availability;
      entry.unknownFacts = (entry.unknownFacts || []).filter((p) => p !== `variantAvailability.targets.${target.semanticRole}.present`);
    }
  }
}

// src/library-text-facts.ts
var record22 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var unknown8 = (node, fact2) => (node.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + "."));
var ordered2 = (shape) => shape.slice().sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
function materializeLibraryText(snapshot, contract) {
  if (!contract.capabilities.facts.some((f) => f.startsWith("libraryTextV1."))) return;
  const paths = snapshotPaths(snapshot), byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const verified = root2 && ["verified", "partial"].includes(String(record22(root2.variantAvailability).status));
  for (const node of snapshot.nodes) {
    delete node.libraryTextV1;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "libraryTextV1" && !p.startsWith("libraryTextV1."));
    if (node.type !== "TEXT") continue;
    node.unknownFacts.push("libraryTextV1.characters", "libraryTextV1.trimmedCharacters", "libraryTextV1.actualTrimmedCharacters");
    if (!paths || !verified || record22(node.baselineProvenance).status !== "matched") continue;
    let owner = byId.get(String(node.parentId));
    const visited = /* @__PURE__ */ new Set();
    while (owner && owner.type !== "INSTANCE" && !visited.has(String(owner.id))) {
      visited.add(String(owner.id));
      owner = byId.get(String(owner.parentId));
    }
    if (!owner || owner.type !== "INSTANCE" || record22(owner.baselineProvenance).status !== "matched" || unknown8(owner, "component.identity") || unknown8(owner, "component.identity.componentKey") || unknown8(owner, "component.identity.componentSetKey")) continue;
    const component = record22(owner.component), identity = record22(component.identity);
    const candidates = (contract.facts.variantEvidence?.libraryText || []).filter((v) => v.componentKey === identity.componentKey && (v.componentSetKey === identity.componentSetKey || !identity.componentSetKey && v.componentSetKey === v.componentKey));
    if (candidates.length !== 1) continue;
    const expected = candidates[0];
    if (Object.entries(expected.properties).some(([name, value]) => component.propertyTypes?.[name] !== "VARIANT" || component.properties?.[name] !== value || unknown8(owner, `component.properties.${name}`) || unknown8(owner, `component.propertyTypes.${name}`))) continue;
    const base = paths.get(String(owner.id));
    const relative = (p) => p === base ? "" : p.slice(base.length + (base ? 3 : 0));
    const descendants = snapshot.nodes.filter((n) => {
      const p = paths.get(String(n.id));
      return p === base || !base || p.startsWith(base + " / ");
    });
    const shape = descendants.map((n) => ({ path: relative(paths.get(String(n.id))), type: n === owner ? "ROOT" : String(n.type) }));
    if (stableHash(ordered2(shape)) !== stableHash(ordered2(expected.structure))) continue;
    const path = relative(paths.get(String(node.id))), text3 = expected.characters[path];
    if (typeof text3 !== "string") continue;
    const actual = record22(node.text).characters;
    node.libraryTextV1 = {
      characters: text3,
      trimmedCharacters: text3.trim(),
      componentKey: expected.componentKey,
      sourceHash: contract.facts.variantEvidence.sourceHash,
      ...typeof actual === "string" && !unknown8(node, "text.characters") ? { actualTrimmedCharacters: actual.trim() } : {}
    };
    node.unknownFacts = node.unknownFacts.filter((p) => p !== "libraryTextV1.characters" && p !== "libraryTextV1.trimmedCharacters" && !(p === "libraryTextV1.actualTrimmedCharacters" && typeof actual === "string" && !unknown8(node, "text.characters")));
  }
}

// src/text-style-facts.ts
var record23 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var textStyleBindingFact = (catalog) => `textStyleBindingsV1.c_${stableHash(catalog).slice(0, 16)}`;
function validTextStyleCatalog(c) {
  return !!c && typeof c.id === "string" && /^[a-f0-9]{64}$/.test(c.sourceHash) && Array.isArray(c.styles) && c.styles.length > 0 && c.styles.every((s) => !!s && /^[a-f0-9]{40}$/.test(s.key) && typeof s.name === "string") && new Set(c.styles.map((s) => s.key)).size === c.styles.length;
}
function materializeTextStyleBindings(snapshot, contract) {
  if (contract.runtimePolicy.textStyleBindingFactsVersion !== 1) return;
  const rawCatalogs = contract.facts.variantEvidence?.textStyleCatalogs;
  const catalogs = Array.isArray(rawCatalogs) ? rawCatalogs.filter((c) => c && typeof c.id === "string") : [];
  for (const node of snapshot.nodes) {
    const prior = node.unknownFacts || [];
    node.unknownFacts = prior.filter((p) => p !== "textStyleBindingsV1" && !p.startsWith("textStyleBindingsV1."));
    node.textStyleBindingsV1 = {};
    if (node.type !== "TEXT") continue;
    const t = record23(record23(node.appearance).typography);
    const evidence = record23(node.textStyleEvidenceV1);
    const captureUnknown = prior.some((p) => p === "appearance" || p === "appearance.typography" || p.startsWith("appearance.typography.") || p === "textStyleEvidenceV1" || p.startsWith("textStyleEvidenceV1."));
    let ids;
    if (!captureUnknown && evidence.version === 1) {
      const text3 = record23(node.text).characters, ranges2 = evidence.segments;
      if (typeof text3 === "string" && Array.isArray(ranges2)) {
        let end = 0;
        const valid = ranges2.every((s) => s && Number.isInteger(s.start) && Number.isInteger(s.end) && s.start === end && s.end > s.start && s.end <= text3.length && (end = s.end));
        if (valid && end === text3.length) ids = ranges2.length ? ranges2.map((s) => s.styleId) : [t.styleId];
      }
    } else if (!captureUnknown && node.textStyleEvidenceV1 === void 0 && typeof t.styleId === "string") ids = [t.styleId];
    for (const catalog of catalogs) {
      const fact2 = textStyleBindingFact(catalog.id), key = fact2.split(".")[1];
      let unknown12 = !ids || !validTextStyleCatalog(catalog) || catalogs.filter((c) => c.id === catalog.id).length !== 1;
      let detached = false, outside = false;
      const keys = [], names = [];
      if (!unknown12) for (const id of ids) {
        if (id === "") {
          detached = true;
          continue;
        }
        if (typeof id !== "string") {
          unknown12 = true;
          continue;
        }
        const match = /^S:([a-f0-9]{40})(?:,[^\s]+)?$/i.exec(id);
        const resolvedKey = match?.[1] || record23(evidence.keysById)[id];
        if (typeof resolvedKey !== "string" || !/^[a-f0-9]{40}$/i.test(resolvedKey)) {
          unknown12 = true;
          continue;
        }
        const styleKey2 = resolvedKey.toLowerCase(), style = catalog.styles.find((s) => s.key === styleKey2);
        keys.push(styleKey2);
        if (style) names.push(style.name);
        else outside = true;
      }
      if (!unknown12 || detached || outside) {
        record23(node.textStyleBindingsV1)[key] = {
          required: !detached,
          library: !detached && !outside && !unknown12,
          state: detached ? "detached" : outside ? "outside-catalog" : "bound",
          catalog: catalog.id,
          styleKeys: [...new Set(keys)].sort(),
          styleNames: [...new Set(names)].sort()
        };
      } else node.unknownFacts.push(fact2);
    }
  }
}

// src/text-binding-identity.ts
var record24 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var unknown9 = (n, fact2) => (n.unknownFacts || []).some((p) => p === fact2 || fact2.startsWith(p + ".") || p.startsWith(fact2 + "."));
var styleKey = (id) => typeof id === "string" ? (/^S:([a-f0-9]{40})(?:,[^\s]+)?$/i.exec(id)?.[1] || (/^[a-f0-9]{40}$/i.test(id) ? id : void 0))?.toLowerCase() : void 0;
var variableKey = (id) => typeof id === "string" ? (/^VariableID:([a-f0-9]{40})(?:\/[^\s]+)?$/i.exec(id)?.[1] || (/^[a-f0-9]{40}$/i.test(id) ? id : void 0))?.toLowerCase() : void 0;
var bindingConsistencyKey = (c) => `b_${stableHash({ kind: c.bindingKind, reference: c.bindingReference, roles: c.targetRoles }).slice(0, 16)}`;
function ranges(node, evidence) {
  if (evidence.version !== 1 || unknown9(node, "text.characters") || typeof node.text?.characters !== "string" || !Array.isArray(evidence.segments)) return;
  let end = 0;
  const valid = evidence.segments.every((s) => s && Number.isInteger(s.start) && Number.isInteger(s.end) && s.start === end && s.end > s.start && s.end <= node.text.characters.length && (end = s.end));
  return valid && end === node.text.characters.length ? evidence.segments : void 0;
}
function materializeTextBindingIdentities(snapshot, contract) {
  if (contract.runtimePolicy.textBindingIdentityFactsVersion !== 1) return;
  for (const node of snapshot.nodes) {
    delete node.textBindingIdentityV1;
    delete node.selectedTextBindingV1;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => !["textBindingIdentityV1", "selectedTextBindingV1"].some((base) => p === base || p.startsWith(base + ".")));
    if (node.type !== "TEXT") continue;
    const facts = {};
    const missing = (kind) => node.unknownFacts.push(`textBindingIdentityV1.${kind}`);
    const fill = record24(node.textFillEvidenceV1), style = record24(node.textStyleEvidenceV1);
    const fillRanges = ranges(node, fill), styleRanges = ranges(node, style);
    const paints = node.textFillEvidenceV1 === void 0 ? [record24(node.appearance).fill] : fillRanges ? fillRanges.length ? fillRanges.map((s) => s.paints) : [fill.emptyPaints] : void 0;
    let unavailable = !paints || unknown9(node, "appearance.fill") || unknown9(node, "textFillEvidenceV1");
    if (fillRanges && !unknown9(node, "textFillEvidenceV1")) unavailable = false;
    let invalid = false;
    const keys = [];
    if (paints) for (const list of paints) {
      if (!Array.isArray(list)) {
        unavailable = true;
        continue;
      }
      let active = 0;
      for (const raw of list) {
        const p = record24(raw);
        if (p.visible === false || p.opacity === 0) continue;
        active++;
        if (p.visible !== true || typeof p.opacity !== "number" || !Number.isFinite(p.opacity)) {
          unavailable = true;
          continue;
        }
        const ids2 = p.type === "SOLID" ? [p.tokenId] : /^GRADIENT_/.test(p.type) && Array.isArray(p.gradientStops) && p.gradientStops.length ? p.gradientStops.filter((s) => s.color?.a !== 0).map((s) => s.tokenId) : [];
        if (!ids2.length) {
          invalid = true;
          continue;
        }
        for (const id of ids2) {
          if (id === void 0 || id === null || id === "") {
            invalid = true;
            continue;
          }
          const key = variableKey(id) || variableKey(record24(fill.keysById)[id]);
          if (key) keys.push(key);
          else unavailable = true;
        }
      }
      if (!active) invalid = true;
    }
    const unique = [...new Set(keys)].sort();
    if (unique.length > 1) invalid = true;
    if (!unavailable || invalid) facts.fill = { valid: !invalid && !unavailable && unique.length === 1, keys: unique };
    else missing("fill");
    const ids = node.textStyleEvidenceV1 === void 0 ? [record24(record24(node.appearance).typography).styleId] : styleRanges ? styleRanges.length ? styleRanges.map((s) => s.styleId) : [record24(record24(node.appearance).typography).styleId] : void 0;
    let styleUnknown = !ids || unknown9(node, "textStyleEvidenceV1");
    if (node.textStyleEvidenceV1 === void 0 && unknown9(node, "appearance.typography")) styleUnknown = true;
    let detached = false;
    const styles = [];
    if (ids) for (const id of ids) {
      if (id === "") {
        detached = true;
        continue;
      }
      const key = styleKey(id) || styleKey(record24(style.keysById)[id]);
      if (key) styles.push(key);
      else styleUnknown = true;
    }
    const uniqueStyles = [...new Set(styles)].sort();
    if (uniqueStyles.length > 1) detached = true;
    if (!styleUnknown || detached) facts.style = { valid: !detached && !styleUnknown && uniqueStyles.length === 1, keys: uniqueStyles };
    else missing("style");
    node.textBindingIdentityV1 = facts;
  }
  const roots = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id)));
  if (roots.length !== 1) return;
  const root2 = roots[0], expected = {};
  root2.selectedTextBindingV1 = expected;
  const reps = contract.facts.representations.filter((r) => r.kind === "figma" && r.status !== "deprecated" && matchesCaptureRepresentation(r, snapshot.source?.componentKey || "", snapshot.source?.componentSetKey || ""));
  const variants = (contract.facts.variantEvidence?.textBindings || []).filter((v) => v.componentKey === snapshot.source?.componentKey && v.componentSetKey === (snapshot.source?.componentSetKey || snapshot.source?.componentKey));
  for (const c of contract.facts.textBindingComparisons || []) {
    if (c.type !== "bindingConsistency" || c.bindingReference !== "selected-variant") continue;
    const path = `selectedTextBindingV1.${bindingConsistencyKey(c)}`;
    const keys = [];
    let valid = reps.length === 1 && variants.length === 1 && ["verified", "partial"].includes(String(record24(root2.variantAvailability).status));
    for (const role of c.targetRoles || []) {
      const targets = contract.facts.targets.filter((t) => t.semanticRole === role), target = targets[0];
      const hints = target?.representationHints?.filter((h) => h.representationId === reps[0]?.id) || [];
      const targetPath = hints.length === 1 ? hints[0].pathHint : target?.pathHint;
      const key = targetPath && styleKey(variants[0]?.styleKeysByPath?.[targetPath.split(" / ").slice(1).join(" / ")]);
      if (targets.length !== 1 || hints.length > 1 || !key) valid = false;
      else keys.push(key);
    }
    if (valid && keys.length && new Set(keys).size === 1) expected[bindingConsistencyKey(c)] = [keys[0]];
    else root2.unknownFacts.push(path);
  }
}

// src/structural-order.ts
function materializeStructuralOrder(snapshot, contract) {
  if (contract.runtimePolicy.structuralOrderFactsVersion !== 1) return;
  const nodes = snapshot.nodes;
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const byParent = /* @__PURE__ */ new Map();
  for (const node of nodes) if (node.parentId) byParent.set(node.parentId, [...byParent.get(node.parentId) || [], node]);
  const unknown12 = (node, path) => (node.unknownFacts || []).some((p) => p === path || path.startsWith(p + "."));
  const duplicateIds = byId.size !== nodes.length;
  for (const node of nodes) {
    delete node.structuralOrderV1;
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "structuralOrderV1.directChildRoles");
    const ids = node.childIds;
    const children = Array.isArray(ids) ? ids.map((id) => byId.get(id)) : [];
    const valid = !duplicateIds && snapshot.source?.truncated !== true && Array.isArray(ids) && !unknown12(node, "childIds") && new Set(ids).size === ids.length && children.every((child) => child && child.parentId === node.id && !unknown12(child, "parentId") && !unknown12(child, "semantic.role") && typeof child.semantic?.role === "string" && child.semantic.role.length > 0) && (byParent.get(node.id) || []).every((child) => ids.includes(child.id));
    if (valid) node.structuralOrderV1 = { directChildRoles: children.map((child) => child.semantic.role) };
    else node.unknownFacts.push("structuralOrderV1.directChildRoles");
  }
}

// src/variant-text-targets.ts
var record25 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var unknown10 = (n, path) => (n.unknownFacts || []).some((p) => p === path || path.startsWith(p + "."));
function materializeVariantTextTargets(snapshot, contract) {
  if (contract.runtimePolicy.variantTextTargetsVersion !== 1) return;
  for (const target of contract.facts.targets.filter((t) => t.variantContinuity)) for (const node of snapshot.nodes) {
    if (record25(node.semantic).role === target.semanticRole && record25(record25(node.variantAvailability).targets)[target.semanticRole]?.present !== true) {
      delete record25(node.semantic).role;
    }
  }
  if (snapshot.instanceContentReferences?.schemaVersion !== "apollo.instance-content-references.v4") return;
  const ref = snapshot.variantReference, paths = snapshotPaths(snapshot);
  if (!ref || !paths || variantAvailability(snapshot, contract).status !== "partial") return;
  const reps = contract.facts.representations.filter((r) => r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey));
  if (reps.length !== 1) return;
  const targetPath = (t) => {
    const p = selectedTargetPathHint(t, reps[0].id, ref.componentKey, contract.facts.variantEvidence?.occurrenceAddressVersion === 1);
    return p ? relativeTargetPath(p) : void 0;
  };
  const candidates = [];
  for (const target of contract.facts.targets) {
    const c = target.variantContinuity;
    if (!c || c.kind !== "same-family-text" || target.resolution !== "resolved") continue;
    const anchors = contract.facts.targets.filter((t) => t.id === c.anchorTargetId && t.resolution === "resolved" && !t.variantContinuity);
    if (anchors.length !== 1) continue;
    const path = targetPath(target), anchorPath = targetPath(anchors[0]);
    if (!path || !anchorPath || !path.startsWith(anchorPath + " / ")) continue;
    if (ref.nodes.filter((n) => n.path === path && n.type === "TEXT").length !== 1) continue;
    const anchorsInSnapshot = snapshot.nodes.filter((n) => record25(n.semantic).role === anchors[0].semanticRole && n.type === "INSTANCE");
    if (anchorsInSnapshot.length !== 1) continue;
    const anchor = anchorsInSnapshot[0], ap = record25(anchor.baselineProvenance);
    if (ap.status !== "matched" || ap.kind !== "independent-host-variant" || ap.boundaryNodeId !== anchor.id || ap.referencePath !== anchorPath || !ap.componentSetKey || unknown10(anchor, "component.identity")) continue;
    const identity = record25(record25(anchor.component).identity);
    if (identity.componentKey !== ap.componentKey || identity.componentSetKey !== ap.componentSetKey) continue;
    const result = snapshot.instanceContentResults?.filter((r) => r.boundaryNodeId === anchor.id) || [];
    if (result.length !== 1 || result[0].status !== "matched" || !result[0].lineageProven) continue;
    const attempts = snapshot.instanceContentReferences.attempts.filter((a) => a.boundaryNodeId === anchor.id);
    if (attempts.length !== 1 || attempts[0].strategy !== "pristine-host-variant-properties" || !attempts[0].reference) continue;
    const reference = attempts[0].reference, referencePaths = snapshotPaths(reference);
    const refs2 = reference.nodes.filter((n) => referencePaths?.get(String(n.id)) === path && n.type === "TEXT");
    if (refs2.length !== 1) continue;
    const nodes = snapshot.nodes.filter((n) => {
      const p = record25(n.baselineProvenance);
      return n.type === "TEXT" && p.status === "matched" && p.kind === "independent-host-variant" && p.boundaryNodeId === anchor.id && p.componentKey === ap.componentKey && p.referencePath === path && result[0].matchedNodeIds.includes(String(n.id));
    });
    if (nodes.length !== 1) continue;
    const node = nodes[0], byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
    let parent3 = byId.get(String(node.parentId));
    while (parent3 && parent3.type !== "INSTANCE") parent3 = byId.get(String(parent3.parentId));
    if (parent3 !== anchor || unknown10(node, "type") || unknown10(node, "parentId")) continue;
    candidates.push({ role: target.semanticRole, node });
  }
  for (const { role, node } of candidates) {
    if (contract.facts.targets.filter((t) => t.semanticRole === role).length !== 1 || candidates.filter((c) => c.node.id === node.id).length !== 1 || snapshot.nodes.some((n) => n !== node && record25(n.semantic).role === role)) continue;
    node.semantic = { ...record25(node.semantic), role };
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "semantic.role");
    for (const entry of snapshot.nodes) {
      const facts = record25(entry.variantAvailability);
      facts.targets = { ...record25(facts.targets), [role]: { present: true, referenceState: "present", evidence: "explicit-independent-host-variant-text" } };
      entry.variantAvailability = facts;
      entry.unknownFacts = (entry.unknownFacts || []).filter((p) => p !== `variantAvailability.targets.${role}.present`);
    }
  }
}

// src/line-height-reference.ts
var record26 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var known = (n, p) => !(n.unknownFacts || []).some((x) => x === p || p.startsWith(x + ".") || x.startsWith(p + "."));
function materializeLineHeightReferences(snapshot, contract) {
  const roles = [...new Set(contract.capabilities.facts.filter((f) => f.startsWith("lineHeightReferenceV1.")).map((f) => f.slice("lineHeightReferenceV1.".length)))];
  if (!roles.length) return;
  const roots = snapshot.nodes.filter((n) => snapshot.selection.includes(String(n.id))), values = {};
  for (const role of roles) {
    if (roots.length !== 1 || !["verified", "partial"].includes(record26(roots[0].variantAvailability).status)) continue;
    const targets = contract.facts.targets.filter((t) => t.semanticRole === role && t.resolution === "resolved");
    const nodes = snapshot.nodes.filter((n2) => n2.type === "TEXT" && record26(n2.semantic).role === role);
    if (targets.length !== 1 || nodes.length !== 1) continue;
    const n = nodes[0], proof = record26(n.baselineProvenance), text3 = record26(record26(record26(n.baseline).effective).text), lh = record26(text3.lineHeight);
    if (proof.status !== "matched" || !known(n, "baseline.effective.text.lineHeight") || !known(n, "baselineProvenance")) continue;
    const pixels = lh.unit === "PIXELS" ? lh.value : lh.unit === "PERCENT" && known(n, "baseline.effective.text.fontSize") && typeof text3.fontSize === "number" && Number.isFinite(text3.fontSize) && text3.fontSize > 0 ? text3.fontSize * lh.value / 100 : void 0;
    if (typeof pixels === "number" && Number.isFinite(pixels) && pixels > 0) values[role] = pixels;
  }
  for (const node of snapshot.nodes) {
    node.lineHeightReferenceV1 = { ...values };
    node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== "lineHeightReferenceV1" && !p.startsWith("lineHeightReferenceV1."));
    for (const role of roles) if (values[role] === void 0) node.unknownFacts.push(`lineHeightReferenceV1.${role}`);
  }
}

// src/native-slot-capture.ts
var record27 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var unknown11 = (node, fact2) => (node?.unknownFacts || []).some((f) => f === fact2 || f.startsWith(fact2 + ".") || fact2.startsWith(f + "."));
function nativeSlotCapturePlan(contract) {
  if (contract.runtimePolicy.nativeSlotTargetsVersion !== 1 || contract.componentDependencies?.length || contract.facts.transitions?.length || contract.nonExecutableRules.length || contract.capabilities.operators.some((op) => !["all", "any", "equals", "one-of", "not", "matches-effective-baseline", "fact-present", "binding-satisfies"].includes(op)) || contract.capabilities.facts.some((f) => /^(relations|children|structuralOrder|host|semanticTargets|semanticApi|transitions|dependency)/.test(f))) return;
  const policies = contract.customizationPolicy.filter((p) => p.status !== "deprecated");
  if (policies.some((p) => (p.targetScope || "self") !== "self" || p.execution?.route === "context-only" || p.execution?.route === "delegated")) return;
  const boundaries = [];
  for (const p of policies) {
    if (p.status !== "reviewed" || p.permission !== "allowed" || p.capability !== "composition.content" || p.applicability.variants !== "all" || p.applicability.modes !== "all" || p.applicability.products?.length || p.applicability.channels?.length || Object.keys(p.applicability.context || {}).length || Object.keys(p.applicability.contextDomains || {}).length) continue;
    const target = contract.facts.targets.find((t) => t.id === p.targetId && t.resolution === "resolved");
    if (!target) continue;
    const controls = p.controlPaths.filter((c) => c.kind === "slot-api" && c.target === target.id && c.contentOwnership === "external" && c.property && !c.ownerTargetId);
    if (controls.length !== 1 || policies.filter((other) => other.targetId === target.id).some((other) => other !== p && other.capability === "composition.content")) continue;
    for (const rep of contract.facts.representations.filter((r) => r.status !== "deprecated")) {
      const hints = target.representationHints?.filter((h) => h.representationId === rep.id) || [];
      if (hints.length > 1) continue;
      const path = (hints[0]?.pathHint || target.pathHint)?.split(" / ").slice(1).join(" / ");
      if (!path || path.includes(" / ")) continue;
      if (policies.some((other) => {
        const t = contract.facts.targets.find((t2) => t2.id === other.targetId);
        const h = t?.representationHints?.find((h2) => h2.representationId === rep.id);
        const otherPath = (h?.pathHint || t?.pathHint)?.split(" / ").slice(1).join(" / ");
        return otherPath?.startsWith(path + " / ");
      })) continue;
      boundaries.push({ targetId: target.id, property: controls[0].property, path, representationId: rep.id });
    }
  }
  return boundaries.length ? { version: 1, manualSourceHash: contract.package.manualSourceHash, boundaries } : void 0;
}
function confirmedNativeSlotCaptureBoundaries(plan, reference, representationId, componentKey, componentSetKey) {
  if (plan?.version !== 1 || !reference.complete || reference.componentKey !== componentKey || reference.componentSetKey !== componentSetKey) return [];
  return plan.boundaries.filter((b) => b.representationId === representationId && reference.nodeProperties[""]?.propertyTypes[b.property] === "SLOT" && reference.nodes.filter((n) => n.type === "SLOT" && !n.path.includes(" / ") && reference.nodeProperties[n.path]?.propertyReferenceBindings?.slotContentId === b.property).length === 1 && reference.nodes.some((n) => n.path === b.path && n.type === "SLOT" && reference.nodeProperties[n.path]?.propertyReferenceBindings?.slotContentId === b.property));
}
function validateNativeSlotCaptureScope(snapshot, contract) {
  const scope = snapshot.source?.nativeSlotCaptureScope;
  if (!scope) return;
  const plan = nativeSlotCapturePlan(contract), ref = snapshot.variantReference, paths = snapshotPaths(snapshot);
  const root2 = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const identity = record27(record27(root2?.component).identity);
  const reps = ref ? contract.facts.representations.filter((r) => r.status !== "deprecated" && r.platform === snapshot.context.platform && matchesCaptureRepresentation(r, ref.componentKey, ref.componentSetKey)) : [];
  let valid = scope.version === 1 && plan?.manualSourceHash === scope.manualSourceHash && !!paths && reps.length === 1 && !!ref && identity.componentKey === ref.componentKey && (identity.componentSetKey || "") === ref.componentSetKey && !unknown11(root2, "component.identity");
  const confirmed = ref && reps.length === 1 ? confirmedNativeSlotCaptureBoundaries(plan, ref, reps[0].id, identity.componentKey, identity.componentSetKey || "") : [];
  const seen = /* @__PURE__ */ new Set();
  for (const omission of scope.omissions) {
    const node = snapshot.nodes.find((n) => n.id === omission.nodeId), component = record27(node?.component);
    const same2 = confirmed.filter((b) => b.targetId === omission.targetId && b.property === omission.property && b.path === paths?.get(omission.nodeId));
    const consumers = snapshot.nodes.filter((n) => n.type === "SLOT" && n.parentId === root2?.id && record27(record27(n.component).propertyReferenceBindings).slotContentId === omission.property);
    if (seen.has(omission.nodeId) || same2.length !== 1 || omission.path !== paths?.get(omission.nodeId) || node?.type !== "SLOT" || node.parentId !== root2?.id || component.propertyReferenceBindings?.slotContentId !== omission.property || record27(record27(root2?.component).propertyTypes)[omission.property] !== "SLOT" || unknown11(root2, `component.propertyTypes.${omission.property}`) || consumers.length !== 1 || !Array.isArray(node.childIds) || node.childIds.length !== 0 || (node.unknownFacts || []).some((f) => f.startsWith("component.propertyReferenceBindings") || f === "type" || f === "parentId")) valid = false;
    seen.add(omission.nodeId);
  }
  if (!scope.omissions.length) valid = false;
  if (!valid && snapshot.source) {
    snapshot.source.truncated = true;
    snapshot.source.captureTopology = { version: 1, complete: false, limitReached: false, issues: [{ kind: "unconfirmed-scope", path: "" }] };
  }
}

// src/instance-main-aliases.ts
function configureInstanceMainAliases(snapshot, enabled) {
  if (snapshot.source) {
    delete snapshot.source.instanceMainComponentAliasesVersion;
    if (enabled) snapshot.source.instanceMainComponentAliasesVersion = 1;
  }
  if (snapshot.instanceContentReferences) {
    configureInstanceMainAliases(snapshot.instanceContentReferences.base, enabled);
    for (const attempt of snapshot.instanceContentReferences.attempts)
      if (attempt.reference) configureInstanceMainAliases(attempt.reference, enabled);
  }
  for (const capture of snapshot.componentDependencyCaptures || [])
    if (capture.snapshot) configureInstanceMainAliases(capture.snapshot, enabled);
}
function restoreInstanceMainAliasBaseline(snapshot) {
  const base = snapshot.instanceContentReferences?.base, original = snapshot.variantReference;
  if (snapshot.source?.instanceMainComponentAliasesVersion !== 1 || !base || !original?.complete || !base.source?.rootNodeId || base.source.rootNodeId === snapshot.source.rootNodeId || base.context.platform !== snapshot.context.platform || stableHash(base.context.modes) !== stableHash(snapshot.context.modes)) return;
  const reference = captureVariantReference(base, base.source.componentKey || "", base.source.componentSetKey || "", original.definedProperties);
  if (!reference.complete || stableHash(reference) !== stableHash(original)) return;
  snapshot.nodes = materializeEffectiveBaseline(snapshot, base, true).snapshot.nodes;
}

// src/runtime.ts
function prepareValidationSnapshot(source, contract, inheritedMainAliases) {
  assertDeclaredTargetContract(contract);
  assertNativeRuleFactPolicies(contract);
  assertConfiguredPropertyContract(contract);
  const shape = contractRepresentationShape(contract), flags = representationFeatureFlags(shape);
  if (flags.evidence || flags.bindings || contract.runtimePolicy.representationEvidenceVersion !== void 0 || contract.runtimePolicy.crossRepresentationBindingsVersion !== void 0) {
    if (contract.runtimePolicy.representationEvidenceVersion !== void 0 && contract.runtimePolicy.representationEvidenceVersion !== 1 || contract.runtimePolicy.crossRepresentationBindingsVersion !== void 0 && contract.runtimePolicy.crossRepresentationBindingsVersion !== 1 || representationEvidenceErrors(shape).length || flags.evidence !== (contract.runtimePolicy.representationEvidenceVersion === 1) || flags.bindings !== (contract.runtimePolicy.crossRepresentationBindingsVersion === 1)) throw new Error("REPRESENTATION_RUNTIME_UNSUPPORTED");
  }
  const snapshot = JSON.parse(JSON.stringify(source));
  delete snapshot.snapshotHash;
  const mainAliases = contract.runtimePolicy.instanceMainComponentAliasesVersion === 1 || inheritedMainAliases === 1;
  configureInstanceMainAliases(snapshot, mainAliases);
  if (mainAliases) restoreInstanceMainAliasBaseline(snapshot);
  validateNativeSlotCaptureScope(snapshot, contract);
  materializeValidationMode(snapshot, contract);
  materializeSemanticFacts(snapshot, contract);
  materializeValidationIntent(snapshot, contract);
  if (!contract.facts.variantEvidence && (snapshot.targetResolution?.schemaVersion === TARGET_RESOLUTION_SCHEMA || contract.runtimePolicy.ruleScopeFactsVersion === 1)) materializeTargetResolution(snapshot, contract);
  if (["variant-facts-v3", "variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) materializeVariantFacts(snapshot, contract);
  if (["variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) materializeInstanceContentReferences(snapshot);
  materializeVerifiedVariantTargets(snapshot, contract);
  materializeVariantTextTargets(snapshot, contract);
  materializeLineHeightReferences(snapshot, contract);
  materializeSlotTargets(snapshot, contract);
  materializeDeclaredTargetIdentities(snapshot, contract);
  materializeNativeTargetProperties(snapshot, contract);
  materializeTextContent(snapshot, contract);
  if (["component-facts-v2", "variant-facts-v3", "variant-facts-v4", "dependency-facts-v5"].includes(contract.package.snapshotProfile || "")) materializeComponentFacts(snapshot, contract);
  if (contract.package.snapshotProfile === "dependency-facts-v5") materializeDependencyFacts(snapshot, contract);
  if (contract.runtimePolicy.gradientPaintFactsVersion === 1) materializeGradientPaintEvidence(snapshot);
  if (contract.runtimePolicy.paintBindingFactsVersion === 1) materializePaintBindings(snapshot);
  materializeTextStyleBindings(snapshot, contract);
  materializeTextBindingIdentities(snapshot, contract);
  if (contract.runtimePolicy.ruleScopeFactsVersion === 1) materializeRuleScopeFacts(snapshot, contract);
  materializeTargetSemanticFacts(snapshot, contract);
  materializeStructuralOrder(snapshot, contract);
  materializeLibraryText(snapshot, contract);
  materializeDependencyComposition(snapshot, contract);
  materializeMemberCollections(snapshot, contract);
  materializeTransitionFacts(snapshot, contract, (before) => prepareValidationSnapshot(before, {
    ...contract,
    runtimePolicy: { ...contract.runtimePolicy, transitionFactsVersion: void 0 }
  }));
  if (contract.runtimePolicy.configuredNativePropertyConformanceVersion === 1) materializeConfiguredNativeProperties(source, snapshot, contract);
  return snapshot;
}
function validationSnapshotHash(snapshot, contract) {
  return (0, import_predicate.snapshotHash)(prepareValidationSnapshot(snapshot, contract));
}
function prepareAuthoringPreviewContract(contract) {
  return {
    ...contract,
    rules: contract.rules.map((rule) => {
      const authority = rule.authority;
      if (authority?.status !== "draft") return rule;
      return {
        ...rule,
        authority: { ...authority, status: "active" }
      };
    })
  };
}
function evaluateCompiledContract(snapshot, contract, ancestry = [], inheritedMainAliases) {
  const mainAliases = contract.runtimePolicy.instanceMainComponentAliasesVersion === 1 || inheritedMainAliases === 1 ? 1 : void 0;
  const prepared = prepareValidationSnapshot(snapshot, contract, mainAliases);
  const result = (0, import_predicate.evaluateRules)({
    snapshot: prepared,
    rules: contract.rules,
    ruleRelease: contract.package.manualSourceHash
  });
  configuredCaptureUnknowns(result, contract);
  if (contract.runtimePolicy.memberCollectionsVersion === 1) {
    const root2 = prepared.nodes.find((n) => n.id === prepared.selection[0]);
    for (const evaluation of result.evaluations) {
      const rule = contract.rules.find((r) => r.ruleId === evaluation.ruleId), id = rule?.presentation?.collectionId;
      const fact2 = id && root2?.memberCollectionsV1?.[id];
      if (!fact2) continue;
      evaluation.collection = { id, ...fact2, summary: memberCollectionSummary(fact2) };
      if (evaluation.classification === "violation") {
        evaluation.focusNodeId = fact2.violations?.find((v) => v.nodeId)?.nodeId || fact2.ownerNodeId || evaluation.focusNodeId;
        evaluation.focusNodeName = prepared.nodes.find((n) => n.id === evaluation.focusNodeId)?.name || evaluation.focusNodeName;
      }
    }
  }
  if (!contract.componentDependencies?.length) return result;
  const runs = [];
  const evaluations = result.evaluations.slice();
  const ancestors = [...ancestry, contract.package.componentId];
  const claimedChildren = /* @__PURE__ */ new Set();
  for (const d of contract.componentDependencies) for (const b of d.bindings) {
    const run = { dependencyId: d.id, bindingId: b.id, componentId: d.componentId, revision: d.revision, compiledHash: d.compiledHash };
    runs.push(run);
    const issue = d.issue || dependencyPinIssue(d, d.contract) || (ancestors.includes(d.componentId) ? "dependency-cycle" : ancestors.length > COMPONENT_DEPENDENCY_DEPTH_LIMIT ? "dependency-depth-limit" : void 0);
    if (issue) {
      Object.assign(run, { status: "not-executed", reason: issue });
      continue;
    }
    const resolved = resolveFixedNestedBinding(prepared, d, b, false, contract);
    if (resolved.status === "inactive") {
      Object.assign(run, { status: "not-applicable", reason: resolved.reason });
      continue;
    }
    Object.assign(run, { nodeId: resolved.nodeId });
    if (resolved.status !== "active" || !resolved.nodeId || !resolved.identityValid) {
      Object.assign(run, { status: "not-executed", reason: resolved.identityValid === false ? "dependency-child-identity-mismatch" : resolved.reason });
      continue;
    }
    if (contract.runtimePolicy.directChildDependenciesVersion === 1) {
      if (claimedChildren.has(resolved.nodeId)) {
        Object.assign(run, { status: "not-executed", reason: "dependency-child-claimed-twice" });
        continue;
      }
      claimedChildren.add(resolved.nodeId);
    }
    const capture = validatedDependencyCapture(prepared, resolved.nodeId, d.contract);
    if (!capture.snapshot || !capture.nodeMap) {
      Object.assign(run, { status: "not-executed", reason: capture.reason });
      continue;
    }
    const output = evaluateCompiledContract(capture.snapshot, d.contract, ancestors, mainAliases);
    const childEvaluations = output.evaluations;
    const unsupported = d.contract.nonExecutableRules.length || d.contract.customizationPolicy.some((p) => p.status !== "deprecated" && ["delegated", "context-only"].includes(p.execution.route));
    const incomplete = unsupported || childEvaluations.some((e) => ["not-executed", "human-review", "not-evaluable", "unknown"].includes(String(e.classification)) || String(e.trace?.reason) === "rule authority is not active" || String(e.trace?.reason) === "selector matched no visible nodes" && (contract.runtimePolicy.dependencyCompletionVersion !== 1 || e.classification !== "not-applicable")) || (output.dependencyRuns || []).some((r) => r.status === "not-executed" || r.status === "incomplete");
    Object.assign(run, {
      status: incomplete ? "incomplete" : "executed",
      snapshotHash: output.snapshotHash,
      evaluations: childEvaluations.length,
      ...incomplete ? { reason: "dependency-check-incomplete" } : {}
    });
    for (const e of childEvaluations) evaluations.push({
      ...e,
      evaluationId: stableHash({ dependencyId: d.id, bindingId: b.id, nodeId: resolved.nodeId, evaluationId: e.evaluationId }),
      subjectNodeId: capture.nodeMap[String(e.subjectNodeId)] || resolved.nodeId,
      focusNodeId: capture.nodeMap[String(e.focusNodeId)] || resolved.nodeId,
      dependency: {
        componentId: d.componentId,
        dependencyId: d.id,
        bindingId: b.id,
        ruleId: e.ruleId,
        revision: d.revision,
        compiledHash: d.compiledHash,
        ...e.dependency ? { nested: e.dependency } : {}
      }
    });
  }
  const byClassification = {};
  evaluations.forEach((e) => {
    const k = String(e.classification);
    byClassification[k] = (byClassification[k] || 0) + 1;
  });
  return { ...result, evaluations, dependencyRuns: runs, coverage: {
    total: evaluations.length,
    byClassification,
    unclassified: evaluations.filter((e) => !e.classification).length,
    duplicateEvaluationIds: evaluations.length - new Set(evaluations.map((e) => e.evaluationId)).size
  } };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  evaluateCompiledContract,
  prepareAuthoringPreviewContract,
  prepareValidationSnapshot,
  validationSnapshotHash
});
