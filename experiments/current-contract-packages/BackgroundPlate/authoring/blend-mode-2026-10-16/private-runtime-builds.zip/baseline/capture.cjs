"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/figma-capture.ts
var figma_capture_exports = {};
__export(figma_capture_exports, {
  applyModes: () => applyModes,
  captureComponentDependencies: () => captureComponentDependencies,
  captureInstanceAudit: () => captureInstanceAudit,
  captureInstanceContentReferences: () => captureInstanceContentReferences,
  collectNodes: () => collectNodes,
  exportPreview: () => exportPreview,
  referenceProperties: () => referenceProperties,
  slug: () => slug
});
module.exports = __toCommonJS(figma_capture_exports);

// src/occurrence-address.ts
function occurrenceSegment(name, sourceId, localId) {
  if (sourceId !== void 0) return "@source:" + encodeURIComponent(sourceId);
  if (localId !== void 0) return "@local:" + encodeURIComponent(localId);
  return name.startsWith("@") || name.includes(" / ") ? "@name:" + encodeURIComponent(name) : name;
}

// src/snapshot-topology.ts
function snapshotPaths(snapshot) {
  if (snapshot.selection.length !== 1 || snapshot.source?.truncated !== false || snapshot.source.captureTopology?.complete === false) return void 0;
  const byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  if (byId.size !== snapshot.nodes.length) return void 0;
  const root = byId.get(snapshot.selection[0]);
  if (!root || root.parentId !== null) return void 0;
  const paths = /* @__PURE__ */ new Map();
  const pathFor = (node, visited = /* @__PURE__ */ new Set()) => {
    const id = String(node.id);
    if (visited.has(id)) return void 0;
    visited.add(id);
    if (node === root) return "";
    const parent = byId.get(String(node.parentId));
    if (!parent || !Array.isArray(parent.childIds) || !parent.childIds.includes(id)) return void 0;
    const parentPath3 = pathFor(parent, visited);
    if (parentPath3 === void 0 || typeof node.name !== "string") return void 0;
    let segment = node.name;
    if (snapshot.source?.occurrenceAddressVersion === 1) {
      const siblings = snapshot.nodes.filter((n) => n.parentId === node.parentId && n.name === node.name);
      const source = node.component?.sourceIdentity;
      segment = siblings.length > 1 ? occurrenceSegment(
        node.name,
        typeof source?.sourceNodeId === "string" && source.sourceNodeId ? source.sourceNodeId : void 0,
        typeof source?.sourceNodeId === "string" && source.sourceNodeId ? void 0 : id
      ) : occurrenceSegment(node.name);
    }
    return [parentPath3, segment].filter(Boolean).join(" / ");
  };
  for (const node of snapshot.nodes) {
    const path = pathFor(node);
    if (path === void 0 || [...paths.values()].includes(path)) return void 0;
    paths.set(String(node.id), path);
    if (!Array.isArray(node.childIds) || new Set(node.childIds).size !== node.childIds.length || node.childIds.some((id) => !byId.has(String(id)) || byId.get(String(id))?.parentId !== node.id)) return void 0;
  }
  return paths;
}
function snapshotShape(snapshot) {
  const paths = snapshotPaths(snapshot);
  return paths && snapshot.nodes.map((n) => ({ path: paths.get(String(n.id)), type: paths.get(String(n.id)) === "" ? "ROOT" : String(n.type) })).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
}

// vendor/sha256.ts
function utf8Bytes(input) {
  const bytes = new Uint8Array(input.length * 3);
  let length = 0;
  for (let index = 0; index < input.length; index += 1) {
    let codePoint = input.charCodeAt(index);
    if (codePoint >= 55296 && codePoint <= 56319) {
      const low = input.charCodeAt(index + 1);
      if (low >= 56320 && low <= 57343) {
        codePoint = 65536 + (codePoint - 55296 << 10) + (low - 56320);
        index += 1;
      } else codePoint = 65533;
    } else if (codePoint >= 56320 && codePoint <= 57343) codePoint = 65533;
    if (codePoint <= 127) {
      bytes[length++] = codePoint;
    } else if (codePoint <= 2047) {
      bytes[length++] = 192 | codePoint >>> 6;
      bytes[length++] = 128 | codePoint & 63;
    } else if (codePoint <= 65535) {
      bytes[length++] = 224 | codePoint >>> 12;
      bytes[length++] = 128 | codePoint >>> 6 & 63;
      bytes[length++] = 128 | codePoint & 63;
    } else {
      bytes[length++] = 240 | codePoint >>> 18;
      bytes[length++] = 128 | codePoint >>> 12 & 63;
      bytes[length++] = 128 | codePoint >>> 6 & 63;
      bytes[length++] = 128 | codePoint & 63;
    }
  }
  return bytes.subarray(0, length);
}
function sha256Hex(input) {
  const rightRotate = (value, amount) => value >>> amount | value << 32 - amount;
  const maxWord = Math.pow(2, 32);
  const words = [];
  const hash = [];
  const constants = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate += 1) {
    if (isComposite[candidate]) continue;
    for (let multiple = candidate * candidate; multiple < 313; multiple += candidate) {
      isComposite[multiple] = true;
    }
    hash[primeCounter] = Math.pow(candidate, 0.5) * maxWord | 0;
    constants[primeCounter] = Math.pow(candidate, 1 / 3) * maxWord | 0;
    primeCounter += 1;
  }
  const bytes = utf8Bytes(input);
  const bitLength = bytes.length * 8;
  const paddedLength = bytes.length + 9 + 63 >> 6 << 6;
  const padded = new Uint8Array(paddedLength);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / maxWord), false);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const w15 = words[index - 15];
      const w2 = words[index - 2];
      const s0 = rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ w15 >>> 3;
      const s1 = rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ w2 >>> 10;
      words[index] = words[index - 16] + s0 + words[index - 7] + s1 | 0;
    }
    const working = hash.slice(0, 8);
    for (let index = 0; index < 64; index += 1) {
      const s1 = rightRotate(working[4], 6) ^ rightRotate(working[4], 11) ^ rightRotate(working[4], 25);
      const choice = working[4] & working[5] ^ ~working[4] & working[6];
      const temp1 = working[7] + s1 + choice + constants[index] + words[index] | 0;
      const s0 = rightRotate(working[0], 2) ^ rightRotate(working[0], 13) ^ rightRotate(working[0], 22);
      const majority = working[0] & working[1] ^ working[0] & working[2] ^ working[1] & working[2];
      const temp2 = s0 + majority | 0;
      working.unshift(temp1 + temp2 | 0);
      working[4] = working[4] + temp1 | 0;
      working.pop();
    }
    for (let index = 0; index < 8; index += 1) {
      hash[index] = hash[index] + working[index] | 0;
    }
  }
  return hash.slice(0, 8).map((value) => (value >>> 0).toString(16).padStart(8, "0")).join("");
}

// src/stable.ts
function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    const object2 = value;
    return `{${Object.keys(object2).filter((key) => object2[key] !== void 0).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(object2[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}
function stableHash(value) {
  return sha256Hex(stableStringify(value));
}

// src/capture-representation.ts
function matchesCaptureRepresentation(rep, componentKey, componentSetKey = "") {
  if (rep.kind !== "figma" || rep.status === "deprecated" || !componentKey) return false;
  const set = rep.locator.componentSetKey;
  if (typeof set === "string" && set) return Boolean(componentSetKey && set === componentSetKey);
  const key = rep.locator.componentKey;
  return typeof key === "string" && Boolean(key) && (key === componentKey || key === componentSetKey);
}
function resolveCaptureRepresentation(representations, componentKey, componentSetKey = "") {
  const matches = representations.filter((rep) => matchesCaptureRepresentation(rep, componentKey, componentSetKey));
  if (matches.length > 1) throw new Error("\u041A\u043B\u044E\u0447 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0430 \u0441\u0432\u044F\u0437\u0430\u043D \u0441 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u043C\u0438 Figma-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u043C\u0438 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430. \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 representations; \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430.");
  if (!matches.length) throw new Error("\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440 \u043D\u0435 \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u043A Figma-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u043C \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440 \u044D\u0442\u043E\u0433\u043E \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430 \u0438\u043B\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0433\u043E \u043F\u0430\u043A\u0435\u0442.");
  if (!matches[0].platform?.trim()) throw new Error("\u0414\u043B\u044F \u043D\u0430\u0439\u0434\u0435\u043D\u043D\u043E\u0433\u043E Figma-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u0430 \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430. \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430.");
  return matches[0];
}

// src/instance-correspondence.ts
var record = (value) => value && typeof value === "object" ? value : {};
var parentPath = (path) => path.split(" / ").slice(0, -1).join(" / ");
var leaf = (path) => path.split(" / ").slice(-1)[0];
function compareInstanceCorrespondence(snapshot, reference, nestedVariants) {
  const paths = snapshotPaths(snapshot), boundaries = [];
  const referencePaths = {};
  const invalid = () => ({ complete: false, boundaries, referencePaths });
  if (!paths || !reference.complete || !snapshot.source?.componentKey || reference.componentKey !== snapshot.source.componentKey || reference.componentSetKey !== (snapshot.source.componentSetKey || "")) return invalid();
  const actual = new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
  const expected = new Map(reference.nodes.map((n) => [n.path, n]));
  if (expected.size !== reference.nodes.length || expected.get("")?.type !== "ROOT") return invalid();
  for (const n of reference.nodes) if (n.path && !expected.has(parentPath(n.path))) return invalid();
  const aIdentity = (n) => record(record(n.component).identity);
  const rIdentity = (path) => reference.nodeProperties[path]?.identity;
  const unknown2 = (n, fact) => (n.unknownFacts || []).some((p) => p === fact || fact.startsWith(p + "."));
  const knownIdentity = (n) => Boolean(typeof aIdentity(n).componentKey === "string" && aIdentity(n).componentKey && !unknown2(n, "component.identity.componentKey") && !unknown2(n, "component.identity.componentSetKey"));
  const compatible = (n, path) => {
    const a = aIdentity(n), b = rIdentity(path);
    if (!knownIdentity(n) || !b?.componentKey) return false;
    if (a.componentSetKey || b.componentSetKey) return Boolean(a.componentSetKey && a.componentSetKey === b.componentSetKey);
    return a.componentKey === b.componentKey;
  };
  const ownerFor = (path, nodes) => {
    let p = parentPath(path);
    while (p) {
      if (nodes.get(p)?.type === "INSTANCE") return p;
      p = parentPath(p);
    }
    return "";
  };
  const actualPort = (path) => {
    const node = actual.get(path), c = record(node.component), property = record(c.propertyReferenceBindings).mainComponent;
    if (property === void 0) return void 0;
    const ownerPath = ownerFor(path, actual), ownerNode = actual.get(ownerPath), owner = record(ownerNode?.component);
    if (typeof property !== "string" || !knownIdentity(node) || typeof c.identity?.mainComponentId !== "string" || record(owner.propertyTypes)[property] !== "INSTANCE_SWAP" || record(owner.properties)[property] !== c.identity.mainComponentId || unknown2(node, "component.propertyReferenceBindings.mainComponent") || unknown2(ownerNode, "component.properties." + property) || unknown2(ownerNode, "component.propertyTypes." + property)) return null;
    return { ownerPath, property };
  };
  const referencePort = (path) => {
    const c = reference.nodeProperties[path], property = c?.propertyReferenceBindings?.mainComponent;
    if (property === void 0) return void 0;
    const ownerPath = ownerFor(path, expected), owner = reference.nodeProperties[ownerPath];
    if (!property || !c.identity?.mainComponentId || owner?.propertyTypes[property] !== "INSTANCE_SWAP" || owner.properties[property] !== c.identity.mainComponentId) return null;
    return { ownerPath, property };
  };
  const sourcePort = (path, referenceSide) => {
    if (snapshot.source?.instanceSourceIdentityVersion !== 1) return void 0;
    const type = (referenceSide ? expected : actual).get(path)?.type;
    if (type !== "INSTANCE" && (snapshot.source?.occurrenceAddressVersion !== 1 || reference.occurrenceAddressVersion !== 1)) return void 0;
    const node = actual.get(path), c = referenceSide ? reference.nodeProperties[path] : record(node?.component);
    const source = c?.sourceIdentity;
    if (source === void 0) return void 0;
    const ownerPath = ownerFor(path, referenceSide ? expected : actual);
    const ownerNode = actual.get(ownerPath);
    const owner = referenceSide ? reference.nodeProperties[ownerPath]?.identity : ownerNode && aIdentity(ownerNode);
    if (!source || source.version !== 1 || typeof source.sourceNodeId !== "string" || !source.sourceNodeId || typeof source.ownerComponentKey !== "string" || typeof source.ownerMainComponentId !== "string" || typeof owner?.componentKey !== "string" || !owner.componentKey || typeof owner.mainComponentId !== "string" || !owner.mainComponentId || source.ownerComponentKey !== owner.componentKey || source.ownerMainComponentId !== owner.mainComponentId || !referenceSide && (!node || type === "INSTANCE" && !knownIdentity(node) || !ownerNode || !knownIdentity(ownerNode) || ["version", "sourceNodeId", "ownerComponentKey", "ownerMainComponentId"].some((field) => unknown2(node, "component.sourceIdentity." + field)) || unknown2(ownerNode, "component.identity.mainComponentId"))) return null;
    return {
      ownerPath,
      sourceNodeId: source.sourceNodeId,
      ownerMainComponentId: source.ownerMainComponentId,
      ownerComponentKey: owner.componentKey,
      ownerComponentSetKey: owner.componentSetKey || ""
    };
  };
  const sameSourceOwner = (a, b) => a.ownerMainComponentId === b.ownerMainComponentId || snapshot.source?.instanceMainComponentAliasesVersion === 1 && a.ownerComponentKey === b.ownerComponentKey && a.ownerComponentSetKey === b.ownerComponentSetKey;
  const verifiedSlot = (actualPath, referencePath) => {
    const node = actual.get(actualPath), ref = reference.nodeProperties[referencePath];
    const property = record(record(node?.component).propertyReferenceBindings).slotContentId;
    if (!node || node.type !== "SLOT" || typeof property !== "string" || !property || ref?.propertyReferenceBindings?.slotContentId !== property || unknown2(node, "component.propertyReferenceBindings.slotContentId")) return false;
    const actualOwnerPath = ownerFor(actualPath, actual);
    const expectedOwnerPath = ownerFor(referencePath, expected);
    const actualOwner = actual.get(actualOwnerPath);
    const expectedOwner = reference.nodeProperties[expectedOwnerPath];
    if (!actualOwner || referencePaths[actualOwnerPath] !== expectedOwnerPath || record(record(actualOwner.component).propertyTypes)[property] !== "SLOT" || expectedOwner?.propertyTypes[property] !== "SLOT" || unknown2(actualOwner, `component.propertyTypes.${property}`)) return false;
    const actualConsumers = [...actual].filter(([p, n]) => n.type === "SLOT" && ownerFor(p, actual) === actualOwnerPath && record(record(n.component).propertyReferenceBindings).slotContentId === property);
    const expectedConsumers = reference.nodes.filter((n) => n.type === "SLOT" && ownerFor(n.path, expected) === expectedOwnerPath && reference.nodeProperties[n.path]?.propertyReferenceBindings?.slotContentId === property);
    return actualConsumers.length === 1 && expectedConsumers.length === 1;
  };
  const visibilityPort = (path, referenceSide) => {
    if (snapshot.source?.propertyReferenceIdentityVersion !== 1) return void 0;
    const node = actual.get(path), c = referenceSide ? reference.nodeProperties[path] : record(node?.component);
    const property = c?.propertyReferenceBindings?.visible;
    if (property === void 0) return void 0;
    const ownerPath = ownerFor(path, referenceSide ? expected : actual);
    const owner = referenceSide ? reference.nodeProperties[ownerPath] : record(actual.get(ownerPath)?.component);
    if (typeof property !== "string" || owner?.propertyTypes?.[property] !== "BOOLEAN" || typeof owner.properties?.[property] !== "boolean" || !referenceSide && (!node || !knownIdentity(node) || unknown2(node, "component.propertyReferenceBindings.visible") || unknown2(actual.get(ownerPath), `component.propertyTypes.${property}`) || unknown2(actual.get(ownerPath), `component.properties.${property}`))) return null;
    return { ownerPath, property };
  };
  referencePaths[""] = "";
  const root = actual.get(""), rootIdentity = root && aIdentity(root);
  if (!root || !knownIdentity(root) || rootIdentity?.componentKey !== reference.componentKey || (rootIdentity.componentSetKey || "") !== reference.componentSetKey) {
    if (reference.occurrenceAddressVersion === 1) delete referencePaths[""];
    return invalid();
  }
  const visit = (actualParent, expectedParent) => {
    const children = [...actual].filter(([p]) => p !== "" && parentPath(p) === actualParent);
    const refChildren = reference.nodes.filter((n) => n.path !== "" && parentPath(n.path) === expectedParent);
    if (children.length !== refChildren.length) return false;
    const claimed = /* @__PURE__ */ new Set();
    for (const [path, node] of children) {
      let candidates = refChildren.filter((n) => n.type === node.type && leaf(n.path) === leaf(path));
      const port = node.type === "INSTANCE" ? actualPort(path) : void 0;
      const visiblePort = node.type === "INSTANCE" && !port ? visibilityPort(path, false) : void 0;
      const source = sourcePort(path, false);
      let sourceCandidate;
      let uniqueVisibilityPort = false;
      if (port === null || visiblePort === null || source === null) return false;
      if (source) {
        const owner = referencePaths[source.ownerPath];
        const consumers = [...actual].filter(([p, n]) => {
          const other = sourcePort(p, false);
          return other?.ownerPath === source.ownerPath && other.sourceNodeId === source.sourceNodeId;
        });
        const matches = reference.nodes.filter((n) => {
          if (n.type !== node.type) return false;
          const other = sourcePort(n.path, true);
          return other?.ownerPath === owner && other.sourceNodeId === source.sourceNodeId && sameSourceOwner(source, other);
        });
        if (owner === void 0 || consumers.length !== 1 || matches.length !== 1 || parentPath(matches[0].path) !== expectedParent) return false;
        sourceCandidate = matches[0];
      }
      if (node.type === "INSTANCE") {
        const typed = refChildren.filter((n) => n.type === "INSTANCE");
        if (port) {
          const owner = referencePaths[port.ownerPath];
          const consumers = [...actual].filter(([p, n]) => {
            if (n.type !== "INSTANCE") return false;
            const other = actualPort(p);
            return other?.ownerPath === port.ownerPath && other.property === port.property;
          });
          const refConsumers = reference.nodes.filter((n) => {
            if (n.type !== "INSTANCE") return false;
            const other = referencePort(n.path);
            return other?.ownerPath === owner && other.property === port.property;
          });
          if (owner === void 0 || consumers.length !== 1 || refConsumers.length !== 1 || parentPath(refConsumers[0].path) !== expectedParent) return false;
          candidates = refConsumers;
        } else if (visiblePort) {
          const owner = referencePaths[visiblePort.ownerPath];
          const consumers = [...actual].filter(([p, n]) => n.type === "INSTANCE" && (() => {
            const other = visibilityPort(p, false);
            return other?.ownerPath === visiblePort.ownerPath && other.property === visiblePort.property;
          })());
          const matches = typed.filter((n) => {
            const other = visibilityPort(n.path, true);
            return other?.ownerPath === owner && other.property === visiblePort.property;
          });
          if (owner !== void 0 && consumers.length === 1 && matches.length === 1) {
            candidates = matches;
            uniqueVisibilityPort = true;
          } else if (sourceCandidate) candidates = [sourceCandidate];
          else {
            const identities = typed.filter((n) => compatible(node, n.path));
            if (identities.length !== 1 || children.filter(([, n]) => n.type === "INSTANCE" && compatible(n, identities[0].path)).length !== 1) return false;
            candidates = identities;
          }
        } else if (sourceCandidate) {
          candidates = [sourceCandidate];
        } else {
          const identities = typed.filter((n) => compatible(node, n.path));
          if (identities.length) {
            if (identities.length !== 1 || children.filter(([, n]) => n.type === "INSTANCE" && compatible(n, identities[0].path)).length !== 1) return false;
            candidates = identities;
          }
        }
      } else if (sourceCandidate) candidates = [sourceCandidate];
      if (candidates.length !== 1 || claimed.has(candidates[0].path)) return false;
      if (source && candidates[0].path !== sourceCandidate?.path) return false;
      if (reference.occurrenceAddressVersion === 1 && /^@(source|local):/.test(leaf(candidates[0].path)) && !sourceCandidate && !port && !uniqueVisibilityPort) return false;
      const refPath = candidates[0].path;
      claimed.add(refPath);
      referencePaths[path] = refPath;
      if (node.type === "SLOT" && verifiedSlot(path, refPath)) continue;
      if (node.type === "INSTANCE") {
        const identity = aIdentity(node), other = rIdentity(refPath), refPort = referencePort(refPath);
        if (refPort === null || sourcePort(refPath, true) === null || Boolean(port) !== Boolean(refPort)) return false;
        const keysKnown = knownIdentity(node) && Boolean(other?.componentKey);
        const sameSet = Boolean(identity.componentSetKey && identity.componentSetKey === other?.componentSetKey);
        const sameIdentity = keysKnown && identity.componentKey === other.componentKey && (identity.componentSetKey || "") === (other?.componentSetKey || "");
        if (!sameIdentity) {
          const variant = nestedVariants && keysKnown && !port && sameSet;
          boundaries.push({
            nodeId: String(node.id),
            actualPath: path,
            referencePath: refPath,
            reason: !keysKnown ? "instance-identity-unavailable" : port ? "instance-swap" : variant ? "component-variant-changed" : "component-identity-changed",
            ...identity.componentKey ? { actualComponentKey: identity.componentKey } : {},
            ...other?.componentKey ? { referenceComponentKey: other.componentKey } : {},
            ...variant ? { componentSetKey: identity.componentSetKey } : {},
            ...port ? { ownerPath: referencePaths[port.ownerPath], property: port.property } : {}
          });
          continue;
        }
      }
      if (!visit(path, refPath)) return false;
    }
    return claimed.size === refChildren.length;
  };
  const complete = visit("", "");
  if (!complete && snapshot.source?.occurrenceAddressVersion === 1 && reference.occurrenceAddressVersion === 1) {
    const claimed = new Set(Object.values(referencePaths));
    const nodes = [...actual].filter(([p]) => p).sort(([a], [b]) => a.split(" / ").length - b.split(" / ").length);
    for (const [path, node] of nodes) {
      if (referencePaths[path] !== void 0 || actualPort(path) !== void 0 || visibilityPort(path, false) === null) continue;
      const source = sourcePort(path, false), parent = referencePaths[parentPath(path)];
      if (!source || parent === void 0) continue;
      const owner = referencePaths[source.ownerPath], ownerIdentity = aIdentity(actual.get(source.ownerPath)), expectedOwner = owner !== void 0 ? rIdentity(owner) : void 0;
      if (owner === void 0 || !expectedOwner || ownerIdentity.componentKey !== expectedOwner.componentKey || snapshot.source?.instanceMainComponentAliasesVersion === 1 && (ownerIdentity.componentSetKey || "") !== (expectedOwner.componentSetKey || "") || ownerIdentity.mainComponentId !== expectedOwner.mainComponentId && snapshot.source?.instanceMainComponentAliasesVersion !== 1) continue;
      const consumers = nodes.filter(([p]) => {
        const s = sourcePort(p, false);
        return s?.ownerPath === source.ownerPath && s.sourceNodeId === source.sourceNodeId;
      });
      const candidates = reference.nodes.filter((n) => n.type === node.type && parentPath(n.path) === parent && (() => {
        const s = sourcePort(n.path, true);
        return s?.ownerPath === owner && s.sourceNodeId === source.sourceNodeId && sameSourceOwner(source, s);
      })());
      if (consumers.length !== 1 || candidates.length !== 1 || claimed.has(candidates[0].path) || referencePort(candidates[0].path) !== void 0 || visibilityPort(candidates[0].path, true) === null) continue;
      const refPath = candidates[0].path, a = aIdentity(node), b = rIdentity(refPath);
      if (node.type === "INSTANCE") {
        if (!knownIdentity(node) || !b?.componentKey) continue;
        const same = a.componentKey === b.componentKey && (a.componentSetKey || "") === (b.componentSetKey || "");
        if (!same) {
          if (!nestedVariants || !a.componentSetKey || a.componentSetKey !== b.componentSetKey) continue;
          boundaries.push({ nodeId: String(node.id), actualPath: path, referencePath: refPath, reason: "component-variant-changed", actualComponentKey: a.componentKey, referenceComponentKey: b.componentKey, componentSetKey: a.componentSetKey });
        }
      }
      referencePaths[path] = refPath;
      claimed.add(refPath);
    }
  }
  return { complete, boundaries, referencePaths };
}

// src/instance-boundaries.ts
var record2 = (value) => value && typeof value === "object" ? value : {};
var parentPath2 = (path) => path.split(" / ").slice(0, -1).join(" / ");
var withinBoundary = (path, boundary) => path === boundary || path.startsWith(`${boundary} / `);
var correspondingPath = (comparison, actualPath) => comparison?.referencePaths ? comparison.referencePaths[actualPath] : actualPath;
function compareInstanceBoundaries(snapshot, reference, nestedVariants = ["apollo.instance-content-references.v2", "apollo.instance-content-references.v3", "apollo.instance-content-references.v4"].includes(snapshot.instanceContentReferences?.schemaVersion || "")) {
  if (!reference.nodeProperties || typeof reference.nodeProperties !== "object" || Array.isArray(reference.nodeProperties)) {
    return { complete: false, boundaries: [], referencePaths: {} };
  }
  if (snapshot.source?.instanceIdentityVersion === 1) return compareInstanceCorrespondence(snapshot, reference, nestedVariants);
  const paths = snapshotPaths(snapshot), shape = snapshotShape(snapshot);
  const boundaries = [];
  const invalid = () => ({ complete: false, boundaries });
  if (!paths || !shape || !reference.complete) return invalid();
  if (!snapshot.source?.componentKey || reference.componentKey !== snapshot.source.componentKey || reference.componentSetKey !== (snapshot.source.componentSetKey || "")) return invalid();
  const actualByPath = new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
  const refByPath = new Map(reference.nodes.map((n) => [n.path, n]));
  if (refByPath.size !== reference.nodes.length) return invalid();
  const ownerFor = (path, nodes) => {
    let parent = parentPath2(path);
    while (parent) {
      if (nodes.get(parent)?.type === "INSTANCE") return parent;
      parent = parentPath2(parent);
    }
    return "";
  };
  const actualPort = (path) => {
    const node = actualByPath.get(path), component = record2(node?.component);
    const property = record2(component.propertyReferenceBindings).mainComponent;
    const ownerPath = ownerFor(path, actualByPath), owner = record2(actualByPath.get(ownerPath)?.component);
    if (typeof property !== "string" || record2(owner.propertyTypes)[property] !== "INSTANCE_SWAP" || typeof record2(component.identity).mainComponentId !== "string" || record2(owner.properties)[property] !== record2(component.identity).mainComponentId) return void 0;
    return { ownerPath, property };
  };
  const referencePort = (path) => {
    const data = reference.nodeProperties[path], property = data?.propertyReferenceBindings?.mainComponent;
    const ownerPath = ownerFor(path, refByPath), owner = reference.nodeProperties[ownerPath];
    if (!property || owner?.propertyTypes[property] !== "INSTANCE_SWAP" || !data?.identity?.mainComponentId || owner.properties[property] !== data.identity.mainComponentId) return void 0;
    return { ownerPath, property };
  };
  const instances = [...actualByPath].filter(([path, n]) => path && n.type === "INSTANCE").sort(([a], [b]) => a.split(" / ").length - b.split(" / ").length);
  for (const [path, node] of instances) {
    if (boundaries.some((b) => withinBoundary(path, b.actualPath))) continue;
    const identity = record2(record2(node.component).identity), port = actualPort(path);
    let refPath = refByPath.get(path)?.type === "INSTANCE" ? path : void 0;
    if (port) {
      const consumers = instances.filter(([p]) => {
        const other = actualPort(p);
        return other?.ownerPath === port.ownerPath && other.property === port.property;
      });
      const candidates = reference.nodes.filter((n) => {
        if (n.type !== "INSTANCE") return false;
        const other = referencePort(n.path);
        return other?.ownerPath === port.ownerPath && other.property === port.property;
      });
      if (consumers.length !== 1 || candidates.length !== 1 || parentPath2(candidates[0].path) !== parentPath2(path)) return invalid();
      refPath = candidates[0].path;
    }
    if (refPath === void 0) return invalid();
    const expected = reference.nodeProperties[refPath]?.identity;
    const keysKnown = typeof identity.componentKey === "string" && Boolean(identity.componentKey) && Boolean(expected?.componentKey);
    if (keysKnown && identity.componentKey === expected.componentKey && path === refPath) continue;
    const sameSet = nestedVariants && keysKnown && !port && path === refPath && typeof identity.componentSetKey === "string" && Boolean(identity.componentSetKey) && identity.componentSetKey === expected?.componentSetKey;
    boundaries.push({
      nodeId: String(node.id),
      actualPath: path,
      referencePath: refPath,
      reason: !keysKnown ? "instance-identity-unavailable" : port ? "instance-swap" : sameSet ? "component-variant-changed" : "component-identity-changed",
      ...sameSet ? { componentSetKey: identity.componentSetKey } : {},
      ...identity.componentKey ? { actualComponentKey: identity.componentKey } : {},
      ...expected?.componentKey ? { referenceComponentKey: expected.componentKey } : {},
      ...port || {}
    });
  }
  const prune = (nodes, actual) => nodes.flatMap((n) => {
    const boundary = boundaries.find((b) => withinBoundary(n.path, actual ? b.actualPath : b.referencePath));
    if (!boundary) return [n];
    if (n.path !== (actual ? boundary.actualPath : boundary.referencePath)) return [];
    return [{ path: boundary.referencePath, type: "INSTANCE" }];
  }).sort((a, b) => a.path.localeCompare(b.path) || a.type.localeCompare(b.type));
  return { complete: stableHash(prune(shape, true)) === stableHash(prune(reference.nodes, false)), boundaries };
}

// src/variant-facts.ts
var record3 = (x) => x && typeof x === "object" && !Array.isArray(x) ? x : {};
var relativeTargetPath = (path) => path.split(" / ").slice(1).join(" / ");
var propertyAvailabilityKey = (name) => `p_${stableHash(name).slice(0, 16)}`;
function captureVariantReference(snapshot, componentKey, componentSetKey, definedProperties) {
  const shape = snapshotShape(snapshot);
  const paths = snapshotPaths(snapshot);
  const root = snapshot.nodes.find((n) => snapshot.selection.includes(String(n.id)));
  const component = record3(root?.component);
  const referencesKnown = snapshot.nodes.every((n) => Array.isArray(record3(n.component).propertyReferences));
  const byId = new Map(snapshot.nodes.map((n) => [String(n.id), n]));
  const consumers = /* @__PURE__ */ new Map();
  for (const node of snapshot.nodes) {
    let parent = byId.get(String(node.parentId));
    const visited = /* @__PURE__ */ new Set();
    while (parent && !visited.has(String(parent.id))) {
      visited.add(String(parent.id));
      if (parent.type === "INSTANCE") {
        const names = consumers.get(String(parent.id)) || /* @__PURE__ */ new Set();
        (record3(node.component).propertyReferences || []).forEach((name) => names.add(name));
        consumers.set(String(parent.id), names);
        break;
      }
      parent = byId.get(String(parent.parentId));
    }
  }
  const nodeProperties = {};
  for (const node of snapshot.nodes) {
    const component2 = record3(node.component);
    const path = paths?.get(String(node.id)) ?? (node === root ? "" : relativeTargetPath(String(record3(node.semantic).path || "")));
    nodeProperties[path] = {
      properties: component2.properties || {},
      propertyTypes: component2.propertyTypes || {},
      propertyReferences: [...consumers.get(String(node.id)) || []],
      ...snapshot.source?.occurrenceAddressVersion === 1 ? { diagnosticName: String(node.name) } : {},
      ...component2.identity?.componentKey ? { identity: component2.identity } : {},
      ...component2.propertyReferenceBindings ? { propertyReferenceBindings: component2.propertyReferenceBindings } : {},
      ...node === root && definedProperties ? { definedProperties } : {}
    };
    if (snapshot.source?.instanceSourceIdentityVersion === 1 && component2.sourceIdentity) nodeProperties[path].sourceIdentity = component2.sourceIdentity;
  }
  return {
    componentKey,
    componentSetKey,
    complete: Boolean(shape && referencesKnown),
    nodes: shape || [],
    ...snapshot.source?.occurrenceAddressVersion === 1 ? { occurrenceAddressVersion: 1 } : {},
    properties: component.properties || {},
    propertyTypes: component.propertyTypes || {},
    propertyReferences: [...consumers.get(String(root?.id)) || []],
    nodeProperties,
    ...definedProperties ? { definedProperties } : {}
  };
}

// src/instance-validation.ts
var EFFECTIVE_FACT_KEYS = [
  "layout",
  "appearance",
  "variable",
  "component",
  "text",
  "visible"
];
function record4(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function semanticRole(node) {
  const semantic = record4(node.semantic);
  return typeof semantic.role === "string" ? semantic.role : "";
}
function intrinsicBounds(value) {
  const bounds = record4(value), result = {};
  for (const key of ["width", "height"]) {
    const size = bounds[key];
    if (typeof size === "number" && Number.isFinite(size) && size >= 0) result[key] = size;
  }
  return result;
}
function effectiveFacts(node, includeDimensions = false) {
  const result = {};
  EFFECTIVE_FACT_KEYS.forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(node, key)) result[key] = node[key];
  });
  if (includeDimensions) {
    const bounds = intrinsicBounds(node.bounds);
    if (Object.keys(bounds).length) result.bounds = bounds;
    if (node.propertyActivityV1) result.propertyActivityV1 = node.propertyActivityV1;
  }
  return result;
}
function cloneSnapshot(snapshot) {
  return JSON.parse(JSON.stringify(snapshot));
}
function materializeEffectiveBaseline(actual, reference, strictInstanceBoundaries = true) {
  const result = cloneSnapshot(actual);
  if (strictInstanceBoundaries) {
    const actualPaths = snapshotPaths(actual), referencePaths = snapshotPaths(reference);
    const ref = captureVariantReference(reference, reference.source?.componentKey || "", reference.source?.componentSetKey || "");
    const comparison = compareInstanceBoundaries(actual, ref);
    const byPath2 = new Map(reference.nodes.map((node) => [referencePaths?.get(String(node.id)), node]));
    const unmatchedNodeIds2 = [];
    let matchedNodes2 = 0;
    result.nodes = result.nodes.map((node) => {
      const path = actualPaths?.get(String(node.id));
      const isolated = path !== void 0 && comparison.boundaries.find((b) => withinBoundary(path, b.actualPath));
      const referencePath = path !== void 0 ? correspondingPath(comparison, path) : void 0;
      const expected = referencePath !== void 0 && comparison.complete && !isolated ? byPath2.get(referencePath) : void 0;
      if (!expected || expected.type !== node.type) {
        unmatchedNodeIds2.push(String(node.id));
        return { ...node, baseline: { effective: {} }, baselineProvenance: { status: "unresolved", reason: isolated ? isolated.reason : "structural-identity-unresolved" } };
      }
      matchedNodes2++;
      return { ...node, baseline: { effective: effectiveFacts(expected, true) }, baselineProvenance: { status: "matched", referencePath } };
    });
    return { snapshot: result, matchedNodes: matchedNodes2, unmatchedNodeIds: unmatchedNodeIds2 };
  }
  const referenceByRole = /* @__PURE__ */ new Map();
  reference.nodes.forEach((candidate) => {
    const node = record4(candidate);
    const role = semanticRole(node);
    if (role && !referenceByRole.has(role)) referenceByRole.set(role, node);
  });
  let matchedNodes = 0;
  const unmatchedNodeIds = [];
  result.nodes = result.nodes.map((candidate, index) => {
    const node = record4(candidate);
    const role = semanticRole(node);
    const referenceNode = referenceByRole.get(role) || (index === 0 ? record4(reference.nodes[0]) : void 0);
    if (!referenceNode || referenceNode.type !== node.type) {
      unmatchedNodeIds.push(String(node.id || `node:${index}`));
      return { ...node, baseline: { effective: {} } };
    }
    matchedNodes += 1;
    return {
      ...node,
      baseline: { effective: effectiveFacts(referenceNode, true) }
    };
  });
  return { snapshot: result, matchedNodes, unmatchedNodeIds };
}
function matchesComponentIdentity(mainComponentKey, componentSetKey, acceptedKeys) {
  const accepted = new Set(acceptedKeys.filter(Boolean));
  return accepted.has(mainComponentKey) || Boolean(componentSetKey && accepted.has(componentSetKey));
}

// src/capture-facts.ts
function captureSupplementalFacts(node, mixed) {
  const text = {};
  const parent = {};
  const unknownFacts = [];
  const read = (source, key, output, fact) => {
    let value;
    try {
      value = source[key];
    } catch {
      value = void 0;
    }
    if (value === mixed || value === void 0 || typeof value === "number" && !Number.isFinite(value)) unknownFacts.push(fact);
    else if (value === null || ["string", "boolean", "number"].includes(typeof value)) output[key] = value;
    else unknownFacts.push(fact);
  };
  if (node.type === "TEXT") {
    for (const key of ["textAutoResize", "textAlignHorizontal", "textAlignVertical", "textTruncation", "maxLines", "paragraphSpacing", "maxHeight"]) read(node, key, text, `text.${key}`);
  }
  const sourceParent = node.parent;
  if (sourceParent && !["PAGE", "DOCUMENT"].includes(String(sourceParent.type))) {
    const layout = {};
    read(sourceParent, "layoutMode", layout, "parent.layout.mode");
    if ("layoutMode" in layout) {
      layout.mode = layout.layoutMode;
      delete layout.layoutMode;
    }
    parent.layout = layout;
    read(sourceParent, "clipsContent", parent, "parent.clipsContent");
  } else if (sourceParent && ["PAGE", "DOCUMENT"].includes(String(sourceParent.type))) {
    parent.layout = { mode: "NONE" };
  } else unknownFacts.push("parent");
  return { text, parent, unknownFacts };
}

// src/capture-topology.ts
function captureSceneTopology(root, limit = 500, omitChildren) {
  const entries = [], issues = [];
  const seenIds = /* @__PURE__ */ new Map(), seenObjects = /* @__PURE__ */ new Set();
  let limitReached = false;
  const visit = (node, parentIndex, ancestors) => {
    let id, name, type;
    try {
      id = node.id;
      name = node.name;
      type = node.type;
    } catch {
      issues.push({ kind: "unreadable-node", path: parentIndex === null ? "" : entries[parentIndex].path });
      return;
    }
    const path = parentIndex === null ? name : `${entries[parentIndex].path} / ${name}`;
    if (!id || typeof id !== "string" || typeof name !== "string" || !type) {
      issues.push({ kind: "unreadable-node", path });
      return;
    }
    const previous = seenIds.get(id);
    if (previous || seenObjects.has(node)) {
      const kind = previous && previous.type !== type ? "identity-conflict" : ancestors.has(id) ? "cycle" : "duplicate-id";
      if (issues.length < 20) issues.push({ kind, nodeId: id, path });
      return;
    }
    if (entries.length >= limit) {
      limitReached = true;
      return;
    }
    const entry = { node, figmaNodeId: id, name, type, parentIndex, childIndexes: [], depth: parentIndex === null ? 0 : entries[parentIndex].depth + 1, path };
    const index = entries.length;
    entries.push(entry);
    seenIds.set(id, entry);
    seenObjects.add(node);
    if (omitChildren?.(entry, index, entries)) return index;
    let children;
    try {
      children = "children" in node ? Array.from(node.children || []) : [];
    } catch {
      issues.push({ kind: "unreadable-node", nodeId: id, path });
      return index;
    }
    entry.observedChildren = children;
    const next = new Set(ancestors);
    next.add(id);
    for (const child of children) {
      const childIndex = visit(child, index, next);
      if (childIndex !== void 0) entry.childIndexes.push(childIndex);
    }
    return index;
  };
  visit(root, null, /* @__PURE__ */ new Set());
  return { entries, issues, limitReached, complete: !limitReached && !issues.length };
}

// src/instance-source-identity.ts
function captureInstanceSourceIdentities(entries, mains, pristineSources = /* @__PURE__ */ new Map(), includeOwnedLayers = false) {
  const result = /* @__PURE__ */ new Map();
  const sources = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    if (!includeOwnedLayers && entry.type !== "INSTANCE" || entry.parentIndex === null) continue;
    let ownerIndex = entry.parentIndex;
    while (ownerIndex !== null && entries[ownerIndex].type !== "INSTANCE") ownerIndex = entries[ownerIndex].parentIndex;
    if (ownerIndex === null) continue;
    const owner = entries[ownerIndex], main = mains.get(owner.figmaNodeId);
    if (!main || main.type !== "COMPONENT" || !main.key || !main.id) continue;
    try {
      let source;
      if (main.remote) {
        const pristine = pristineSources.get(main.id), root = pristine?.topology.entries[0];
        if (!pristine?.topology.complete || !root || root.type !== "INSTANCE" || root.parentIndex !== null || pristine.mainComponentId !== main.id || pristine.componentKey !== main.key || root.figmaNodeId === owner.figmaNodeId) continue;
        const sourcePrefix = (root.figmaNodeId.startsWith("I") ? root.figmaNodeId : "I" + root.figmaNodeId) + ";";
        const normalized = pristine.topology.entries.map((n, index) => ({
          figmaNodeId: index === 0 ? main.id : n.figmaNodeId.startsWith(sourcePrefix) ? n.figmaNodeId.slice(sourcePrefix.length) : "",
          type: index === 0 ? "COMPONENT" : n.type,
          parentIndex: n.parentIndex
        }));
        if (normalized.some((n) => !n.figmaNodeId) || new Set(normalized.map((n) => n.figmaNodeId)).size !== normalized.length) continue;
        source = { entries: normalized, complete: true };
      } else {
        if (!sources.has(main)) sources.set(main, captureSceneTopology(
          main,
          500,
          (node, index) => index > 0 && (node.type === "INSTANCE" || node.type === "SLOT")
        ));
        source = sources.get(main);
        if (!source.complete) continue;
      }
      const prefix = (owner.figmaNodeId.startsWith("I") ? owner.figmaNodeId : "I" + owner.figmaNodeId) + ";";
      const chain = [];
      let current = entry;
      while (current && current !== owner) {
        chain.unshift(current);
        current = current.parentIndex === null ? void 0 : entries[current.parentIndex];
      }
      if (current !== owner) continue;
      let sourceParentIndex = 0, sourceNodeId = "", valid = true;
      for (const inherited of chain) {
        if (!inherited.figmaNodeId.startsWith(prefix)) {
          valid = false;
          break;
        }
        const id = inherited.figmaNodeId.slice(prefix.length);
        const index = source.entries.findIndex((n) => n.figmaNodeId === id && n.type === inherited.type && n.parentIndex === sourceParentIndex);
        if (!id || index < 1) {
          valid = false;
          break;
        }
        sourceParentIndex = index;
        sourceNodeId = id;
      }
      if (valid) result.set(entry.figmaNodeId, { version: 1, ownerComponentKey: main.key, ownerMainComponentId: main.id, sourceNodeId });
    } catch {
    }
  }
  return result;
}

// src/native-slot-capture.ts
function confirmedNativeSlotCaptureBoundaries(plan, reference, representationId, componentKey, componentSetKey) {
  if (plan?.version !== 1 || !reference.complete || reference.componentKey !== componentKey || reference.componentSetKey !== componentSetKey) return [];
  return plan.boundaries.filter((b) => b.representationId === representationId && reference.nodeProperties[""]?.propertyTypes[b.property] === "SLOT" && reference.nodes.filter((n) => n.type === "SLOT" && !n.path.includes(" / ") && reference.nodeProperties[n.path]?.propertyReferenceBindings?.slotContentId === b.property).length === 1 && reference.nodes.some((n) => n.path === b.path && n.type === "SLOT" && reference.nodeProperties[n.path]?.propertyReferenceBindings?.slotContentId === b.property));
}

// src/variable-mode-facts.ts
function captureResolvedVariableModes(resolved, collections) {
  const modes = {};
  const modeCatalog = {};
  const unknownFacts = [];
  const byKey = /* @__PURE__ */ new Map();
  for (const collection of collections) {
    if (!/^[a-f0-9]{40}$/i.test(collection.key)) continue;
    byKey.set(collection.key, [...byKey.get(collection.key) || [], collection]);
  }
  for (const [key, candidates] of byKey) {
    const collection = candidates[0];
    if (candidates.length !== 1) {
      unknownFacts.push(`variable.modes.${key}`);
      continue;
    }
    if (typeof collection.name !== "string" || !Array.isArray(collection.modes) || collection.modes.some((mode) => !mode || typeof mode.modeId !== "string" || typeof mode.name !== "string")) {
      unknownFacts.push(`variable.modes.${key}`);
      continue;
    }
    modeCatalog[key] = {
      collectionId: collection.id,
      collectionName: collection.name,
      defaultModeId: collection.defaultModeId,
      modes: collection.modes.map((mode) => ({ modeId: mode.modeId, name: mode.name }))
    };
    const modeId = resolved[collection.id];
    if (typeof modeId === "string" && collection.modes.filter((mode) => mode.modeId === modeId).length === 1) {
      modes[key] = modeId;
    } else {
      unknownFacts.push(`variable.modes.${key}`);
    }
  }
  return { modes, modeCatalog, unknownFacts };
}

// src/host-context-variable-modes.ts
var record5 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var object = (v) => Boolean(v && typeof v === "object" && !Array.isArray(v));
var unknown = (n, fact) => (n.unknownFacts || []).some((p) => p === fact || fact.startsWith(p + ".") || p.startsWith(fact + "."));
function tokenIds(values) {
  const ids = /* @__PURE__ */ new Set();
  let complete = true;
  const add = (id) => {
    if (typeof id === "string" && id.trim()) ids.add(id);
    else complete = false;
  };
  const visit = (v) => {
    if (Array.isArray(v)) {
      v.forEach(visit);
      return;
    }
    if (!v || typeof v !== "object") return;
    for (const [key, value] of Object.entries(v)) {
      if (key === "tokenId" && value !== null) add(value);
      else if (key === "tokenIds") {
        if (Array.isArray(value)) value.forEach(add);
        else complete = false;
      } else if (key === "id" && record5(v).type === "VARIABLE_ALIAS") add(value);
      else visit(value);
    }
    if (record5(v).type === "VARIABLE_ALIAS" && !Object.prototype.hasOwnProperty.call(v, "id")) complete = false;
  };
  values.forEach(visit);
  return { ids: Array.from(ids).sort(), complete };
}
async function captureHostVariableUsage(node, resolve) {
  const usage = { version: 1, complete: true, bindings: {} };
  try {
    const values = ["boundVariables", "fills", "strokes", "effects", "layoutGrids"].map((key) => node[key]);
    if (node.type === "TEXT") values.push(node.getStyledTextSegments(["fills", "boundVariables"]));
    const tokens = tokenIds(values);
    usage.complete = tokens.complete;
    const visiting = /* @__PURE__ */ new Set();
    let count = 0;
    const visit = async (id, depth) => {
      if (visiting.has(id) || depth > 16 || ++count > 128) {
        usage.complete = false;
        return;
      }
      if (usage.bindings[id]) return;
      visiting.add(id);
      const collection = await resolve(id, record5(node.resolvedVariableModes));
      if (!collection || !Array.isArray(collection.referencedVariableIds)) usage.complete = false;
      else {
        for (const alias of collection.referencedVariableIds) {
          if (typeof alias !== "string" || !alias) usage.complete = false;
          else await visit(alias, depth + 1);
        }
        usage.bindings[id] = collection;
      }
      visiting.delete(id);
    };
    for (const id of tokens.ids) await visit(id, 0);
  } catch {
    usage.complete = false;
  }
  return usage;
}
function hostContextFacts(node) {
  const usage = record5(node.hostVariableUsageV1), variable = record5(node.variable);
  if (usage.version !== 1 || usage.complete !== true || !object(usage.bindings) || !object(variable.bindings) || !object(variable.modes) || !object(variable.modeCatalog) || unknown(node, "hostVariableUsageV1") || unknown(node, "variable.bindings")) return;
  const tokens = tokenIds([variable.bindings, node.appearance, node.textFillEvidenceV1]);
  if (!tokens.complete || tokens.ids.some((id) => !Object.prototype.hasOwnProperty.call(usage.bindings, id))) return;
  const checked = /* @__PURE__ */ new Set(), visiting = /* @__PURE__ */ new Set();
  const validChain = (id, depth) => {
    if (visiting.has(id) || depth > 16) return false;
    if (checked.has(id)) return true;
    const refs = record5(usage.bindings[id]).referencedVariableIds;
    if (!Array.isArray(refs)) return false;
    visiting.add(id);
    if (refs.some((alias) => typeof alias !== "string" || !Object.prototype.hasOwnProperty.call(usage.bindings, alias) || !validChain(alias, depth + 1))) return false;
    visiting.delete(id);
    checked.add(id);
    return true;
  };
  if (Object.keys(usage.bindings).length > 128 || Object.keys(usage.bindings).some((id) => !validChain(id, 0))) return;
  const modes = {}, catalog = {};
  const ids = /* @__PURE__ */ new Map();
  for (const binding of Object.values(usage.bindings)) {
    const collection = record5(binding), key = collection.collectionKey, id = collection.collectionId;
    if (typeof key !== "string" || !/^[a-f0-9]{40}$/i.test(key) || typeof id !== "string" || !id || ids.has(key) && ids.get(key) !== id) return;
    if (!Array.isArray(collection.referencedVariableIds) || collection.referencedVariableIds.some((alias) => typeof alias !== "string" || !Object.prototype.hasOwnProperty.call(usage.bindings, alias))) return;
    ids.set(key, id);
    const mode = variable.modes[key], entry = record5(variable.modeCatalog[key]);
    if (unknown(node, `variable.modes.${key}`) || unknown(node, `variable.modeCatalog.${key}`) || typeof mode !== "string" || record5(node.resolvedModes)[id] !== mode || entry.collectionId !== id || !Array.isArray(entry.modes) || entry.modes.filter((m) => m?.modeId === mode).length !== 1) return;
    modes[key] = mode;
    catalog[key] = entry;
  }
  const facts = JSON.parse(JSON.stringify(effectiveFacts(node)));
  facts.variable = Object.assign({}, variable, { modes, modeCatalog: catalog });
  facts.hostVariableUsageV1 = usage;
  return facts;
}

// src/property-applicability.ts
function capturePropertyActivity(node) {
  const result = {};
  try {
    if (Array.isArray(node.strokes)) result.strokePresent = node.strokes.length > 0;
  } catch {
  }
  try {
    const mode = node.layoutMode;
    if (mode === "HORIZONTAL" || mode === "VERTICAL" || mode === "GRID") {
      result.paddingApplicable = true;
      result.axisAlignmentApplicable = mode !== "GRID";
    } else if (mode === "NONE") {
      result.paddingApplicable = false;
      result.axisAlignmentApplicable = false;
    }
    if (mode === "NONE" || mode === "GRID") result.gapApplicable = false;
    else if (mode === "HORIZONTAL" || mode === "VERTICAL") {
      if (!Array.isArray(node.children)) return result;
      let certain = 0, possible = 0;
      for (const child of node.children) {
        try {
          const visible = child.visible, positioning = child.layoutPositioning;
          if (visible === false || positioning === "ABSOLUTE") continue;
          possible++;
          if (visible === true && positioning === "AUTO") certain++;
        } catch {
          possible++;
        }
      }
      if (certain >= 2) result.gapApplicable = true;
      else if (possible < 2) result.gapApplicable = false;
    } else if (["GROUP", "BOOLEAN_OPERATION", "VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "TEXT"].includes(String(node.type))) {
      result.gapApplicable = false;
      result.paddingApplicable = false;
      result.axisAlignmentApplicable = false;
    }
  } catch {
  }
  return result;
}

// src/gradient-paint-facts.ts
var TYPES = /* @__PURE__ */ new Set(["GRADIENT_LINEAR", "GRADIENT_RADIAL", "GRADIENT_ANGULAR", "GRADIENT_DIAMOND"]);
var record6 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var unit = (v) => finite(v) && v >= 0 && v <= 1;
var transformValid = (v) => Array.isArray(v) && v.length === 2 && v.every((row) => Array.isArray(row) && row.length === 3 && row.every(finite));
var colorValid = (v) => ["r", "g", "b", "a"].every((key) => unit(record6(v)[key]));
function captureGradientPaintDetails(value) {
  const paint = record6(value), facts = {};
  if (!TYPES.has(String(paint.type))) return facts;
  if (transformValid(paint.gradientTransform)) facts.gradientTransform = paint.gradientTransform.map((row) => row.slice());
  if (Array.isArray(paint.gradientStops)) facts.gradientStops = paint.gradientStops.map((raw) => {
    const stop = record6(raw), result = {};
    if (unit(stop.position)) result.position = stop.position;
    if (colorValid(stop.color)) result.color = Object.fromEntries(["r", "g", "b", "a"].map((key) => [key, record6(stop.color)[key]]));
    if (stop.boundVariables === void 0 || stop.boundVariables && typeof stop.boundVariables === "object" && !Array.isArray(stop.boundVariables) && !Object.prototype.hasOwnProperty.call(stop.boundVariables, "color")) result.tokenId = null;
    else {
      const alias = record6(record6(stop.boundVariables).color);
      if (alias.type === "VARIABLE_ALIAS" && typeof alias.id === "string" && alias.id.trim()) result.tokenId = alias.id;
    }
    return result;
  });
  if (typeof paint.blendMode === "string") facts.blendMode = paint.blendMode;
  return facts;
}

// src/effect-facts.ts
function captureEffectDetails(effects, styleId) {
  if (!Array.isArray(effects) || typeof styleId !== "string") return void 0;
  if (effects.some((e) => !e || typeof e !== "object" || typeof e.type !== "string")) return void 0;
  if (effects.some((e) => ["BACKGROUND_BLUR", "LAYER_BLUR"].includes(e.type) && (typeof e.radius !== "number" || !Number.isFinite(e.radius) || e.radius < 0))) return void 0;
  const key = /^S:([a-f0-9]{40})(?:,|$)/i.exec(styleId)?.[1];
  return {
    version: 1,
    styleRef: key ? `key:${key.toLowerCase()}` : styleId ? `local:${styleId}` : null,
    effects: effects.map((e) => JSON.parse(JSON.stringify(e)))
  };
}

// src/text-style-facts.ts
async function captureTextStyleEvidence(node, resolveKey) {
  const result = { version: 1 };
  try {
    result.segments = node.getStyledTextSegments(["textStyleId"]).map((s) => ({ start: s.start, end: s.end, styleId: s.textStyleId }));
  } catch {
    return result;
  }
  const ids = [...new Set([node.textStyleId, ...result.segments.map((s) => s.styleId)].filter((id) => typeof id === "string" && id && !/^S:[a-f0-9]{40}(?:,[^\s]+)?$/i.test(id)))];
  result.keysById = {};
  for (const id of ids) {
    try {
      const key = await resolveKey(id);
      if (key) result.keysById[id] = key;
    } catch {
    }
  }
  return result;
}

// src/text-decoration-facts.ts
function captureTextDecoration(node) {
  try {
    if (node.type !== "TEXT" || typeof node.characters !== "string") return;
    const valid = (v) => typeof v === "string" && ["NONE", "UNDERLINE", "STRIKETHROUGH"].includes(v);
    if (!node.characters.length) return valid(node.textDecoration) ? [node.textDecoration] : void 0;
    const ranges = node.getStyledTextSegments(["textDecoration"]);
    if (!Array.isArray(ranges)) return;
    let end = 0;
    if (!ranges.every((r) => r && Number.isInteger(r.start) && Number.isInteger(r.end) && r.start === end && r.end > r.start && r.end <= node.characters.length && valid(r.textDecoration) && (end = r.end)) || end !== node.characters.length) return;
    return [...new Set(ranges.map((r) => r.textDecoration))].sort();
  } catch {
    return;
  }
}

// src/text-binding-identity.ts
var variableKey = (id) => typeof id === "string" ? (/^VariableID:([a-f0-9]{40})(?:\/[^\s]+)?$/i.exec(id)?.[1] || (/^[a-f0-9]{40}$/i.test(id) ? id : void 0))?.toLowerCase() : void 0;
async function captureTextFillEvidence(node, serialize, resolveKey) {
  const evidence = { version: 1, keysById: {} };
  try {
    evidence.segments = node.getStyledTextSegments(["fills"]).map((s) => ({ start: s.start, end: s.end, paints: serialize(s.fills) }));
    evidence.emptyPaints = serialize(node.fills);
  } catch {
    return evidence;
  }
  const ids = /* @__PURE__ */ new Set();
  for (const paints of [evidence.emptyPaints, ...evidence.segments.map((s) => s.paints)]) {
    if (Array.isArray(paints)) for (const p of paints) {
      for (const id of [p.tokenId, ...Array.isArray(p.gradientStops) ? p.gradientStops.map((s) => s.tokenId) : []]) {
        if (typeof id === "string" && id && !variableKey(id)) ids.add(id);
      }
    }
  }
  await Promise.all([...ids].map(async (id) => {
    try {
      const key = await resolveKey(id);
      if (key) evidence.keysById[id] = key;
    } catch {
    }
  }));
  return evidence;
}

// src/component-dependencies.ts
var COMPONENT_DEPENDENCY_CAPTURE_LIMIT = 8;
var DIRECT_CHILD_DEPENDENCY_CAPTURE_LIMIT = 16;

// src/dependency-capture-diagnostics.ts
function boundedText(value, limit) {
  return typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, limit) : "";
}
function errorField(error, field) {
  try {
    return error && typeof error === "object" ? error[field] : void 0;
  } catch {
    return void 0;
  }
}
function dependencyCaptureFailureDetails(stage, error) {
  return {
    version: 1,
    stage,
    errorName: boundedText(errorField(error, "name"), 80) || "Error",
    message: boundedText(typeof error === "string" ? error : errorField(error, "message"), 360) || "\u041E\u0448\u0438\u0431\u043A\u0430 \u0431\u0435\u0437 \u0442\u0435\u043A\u0441\u0442\u0430."
  };
}

// src/transition-capture.ts
var layoutKeys = [
  "layoutMode",
  "layoutWrap",
  "layoutSizingHorizontal",
  "layoutSizingVertical",
  "primaryAxisSizingMode",
  "counterAxisSizingMode",
  "primaryAxisAlignItems",
  "counterAxisAlignItems",
  "counterAxisAlignContent",
  "paddingTop",
  "paddingRight",
  "paddingBottom",
  "paddingLeft",
  "itemSpacing",
  "counterAxisSpacing",
  "layoutGrow",
  "layoutAlign",
  "layoutPositioning",
  "minWidth",
  "maxWidth",
  "minHeight",
  "maxHeight",
  "constraints",
  "resolvedVariableModes",
  "boundVariables",
  "rotation",
  "visible"
];
function fields(node, keys) {
  const out = {};
  for (const k of keys) if (k in node) {
    const v = node[k];
    if (v !== void 0) out[k] = v;
  }
  return JSON.parse(JSON.stringify(out));
}
function captureTransitionContext(subject) {
  try {
    const ancestors = [];
    let branch = subject, parent = subject.parent;
    while (parent && parent.type !== "PAGE") {
      if (ancestors.length >= 32) throw Error("ancestor-limit");
      const siblings = (parent.children || []).filter((n) => n !== branch);
      if (siblings.length > 200) throw Error("sibling-limit");
      const layout = fields(parent, layoutKeys);
      if (parent.relativeTransform) layout.linearTransform = parent.relativeTransform.map((row) => row.slice(0, 2));
      if (parent.type !== "GROUP") {
        if (parent.layoutSizingHorizontal !== "HUG") {
          if (!Number.isFinite(parent.width)) throw Error("parent-width-unknown");
          layout.width = parent.width;
        }
        if (parent.layoutSizingVertical !== "HUG") {
          if (!Number.isFinite(parent.height)) throw Error("parent-height-unknown");
          layout.height = parent.height;
        }
      }
      if (parent.layoutMode === "GRID") throw Error("unsupported-grid-context");
      ancestors.push({
        id: parent.id,
        type: parent.type,
        layout,
        childIds: (parent.children || []).map((n) => n.id),
        siblings: siblings.map((n) => ({ id: n.id, ...fields(n, ["width", "height", "visible", ...layoutKeys]) }))
      });
      branch = parent;
      parent = parent.parent;
    }
    if (!parent || parent.type !== "PAGE") throw Error("page-unknown");
    const context = {
      profile: "same-instance-context@1",
      pageId: parent.id,
      ancestors,
      rootConstraints: fields(subject, ["minWidth", "maxWidth", "minHeight", "maxHeight", "constraints", "layoutGrow", "layoutAlign", "layoutPositioning", "rotation"])
    };
    const nodes = [];
    const visit = (n) => {
      if (nodes.length >= 500) throw Error("node-limit");
      nodes.push({ id: n.id, ...fields(n, ["visible", "width", "height", "componentProperties", "resolvedVariableModes", ...layoutKeys]) });
      for (const c of n.children || []) visit(c);
    };
    visit(subject);
    return { context, fingerprint: stableHash({ context, nodes }), complete: true };
  } catch {
    return { context: { profile: "same-instance-context@1" }, fingerprint: "", complete: false, reason: "capture-context-incomplete" };
  }
}

// src/nested-instance-content-reference.ts
var INSTANCE_CONTENT_REFERENCE_LIMIT = 8;
var record7 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var clone = (v) => JSON.parse(JSON.stringify(v));
var referenceFor = (s) => captureVariantReference(s, s.source?.componentKey || "", s.source?.componentSetKey || "");
var nodesByPath = (s) => {
  const paths = snapshotPaths(s);
  return paths && new Map(s.nodes.map((n) => [paths.get(String(n.id)), n]));
};
function planNestedInstanceContentReferences(snapshot, reference, parent) {
  const comparison = compareInstanceBoundaries(snapshot, referenceFor(reference), true);
  return comparison.complete ? comparison.boundaries.filter((b) => b.actualPath !== parent.actualPath && withinBoundary(b.actualPath, parent.actualPath)) : [];
}
function materializeNestedInstanceContentReferences(snapshot) {
  const evidence = snapshot.instanceContentReferences;
  const actual = nodesByPath(snapshot), original = snapshot.variantReference;
  const results = [];
  snapshot.instanceContentResults = results;
  const comparison = original && compareInstanceBoundaries(snapshot, original, true);
  const roots = comparison?.complete ? comparison.boundaries : [];
  snapshot.instanceBoundaries = [...roots];
  const base = evidence.base;
  const baseRef = base && captureVariantReference(base, base.source?.componentKey || "", base.source?.componentSetKey || "", original?.definedProperties);
  const baseValid = actual && original?.complete && baseRef?.complete && base.source?.rootNodeId && base.source.rootNodeId !== snapshot.source?.rootNodeId && stableHash(baseRef) === stableHash(original) && base.context.platform === snapshot.context.platform && stableHash(base.context.modes) === stableHash(snapshot.context.modes);
  let visited = 0;
  const visit = (boundary, context, parentId) => {
    const result = { boundaryNodeId: boundary.nodeId, status: "unresolved", reason: "reference-not-captured", matchedNodeIds: [] };
    results.push(result);
    if (actual) {
      for (const [path, node] of actual) if (withinBoundary(path, boundary.actualPath)) {
        node.baseline = { effective: {} };
        node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
        if (node.semantic) delete record7(node.semantic).role;
      }
    }
    const fail = (reason) => {
      result.reason = reason;
      return result;
    };
    if (++visited > INSTANCE_CONTENT_REFERENCE_LIMIT) return fail("reference-capture-limit");
    if (!baseValid) return fail("original-host-evidence-invalid");
    if (evidence.hostContextVariableModesVersion !== void 0 && evidence.hostContextVariableModesVersion !== 1) return fail("host-context-mode-version-unsupported");
    const variant = boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
    if (!boundary.actualComponentKey || !variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) return fail("explicit-swap-port-required");
    const attempts = evidence.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId);
    if (attempts.length !== 1) return fail(attempts.length ? "ambiguous-reference" : "reference-not-captured");
    const attempt = attempts[0], reference = attempt.reference;
    if (attempt.parentBoundaryNodeId !== parentId) return fail("reference-parent-mismatch");
    if (attempt.failure || !reference) return fail(attempt.failure || "reference-not-captured");
    if (variant && attempt.strategy !== "pristine-host-variant-properties") return fail("variant-capture-strategy-unproven");
    const expected = nodesByPath(reference), contextNodes = nodesByPath(context);
    const refId = reference.source?.rootNodeId;
    if (!expected || !contextNodes || !refId || refId === snapshot.source?.rootNodeId || refId === base.source?.rootNodeId || refId === context.source?.rootNodeId || reference.context.platform !== snapshot.context.platform || stableHash(reference.context.modes) !== stableHash(snapshot.context.modes)) return fail("replacement-reference-incomplete");
    const change = compareInstanceBoundaries(reference, referenceFor(context), true), refBoundary = change.boundaries[0];
    if (!change.complete || change.boundaries.length !== 1 || refBoundary.reason !== boundary.reason || refBoundary.referencePath !== boundary.referencePath || refBoundary.ownerPath !== boundary.ownerPath || refBoundary.property !== boundary.property || refBoundary.actualComponentKey !== boundary.actualComponentKey || refBoundary.componentSetKey !== boundary.componentSetKey) return fail("replacement-identity-or-port-mismatch");
    for (const [path, node] of contextNodes) {
      if (withinBoundary(path, boundary.referencePath)) continue;
      const other = expected.get(path);
      if (!other) return fail("host-context-changed");
      const before = evidence.hostContextVariableModesVersion === 1 ? hostContextFacts(node) : clone(effectiveFacts(node));
      const after = evidence.hostContextVariableModesVersion === 1 ? hostContextFacts(other) : clone(effectiveFacts(other));
      if (!before || !after) return fail("host-context-variable-evidence-incomplete");
      if (!variant && path === boundary.ownerPath && boundary.property) {
        delete record7(record7(before.component).properties)[boundary.property];
        delete record7(record7(after.component).properties)[boundary.property];
      }
      if (stableHash(before) !== stableHash(after)) return fail("host-context-changed");
    }
    const remainder = compareInstanceBoundaries(snapshot, referenceFor(reference), true);
    if (!remainder.complete) return fail("replacement-structure-needs-remap");
    const children = remainder.boundaries.filter((b) => withinBoundary(b.actualPath, boundary.actualPath));
    if (children.some((b) => b.actualPath === boundary.actualPath)) return fail("replacement-nested-identity-unresolved");
    const pairs = [];
    for (const [path, node] of actual) {
      if (!withinBoundary(path, boundary.actualPath) || children.some((b) => withinBoundary(path, b.actualPath))) continue;
      const relative = path.slice(boundary.actualPath.length);
      const referencePath = remainder.referencePaths ? correspondingPath(remainder, path) : refBoundary.actualPath + relative;
      const other = referencePath !== void 0 ? expected.get(referencePath) : void 0;
      if (!other || other.type !== node.type) return fail("replacement-structure-needs-remap");
      if (node.type === "INSTANCE") {
        const a = record7(record7(node.component).identity), b = record7(record7(other.component).identity);
        if (!a.componentKey || a.componentKey !== b.componentKey || (a.componentSetKey || "") !== (b.componentSetKey || "")) return fail("replacement-nested-identity-unresolved");
      }
      pairs.push([path, node, other]);
    }
    if (variant) {
      const props = (n) => {
        const c = record7(n?.component);
        return Object.fromEntries(Object.entries(record7(c.propertyTypes)).filter(([, t]) => t === "VARIANT").map(([p]) => [p, record7(c.properties)[p]]));
      };
      const expectedProperties = props(expected.get(refBoundary.actualPath));
      if (!Object.keys(expectedProperties).length || stableHash(props(actual.get(boundary.actualPath))) !== stableHash(expectedProperties)) return fail("variant-properties-mismatch");
    }
    result.lineageProven = true;
    for (const [path, node, other] of pairs) {
      node.baseline = { effective: clone(effectiveFacts(
        other,
        snapshot.source?.geometryCaptureVersion === 1 && reference.source?.geometryCaptureVersion === 1
      )) };
      if (variant && path === boundary.actualPath) {
        const originalComponent = record7(contextNodes.get(boundary.referencePath)?.component), current = record7(node.component);
        const baseline = record7(record7(record7(node.baseline).effective).component), available = record7(record7(node.variantAvailability).componentProperties);
        for (const [name, type] of Object.entries(record7(current.propertyTypes))) {
          if (type !== "VARIANT" || record7(originalComponent.propertyTypes)[name] !== "VARIANT" || !Object.prototype.hasOwnProperty.call(record7(originalComponent.properties), name)) continue;
          record7(baseline.properties)[name] = originalComponent.properties[name];
          available[propertyAvailabilityKey(name)] = true;
          node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== `variantAvailability.componentProperties.${propertyAvailabilityKey(name)}`);
        }
        if (node.variantAvailability) record7(node.variantAvailability).componentProperties = available;
      }
      node.baselineProvenance = {
        status: "matched",
        kind: variant ? "independent-host-variant" : "independent-host-swap",
        boundaryNodeId: boundary.nodeId,
        componentKey: boundary.actualComponentKey,
        ownerPath: boundary.ownerPath,
        property: boundary.property,
        ...variant ? { componentSetKey: boundary.componentSetKey } : {},
        referencePath: remainder.referencePaths ? correspondingPath(remainder, path) : refBoundary.actualPath + path.slice(boundary.actualPath.length)
      };
      result.matchedNodeIds.push(String(node.id));
    }
    let complete = true;
    for (const child of children) {
      snapshot.instanceBoundaries.push(child);
      const childResult = visit(child, reference, boundary.nodeId);
      complete = complete && childResult.status === "matched";
      result.matchedNodeIds.push(...childResult.matchedNodeIds);
    }
    result.status = complete ? "matched" : "partial";
    result.reason = complete ? variant ? "independent-host-variant-reference" : "independent-host-swap-reference" : "nested-content-reference-unresolved";
    return result;
  };
  for (const boundary of roots) visit(boundary, base);
}

// src/instance-content-reference.ts
var record8 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var clone2 = (v) => JSON.parse(JSON.stringify(v));
function planInstanceContentReferences(snapshot) {
  if (!snapshot.variantReference) return [];
  const comparison = compareInstanceBoundaries(snapshot, snapshot.variantReference);
  return comparison.complete ? comparison.boundaries : [];
}
function byPath(snapshot) {
  const paths = snapshotPaths(snapshot);
  return paths && new Map(snapshot.nodes.map((n) => [paths.get(String(n.id)), n]));
}
function subtree(nodes, root) {
  return new Map([...nodes].filter(([p]) => withinBoundary(p, root)).map(([p, n]) => [p === root ? "" : p.slice(root.length + 3), n]));
}
function materializeInstanceContentReferences(snapshot) {
  const evidence = snapshot.instanceContentReferences;
  if (!evidence) return;
  if (evidence.schemaVersion === "apollo.instance-content-references.v4") {
    materializeNestedInstanceContentReferences(snapshot);
    return;
  }
  const boundaries = planInstanceContentReferences(snapshot);
  const results = [];
  snapshot.instanceContentResults = results;
  const original = snapshot.variantReference;
  const actualNodes = byPath(snapshot);
  const base = evidence.base;
  const baseNodes = base && byPath(base);
  const baseReference = base && captureVariantReference(
    base,
    base.source?.componentKey || "",
    base.source?.componentSetKey || "",
    original?.definedProperties
  );
  const nestedVariants = ["apollo.instance-content-references.v2", "apollo.instance-content-references.v3"].includes(evidence.schemaVersion);
  const baseValid = (evidence.schemaVersion === "apollo.instance-content-references.v1" || nestedVariants) && actualNodes && baseNodes && original?.complete && baseReference?.complete && base.source?.rootNodeId && base.source.rootNodeId !== snapshot.source?.rootNodeId && stableHash(baseReference) === stableHash(original) && stableHash(base.context.modes) === stableHash(snapshot.context.modes) && base.context.platform === snapshot.context.platform;
  for (const boundary of boundaries) {
    const result = { boundaryNodeId: boundary.nodeId, status: "unresolved", reason: "reference-not-captured", matchedNodeIds: [] };
    results.push(result);
    if (actualNodes) for (const node of subtree(actualNodes, boundary.actualPath).values()) {
      node.baseline = { effective: {} };
      node.baselineProvenance = { status: "unresolved", reason: boundary.reason, boundaryNodeId: boundary.nodeId };
      if (node.semantic && typeof node.semantic === "object") delete record8(node.semantic).role;
    }
    if (!baseValid) {
      result.reason = "original-host-evidence-invalid";
      continue;
    }
    const variant = nestedVariants && boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
    if (!boundary.actualComponentKey || !variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) {
      result.reason = "explicit-swap-port-required";
      continue;
    }
    const attempts = evidence.attempts.filter((a) => a.boundaryNodeId === boundary.nodeId);
    if (attempts.length !== 1) {
      result.reason = attempts.length ? "ambiguous-reference" : "reference-not-captured";
      continue;
    }
    const attempt = attempts[0], reference = attempt.reference;
    if (attempt.failure || !reference) {
      result.reason = attempt.failure || "reference-not-captured";
      continue;
    }
    if (variant && evidence.schemaVersion === "apollo.instance-content-references.v3" && attempt.strategy !== "pristine-host-variant-properties") {
      result.reason = "variant-capture-strategy-unproven";
      continue;
    }
    const refNodes = byPath(reference);
    const independent = reference.source?.rootNodeId && reference.source.rootNodeId !== snapshot.source?.rootNodeId && reference.source.rootNodeId !== base.source?.rootNodeId;
    if (!independent || !refNodes || stableHash(reference.context.modes) !== stableHash(snapshot.context.modes) || reference.context.platform !== snapshot.context.platform) {
      result.reason = "replacement-reference-incomplete";
      continue;
    }
    const comparison = compareInstanceBoundaries(reference, original, nestedVariants);
    const refBoundary = comparison.boundaries[0];
    if (!comparison.complete || comparison.boundaries.length !== 1 || refBoundary.reason !== boundary.reason || refBoundary.referencePath !== boundary.referencePath || refBoundary.ownerPath !== boundary.ownerPath || refBoundary.property !== boundary.property || refBoundary.actualComponentKey !== boundary.actualComponentKey || refBoundary.componentSetKey !== boundary.componentSetKey) {
      result.reason = "replacement-identity-or-port-mismatch";
      continue;
    }
    let hostIntact = true;
    for (const [path, node] of baseNodes) {
      if (withinBoundary(path, boundary.referencePath)) continue;
      const other = refNodes.get(path);
      if (!other) {
        hostIntact = false;
        break;
      }
      const expected2 = clone2(effectiveFacts(node)), observed = clone2(effectiveFacts(other));
      if (!variant && path === boundary.ownerPath && boundary.property) {
        delete record8(record8(expected2.component).properties)[boundary.property];
        delete record8(record8(observed.component).properties)[boundary.property];
      }
      if (stableHash(expected2) !== stableHash(observed)) {
        hostIntact = false;
        break;
      }
    }
    if (!hostIntact) {
      result.reason = "host-context-changed";
      continue;
    }
    const actual = subtree(actualNodes, boundary.actualPath), expected = subtree(refNodes, refBoundary.actualPath);
    const shape = (nodes) => [...nodes].map(([p, n]) => [p, n.type]).sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    if (stableHash(shape(actual)) !== stableHash(shape(expected))) {
      result.reason = "replacement-structure-needs-remap";
      continue;
    }
    const identityKnown = [...actual].every(([path, node]) => {
      if (node.type !== "INSTANCE") return true;
      const a = record8(record8(node.component).identity), b = record8(record8(expected.get(path)?.component).identity);
      return Boolean(a.componentKey && b.componentKey && a.componentKey === b.componentKey && (a.componentSetKey || "") === (b.componentSetKey || ""));
    });
    if (!identityKnown) {
      result.reason = "replacement-nested-identity-unresolved";
      continue;
    }
    if (variant) {
      const variantProperties = (node) => {
        const component = record8(node?.component);
        return Object.fromEntries(Object.entries(record8(component.propertyTypes)).filter(([, type]) => type === "VARIANT").map(([name]) => [name, record8(component.properties)[name]]));
      };
      const expectedProperties = variantProperties(expected.get(""));
      if (!Object.keys(expectedProperties).length || stableHash(variantProperties(actual.get(""))) !== stableHash(expectedProperties)) {
        result.reason = "variant-properties-mismatch";
        continue;
      }
    }
    for (const [path, node] of actual) {
      node.baseline = { effective: clone2(effectiveFacts(
        expected.get(path),
        snapshot.source?.geometryCaptureVersion === 1 && reference.source?.geometryCaptureVersion === 1
      )) };
      if (variant && path === "") {
        const originalComponent = record8(baseNodes.get(boundary.referencePath)?.component);
        const current = record8(node.component), baseline = record8(record8(record8(node.baseline).effective).component);
        const available = record8(record8(node.variantAvailability).componentProperties);
        for (const [name, type] of Object.entries(record8(current.propertyTypes))) {
          if (type !== "VARIANT" || record8(originalComponent.propertyTypes)[name] !== "VARIANT" || !Object.prototype.hasOwnProperty.call(record8(originalComponent.properties), name)) continue;
          record8(baseline.properties)[name] = originalComponent.properties[name];
          available[propertyAvailabilityKey(name)] = true;
          node.unknownFacts = (node.unknownFacts || []).filter((p) => p !== `variantAvailability.componentProperties.${propertyAvailabilityKey(name)}`);
        }
        if (node.variantAvailability) record8(node.variantAvailability).componentProperties = available;
      }
      node.baselineProvenance = {
        status: "matched",
        kind: variant ? "independent-host-variant" : "independent-host-swap",
        boundaryNodeId: boundary.nodeId,
        componentKey: boundary.actualComponentKey,
        ownerPath: boundary.ownerPath,
        property: boundary.property,
        ...variant ? { componentSetKey: boundary.componentSetKey } : {},
        referencePath: [refBoundary.actualPath, path].filter(Boolean).join(" / ")
      };
      result.matchedNodeIds.push(String(node.id));
    }
    result.status = "matched";
    result.reason = variant ? "independent-host-variant-reference" : "independent-host-swap-reference";
  }
}

// src/instance-main-aliases.ts
function configureInstanceMainAliases(snapshot, enabled) {
  if (snapshot.source) {
    delete snapshot.source.instanceMainComponentAliasesVersion;
    if (enabled) snapshot.source.instanceMainComponentAliasesVersion = 1;
  }
  if (snapshot.instanceContentReferences) {
    configureInstanceMainAliases(snapshot.instanceContentReferences.base, enabled);
    for (const attempt of snapshot.instanceContentReferences.attempts)
      if (attempt.reference) configureInstanceMainAliases(attempt.reference, enabled);
  }
  for (const capture of snapshot.componentDependencyCaptures || [])
    if (capture.snapshot) configureInstanceMainAliases(capture.snapshot, enabled);
}

// src/figma-capture.ts
var transitionSessionId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
var transitionSequence = 0;
function slug(value) {
  return value.replace(/^\s*(?:❌|🔒|🔄)?\s*\[[DMT]\]\s*/u, "").replace(/([a-z\d])([A-Z])/g, "$1-$2").normalize("NFKD").replace(/[^a-zA-Z0-9а-яА-ЯёЁ]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase() || "target";
}
function finite2(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : void 0;
}
function paintFacts(paints) {
  if (paints === figma.mixed || !Array.isArray(paints)) return null;
  return paints.map((paint) => {
    const fact = {
      type: paint.type,
      visible: !("visible" in paint) || paint.visible !== false,
      opacity: "opacity" in paint ? finite2(paint.opacity) ?? 1 : 1
    };
    const bound = paint.boundVariables;
    if (bound?.color?.id) fact.tokenId = bound.color.id;
    if (paint.type === "SOLID") {
      fact.color = {
        r: Math.round(paint.color.r * 255),
        g: Math.round(paint.color.g * 255),
        b: Math.round(paint.color.b * 255)
      };
    }
    Object.assign(fact, captureGradientPaintDetails(paint));
    return fact;
  });
}
function variableBindings(node) {
  const result = {};
  const boundVariables = node.boundVariables;
  if (!boundVariables) return result;
  for (const [field, value] of Object.entries(boundVariables)) {
    const ids = (Array.isArray(value) ? value : [value]).map((alias) => {
      let candidate = alias;
      while (candidate && typeof candidate === "object" && "id" in candidate) {
        candidate = candidate.id;
      }
      return String(candidate);
    });
    result[field.replace(/\./g, "_")] = {
      required: true,
      tokenIds: ids
    };
  }
  return result;
}
function layoutFacts(node) {
  const layout = {};
  if ("layoutMode" in node) layout.mode = String(node.layoutMode);
  if ("itemSpacing" in node) layout.itemSpacing = finite2(node.itemSpacing) ?? 0;
  if ("paddingTop" in node) {
    layout.padding = {
      top: finite2(node.paddingTop) ?? 0,
      right: finite2(node.paddingRight) ?? 0,
      bottom: finite2(node.paddingBottom) ?? 0,
      left: finite2(node.paddingLeft) ?? 0,
      horizontal: (finite2(node.paddingLeft) ?? 0) + (finite2(node.paddingRight) ?? 0),
      vertical: (finite2(node.paddingTop) ?? 0) + (finite2(node.paddingBottom) ?? 0)
    };
  }
  if ("primaryAxisAlignItems" in node) layout.primaryAxisAlignItems = String(node.primaryAxisAlignItems);
  if ("counterAxisAlignItems" in node) layout.counterAxisAlignItems = String(node.counterAxisAlignItems);
  if ("layoutSizingHorizontal" in node) layout.sizingHorizontal = String(node.layoutSizingHorizontal);
  if ("layoutSizingVertical" in node) layout.sizingVertical = String(node.layoutSizingVertical);
  if ("gridStyleId" in node) layout.gridStyleId = String(node.gridStyleId);
  if ("clipsContent" in node) layout.clipsContent = node.clipsContent;
  return layout;
}
function appearanceFacts(node) {
  const appearance = {};
  if ("fills" in node) appearance.fill = paintFacts(node.fills);
  if ("fillStyleId" in node && node.fillStyleId !== figma.mixed) appearance.fillStyleId = String(node.fillStyleId);
  if ("strokes" in node && Array.isArray(node.strokes)) appearance.stroke = paintFacts(node.strokes);
  if ("strokeStyleId" in node) appearance.strokeStyleId = String(node.strokeStyleId);
  if ("strokeWeight" in node) {
    if (node.strokeWeight !== figma.mixed) appearance.strokeWeight = finite2(node.strokeWeight) ?? 0;
    else {
      const sides = node;
      appearance.strokeWeight = {
        top: finite2(sides.strokeTopWeight) ?? 0,
        right: finite2(sides.strokeRightWeight) ?? 0,
        bottom: finite2(sides.strokeBottomWeight) ?? 0,
        left: finite2(sides.strokeLeftWeight) ?? 0
      };
    }
  }
  if ("strokeAlign" in node) appearance.strokeAlign = String(node.strokeAlign);
  if ("dashPattern" in node) appearance.dashPattern = node.dashPattern.slice();
  if ("opacity" in node) appearance.opacity = finite2(node.opacity) ?? 1;
  if ("effects" in node) {
    appearance.effects = node.effects.map((effect) => ({ type: effect.type, visible: effect.visible !== false }));
    const details = captureEffectDetails(node.effects, "effectStyleId" in node ? node.effectStyleId : void 0);
    if (details !== void 0) appearance.effectDetailsV1 = details;
  }
  if ("effectStyleId" in node) appearance.effectStyleId = String(node.effectStyleId);
  if ("cornerRadius" in node) {
    if (node.cornerRadius === figma.mixed) {
      const corners = node;
      appearance.radius = {
        topLeft: finite2(corners.topLeftRadius) ?? 0,
        topRight: finite2(corners.topRightRadius) ?? 0,
        bottomRight: finite2(corners.bottomRightRadius) ?? 0,
        bottomLeft: finite2(corners.bottomLeftRadius) ?? 0
      };
    } else {
      appearance.radius = finite2(node.cornerRadius) ?? 0;
    }
  }
  if ("textStyleId" in node && node.textStyleId !== figma.mixed) {
    appearance.typography = { styleId: String(node.textStyleId) };
  }
  return appearance;
}
function componentFacts(node, identity, sourceIdentity) {
  const propertyReferences = Object.values(node.componentPropertyReferences || {}).filter((value) => typeof value === "string");
  const propertyReferenceBindings = Object.fromEntries(Object.entries(node.componentPropertyReferences || {}).filter((entry) => typeof entry[1] === "string"));
  if (node.type !== "INSTANCE") {
    const facts2 = { propertyReferences, propertyReferenceBindings };
    if (sourceIdentity) facts2.sourceIdentity = sourceIdentity;
    return facts2;
  }
  const properties = {};
  const propertyTypes = {};
  for (const [name, property] of Object.entries(node.componentProperties)) {
    properties[name] = property.value;
    propertyTypes[name] = property.type;
  }
  const facts = { properties, propertyTypes, propertyReferences, propertyReferenceBindings, identity: identity || {} };
  if (sourceIdentity) facts.sourceIdentity = sourceIdentity;
  return facts;
}
function textFacts(node) {
  if (node.type !== "TEXT") return {};
  const text = { characters: node.characters };
  if (node.fontSize !== figma.mixed) text.fontSize = node.fontSize;
  if (node.fontName !== figma.mixed) {
    text.fontName = { family: node.fontName.family, style: node.fontName.style };
  }
  if (node.lineHeight !== figma.mixed) text.lineHeight = node.lineHeight;
  if (node.letterSpacing !== figma.mixed) text.letterSpacing = node.letterSpacing;
  if (node.textCase !== figma.mixed) text.case = node.textCase;
  const decoration = captureTextDecoration(node);
  if (decoration !== void 0) text.decoration = decoration;
  return text;
}
async function collectSceneNodes(root, platform, modes, captureScope) {
  const roleCounts = /* @__PURE__ */ new Map();
  const omissions = [];
  const topology = captureSceneTopology(root, 500, (entry, index, all) => {
    if (entry.parentIndex !== 0 || entry.type !== "SLOT" || !captureScope) return false;
    const node = entry.node, owner = all[0].node;
    const property = node.componentPropertyReferences?.slotContentId;
    const path = entry.path.split(" / ").slice(1).join(" / ");
    const candidates = captureScope.boundaries.filter((b) => b.path === path && b.property === property);
    if (typeof property !== "string" || candidates.length !== 1 || owner.type !== "INSTANCE" || String(owner.componentProperties[property]?.type) !== "SLOT" || node.parent?.id !== owner.id || node.parent?.type !== "INSTANCE") return false;
    const consumers = (all[0].observedChildren || []).filter((child) => String(child.type) === "SLOT" && child.componentPropertyReferences?.slotContentId === property);
    if (consumers.length !== 1 || consumers[0].id !== entry.figmaNodeId) return false;
    omissions.push({ nodeId: `preview:${index}`, targetId: candidates[0].targetId, property, path });
    return true;
  });
  const entries = topology.entries.map((entry) => {
    const baseRole = slug(entry.name);
    const count = (roleCounts.get(baseRole) || 0) + 1;
    roleCounts.set(baseRole, count);
    const role = count === 1 ? baseRole : `${baseRole}-${count}`;
    return { ...entry, node: entry.node, role };
  });
  const collectionIds = new Set(entries.flatMap((entry) => Object.keys(entry.node.resolvedVariableModes || {})));
  const resolvedCollections = (await Promise.all(Array.from(collectionIds).map(async (id) => {
    try {
      return await figma.variables.getVariableCollectionByIdAsync(id);
    } catch {
      return null;
    }
  }))).filter((collection) => Boolean(collection));
  const identities = /* @__PURE__ */ new Map();
  const mains = /* @__PURE__ */ new Map();
  const instances = entries.filter((entry) => entry.node.type === "INSTANCE");
  let nextIdentity = 0;
  await Promise.all(Array.from({ length: Math.min(6, instances.length) }, async () => {
    while (nextIdentity < instances.length) {
      const instance = instances[nextIdentity++].node;
      try {
        const main = await instance.getMainComponentAsync();
        if (main) mains.set(instance.id, main);
        if (main) identities.set(instance.id, {
          componentKey: main.key,
          mainComponentId: main.id,
          ...main.parent?.type === "COMPONENT_SET" ? { componentSetKey: main.parent.key } : {}
        });
      } catch {
      }
    }
  }));
  const pristineSources = /* @__PURE__ */ new Map();
  const sourceCapture = [];
  if (topology.complete) {
    const requested = /* @__PURE__ */ new Map();
    for (const entry of topology.entries) {
      if (entry.parentIndex === null) continue;
      let ownerIndex = entry.parentIndex;
      while (ownerIndex !== null && topology.entries[ownerIndex].type !== "INSTANCE") ownerIndex = topology.entries[ownerIndex].parentIndex;
      const main = ownerIndex === null ? void 0 : mains.get(topology.entries[ownerIndex].figmaNodeId);
      if (main?.remote) requested.set(main.id, main);
    }
    for (const main of requested.values()) {
      let pristine;
      const diagnostic = { mainComponentId: main.id, componentKey: main.key, status: "unavailable" };
      try {
        pristine = main.createInstance();
        diagnostic.sourceInstanceId = pristine.id;
        const selected = await pristine.getMainComponentAsync();
        if (!selected || selected.id !== main.id || selected.key !== main.key) diagnostic.reason = "pristine-source-identity-mismatch";
        else {
          const sourceTopology = captureSceneTopology(pristine, 500, (entry, index) => index > 0 && (entry.type === "INSTANCE" || entry.type === "SLOT"));
          if (!sourceTopology.complete) diagnostic.reason = "incomplete-pristine-source-topology";
          else {
            pristineSources.set(main.id, { mainComponentId: main.id, componentKey: main.key, topology: sourceTopology });
            diagnostic.status = "captured";
          }
        }
      } catch {
        diagnostic.reason = "pristine-source-capture-unavailable";
      } finally {
        pristine?.remove();
      }
      sourceCapture.push(diagnostic);
    }
  }
  const sourceIdentities = topology.complete ? captureInstanceSourceIdentities(topology.entries, mains, pristineSources, true) : /* @__PURE__ */ new Map();
  const roleToId = new Map(entries.map((entry, index) => [entry.role, `preview:${index}`]));
  const styleKeys = /* @__PURE__ */ new Map();
  const resolveStyleKey = (id) => {
    if (!styleKeys.has(id)) styleKeys.set(id, figma.getStyleByIdAsync(id).then((s) => s?.type === "TEXT" ? s.key : void 0).catch(() => void 0));
    return styleKeys.get(id);
  };
  const styleEvidence = /* @__PURE__ */ new Map();
  const fillEvidence = /* @__PURE__ */ new Map();
  const variableKeys = /* @__PURE__ */ new Map();
  const resolveVariableKey = (id) => {
    if (!variableKeys.has(id)) variableKeys.set(id, figma.variables.getVariableByIdAsync(id).then((v) => v?.resolvedType === "COLOR" ? v.key : void 0).catch(() => void 0));
    return variableKeys.get(id);
  };
  for (const entry of entries) if (entry.node.type === "TEXT") {
    styleEvidence.set(entry.node.id, await captureTextStyleEvidence(entry.node, resolveStyleKey));
    fillEvidence.set(entry.node.id, await captureTextFillEvidence(entry.node, paintFacts, resolveVariableKey));
  }
  const usageEvidence = /* @__PURE__ */ new Map();
  const bindingVariables = /* @__PURE__ */ new Map();
  const resolveBindingCollection = async (id, modes2) => {
    if (!bindingVariables.has(id)) bindingVariables.set(id, (async () => {
      try {
        const variable = await figma.variables.getVariableByIdAsync(id);
        if (!variable) return;
        const collection = resolvedCollections.find((c) => c.id === variable.variableCollectionId) || await figma.variables.getVariableCollectionByIdAsync(variable.variableCollectionId);
        if (!collection || !/^[a-f0-9]{40}$/i.test(collection.key)) return;
        return { variable, collection };
      } catch {
        return;
      }
    })());
    const proof = await bindingVariables.get(id);
    if (!proof) return;
    const mode = modes2[proof.collection.id], values = proof.variable.valuesByMode;
    if (typeof mode !== "string" || !values || !Object.prototype.hasOwnProperty.call(values, mode)) return;
    const value = values[mode];
    const alias = value && typeof value === "object" && "type" in value && value.type === "VARIABLE_ALIAS";
    if (alias && (!("id" in value) || typeof value.id !== "string" || !value.id)) return;
    if (!alias && !["string", "boolean", "number"].includes(typeof value) && !(value && typeof value === "object" && "r" in value && "g" in value && "b" in value)) return;
    return {
      collectionId: proof.collection.id,
      collectionKey: proof.collection.key,
      referencedVariableIds: alias ? [value.id] : []
    };
  };
  let nextUsage = 0;
  await Promise.all(Array.from({ length: Math.min(6, entries.length) }, async () => {
    while (nextUsage < entries.length) {
      const entry = entries[nextUsage++];
      usageEvidence.set(entry.node.id, await captureHostVariableUsage(entry.node, resolveBindingCollection));
    }
  }));
  const anatomy = entries.map((entry, index) => {
    const supplemental = captureSupplementalFacts(entry.node, figma.mixed);
    const modeFacts = captureResolvedVariableModes(entry.node.resolvedVariableModes || {}, resolvedCollections);
    const childIds = entry.childIndexes.map((index2) => `preview:${index2}`);
    const properties = {
      layout: layoutFacts(entry.node),
      appearance: appearanceFacts(entry.node),
      variable: { bindings: variableBindings(entry.node), modes: modeFacts.modes, modeCatalog: modeFacts.modeCatalog },
      hostVariableUsageV1: usageEvidence.get(entry.node.id),
      component: componentFacts(entry.node, identities.get(entry.node.id), sourceIdentities.get(entry.node.id)),
      text: { ...textFacts(entry.node), ...supplemental.text },
      ...styleEvidence.has(entry.node.id) ? { textStyleEvidenceV1: styleEvidence.get(entry.node.id) } : {},
      ...fillEvidence.has(entry.node.id) ? { textFillEvidenceV1: fillEvidence.get(entry.node.id) } : {},
      parent: supplemental.parent,
      propertyActivityV1: capturePropertyActivity(entry.node),
      bounds: {
        x: finite2(entry.node.x) ?? 0,
        y: finite2(entry.node.y) ?? 0,
        ...intrinsicBounds(entry.node)
      },
      resolvedModes: { ...entry.node.resolvedVariableModes }
    };
    return {
      id: `preview:${index}`,
      figmaNodeId: entry.figmaNodeId,
      parentId: entry.parentIndex === null ? null : `preview:${entry.parentIndex}`,
      name: entry.name,
      type: entry.type,
      path: entry.path,
      semanticRole: entry.role,
      visible: entry.node.visible,
      order: index,
      depth: entry.depth,
      childIds,
      properties,
      unknownFacts: [...supplemental.unknownFacts, ...modeFacts.unknownFacts]
    };
  });
  const nodes = anatomy.map((entry) => {
    const facts = entry.properties;
    const relations = {};
    roleToId.forEach((id, role) => {
      relations[role] = id;
    });
    return {
      id: entry.id,
      parentId: entry.parentId,
      childIds: entry.childIds,
      order: entry.order,
      name: entry.name,
      type: entry.type,
      visible: entry.visible,
      semantic: { role: entry.semanticRole, path: entry.path },
      component: facts.component || {},
      layout: facts.layout || {},
      appearance: facts.appearance || {},
      variable: facts.variable || {},
      hostVariableUsageV1: facts.hostVariableUsageV1,
      text: facts.text || {},
      ...facts.textStyleEvidenceV1 ? { textStyleEvidenceV1: facts.textStyleEvidenceV1 } : {},
      ...facts.textFillEvidenceV1 ? { textFillEvidenceV1: facts.textFillEvidenceV1 } : {},
      parent: facts.parent || {},
      propertyActivityV1: facts.propertyActivityV1 || {},
      bounds: facts.bounds || {},
      resolvedModes: facts.resolvedModes || {},
      baseline: {
        effective: {
          layout: facts.layout || {},
          appearance: facts.appearance || {},
          variable: facts.variable || {},
          component: facts.component || {},
          text: facts.text || {},
          visible: entry.visible,
          bounds: intrinsicBounds(facts.bounds),
          propertyActivityV1: facts.propertyActivityV1 || {}
        }
      },
      relations,
      unknownFacts: entry.unknownFacts
    };
  });
  for (const entry of entries) if (entry.node.id !== entry.figmaNodeId || entry.node.type !== entry.type || entry.node.name !== entry.name) {
    topology.issues.push({ kind: "identity-changed", nodeId: entry.figmaNodeId, path: entry.path });
    topology.complete = false;
  }
  const result = {
    anatomy,
    snapshot: {
      schemaVersion: "apollo.predicate-snapshot.v2",
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      source: {
        geometryCaptureVersion: 1,
        gradientPaintCaptureVersion: 1,
        instanceIdentityVersion: 1,
        instanceSourceIdentityVersion: 1,
        occurrenceAddressVersion: 1,
        instanceSourceIdentityCapture: { version: 1, owners: sourceCapture },
        propertyReferenceIdentityVersion: 1,
        fileKey: figma.fileKey,
        fileName: figma.root.name,
        pageId: (() => {
          let parent = root.parent;
          while (parent && parent.type !== "PAGE") parent = parent.parent;
          return parent?.id || figma.currentPage.id;
        })(),
        rootNodeId: root.id,
        truncated: !topology.complete,
        captureTopology: { version: 1, complete: topology.complete, limitReached: topology.limitReached, issues: topology.issues },
        ...omissions.length && captureScope ? { nativeSlotCaptureScope: { version: 1, manualSourceHash: captureScope.manualSourceHash, omissions } } : {},
        nodeLimit: 500
      },
      selection: anatomy.length ? [anatomy[0].id] : [],
      context: { platform, modes, unknownFacts: [] },
      nodes
    }
  };
  {
    const paths = snapshotPaths(result.snapshot);
    if (paths) for (const entry of anatomy) {
      const path = paths.get(entry.id);
      if (path !== void 0) {
        entry.path = [root.name, path].filter(Boolean).join(" / ");
        const node = nodes.find((n) => n.id === entry.id);
        node.semantic.path = entry.path;
      }
    }
  }
  const nativeInstances = /* @__PURE__ */ new Map();
  if (topology.complete) for (const entry of entries) {
    if (entry.observedChildren) {
      let children;
      try {
        children = "children" in entry.node ? Array.from(entry.node.children) : [];
      } catch {
        topology.complete = false;
        topology.issues.push({ kind: "unreadable-node", nodeId: entry.figmaNodeId, path: entry.path });
        result.snapshot.source.truncated = true;
        result.snapshot.source.captureTopology.complete = false;
        break;
      }
      if (children.length !== entry.childIndexes.length || children.some((child, index) => child.id !== entries[entry.childIndexes[index]].figmaNodeId)) {
        topology.complete = false;
        topology.issues.push({ kind: "identity-changed", nodeId: entry.figmaNodeId, path: entry.path });
        result.snapshot.source.truncated = true;
        result.snapshot.source.captureTopology.complete = false;
        break;
      }
    }
    if (entry.node.type === "INSTANCE") nativeInstances.set(entry.figmaNodeId, entry.node);
  }
  if (!topology.complete) nativeInstances.clear();
  return { anatomy: result.anatomy, snapshot: result.snapshot, nativeInstances };
}
async function collectNodes(root, platform, modes, captureScope) {
  const result = await collectSceneNodes(root, platform, modes, captureScope);
  return { anatomy: result.anatomy, snapshot: result.snapshot };
}
async function applyModes(instance, modes) {
  const warnings = [];
  for (const [collectionId, modeId] of Object.entries(modes)) {
    try {
      const collection = await figma.variables.getVariableCollectionByIdAsync(collectionId);
      if (collection) instance.setExplicitVariableModeForCollection(collection, modeId);
      else warnings.push(`\u041A\u043E\u043B\u043B\u0435\u043A\u0446\u0438\u044F ${collectionId} \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430; mode ${modeId} \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0451\u043D \u043A reference instance.`);
    } catch {
      warnings.push(`\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C mode ${modeId} \u043A\u043E\u043B\u043B\u0435\u043A\u0446\u0438\u0438 ${collectionId} \u043A reference instance.`);
    }
  }
  return warnings;
}
function referenceProperties(subject, reference, allowedNames) {
  const allowed = new Set(allowedNames);
  const result = {};
  for (const [name, property] of Object.entries(subject.componentProperties)) {
    const referenceProperty = reference.componentProperties[name];
    if (!referenceProperty) continue;
    const isVariant = property.type === "VARIANT";
    if (!isVariant && !allowed.has(name)) continue;
    if (typeof property.value === "string" || typeof property.value === "boolean") {
      result[name] = property.value;
    }
  }
  return result;
}
async function instanceAtPath(root, path, expected) {
  if (path.split(" / ").some((segment) => segment.startsWith("@local:") || segment.startsWith("@catalog:"))) return void 0;
  const priorScope = expected.source?.nativeSlotCaptureScope;
  const captureScope = priorScope ? {
    manualSourceHash: priorScope.manualSourceHash,
    boundaries: priorScope.omissions.map((entry) => ({
      targetId: entry.targetId,
      property: entry.property,
      path: entry.path,
      representationId: expected.source?.representationId || ""
    }))
  } : void 0;
  const current = await collectSceneNodes(root, expected.context.platform, expected.context.modes, captureScope);
  if (expected.source?.occurrenceAddressVersion !== 1 && current.snapshot.source) delete current.snapshot.source.occurrenceAddressVersion;
  const paths = snapshotPaths(current.snapshot), expectedPaths = snapshotPaths(expected);
  if (!paths || !expectedPaths) return void 0;
  let node = current.snapshot.nodes.find((n) => paths.get(String(n.id)) === path);
  let prior = expected.nodes.find((n) => expectedPaths.get(String(n.id)) === path);
  if (!node || !prior || node.type !== "INSTANCE" || prior.type !== "INSTANCE") return void 0;
  const locator = current.anatomy.find((n) => n.id === node.id)?.figmaNodeId;
  const instance = locator ? current.nativeInstances.get(locator) : void 0;
  while (node && prior) {
    if (node.type !== prior.type) return void 0;
    const component = node.component;
    const previous = prior.component;
    for (const field of ["componentKey", "mainComponentId", "componentSetKey"]) {
      if (previous?.identity?.[field] !== component?.identity?.[field]) return void 0;
    }
    const source = previous?.sourceIdentity, fresh = component?.sourceIdentity;
    if (source && (!fresh || source.version !== fresh.version || source.ownerComponentKey !== fresh.ownerComponentKey || source.ownerMainComponentId !== fresh.ownerMainComponentId || source.sourceNodeId !== fresh.sourceNodeId)) return void 0;
    if (node.parentId === null || prior.parentId === null) return node.parentId === prior.parentId ? instance : void 0;
    node = current.snapshot.nodes.find((n) => n.id === node.parentId);
    prior = expected.nodes.find((n) => n.id === prior.parentId);
  }
  return void 0;
}
async function captureInstanceContentReferences(subject, pristine, page, snapshot, base, modesReliable) {
  const attempts = [];
  snapshot.instanceContentReferences = { schemaVersion: "apollo.instance-content-references.v4", hostContextVariableModesVersion: 1, base, attempts };
  const boundaries = planInstanceContentReferences(snapshot);
  let captured = 0;
  const capture = async (boundaries2, contextHost, contextSnapshot, parentBoundaryNodeId) => {
    for (const boundary of boundaries2) {
      const attempt = { boundaryNodeId: boundary.nodeId, ...parentBoundaryNodeId ? { parentBoundaryNodeId } : {} };
      attempts.push(attempt);
      if (!modesReliable) {
        attempt.failure = "variable-modes-unavailable";
        continue;
      }
      const variant = boundary.reason === "component-variant-changed" && Boolean(boundary.componentSetKey);
      if (!variant && (boundary.reason !== "instance-swap" || !boundary.property || boundary.ownerPath === void 0)) {
        attempt.failure = "explicit-swap-port-required";
        continue;
      }
      if (captured++ >= INSTANCE_CONTENT_REFERENCE_LIMIT) {
        attempt.failure = "reference-capture-limit";
        continue;
      }
      let host;
      try {
        const actual = await instanceAtPath(subject, boundary.actualPath, snapshot);
        const main = actual && await actual.getMainComponentAsync();
        if (!main || main.key !== boundary.actualComponentKey) {
          attempt.failure = "replacement-component-unavailable";
          continue;
        }
        host = contextHost.clone();
        page.appendChild(host);
        const consumer = await instanceAtPath(host, boundary.referencePath, contextSnapshot);
        const before = consumer && await consumer.getMainComponentAsync();
        const owner = boundary.ownerPath !== void 0 ? await instanceAtPath(host, boundary.ownerPath, contextSnapshot) : void 0;
        const provenControl = variant ? before?.parent?.type === "COMPONENT_SET" && main.parent?.type === "COMPONENT_SET" && before.parent.key === boundary.componentSetKey && main.parent.key === boundary.componentSetKey : owner && boundary.property && consumer?.componentPropertyReferences?.mainComponent === boundary.property && owner.componentProperties[boundary.property]?.type === "INSTANCE_SWAP" && owner.componentProperties[boundary.property]?.value === before?.id;
        if (!consumer || !before || before.key !== boundary.referenceComponentKey || !provenControl) {
          attempt.failure = "replacement-identity-or-port-mismatch";
          continue;
        }
        if (variant) {
          const properties = main.variantProperties;
          if (!properties || !Object.keys(properties).length || Object.entries(properties).some(([name, value]) => typeof value !== "string" || consumer.componentProperties[name]?.type !== "VARIANT")) {
            attempt.failure = "variant-properties-unavailable";
            continue;
          }
          consumer.setProperties(properties);
          const selected = await consumer.getMainComponentAsync();
          if (!selected || selected.key !== main.key || selected.parent?.type !== "COMPONENT_SET" || selected.parent.key !== boundary.componentSetKey) {
            attempt.failure = "variant-switch-identity-mismatch";
            continue;
          }
          attempt.strategy = "pristine-host-variant-properties";
        } else {
          consumer.mainComponent = main;
        }
        const reference = (await collectNodes(host, snapshot.context.platform, snapshot.context.modes)).snapshot;
        configureInstanceMainAliases(reference, snapshot.source?.instanceMainComponentAliasesVersion === 1);
        if (reference.source) {
          reference.source.componentKey = base.source?.componentKey;
          reference.source.componentSetKey = base.source?.componentSetKey;
        }
        attempt.reference = reference;
        materializeInstanceContentReferences(snapshot);
        if (snapshot.instanceContentResults?.some((r) => r.boundaryNodeId === boundary.nodeId && r.lineageProven)) {
          await capture(planNestedInstanceContentReferences(snapshot, reference, boundary), host, reference, boundary.nodeId);
        }
      } catch {
        attempt.failure = "reference-capture-failed";
      } finally {
        host?.remove();
      }
    }
  };
  await capture(boundaries, pristine, base);
  materializeInstanceContentReferences(snapshot);
}
async function captureComponentDependencies(anatomy, snapshot, temporaryPage, acceptedKeys = [], directChildDependenciesVersion, instanceMainComponentAliasesVersion) {
  if (!acceptedKeys.length) return;
  snapshot.componentDependencyCaptures = [];
  const keys = new Set(acceptedKeys);
  const candidates = snapshot.nodes.filter((n) => !snapshot.selection.includes(String(n.id)) && n.type === "INSTANCE" && (() => {
    const identity = n.component?.identity;
    return identity && (keys.has(identity.componentKey) || keys.has(identity.componentSetKey));
  })());
  for (const [index, node] of candidates.entries()) {
    const attempt = { nodeId: String(node.id) };
    snapshot.componentDependencyCaptures.push(attempt);
    if (index >= (directChildDependenciesVersion === 1 ? DIRECT_CHILD_DEPENDENCY_CAPTURE_LIMIT : COMPONENT_DEPENDENCY_CAPTURE_LIMIT)) {
      attempt.failure = "dependency-reference-capture-limit";
      continue;
    }
    let reference = null;
    let stage = "resolve-instance";
    try {
      const locator = anatomy.find((n) => n.id === node.id)?.figmaNodeId;
      const instance = locator ? await figma.getNodeByIdAsync(locator) : null;
      if (!instance || instance.type !== "INSTANCE") {
        attempt.failure = "dependency-instance-unavailable";
        continue;
      }
      stage = "read-main-component";
      const main = await instance.getMainComponentAsync();
      if (!main) {
        attempt.failure = "dependency-main-component-unavailable";
        continue;
      }
      stage = "create-reference-instance";
      reference = main.createInstance();
      stage = "append-reference-instance";
      temporaryPage.appendChild(reference);
      stage = "read-variable-modes";
      const modes = Object.assign({}, instance.resolvedVariableModes);
      stage = "apply-variable-modes";
      const warnings = await applyModes(reference, modes);
      if (warnings.length) {
        attempt.failure = "dependency-variable-modes-unavailable";
        continue;
      }
      stage = "capture-actual";
      const actual = await collectNodes(instance, snapshot.context.platform, modes);
      stage = "capture-reference";
      const baseline = await collectNodes(reference, snapshot.context.platform, modes);
      const setKey = main.parent?.type === "COMPONENT_SET" ? main.parent.key : "";
      for (const s of [actual.snapshot, baseline.snapshot]) if (s.source) {
        s.source.componentKey = main.key;
        s.source.componentSetKey = setKey;
      }
      configureInstanceMainAliases(actual.snapshot, instanceMainComponentAliasesVersion === 1);
      configureInstanceMainAliases(baseline.snapshot, instanceMainComponentAliasesVersion === 1);
      stage = "materialize-baseline";
      const materialized = materializeEffectiveBaseline(actual.snapshot, baseline.snapshot, true);
      stage = "capture-variant-reference";
      materialized.snapshot.variantReference = captureVariantReference(
        baseline.snapshot,
        main.key,
        setKey,
        Object.keys((main.parent?.type === "COMPONENT_SET" ? main.parent : main).componentPropertyDefinitions)
      );
      stage = "capture-nested-reference";
      await captureInstanceContentReferences(instance, reference, temporaryPage, materialized.snapshot, baseline.snapshot, true);
      stage = "map-node-ids";
      attempt.nodeMap = Object.fromEntries(actual.anatomy.map((local) => [local.id, anatomy.find((host) => host.figmaNodeId === local.figmaNodeId)?.id || ""]));
      attempt.snapshot = materialized.snapshot;
    } catch (error) {
      attempt.failure = "dependency-reference-capture-failed";
      attempt.failureDetails = dependencyCaptureFailureDetails(stage, error);
    } finally {
      reference?.remove();
    }
  }
}
async function exportPreview(node) {
  const longest = Math.max(node.width, node.height, 1);
  const scale = Math.min(2, 1600 / longest);
  const bytes = await node.exportAsync({
    format: "PNG",
    constraint: { type: "SCALE", value: scale }
  });
  return {
    dataUrl: `data:image/png;base64,${figma.base64Encode(bytes)}`,
    width: node.width,
    height: node.height
  };
}
async function captureInstanceAudit(subject, message) {
  if (message.expectedRootNodeId && message.expectedRootNodeId !== subject.id) {
    throw new Error("\u0412\u044B\u0434\u0435\u043B\u0435\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u0417\u0430\u0434\u0430\u0439\u0442\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u043C\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043B\u044F \u043D\u043E\u0432\u043E\u0433\u043E instance \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443.");
  }
  const temporalStart = message.captureTransitionContext ? captureTransitionContext(subject) : void 0;
  const temporalSequence = temporalStart ? ++transitionSequence : 0;
  const main = await subject.getMainComponentAsync();
  if (!main) throw new Error("\u0423 \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u043D\u043E\u0433\u043E instance \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D main component.");
  const acceptedKeys = new Set([message.componentKey, ...message.acceptedComponentKeys].filter(Boolean));
  const componentSetKey = main.parent?.type === "COMPONENT_SET" ? main.parent.key : "";
  const representation = message.representations === void 0 ? void 0 : resolveCaptureRepresentation(
    message.representations,
    main.key,
    componentSetKey
  );
  if (!representation && !matchesComponentIdentity(main.key, componentSetKey, Array.from(acceptedKeys))) {
    throw new Error("\u041A\u043B\u044E\u0447 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u043E\u043C \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0435. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0439 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440 \u0438\u043B\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0433\u043E \u043F\u0430\u043A\u0435\u0442.");
  }
  const platform = representation?.platform || message.platform;
  let temporaryPage = null;
  let reference = null;
  try {
    temporaryPage = figma.createPage();
    temporaryPage.name = "__Apollo_IndependentReference__";
    reference = main.createInstance();
    temporaryPage.appendChild(reference);
    const compatible = referenceProperties(subject, reference, message.allowedComponentProperties);
    if (Object.keys(compatible).length) reference.setProperties(compatible);
    const modes = { ...subject.resolvedVariableModes };
    const warnings = await applyModes(reference, modes);
    const baseline = await collectNodes(reference, platform, modes);
    if (baseline.snapshot.source) {
      baseline.snapshot.source.componentKey = main.key;
      baseline.snapshot.source.componentSetKey = componentSetKey;
      if (representation) baseline.snapshot.source.representationId = representation.id;
    }
    const independentReference = captureVariantReference(
      baseline.snapshot,
      main.key,
      componentSetKey,
      Object.keys((main.parent?.type === "COMPONENT_SET" ? main.parent : main).componentPropertyDefinitions)
    );
    const requestedPlan = message.nativeSlotCapturePlan;
    const boundaries = requestedPlan?.manualSourceHash === message.manualSourceHash ? confirmedNativeSlotCaptureBoundaries(requestedPlan, independentReference, representation?.id || "", main.key, componentSetKey) : [];
    const actual = await collectNodes(subject, platform, modes, boundaries.length ? { manualSourceHash: message.manualSourceHash, boundaries } : void 0);
    if (actual.snapshot.source) {
      actual.snapshot.source.componentKey = main.key;
      actual.snapshot.source.componentSetKey = componentSetKey;
      if (representation) actual.snapshot.source.representationId = representation.id;
    }
    configureInstanceMainAliases(actual.snapshot, message.instanceMainComponentAliasesVersion === 1);
    configureInstanceMainAliases(baseline.snapshot, message.instanceMainComponentAliasesVersion === 1);
    const materialized = materializeEffectiveBaseline(actual.snapshot, baseline.snapshot, true);
    materialized.snapshot.variantReference = independentReference;
    await captureInstanceContentReferences(subject, reference, temporaryPage, materialized.snapshot, baseline.snapshot, warnings.length === 0);
    await captureComponentDependencies(actual.anatomy, materialized.snapshot, temporaryPage, message.componentDependencyKeys, message.directChildDependenciesVersion, message.instanceMainComponentAliasesVersion);
    materialized.unmatchedNodeIds = materialized.snapshot.nodes.filter((node) => node.baselineProvenance?.status !== "matched").map((node) => String(node.id));
    materialized.matchedNodes = materialized.snapshot.nodes.length - materialized.unmatchedNodeIds.length;
    const preview = await exportPreview(subject);
    if (temporalStart) {
      const end = captureTransitionContext(subject), complete = temporalStart.complete && end.complete && temporalStart.fingerprint === end.fingerprint;
      materialized.snapshot.transitionCapture = {
        schemaVersion: "apollo.transition-capture.v1",
        sessionId: transitionSessionId,
        sequence: temporalSequence,
        manualSourceHash: message.manualSourceHash,
        externalContext: temporalStart.context,
        complete,
        ...!complete ? { reason: temporalStart.reason || end.reason || "changed-during-capture" } : {}
      };
    }
    if (materialized.unmatchedNodeIds.length) {
      warnings.push(`${materialized.unmatchedNodeIds.length} \u0443\u0437\u043B\u043E\u0432 instance \u043D\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u044B \u0441 reference baseline.`);
    }
    if (actual.snapshot.source?.captureTopology?.issues.length) warnings.push("\u0417\u0430\u0445\u0432\u0430\u0442 \u0434\u0435\u0440\u0435\u0432\u0430 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D: \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u044B\u0435/\u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0440\u0435\u0447\u0438\u0432\u044B\u0435 Figma ID \u0438\u043B\u0438 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 \u0443\u0437\u043B\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043D\u0435\u043F\u043E\u043B\u043D\u0430\u044F.");
    if (actual.snapshot.source?.nativeSlotCaptureScope) warnings.push("\u0412\u043D\u0435\u0448\u043D\u0435\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 native SLOT \u043D\u0435 \u043E\u0431\u0445\u043E\u0434\u0438\u043B\u043E\u0441\u044C: \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E host \u0438 \u0433\u0440\u0430\u043D\u0438\u0446\u0430 \u0441\u043B\u043E\u0442\u0430. \u041F\u0440\u0430\u0432\u0438\u043B\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u043B\u0438\u0441\u044C.");
    return {
      componentKey: main.key,
      anatomy: actual.anatomy,
      snapshot: materialized.snapshot,
      imageDataUrl: preview.dataUrl,
      width: preview.width,
      height: preview.height,
      matchedBaselineNodes: materialized.matchedNodes,
      unmatchedBaselineNodeIds: materialized.unmatchedNodeIds,
      warnings,
      manualSourceHash: message.manualSourceHash
    };
  } finally {
    reference?.remove();
    temporaryPage?.remove();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  applyModes,
  captureComponentDependencies,
  captureInstanceAudit,
  captureInstanceContentReferences,
  collectNodes,
  exportPreview,
  referenceProperties,
  slug
});
