---
id: ptrn:landing-pages.alfa-business
layer: product
product: ab
platforms: [web]
targets: []
status: verified
lastReviewed: 2026-09-02
---

# Pattern: Лендинги в Альфа-Бизнесе

- documentType: pattern
- patternType: layout
- patternId: ptrn:landing-pages.alfa-business
- patternKey: landing-pages.alfa-business
- productType: alfa-business
- platforms: desktop, mobileweb, adaptive
- locale: ru-RU
- owner: Editorial / Design System
- status: draft
- updatedAt: 2026-09-02
- sourceType: design-guideline
- tags: landing, promo, alfa-business, promo-main-block, benefits, content, footer, modal, mobileweb, editorial
- figmaLink: none
- relatedPatterns:
  - ptrn:components.corporate-page
- sections: 10

## Section 1: Определение

Лендинг в Альфа-Бизнесе — отдельная страница или модальное окно, задача которого довести пользователя до одного конкретного действия: оставить заявку, купить, подписаться, перейти к подключению или выполнить другой целевой шаг.

Вся структура лендинга — главный блок, бенефиты, основной контент, форма, оффер и футер — подчинена одной цели: повысить вероятность целевого действия и закрыть вопросы пользователя до начала пользования продуктом, не перегружая страницу лишней информацией.

## Section 2: Когда использовать

Используйте паттерн, когда проектируете:

- промо-страницу продукта, сервиса или предложения Альфа-Бизнеса;
- лендинг, который заменяет пустое состояние и ведёт пользователя к началу флоу;
- модальный лендинг с описанием продукта или условий;
- лендинг в конструкторе «Витрина и лендинги»;
- страницу с главным оффером, бенефитами, контентными блоками и футером;
- адаптивный лендинг для Desktop и Mobile Web;
- лендинг для сегментов СБ/КИБ с отдельной стилизацией.

## Section 3: Когда не использовать

Не используйте лендинг, если:

- нужно просто показать справочный текст без целевого действия;
- основной контент содержит меньше двух контентных блоков;
- страница не помогает пользователю принять решение или начать действие;
- нужно собрать обычную продуктовую страницу с рабочим интерфейсом, а не промо-страницу;
- весь сценарий можно закрыть обычным пустым состоянием, уведомлением или формой без промо-структуры.

Лендинги, созданные в конструкторе, всегда открываются в модальном окне и не поддерживают открытие отдельной страницей.

## Section 4: Принципы

1. У лендинга одна цель и одно главное целевое действие.
2. Лендинг всегда состоит из трёх частей: главный блок, основной контент и футер.
3. Основной контент содержит не меньше двух контентных блоков.
4. Главный блок всегда строится на `PromoMainBlock`.
5. Основная библиотека для лендингов — `Web :: Corp Promo Components`.
6. Если у компонента есть версия с темизацией `[Promo]`, используйте именно её.
7. Блок с бенефитами всегда идёт первым в основном контенте.
8. Контент строится по системной сетке и gutter текущего разрешения.
9. Цвета берутся из `033 :: Promo Colors`, с ограничениями по месту использования.
10. Футер всегда находится в конце лендинга и не переносится в основной контент.
11. Compact-вид используется на разрешениях меньше `1024 px`.
12. Редактура лендинга должна быть такой же системной, как визуальная сборка.

## Section 5: Структура текста

Заголовок первого экрана выводит главное вперёд. Чаще всего лучший заголовок — название продукта в именительном падеже: `Альфа-Таргет`, `Зарплатный проект`, `Идентификация платежей`.

Подзаголовок раскрывает главную мысль лендинга. Он может быть побудительным предложением или коротким объяснением пользы. Если одного предложения недостаточно, допустимы 2 или 3, но на `1440 px` не используйте больше трёх строк.

Если на лендинге есть стоимость, пишите её на первом экране. Для подписки добавляйте бесплатный период, если он есть. Суммы на лендингах отбиваются с пятизначных: `10 000 ₽`. В тарифах и калькуляторах — с четырёхзначных: `1 000 ₽`. Перед знаком валюты ставится узкий неразрывный пробел. Копейки на лендингах не используются.

Кнопка первого экрана выбирается по действию. `Создать заявку` подходит для большинства сценариев. `Отправить заявку` используйте только если заявка сразу отправляется менеджеру. `Попробовать бесплатно` — для trial-версий подписки. `К разделу` — если действия нет, а есть переход. `Подключить`, `Оформить`, `Получить` — если действие происходит сразу.

В FAQ заголовок всегда `Частые вопросы`. Теги пишутся в именительном падеже. Вопросы пишутся с вопросительным знаком. В ответах ставятся точки после каждого обычного абзаца.

## Section 6: Правила

### Rule 1: Собирай лендинг из трёх обязательных частей

- ruleId: rule:landing-pages.alfa-business.required-three-sections
- severity: error
- appliesTo: screen
- checkType: llm
- autofix: no

Каждый лендинг должен состоять из главного блока, основного контента и футера. Основной контент должен содержать не меньше двух контентных блоков.

#### Правильно

```text
PromoMainBlock
Benefits
Content block 1
Content block 2
Footer
```

#### Неправильно

```text
PromoMainBlock
Content block 1
```

#### Почему

Если нет основного контента и футера, лендинг не закрывает вопросы пользователя и не выполняет промо-задачу.

### Rule 2: Используй Promo-компоненты как основной набор

- ruleId: rule:landing-pages.alfa-business.use-promo-components
- severity: error
- appliesTo: component
- checkType: llm
- autofix: no

Основная библиотека для лендингов — `Web :: Corp Promo Components`. Компоненты из Core и Corp допустимы только если аналога нет в Promo Components. Если есть версия с темизацией `[Promo]`, используйте её.

#### Правильно

```text
PromoMainBlock
[Promo] BackgroundPlate
BenefitCard из Promo Components
```

#### Неправильно

```text
Использован обычный Corp-компонент, хотя есть Promo-версия.
```

#### Почему

Promo-компоненты поддерживают нужную визуальную плотность, палитры и поведение лендингов.

### Rule 3: Строй главный блок на PromoMainBlock

- ruleId: rule:landing-pages.alfa-business.hero-promomainblock-only
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

Hero-зона лендинга всегда расположена первой и содержит ровно один `PromoMainBlock`. Это правило одинаково для отдельной страницы и модального лендинга: во втором случае считается порядок внутри контента модальной сущности.

#### Правильно

```text
First hero -> exactly one PromoMainBlock
```

#### Неправильно

```text
До PromoMainBlock расположен другой контентный блок.
Hero собран вручную из текстового блока, картинки и кнопки.
В hero расположены два PromoMainBlock.
```

#### Почему

`PromoMainBlock` задаёт системный первый экран, адаптивность и стилизацию лендинга.

### Rule 4: Ограничивай палитры главного блока на странице

- ruleId: rule:landing-pages.alfa-business.page-hero-promo-colors
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

На отдельной странице цвет главного блока настраивается только токенами из `033 :: Promo Colors`. Не используйте `promo-pale` и `promo-muted`. `promo-vibrant` допускается, но не рекомендуется.

#### Правильно

```text
PromoMainBlock background: token from 033 :: Promo Colors
```

#### Неправильно

```text
PromoMainBlock background: promo-pale
PromoMainBlock background: raw fill
```

#### Почему

Палитра первого экрана должна соответствовать промо-системе и не уходить в случайные цвета.

### Rule 5: Для модального лендинга используй фон и сепаратор главного блока

- ruleId: rule:landing-pages.alfa-business.modal-hero-background-and-separator
- severity: error
- appliesTo: component
- checkType: llm
- autofix: no

В модальном лендинге `PromoMainBlock` отображается с фоном и blur-эффектом изображения. Главный блок отделён от основного контента сепаратором со скруглёнными углами. Шапка модального окна размещается абсолютно поверх главного блока и не имеет фоновой заливки.

#### Правильно

```text
UniversalModalHeader absolute over PromoMainBlock
PromoMainBlock with background
Rounded separator before content
```

#### Неправильно

```text
Шапка модального окна имеет собственную заливку.
Главный блок не отделён сепаратором.
```

#### Почему

Модальный лендинг должен сохранять ощущение единой промо-поверхности и не дробиться лишними заливками.

### Rule 6: Для СБ/КИБ используй отдельную промо-стилизацию

- ruleId: rule:landing-pages.alfa-business.sb-kib-promo-classic-dark
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

Для сегментов СБ/КИБ в главном блоке используется `promo-classic` и `Appearance=dark`. В контенте СБ/КИБ допустимы только нейтральные токены из `033 :: Promo Colors`, например `promo-classic` или `promo-gravel`. Цветные токены запрещены.

#### Правильно

```text
Segment: СБ/КИБ
Hero token: promo-classic
Appearance: dark
Content tokens: promo-classic / promo-gravel
```

#### Неправильно

```text
Segment: СБ/КИБ
Content token: promo-vibrant
```

#### Почему

Для СБ/КИБ используется более строгая нейтральная стилизация.

### Rule 7: Соблюдай редакционные ограничения первого экрана

- ruleId: rule:landing-pages.alfa-business.hero-editorial
- severity: warning
- appliesTo: text
- checkType: llm
- autofix: partial

Заголовок первого экрана должен выводить главное вперёд. Подзаголовок не должен занимать больше трёх строк на `1440 px`. Если в тексте два абзаца или больше, точка нужна после каждого.

#### Правильно

```text
Бухгалтерия для ИП на УСН «Доходы»
Рассчитаем налоги и покажем данные ЕНС онлайн — это поможет избежать ошибок и штрафов.
```

#### Неправильно

```text
Длинный подзаголовок на 5 строк без явной главной мысли.
```

#### Почему

Первый экран должен быстро объяснить продукт и не ломать адаптив длинным текстом.

### Rule 8: Пиши стоимость по правилам лендинга

- ruleId: rule:landing-pages.alfa-business.price-format
- severity: warning
- appliesTo: text
- checkType: dictionary
- autofix: partial

На лендингах суммы отбиваются с пятизначных: `10 000 ₽`. В тарифах и калькуляторах — с четырёхзначных: `1 000 ₽`. Перед знаком валюты ставится узкий неразрывный пробел. Копейки на лендингах не используются. Стоимость не нужно болдить или делать серой.

#### Правильно

```text
600 ₽ в месяц
10 000 ₽
1 000 ₽ в тарифе
```

#### Неправильно

```text
10000₽
600,00 ₽
```

#### Почему

Стоимость должна быть легко считываемой и соответствовать редполитике.

### Rule 9: Выбирай CTA по фактическому действию

- ruleId: rule:landing-pages.alfa-business.cta-by-action
- severity: warning
- appliesTo: text
- checkType: llm
- autofix: partial

Текст кнопки должен соответствовать действию. `Создать заявку` подходит для большинства сценариев. `Отправить заявку` используется только если заявка сразу отправляется менеджеру. `Попробовать бесплатно` — для trial. `К разделу` — для перехода без действия. `Подключить`, `Оформить`, `Получить` — только если действие происходит сразу.

#### Правильно

```text
Trial -> Попробовать бесплатно
Переход в раздел -> К заявкам
Начало флоу заявки -> Создать заявку
```

#### Неправильно

```text
Кнопка «Подключить» открывает флоу подключения, но подключение ещё не происходит.
```

#### Почему

CTA не должен обещать действие, которое ещё не произошло.

### Rule 10: Ставь бенефиты первыми в основном контенте

- ruleId: rule:landing-pages.alfa-business.benefits-first
- severity: error
- appliesTo: screen
- checkType: llm
- autofix: no

Блок с бенефитами всегда располагается первым в основном контенте. На Desktop рекомендуется `BenefitCard` с `Icon`, на Mobile Web — `BenefitCard` с `IconView`.

#### Правильно

```text
Hero
Benefits
Content block
Content block
Footer
```

#### Неправильно

```text
Hero
Content block
Benefits
Footer
```

#### Почему

Бенефиты быстро отвечают на вопрос пользователя «зачем мне это нужно».

### Rule 11: В модальном лендинге показывай сепараторы контента сверху и снизу

- ruleId: rule:landing-pages.alfa-business.modal-content-separators
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

В модальном лендинге основной контент визуально отделён сепараторами сверху и снизу. Сепараторы всегда должны отображаться до и после контента.

#### Правильно

```text
Hero
Top separator
Main content
Bottom separator
Footer
```

#### Неправильно

```text
Hero
Main content без сепараторов
Footer
```

#### Почему

Сепараторы объединяют контент в модальном окне и отделяют его от главного блока и футера.

### Rule 12: Соблюдай сетку и gutter в контенте

- ruleId: rule:landing-pages.alfa-business.content-grid-and-gutter
- severity: error
- appliesTo: screen
- checkType: deterministic
- autofix: no

Контентные элементы строятся по системной сетке. Внутренние интервалы между элементами должны соответствовать gap-значениям текущей сетки и gutter конкретного разрешения.

#### Правильно

```text
Desktop content block uses grid gutter 24
Internal gaps match current grid
```

#### Неправильно

```text
Контентные элементы выровнены вручную случайными отступами.
```

#### Почему

Сетка удерживает ритм лендинга и адаптивное поведение.

### Rule 13: Ограничивай палитры основного контента

- ruleId: rule:landing-pages.alfa-business.content-palette
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

На странице для фонов основного контента используйте только promo-палитру из `033 :: Promo Colors`; `promo-pale` и `promo-muted` не используются. В модальном окне и Mobile Web допускаются все палитры из `033 :: Promo Colors`, рекомендуемая — `promo-pale`. `promo-vibrant` допускается, но не рекомендуется.

#### Правильно

```text
Page content: promo token
Modal content: promo-pale
```

#### Неправильно

```text
Page content: promo-muted
Page content: raw fill
```

#### Почему

Цвета контента должны оставаться внутри промо-палитры и не конфликтовать с фоном страницы.

### Rule 14: Окрашивай карточки блока единообразно

- ruleId: rule:landing-pages.alfa-business.uniform-card-color-in-block
- severity: warning
- appliesTo: component
- checkType: llm
- autofix: no

Если внутри блока есть акцентная информация и вы используете цвет фона, окрашивайте все элементы внутри блока единообразно. Не окрашивайте только часть карточек, кроме особых случаев вроде таблицы с акцентной строкой.

#### Правильно

```text
Все карточки блока окрашены в один тон из promo-палитры.
```

#### Неправильно

```text
Окрашена только одна карточка из трёх без сценарного основания.
```

#### Почему

Разный цвет части карточек создаёт визуальный диссонанс и ломает ритм композиции.

### Rule 15: Соблюдай фиксированные отступы контентного блока

- ruleId: rule:landing-pages.alfa-business.content-block-spacing
- severity: warning
- appliesTo: component
- checkType: deterministic
- autofix: no

На Desktop между заголовком и контентом `40 px`, в compact-версии `32 px`; между заголовком и группой тегов `32 px`, в compact-версии `24 px`. В Mobile Web между заголовком и контентом `24 px`, между группой тегов и заголовком `20 px`.

#### Правильно

```text
Desktop: title -> content 40 px
Compact: title -> content 32 px
Mobile: title -> content 24 px
```

#### Неправильно

```text
Desktop: title -> content 18 px
```

#### Почему

Фиксированные интервалы сохраняют визуальный ритм блоков.

### Rule 16: Используй промо-скругления

- ruleId: rule:landing-pages.alfa-business.promo-radius
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

Для лендингов используйте `[D][Promo] BackgroundPlate` соответствующего уровня. Внешние скругления первого уровня на Desktop и Mobile Web — `24 px`. Скругления вложенных элементов не могут превышать `24 px`; обычно используются `16 px`. Чем выше уровень вложенности, тем меньше радиус.

#### Правильно

```text
Outer promo plate: 24 px
Nested element: 16 px
```

#### Неправильно

```text
Nested element: 32 px
```

#### Почему

Лендинги используют более крупные промо-скругления, но вложенность должна оставаться иерархичной.

### Rule 17: Не используй hero-типографику в основном контенте

- ruleId: rule:landing-pages.alfa-business.hero-type-only-in-hero
- severity: error
- appliesTo: text
- checkType: deterministic
- autofix: no

Заголовок главного блока на Desktop — `Headline-System / 40–48 Large`, на Mobile Web — `Headline-System-Mobile / 26–32 Medium`. Эти размеры нельзя использовать в основном контенте.

#### Правильно

```text
Hero title: 40–48 Large
Content title: 30–36 Medium
```

#### Неправильно

```text
Content title: 40–48 Large
```

#### Почему

Hero-типографика должна оставаться уникальной для первого экрана.

### Rule 18: Чередуй визуальные акценты

- ruleId: rule:landing-pages.alfa-business.alternate-visual-accents
- severity: recommendation
- appliesTo: screen
- checkType: llm
- autofix: no

Иллюстрации и акцентные элементы в разных частях экрана рекомендуется чередовать по сторонам и стилям, чтобы создать динамичный ритм восприятия.

#### Правильно

```text
Block 1: illustration left
Block 2: illustration right
Block 3: another visual style
```

#### Неправильно

```text
Все иллюстрации выровнены по одной стороне и сделаны в одном стиле.
```

#### Почему

Чередование акцентов делает лендинг менее монотонным.

### Rule 19: Оформляй блок преимуществ без общего заголовка «Преимущества»

- ruleId: rule:landing-pages.alfa-business.benefits-editorial
- severity: warning
- appliesTo: text
- checkType: llm
- autofix: partial

Общий заголовок для блока преимуществ не нужен. Не называйте преимущества словом `Преимущества`. Заголовки самих преимуществ пишутся в свободной форме, не больше трёх строк, примерно одинакового объёма. Подзаголовок не продолжает заголовок.

#### Правильно

```text
Ускорьте процессы
От запроса до готового решения за считанные минуты
```

#### Неправильно

```text
Преимущества
Быстро
и удобно
```

#### Почему

Иконки и структура блока уже показывают, что это преимущества; слово становится шаблоном.

### Rule 20: Делай блок «Как это работает» из 3–5 шагов

- ruleId: rule:landing-pages.alfa-business.how-it-works-steps
- severity: warning
- appliesTo: text
- checkType: llm
- autofix: no

Заголовок `Как это работает` пишется без вопросительного знака. Блок содержит путь пользователя из `3–5` шагов, начиная с первого действия в интерфейсе. Финальный шаг можно показать с зелёной галочкой как целевое успешное действие.

#### Правильно

```text
Как это работает
1 Подключите мультиподписку
2 Следите за индикаторами
3 Минимизируйте риски
```

#### Неправильно

```text
Как это работает?
1 ...
2 ...
3 ...
4 ...
5 ...
6 ...
```

#### Почему

Больше пяти шагов выглядит тяжело и усложняет путь пользователя.

### Rule 21: Размещай футер только в конце лендинга

- ruleId: rule:landing-pages.alfa-business.footer-at-end
- severity: error
- appliesTo: screen
- checkType: llm
- autofix: no

Футер всегда находится в конце лендинга. Он может включать только `Form`, `FAQ` или `Files`; эти блоки могут меняться местами, но не размещаются в основном контенте.

#### Правильно

```text
Main content
Footer: Form + FAQ + Files
```

#### Неправильно

```text
FAQ размещён в середине основного контента.
Footer отсутствует.
```

#### Почему

Футер завершает лендинг и содержит финальные действия, документы и ответы на вопросы.

### Rule 22: Используй специальный футер в модальном окне

- ruleId: rule:landing-pages.alfa-business.modal-footer-style
- severity: error
- appliesTo: component
- checkType: deterministic
- autofix: no

В модальном лендинге футер отличается по стилю от основного контента, отделяется сверху сепаратором и внутренними отступами. Фон футера менять нельзя. Рекомендуется использовать preset `🔒 [D] Footer`.

#### Правильно

```text
Modal content
Footer separator
🔒 [D] Footer
```

#### Неправильно

```text
Футер модального лендинга окрашен вручную.
```

#### Почему

Футер в модальном окне должен оставаться системным и визуально отделённым.

### Rule 23: Соблюдай редактуру формы и FAQ

- ruleId: rule:landing-pages.alfa-business.form-and-faq-editorial
- severity: warning
- appliesTo: text
- checkType: llm
- autofix: partial

Форма использует побудительный заголовок и кнопку с тем же неймингом, что на первом экране. FAQ всегда называется `Частые вопросы`; теги пишутся в именительном падеже; вопросы — с вопросительным знаком; ответы должны быть подробными, со ссылками при необходимости.

#### Правильно

```text
Подключите постоянные поручения
Создать заявку
Частые вопросы
```

#### Неправильно

```text
FAQ
Преимущества сервиса?
```

#### Почему

Форма завершает продажу, а FAQ должен быть предсказуемым и редакционно аккуратным.

### Rule 24: Используй compact-вид при viewport не больше 1024 px

- ruleId: rule:landing-pages.alfa-business.compact-under-1024
- severity: error
- appliesTo: screen
- checkType: deterministic
- autofix: no

Compact-вид используется при viewport `≤1024 px`. Compact-настройки индивидуальны для каждого компонента и пресета лендинга; исключения — `PromoTableView` и компоненты из `Web Corp Components`. Для PromoMainBlock правило относится только к desktop; у mobile root свойства Compact нет.

#### Правильно

```text
Viewport 768 px -> Compact=true для поддерживаемых Promo-компонентов
```

#### Неправильно

```text
Viewport 768 px -> Compact=false во всех блоках
```

#### Почему

Compact-вид уменьшает типографику, отступы и плотность блоков для узких разрешений.

### Rule 25: Выбирай Appearance по сегменту лендинга

- ruleId: rule:landing-pages.alfa-business.hero-appearance-by-segment
- severity: error
- appliesTo: component, page.segment
- checkType: llm
- autofix: partial

Appearance PromoMainBlock — не тема и выбирается строго по контексту: `Light` для светлых цветных поверхностей сегмента ММБ, `Dark` для тёмной поверхности КИБ. Условие относится ко всему лендингу и одинаково передаётся в D/M.

#### Правильно

```text
Segment: ММБ -> Appearance=Light
Segment: КИБ -> Appearance=Dark
```

#### Неправильно

```text
Segment: КИБ -> Appearance=Light
Appearance выбран как пользовательская тема
```

### Rule 26: Показывай Holding только в режиме холдинга

- ruleId: rule:landing-pages.alfa-business.hero-holding-context
- severity: error
- appliesTo: component, user.context
- checkType: llm
- autofix: no

Holding в `[D] PromoMainBlock` показывается только пользователю в режиме холдинга. На MobileWeb Holding пока отсутствует и не переносится с desktop.

#### Правильно

```text
Desktop + режим холдинга -> Holding допустим
MobileWeb -> Holding отсутствует
```

#### Неправильно

```text
Обычный пользователь -> Holding показан
MobileWeb -> вручную добавлен desktop Holding
```

### Rule 27: Выноси mobile-действия в fixed ButtonStack

- ruleId: rule:landing-pages.alfa-business.mobile-hero-actions-button-stack
- severity: error
- appliesTo: mobile.actions, layout.position
- checkType: deterministic
- autofix: partial

Если у PromoMainBlock есть действия, на MobileWeb скрой внутренний ButtonGroup и используй отдельный `🔒 [M] ButtonStack`. ButtonStack фиксируется у нижней границы страницы, а в модальном сценарии — у нижней границы модальной сущности. Состав, назначение, label и порядок действий сохраняются относительно desktop.

#### Правильно

```text
PromoMainBlock.ButtonGroup=False
ButtonStack: fixed bottom=0
```

#### Неправильно

```text
Mobile PromoMainBlock использует только internal ButtonGroup
ButtonStack прокручивается вместе с hero-контентом
```

## Section 7: Шаблоны

### Лендинг на странице

```text
PromoMainBlock
Benefits
Content block 1
Content block 2
Footer
```

### Модальный лендинг

```text
UniversalModalHeader absolute
PromoMainBlock
Top separator
Main content
Bottom separator
Footer separator
🔒 [D] Footer
```

### Основной контент

```text
Benefits
Content block
  Title
  Tags
  Custom content
Content block
  Title
  Custom content
```

### CTA первого экрана

```text
Создать заявку
Попробовать бесплатно
К заявкам
К подключению
Выбрать условия
```

## Section 8: Примеры

### Пример 1: Лендинг подписки

```text
PromoMainBlock: название подписки, УТП, бесплатный период, Попробовать бесплатно
Benefits: 4 карточки
Content: Как это работает
Content: Стоимость и условия
Footer: Form + FAQ + Files
```

Структура ведёт пользователя от оффера к преимуществам, объяснению и финальному действию.

### Пример 2: Лендинг вместо пустого состояния

```text
PromoMainBlock: продукт в именительном падеже
CTA: Создать заявку
Benefits
Content: что получит пользователь
Footer: форма с той же кнопкой
```

Кнопка ведёт к началу флоу и не обещает моментального подключения.

### Пример 3: СБ/КИБ

```text
Hero: promo-classic, Appearance=dark
Content: promo-classic / promo-gravel
No colorful tokens
```

Стилизация сохраняет нейтральный характер сегмента.

## Section 9: Антипримеры

### Антипример 1: Лендинг без футера

```text
PromoMainBlock
Benefits
Content block
```

Футер обязателен и должен завершать лендинг.

### Антипример 2: Основной контент из одного блока

```text
PromoMainBlock
Benefits
Footer
```

Если основного контента меньше двух блоков, лендинг не раскрывает продукт.

### Антипример 3: FAQ в середине страницы

```text
PromoMainBlock
FAQ
Benefits
Footer
```

FAQ относится к футеру и не размещается в основном контенте.

### Антипример 4: Hero-типографика в карточке

```text
Content card title: Headline-System / 40–48 Large
```

Размер `40–48 Large` используется только в главном блоке.

### Антипример 5: Случайная палитра

```text
Content background: raw fill
Page content: promo-muted
```

Фоны лендинга должны использовать допустимые токены `033 :: Promo Colors`.

## Section 10: Машинная обработка

### Детерминированные проверки

- Проверять наличие главного блока, основного контента и футера.
- Проверять, что главный блок построен на `PromoMainBlock`.
- Проверять, что основной контент содержит минимум два контентных блока.
- Проверять использование токенов `033 :: Promo Colors` и запрет raw fill.
- Проверять запрет `promo-pale` и `promo-muted` на отдельной странице.
- Проверять `promo-classic` + `Appearance=dark` для СБ/КИБ.
- Проверять hero-типографику только в главном блоке.
- Проверять внешнее скругление `24 px` и вложенные радиусы не больше `24 px`.
- Проверять compact-вид на разрешениях меньше `1024 px`.
- Проверять расположение футера в конце лендинга.

### Словарные проверки

- Находить CTA: `Создать заявку`, `Отправить заявку`, `Попробовать бесплатно`, `К разделу`, `Подключить`, `Оформить`, `Получить`.
- Находить запрещённые или рискованные заголовки: `Преимущества`, `Как это работает?`, `FAQ`.
- Находить суммы без пробелов, суммы с копейками и отсутствие пробела перед `₽`.
- Находить названия палитр `promo-pale`, `promo-muted`, `promo-vibrant`, `promo-classic`, `promo-gravel`.

### LLM-проверки

- Проверять, что лендинг подчинён одному целевому действию.
- Проверять, что подзаголовок первого экрана не перегружен.
- Проверять соответствие CTA фактическому действию.
- Проверять логичность порядка блоков.
- Проверять единообразное окрашивание карточек внутри блока.
- Проверять качество редакторских формулировок в преимуществах, форме и FAQ.

### Не проверяется автоматически

- Реальная эффективность оффера.
- Достаточность продуктовых аргументов для принятия решения.
- Фактическая фронтовая настройка инверсии крестика модального окна за пределами главного блока.
- Уместность конкретной иллюстрации и её стиля без визуального контекста.
- Корректность сегментации СБ/КИБ без данных продукта.

### Автоисправления

- Заменить `FAQ` на `Частые вопросы`.
- Убрать вопросительный знак из `Как это работает?`.
- Предложить корректный CTA по типу действия.
- Исправить формат суммы, если известна числовая строка.
- Предложить заменить raw fill на токен `033 :: Promo Colors`.
