---
id: BackgroundPlate.cookbook.04-paint-and-layout
layer: product
product: ab
platforms: [web]
targets: [figma]
status: verified
lastReviewed: 2026-07-28
---

# BackgroundPlate — paint, effects и layout

Overview — [`01-overview.md`](01-overview.md).

## Primary и Secondary

- Используй paint effective baseline текущих Level, BackgroundColor и Type.
- Не меняй fill или stroke вручную.
- Новый token binding не делает ручную замену допустимой.
- Secondary не используется на Level 2.

## Colored

- Fill обязателен.
- Fill связан с color token.
- Raw fill запрещён.
- Stroke отсутствует.

## Border

- Видимая fill отсутствует.
- Stroke связан с color token.
- Рекомендуемый стартовый weight — `1 px`.
- Weight, align и другие параметры stroke можно менять под контекст.
- Вся поверхность не может быть кликабельной.

## Общие layer properties

| Property | Политика |
|---|---|
| Radius | Только effective baseline |
| Opacity | Только effective baseline |
| Blend mode | Только effective baseline |
| Drop shadow | Запрещён |
| Inner shadow | Запрещён |
| Layer blur | По контексту |
| Background blur | По контексту |

## Slot

- Horizontal sizing: `Fill`.
- Vertical sizing: `Hug`.
- Axis, item spacing и alignment: по композиции.
- Clip content: `true` или `false` по контексту.
- Padding: по контексту; `Spacing` tokens предпочтительны, но не обязательны.

Отличие от рекомендуемых `32/24` и отсутствие token binding не являются ошибкой сами по себе. Ошибка — нарушение exact pattern или подтверждённого layout-контракта потребителя.

## Table Wide

Для `[D] Table Wide` внутри BackgroundPlateSlot:

```text
[D] BackgroundPlateSlot root padding:
  top: Spacing/0
  right: Spacing/16
  bottom: Spacing/16
  left: Spacing/16

Slot padding:
  top: Spacing/0
  right: Spacing/0
  bottom: Spacing/0
  left: Spacing/0
```

Все четыре стороны root и Slot должны быть явно связаны с `Spacing` variables. Не переноси table inset на Slot и не дели его между root и Slot.

`[D] TopBar` располагается рядом с BackgroundPlateSlot в общем контейнере Level 0, а не внутри Slot. Не добавляй дополнительный inset к HeadRow, BodyRow или cells: таблица использует собственный baseline.

## Reset

При обнаружении customization:

1. Определи host root и текущие variant/modes.
2. Получи effective baseline.
3. Сравни `effectiveBaseline → actual`.
4. Component property и layer property сбрасывай независимо.
5. Не используй standalone baseline внутреннего Style Level вместо host baseline.
