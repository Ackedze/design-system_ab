---
id: BackgroundPlate.cookbook.05-verify
layer: product
product: ab
platforms: [web]
targets: [figma]
status: verified
lastReviewed: 2026-08-23
---

# BackgroundPlate — Verify

Overview — [`01-overview.md`](01-overview.md). Проверка обязательна после каждого рецепта.

## Library integrity

- BackgroundPlate — библиотечный `INSTANCE`.
- Нет detached nodes и перерисованных аналогов.
- Platform root соответствует desktop/mobile-web.
- Внутренние Style Level не размещены самостоятельно.
- На canvas не осталось import probes или component sets.

## Public boundary

- Новый обычный блок использует BackgroundPlateSlot.
- Legacy BackgroundPlate сохранён только в существующей композиции.
- Новый promo-блок также использует BackgroundPlateSlot, а не `[D|M][Promo] BackgroundPlate`.
- BackgroundPlateSlot на promo-странице использует `[Promo] BackgroundPlate Radius`.
- Content расположен внутри Slot.

## Levels

- Главная поверхность имеет `Level-0 (base)`.
- Level 0 не назначен самому BackgroundPlate.
- Первый plate имеет Level 1.
- Каждый Level 2 находится с Level 1 в общем Auto Layout.
- Level 1 имеет `positioning=ABSOLUTE`, расположен перед Level 2 и геометрически содержит его.
- Level 2 остаётся обычным Auto Layout child с `positioning=AUTO`.
- Внутри Slot нет дочернего Level 0 или Level 1.
- Обычный контент не обёрнут в лишний Level 2.

## Variants and context

- Type соответствует задаче.
- Secondary отсутствует на Level 2.
- BackgroundColor соответствует page/modal и gray/white context.
- Все plates одной поверхности используют согласованный color context.
- Loading использует `Skeleton=True`, если нет отдельного сложного паттерна.

## Paint and effects

- Primary/Secondary совпадают с effective baseline.
- Colored имеет tokenized fill без stroke.
- Border не имеет fill; цвет stroke tokenized, остальные параметры обводки выбраны по контексту.
- Radius, opacity и blend mode не изменены вручную.
- Нет Drop shadow и Inner shadow.
- Blur, если есть, обоснован контекстом.

## Slot and layout

- `Fill` по ширине и `Hug` по высоте используются как рекомендуемая стартовая сборка; отличие оценивается только по применимому паттерну и не является самостоятельной ошибкой.
- Axis, gap и alignment соответствуют контенту.
- Clip content выбран осознанно.
- Padding выбран осознанно; отсутствие `Spacing` binding само по себе не считается ошибкой.
- Для адаптива не остались лишние desktop `32 px`.

## Special cases

- Table Wide на продуктовой странице использует `0/16/16/16` на root `BackgroundPlateSlot` и `0/0/0/0` на внутреннем Slot.
- Все стороны root и Slot связаны с `Spacing` variables; table inset не разделён между уровнями.
- TopBar находится рядом с plate, а не внутри Slot.
- Promo radius каждого BackgroundPlateSlot получен из `[Promo] BackgroundPlate Radius`.
- Promo radius не воспроизведён ручным corner radius.
- После удаления outer plate в адаптиве бывший Level 2 переведён в Level 1.

## Evidence report

Перед передачей результата зафиксируй:

- platform и root component key;
- product/promo/legacy context;
- root Level mode и вложенные уровни;
- BackgroundColor, Type и Skeleton;
- root и Slot sizing, padding и конкретный слой-владелец каждого inset;
- все paint/effect customizations относительно effective baseline;
- наличие Table Wide/adaptive исключений;
- оставшиеся `[VERIFY]`, включая Code Connect coverage.
