---
id: BackgroundPlate.instructions
layer: product
product: ab
platforms: [web]
targets: []
status: draft
lastReviewed: 2026-10-16
---

# BackgroundPlate

`BackgroundPlate` — семейство variable-driven подложек Альфа-Бизнеса для смысловых блоков и вложенных поверхностей. Для нового продуктового контента используй `BackgroundPlateSlot`; старые `[D|M] BackgroundPlate` остаются активными для существующих макетов, но не являются стартовой точкой новой генерации.

Компонентные нормы и ссылки на внешние паттерны — [`ptrn:components.background-plate`](../../patterns/background-plate.md). Этот файл задаёт маршрут выбора и главные ограничения, но не заменяет exact rules исходного component package.

## Граница семейства

| Корень | Роль | Новые макеты |
|---|---|---|
| `[D] BackgroundPlateSlot` | Desktop-контейнер с контентным слотом | Предпочтительный для product и promo |
| `[M] BackgroundPlateSlot` | Mobile-web контейнер с контентным слотом | Предпочтительный для product и promo |
| `[D] BackgroundPlate` | Legacy surface wrapper | Не использовать как основу нового блока |
| `[M] BackgroundPlate` | Legacy surface wrapper | Не использовать как основу нового блока |
| `[D][Promo] BackgroundPlate` | Существующий promo desktop root | Не использовать как основу нового блока |
| `[M][Promo] BackgroundPlate` | Существующий promo mobile-web root | Не использовать как основу нового блока |

`Style Level 1` и `Style Level 2` — внутренние части. Не импортируй и не размещай их отдельно.

Строки `[D|M][Promo] BackgroundPlate` описывают существующие узлы библиотеки, а не отдельный маршрут генерации. На promo-странице `BackgroundPlateSlot` не заменяется другим компонентом: используй тот же `[D|M] BackgroundPlateSlot`, но обязательно переключи radius context на collection `[Promo] BackgroundPlate Radius`.

## Когда использовать

- Нужно отделить самостоятельный смысловой блок системной поверхностью.
- Нужна вложенная поверхность второго уровня.
- Нужен штатный loading-state через `Skeleton=True`.
- Собирается явно обозначенная promo-композиция.

## Когда не использовать

- Нужен только декоративный прямоугольник или произвольный цвет фона.
- `Level 2` размещается без общей Auto Layout-композиции с `Level 1`.
- `Border` должен быть кликабельным.
- Внутренние `Style Level` используются как самостоятельные компоненты.
- Legacy `[D|M] BackgroundPlate` выбирается для нового контентного блока вместо `BackgroundPlateSlot`.
- `[D|M][Promo] BackgroundPlate` выбирается как root нового promo-блока вместо `[D|M] BackgroundPlateSlot`.

## Уровни поверхности

Нормативный владелец — [сборка поверхностей](../../patterns/surface-composition.md). Ниже приведён маршрут настройки.

1. Главной поверхности страницы или модальной сущности назначь mode `BackgroundPlate Level=Level-0 (base)`.
2. Не назначай `Level-0` самому BackgroundPlate.
3. Первый вложенный BackgroundPlate получает `Level-1 (outer)`.
4. `Level-2 (inner)` допустим только поверх `Level-1` в общем Auto Layout: Level 1 — sibling с `positioning=ABSOLUTE`, Level 2 — обычный Auto Layout child.
5. Обычный контент можно помещать прямо в Slot уровня 1; дополнительный Level 2 не обязателен.
6. Внутри Slot запрещены дочерние BackgroundPlate с `Level-0` или `Level-1`.

В token-каталоге исходный mode может называться `Level-2 (outer)`, но его каноническая семантика в component API и паттерне — `Level-2 (inner)`.

## Выбор BackgroundColor

| Контекст | Значения |
|---|---|
| Обычная страница | `base-bg-alt (gray)` или `base-bg (white)` |
| Модальная сущность | `modal-bg-alt (gray)` или `modal-bg (white)` |

Выбирай значение по фактическому фону родительской поверхности.

## Type

| `Type` | Когда использовать | Ограничения |
|---|---|---|
| `Primary` | Основная контрастная подложка | Paint определяется effective baseline |
| `Secondary` | Менее контрастная подложка | Запрещён для `Level-2` |
| `Colored` | Нужна особая цветная поверхность | Только tokenized fill; stroke отсутствует |
| `Border` | Нужна поверхность без заливки с обводкой | Не кликабельна; цвет stroke tokenized, остальные параметры обводки — по контексту |

Для `Primary` и `Secondary` нельзя вручную менять fill или stroke, даже если новое значение связано с токеном. Для `Colored` обязателен color token и запрещён stroke. Для `Border` запрещена видимая заливка; цвет обводки задаётся токеном, а толщину, положение и другие параметры stroke можно менять по контексту.

## Skeleton и интерактивность

Нормы сценария загрузки — [loading-states](../../patterns/loading-states.md); кликабельность Border — паттерн использования BackgroundPlate.

- `Skeleton=False` — контент доступен.
- `Skeleton=True` — загружается компонент или его содержимое.
- Для обычной загрузки используй штатный property, а не ручные placeholder-слои.
- Сложная skeleton-композиция допустима только по отдельному подтверждённому паттерну.
- `Primary`, `Secondary` и `Colored` могут быть кликабельными только через предусмотренную реализацию в коде.
- `Border` всегда остаётся декоративным.

## Slot и layout

- Направление, gap и alignment Slot определяются композицией и вложенным контентом.
- `Fill` по ширине и `Hug` по высоте — рекомендуемая стартовая сборка Slot, но её отличие само по себе не является нарушением.
- `Clip content` может быть включён или выключен по контексту.
- Рекомендуемый стартовый padding: `Spacing/32` для Level 1 и `Spacing/24` для Level 2.
- Другие padding допустимы по контексту или паттерну. Token binding предпочтителен, но его отсутствие само по себе не является нарушением.
- Radius, opacity и blend mode определяются effective baseline и вручную не меняются.
- Layer blur и Background blur допустимы по контексту.

Специальное исключение Table Wide на продуктовой странице: корень `BackgroundPlateSlot` использует `top=Spacing/0`, остальные стороны `Spacing/16`, а внутренний Slot — `Spacing/0` со всех сторон. `[D] TopBar` располагается рядом с плейтом в общем Level-0 контейнере, а не внутри Slot.

## Desktop, mobile и promo

Канал проверяется общим [правилом дизайн-системы](../../patterns/design-system-usage.md). Promo Radius относится к [паттерну лендингов](../../patterns/landing-pages.md).

| Контекст | Level 1 radius | Level 2 radius |
|---|---:|---:|
| Desktop product | 16 | 12 |
| Mobile-web product | 24 | 16 |
| Promo desktop/mobile | 24 | 16 |

Значения принадлежат variable collections и не задаются вручную. Для обычной продуктовой поверхности `BackgroundPlateSlot` использует `BackgroundPlate Radius`; для любого `BackgroundPlateSlot` на promo-странице используй `[Promo] BackgroundPlate Radius`. Нельзя воспроизводить promo radius ручной заменой corner radius или оставлять обычную collection.

В адаптивной композиции:

- если внешний Level 1 удалён, бывший Level 2 вручную переведи в Level 1;
- проверь, не остались ли desktop-отступы `32 px`, которые сжимают mobile-контент;
- повторно проверь вложенность, token bindings и sizing Slot.

## Алгоритм

1. Определи platform и обычный либо promo-контекст.
2. Назначь родительской поверхности `Level-0 (base)`.
3. Импортируй `[D|M] BackgroundPlateSlot`.
4. Если это promo-страница, назначь `[Promo] BackgroundPlate Radius`; иначе оставь `BackgroundPlate Radius`.
5. Выбери `Type` и `Skeleton`.
6. Выбери page/modal `BackgroundColor`.
7. Помести обычный контент прямо в Slot.
8. Добавь Level 2 только при необходимости отдельной вложенной поверхности.
9. Настрой padding и sizing Slot по контексту, начиная с `32/24` и `Fill/Hug`; эти стартовые значения не являются жёстким audit baseline.
10. Выполни [`05-verify.md`](cookbook/05-verify.md).

## Источники

- Figma: `Web — Corp Components`, section `BackgroundPlate`, node `11057:102322`.
- Curated semantics: `BackgroundPlate/contract.overrides.json`.
- Composition: `BackgroundPlate/composition-contract.json`.
- Normative rules: `patterns/p_background-plate.md` и `BackgroundPlate/rules.json`.
- Runtime context: `BackgroundPlate/agent-context.json`.
- Live Figma MCP: публичные default variants `[D|M] BackgroundPlate`, `BackgroundPlateSlot` и Promo.
