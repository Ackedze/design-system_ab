---
id: ptrn:ux.loading-states
layer: product
product: ab
platforms: [web]
targets: [figma, code]
status: draft
lastReviewed: 2026-10-16
---

# Pattern: Использование состояний загрузки

- documentType: pattern
- patternType: ux
- patternId: ptrn:ux.loading-states
- patternKey: ux.loading-states
- productType: alfa-business
- platforms: desktop, mobileweb, adaptive
- locale: ru-RU
- owner: Design System
- status: draft
- updatedAt: 2026-10-16
- sourceType: owner-decision
- tags: backgroundplate, composition, contracts
- figmaLink: none
- sections: 10

## Section 1: Определение

Выбор штатного loading-состояния и явно описанных исключений.

## Section 2: Когда использовать

При проектировании загрузки BackgroundPlate или его содержимого. API других компонентов не предполагается автоматически.

## Section 3: Когда не использовать

Не применяйте норму вне указанного контекста или без доказанных входных данных.

## Section 4: Принципы

Каждая норма имеет одного владельца. Контракт компонента хранит ссылку на внешнюю норму, а не её копию.

## Section 5: Структура текста

Контекст проверки задаётся отдельно от свойств проверяемого экземпляра. Отсутствующий факт не заменяется предположением.

## Section 6: Правила

### Rule 1: Используй штатное состояние загрузки BackgroundPlate

- ruleId: rule:components.background-plate.skeleton-variant
- severity: error
- appliesTo: flow
- checkType: manual
- autofix: no

Skeleton=True — штатное состояние загрузки BackgroundPlate или расположенного внутри контента. Для обычной загрузки используй component property вместо ручных placeholder-слоёв. Более сложная skeleton-композиция допустима только при наличии явного правила или сценария в паттерне; без такого подтверждения не придумывай исключение. Само переключение Skeleton=False → True является разрешённым изменением состояния, а не нарушением.

#### Правильно

Для обычной загрузки включён Skeleton=True; сложное исключение имеет ссылку на применимый паттерн.

#### Неправильно

Штатная загрузка заменена ручными placeholder-слоями без подтверждённого исключения.

#### Почему

Норма описывает выбор состояния в сценарии использования, а не запрет переключения публичного API.

## Section 7: Шаблоны

```text
BackgroundPlate
Skeleton=True
```

## Section 8: Примеры

```text
BackgroundPlate
Skeleton=True
```

## Section 9: Антипримеры

```text
Обычная загрузка собрана вручную при доступном Skeleton=True.
```

## Section 10: Машинная обработка

### Детерминированные проверки

Само значение Skeleton читается из component API. Решение о необходимости loading и наличии сложного исключения требует контекста сценария; один static snapshot не доказывает весь сценарий.

### Словарные проверки

Имя слоя или совпадение названия токена не доказывают identity.

### LLM-проверки

Уточняют применимый сценарий по предоставленному контексту.

### Не проверяется автоматически

Неполный контекст, недоступный registry или неподтверждённый mapping дают UNKNOWN либо ручную проверку. Этот документ не заявляет готовность runtime.

### Автоисправления

Автоматическое исправление не предусмотрено.
