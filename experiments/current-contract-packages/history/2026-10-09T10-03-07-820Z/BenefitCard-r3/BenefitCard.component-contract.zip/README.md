# BenefitCard r3

Исправлена переносимость native target identity после импорта библиотеки в другой Figma-файл. Editor 0.2.93 / core 0.1.12, явный declaredTargetIdentityVersion=2. Независимые эталоны подтверждают 32 варианта и 96 source bindings. Из portable reference hash исключаются только file-local main IDs; actual/reference владельцы проверяются точно.

Повтор 10 пользовательских отчётов: четыре ожидаемых нарушения при скрытии Title/Graphic и 16 compliant результатов; unknown отсутствуют в двух quantity checks. Исходные отчёты сохранены без изменений. Требуется свежий прогон новой сборки Editor.

Все 30 норм и прежние predicate bodies сохранены. 29 context-only норм остаются неисполняемыми; весь контракт Draft. Реестр обновлён и прочитан 09.10.2026. Подробности: reports/update.2026-10-09.json и reports/native-portable-capture.2026-10-09.json.

## Исторический паспорт r2

# BenefitCard — contract r2

Primary source: `contract.manual.json`. Статус Draft. 32 public variants; native target identities для desktop/mobile-web закреплены за текущими master-компонентами лаборатории.

Все 30 исходных RuleID и формулировок сохранены. API availability подтверждена; parity, live r2 и release не приняты.

Исходный contract.generated.json сохраняется в ZIP байт-в-байт как historical/contract.generated.json.txt. Runtime anatomy использует derived contract.generated.r2.json; raw каталоги и нормы не меняются. Привязки при другой версии импорта требуют повторного authoring.

Паспорт и отчёты: reports/. Перед Reviewed/Ready выполнить live-checklist.md.
